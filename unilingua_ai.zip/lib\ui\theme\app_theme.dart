import 'package:flutter/material.dart';

class AppTheme {
  const AppTheme._();

  static const Color bgDeep = Color(0xFF070B19);
  static const Color bgSurface = Color(0xFF10172A);
  static const Color bgCard = Color(0xFF161F38);
  static const Color bgCardElevated = Color(0xFF1E294B);

  static const Color cyanPrimary = Color(0xFF00E5FF);
  static const Color violetAccent = Color(0xFF7C3AED);
  static const Color goldAccent = Color(0xFFFFB800);
  static const Color emeraldSuccess = Color(0xFF10B981);
  static const Color coralDanger = Color(0xFFF43F5E);

  static const Color textPrimary = Color(0xFFF8FAFC);
  static const Color textSecondary = Color(0xFF94A3B8);
  static const Color borderSubtle = Color(0xFF263354);

  static ThemeData get darkTheme {
    final base = ThemeData.dark(useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: bgDeep,
      primaryColor: cyanPrimary,
      colorScheme: const ColorScheme.dark(
        primary: cyanPrimary,
        secondary: violetAccent,
        tertiary: goldAccent,
        surface: bgSurface,
        error: coralDanger,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: bgDeep,
        foregroundColor: textPrimary,
        elevation: 0,
        centerTitle: false,
      ),
      cardTheme: CardThemeData(
        color: bgCard,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: borderSubtle, width: 1),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: bgSurface,
        hintStyle: const TextStyle(color: textSecondary, fontSize: 14),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: borderSubtle),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: borderSubtle),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: cyanPrimary, width: 1.6),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: cyanPrimary,
          foregroundColor: const Color(0xFF04101E),
          textStyle: const TextStyle(
            fontWeight: FontWeight.w700,
            fontSize: 15,
          ),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
      ),
    );
  }
}
