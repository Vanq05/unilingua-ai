import 'package:flutter/foundation.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../../domain/models/learning_models.dart';

/// Handles Google Authentication with native Google Play Services on Android
/// and seamless university Google account profile persistence on Android & iOS.
class GoogleAuthService {
  GoogleAuthService();

  final GoogleSignIn _googleSignIn = GoogleSignIn(
    scopes: <String>['email', 'profile'],
  );

  /// Attempts native Google Sign-In on Android first.
  /// On iOS without a bundled GoogleService-Info.plist (unsigned IPA sideload),
  /// returns null cleanly to avoid native GIDClientID crash and opens the
  /// built-in Google Account Sign-In modal instead.
  Future<GoogleUserProfile?> tryNativeGoogleSignIn() async {
    if (kIsWeb || defaultTargetPlatform == TargetPlatform.iOS) {
      return null;
    }
    try {
      final account = await _googleSignIn
          .signIn()
          .timeout(const Duration(seconds: 12));
      if (account == null) return null;
      return GoogleUserProfile(
        id: 'google_${account.id}',
        email: account.email,
        displayName: (account.displayName?.trim().isNotEmpty ?? false)
            ? account.displayName!.trim()
            : account.email.split('@').first,
        photoUrl: account.photoUrl ?? '',
      );
    } catch (_) {
      return null;
    }
  }

  Future<void> signOut() async {
    if (kIsWeb || defaultTargetPlatform == TargetPlatform.iOS) return;
    try {
      await _googleSignIn.signOut();
    } catch (_) {}
  }
}
