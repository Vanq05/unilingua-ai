import 'package:flutter/material.dart';

import '../../data/repositories/curriculum_repository.dart';
import '../../domain/models/learning_models.dart';
import '../theme/app_theme.dart';
import '../view_models/learning_view_model.dart';

class GoogleAuthScreen extends StatefulWidget {
  const GoogleAuthScreen({
    super.key,
    required this.viewModel,
  });

  final LearningViewModel viewModel;

  @override
  State<GoogleAuthScreen> createState() => _GoogleAuthScreenState();
}

class _GoogleAuthScreenState extends State<GoogleAuthScreen> {
  Future<void> _handleGoogleSignInPressed() async {
    final nativeProfile = await widget.viewModel.tryNativeGoogleSignIn();
    if (!mounted) return;
    if (nativeProfile != null) {
      await _showUniversityProfileSetupSheet(prefilled: nativeProfile);
    } else {
      await _showUniversityProfileSetupSheet();
    }
  }

  Future<void> _showUniversityProfileSetupSheet({
    GoogleUserProfile? prefilled,
  }) async {
    final nameCtrl = TextEditingController(
      text: prefilled?.displayName ?? 'Nguyễn Minh Anh',
    );
    final emailCtrl = TextEditingController(
      text: prefilled?.email ?? 'minhanh.sv@gmail.com',
    );
    final uniCtrl = TextEditingController(
      text: prefilled?.universityName ?? 'Đại học Bách Khoa / Quốc Gia',
    );
    var selectedMajor =
        prefilled?.majorField ?? CurriculumRepository.universityMajors.first;
    var selectedGoal =
        prefilled?.targetGoal ?? CurriculumRepository.universityGoals.first;

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppTheme.bgCard,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setSheetState) {
            return Padding(
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 18,
                bottom: MediaQuery.of(ctx).viewInsets.bottom + 24,
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Center(
                      child: Container(
                        width: 44,
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.white24,
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: <Widget>[
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          alignment: Alignment.center,
                          child: const Text(
                            'G',
                            style: TextStyle(
                              color: Color(0xFF4285F4),
                              fontSize: 26,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                'Đăng nhập Tài khoản Google',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w800,
                                  color: AppTheme.textPrimary,
                                ),
                              ),
                              SizedBox(height: 2),
                              Text(
                                'Đồng bộ tiến trình học tập, Streak & Lộ trình Đại học',
                                style: TextStyle(
                                  fontSize: 12.5,
                                  color: AppTheme.textSecondary,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 18),
                    const Text(
                      'Email Google (@gmail.com hoặc @edu.vn)',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 6),
                    TextField(
                      controller: emailCtrl,
                      keyboardType: TextInputType.emailAddress,
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.alternate_email_rounded),
                        hintText: 'sinhvien@gmail.com',
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'Họ và tên sinh viên',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 6),
                    TextField(
                      controller: nameCtrl,
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.person_outline_rounded),
                        hintText: 'Nhập họ tên của bạn',
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'Trường Đại học / Học viện',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 6),
                    TextField(
                      controller: uniCtrl,
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.school_outlined),
                        hintText: 'VD: ĐH Bách Khoa, ĐH Kinh Tế, ĐH Quốc Gia...',
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'Khối ngành Đại học (để AI tối ưu tài liệu đọc & nghe)',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 6),
                    DropdownButtonFormField<String>(
                      value: selectedMajor,
                      dropdownColor: AppTheme.bgCardElevated,
                      isExpanded: true,
                      items: CurriculumRepository.universityMajors
                          .map(
                            (m) => DropdownMenuItem<String>(
                              value: m,
                              child: Text(
                                m,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontSize: 14),
                              ),
                            ),
                          )
                          .toList(),
                      onChanged: (val) {
                        if (val != null) {
                          setSheetState(() => selectedMajor = val);
                        }
                      },
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'Mục tiêu Tiếng Anh ưu tiên',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 6),
                    DropdownButtonFormField<String>(
                      value: selectedGoal,
                      dropdownColor: AppTheme.bgCardElevated,
                      isExpanded: true,
                      items: CurriculumRepository.universityGoals
                          .map(
                            (g) => DropdownMenuItem<String>(
                              value: g,
                              child: Text(
                                g,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontSize: 14),
                              ),
                            ),
                          )
                          .toList(),
                      onChanged: (val) {
                        if (val != null) {
                          setSheetState(() => selectedGoal = val);
                        }
                      },
                    ),
                    const SizedBox(height: 20),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: () async {
                          final rawEmail = emailCtrl.text.trim();
                          final email = rawEmail.contains('@')
                              ? rawEmail
                              : '${rawEmail.isEmpty ? "sinhvien" : rawEmail}@gmail.com';
                          final name = nameCtrl.text.trim().isNotEmpty
                              ? nameCtrl.text.trim()
                              : 'Sinh viên Đại học';
                          final uni = uniCtrl.text.trim().isNotEmpty
                              ? uniCtrl.text.trim()
                              : 'Đại học Quốc gia';

                          final profile = GoogleUserProfile(
                            id: 'google_${email.toLowerCase()}',
                            email: email,
                            displayName: name,
                            universityName: uni,
                            majorField: selectedMajor,
                            targetGoal: selectedGoal,
                          );
                          Navigator.of(ctx).pop();
                          await widget.viewModel
                              .signInWithGoogleProfile(profile);
                        },
                        icon: const Icon(Icons.verified_user_rounded),
                        label: const Text(
                          'Tiếp tục với Google & Lưu tiến trình',
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _showRestoreSyncDialog() async {
    final codeCtrl = TextEditingController();
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.bgCard,
        title: const Text('Khôi phục Mã Đồng Bộ Google'),
        content: TextField(
          controller: codeCtrl,
          maxLines: 3,
          decoration: const InputDecoration(
            hintText: 'Dán mã đồng bộ tiến trình học tập của bạn vào đây...',
          ),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Hủy'),
          ),
          ElevatedButton(
            onPressed: () async {
              final ok = await widget.viewModel
                  .importCloudSyncCode(codeCtrl.text.trim());
              if (!mounted) return;
              Navigator.of(ctx).pop();
              if (!ok) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Mã đồng bộ không hợp lệ. Vui lòng kiểm tra lại.'),
                  ),
                );
              }
            },
            child: const Text('Khôi phục'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final known = widget.viewModel.knownAccounts;
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, -0.55),
            radius: 1.25,
            colors: <Color>[
              Color(0xFF1E1B4B),
              AppTheme.bgDeep,
            ],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  // App Icon Emblem
                  Container(
                    width: 112,
                    height: 112,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(28),
                      boxShadow: <BoxShadow>[
                        BoxShadow(
                          color: AppTheme.cyanPrimary.withValues(alpha: 0.32),
                          blurRadius: 32,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(28),
                      child: Image.asset(
                        'assets/icon/app_icon.png',
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          color: AppTheme.bgCardElevated,
                          child: const Icon(
                            Icons.school_rounded,
                            size: 56,
                            color: AppTheme.cyanPrimary,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                    decoration: BoxDecoration(
                      color: AppTheme.cyanPrimary.withValues(alpha: 0.14),
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(
                        color: AppTheme.cyanPrimary.withValues(alpha: 0.4),
                      ),
                    ),
                    child: const Text(
                      '✨ AI ENGLISH FOR UNIVERSITY STUDENTS',
                      style: TextStyle(
                        color: AppTheme.cyanPrimary,
                        fontSize: 11.5,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.8,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'UniLingua AI',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.w900,
                      color: AppTheme.textPrimary,
                      letterSpacing: -0.5,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Chinh phục 4 kỹ năng Nghe • Nói • Đọc • Viết, Bài Test Đầu Vào CEFR/IELTS & Lộ trình Đại học cá nhân hóa 12 tuần.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 14.5,
                      height: 1.45,
                      color: AppTheme.textSecondary,
                    ),
                  ),
                  const SizedBox(height: 24),

                  // 4-Skill Feature Highlights Card
                  Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: AppTheme.bgCard.withValues(alpha: 0.9),
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: AppTheme.borderSubtle),
                    ),
                    child: const Column(
                      children: <Widget>[
                        _FeatureRow(
                          icon: Icons.analytics_outlined,
                          color: AppTheme.goldAccent,
                          title: 'Bài Test Đầu Vào Đại Học 4 Kỹ Năng',
                          subtitle:
                              'Đánh giá chuẩn CEFR (A2-C1), IELTS & TOEIC để AI lập lộ trình 12 tuần riêng cho bạn.',
                        ),
                        SizedBox(height: 14),
                        _FeatureRow(
                          icon: Icons.local_fire_department_rounded,
                          color: Color(0xFFFF6B35),
                          title: 'Bài Tập Hàng Ngày & Chuỗi Streak',
                          subtitle:
                              '5 nhiệm vụ Nghe, Nói, Đọc, Viết & Từ vựng tự động làm mới mỗi ngày.',
                        ),
                        SizedBox(height: 14),
                        _FeatureRow(
                          icon: Icons.record_voice_over_rounded,
                          color: AppTheme.cyanPrimary,
                          title: 'Phòng Hội Thoại AI 1-1 & Chấm Luận IELTS',
                          subtitle:
                              'Luyện phỏng vấn thực tập, bảo vệ đồ án và chấm điểm Writing chi tiết.',
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Primary Google Sign-In Button
                  SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: ElevatedButton(
                      onPressed: widget.viewModel.isBusy
                          ? null
                          : _handleGoogleSignInPressed,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: const Color(0xFF1F2937),
                        elevation: 4,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Container(
                            width: 26,
                            height: 26,
                            decoration: BoxDecoration(
                              color: const Color(0xFF4285F4),
                              borderRadius: BorderRadius.circular(7),
                            ),
                            alignment: Alignment.center,
                            child: const Text(
                              'G',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w900,
                                fontSize: 16,
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          const Flexible(
                            child: Text(
                              'Đăng nhập bằng Google để lưu tiến trình',
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  if (known.isNotEmpty) ...<Widget>[
                    const SizedBox(height: 20),
                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Tài khoản Google đã lưu trên thiết bị:',
                        style: TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.textSecondary,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    ...known.map(
                      (acc) => Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(14),
                          onTap: () =>
                              widget.viewModel.signInWithGoogleProfile(acc),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 10,
                            ),
                            decoration: BoxDecoration(
                              color: AppTheme.bgCard,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: AppTheme.borderSubtle),
                            ),
                            child: Row(
                              children: <Widget>[
                                CircleAvatar(
                                  radius: 18,
                                  backgroundColor: AppTheme.violetAccent,
                                  child: Text(
                                    acc.initials,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w800,
                                      fontSize: 13,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Text(
                                        acc.displayName,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w700,
                                          fontSize: 14,
                                        ),
                                      ),
                                      Text(
                                        '${acc.email} • ${acc.majorField}',
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          fontSize: 12,
                                          color: AppTheme.textSecondary,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const Icon(
                                  Icons.arrow_forward_ios_rounded,
                                  size: 15,
                                  color: AppTheme.cyanPrimary,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],

                  const SizedBox(height: 12),
                  TextButton.icon(
                    onPressed: _showRestoreSyncDialog,
                    icon: const Icon(
                      Icons.cloud_download_outlined,
                      size: 18,
                      color: AppTheme.cyanPrimary,
                    ),
                    label: const Text(
                      'Khôi phục tiến trình bằng Mã Đồng Bộ Đám Mây',
                      style: TextStyle(
                        color: AppTheme.cyanPrimary,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _FeatureRow extends StatelessWidget {
  const _FeatureRow({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
  });

  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.15),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: color, size: 22),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                title,
                style: const TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 14,
                  color: AppTheme.textPrimary,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: const TextStyle(
                  fontSize: 12.5,
                  height: 1.35,
                  color: AppTheme.textSecondary,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
