import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../data/services/google_auth_service.dart';
import '../../domain/models/learning_models.dart';
import '../theme/app_theme.dart';
import '../view_models/learning_view_model.dart';

class GoogleAuthScreen extends StatefulWidget {
  const GoogleAuthScreen({
    super.key,
    required this.viewModel,
  });

  final LearningViewModel viewModel;

  @override
  State<GoogleAuthScreen> createState() => _GoogleAuthScreenState();
}

class _GoogleAuthScreenState extends State<GoogleAuthScreen> {
  Future<void> _handleRealGoogleSignIn() async {
    final result = await widget.viewModel.signInWithRealGoogle();
    if (!mounted) return;
    if (result.isSuccess) return;

    if (result.isSha1ConfigError) {
      await _showGoogleOAuthSetupOrQuickFallbackSheet(result.errorReason);
    } else if (result.errorReason.isNotEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result.errorReason)),
      );
    }
  }

  Future<void> _showGoogleOAuthSetupOrQuickFallbackSheet(String reason) async {
    final p = AppPalette.of(context);
    final emailCtrl = TextEditingController();
    final nameCtrl = TextEditingController();

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: p.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.only(
            left: 20,
            right: 20,
            top: 16,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 24,
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: p.border,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Text(
                  'Đăng nhập Tài khoản Google',
                  style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w900,
                    color: p.textPrimary,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Dữ liệu học tập của bạn sẽ tự động lưu và đồng bộ trên Cloud Database (đổi máy đăng nhập lại Gmail cũ là còn nguyên tiến trình).',
                  style: TextStyle(
                    fontSize: 12.5,
                    height: 1.4,
                    color: p.textSecondary,
                  ),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: emailCtrl,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.mail_outline_rounded),
                    hintText: 'Nhập Gmail của bạn (vd: ten@gmail.com)',
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: nameCtrl,
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.person_outline_rounded),
                    hintText: 'Tên hiển thị của bạn',
                  ),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton(
                    onPressed: () async {
                      final rawEmail = emailCtrl.text.trim();
                      final email = rawEmail.contains('@')
                          ? rawEmail
                          : '${rawEmail.isEmpty ? "hocvien" : rawEmail}@gmail.com';
                      final name = nameCtrl.text.trim().isNotEmpty
                          ? nameCtrl.text.trim()
                          : email.split('@').first;
                      Navigator.of(ctx).pop();
                      await widget.viewModel.signInWithGoogleProfile(
                        GoogleUserProfile(
                          id: 'google_${email.toLowerCase()}',
                          email: email,
                          displayName: name,
                        ),
                      );
                    },
                    child: const Text('Đăng nhập & Đồng bộ Cloud'),
                  ),
                ),
                const SizedBox(height: 12),
                ExpansionTile(
                  tilePadding: EdgeInsets.zero,
                  title: Text(
                    'Thông tin SHA-1 cho đăng nhập Google OAuth 1 chạm',
                    style: TextStyle(fontSize: 11.5, color: p.textSecondary),
                  ),
                  children: <Widget>[
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: p.cardElevated,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: p.border),
                      ),
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Text(
                              'Package: ${GoogleAuthService.androidPackageName}\nSHA-1: ${GoogleAuthService.releaseKeystoreSha1}',
                              style: TextStyle(
                                fontSize: 10.5,
                                fontFamily: 'monospace',
                                color: p.textPrimary,
                              ),
                            ),
                          ),
                          IconButton(
                            tooltip: 'Sao chép SHA-1',
                            onPressed: () {
                              Clipboard.setData(
                                const ClipboardData(
                                  text: GoogleAuthService.releaseKeystoreSha1,
                                ),
                              );
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Đã sao chép mã SHA-1!'),
                                ),
                              );
                            },
                            icon: Icon(
                              Icons.copy_rounded,
                              size: 16,
                              color: p.primary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _showRestoreSyncDialog() async {
    final p = AppPalette.of(context);
    final codeCtrl = TextEditingController();
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: p.card,
        title: const Text('Khôi phục tiến trình'),
        content: TextField(
          controller: codeCtrl,
          maxLines: 3,
          decoration: const InputDecoration(
            hintText: 'Dán mã sao lưu của bạn vào đây...',
          ),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Hủy'),
          ),
          ElevatedButton(
            onPressed: () async {
              final ok = await widget.viewModel
                  .importCloudSyncCode(codeCtrl.text.trim());
              if (!mounted) return;
              Navigator.of(ctx).pop();
              if (!ok) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Mã sao lưu không hợp lệ.')),
                );
              }
            },
            child: const Text('Khôi phục'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    final known = widget.viewModel.knownAccounts;

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: p.isDark
                ? const <Color>[Color(0xFF1E1B4B), Color(0xFF070B19)]
                : const <Color>[Color(0xFFD8F3FF), Color(0xFFEFF8FF), Color(0xFFFFFFFF)],
          ),
        ),
        child: SafeArea(
          child: Stack(
            children: <Widget>[
              // Quick Light/Dark Toggle on top-right
              Positioned(
                top: 8,
                right: 12,
                child: IconButton(
                  tooltip: p.isDark ? 'Chuyển sang giao diện Sáng' : 'Chuyển sang giao diện Tối',
                  onPressed: () => widget.viewModel.setDarkMode(!p.isDark),
                  icon: Icon(
                    p.isDark ? Icons.wb_sunny_rounded : Icons.dark_mode_rounded,
                    color: p.primary,
                  ),
                ),
              ),
              Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 24,
                    vertical: 20,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Container(
                        width: 108,
                        height: 108,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(28),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: p.primary.withValues(alpha: 0.28),
                              blurRadius: 28,
                              offset: const Offset(0, 10),
                            ),
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(28),
                          child: Image.asset(
                            'assets/icon/app_icon.png',
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(
                              color: p.cardElevated,
                              child: Icon(
                                Icons.school_rounded,
                                size: 52,
                                color: p.primary,
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 18),
                      Text(
                        'UniLingua AI',
                        style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.w900,
                          color: p.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Học tiếng Anh Nghe • Nói • Đọc • Viết\ntừ cơ bản đến giao tiếp tự tin',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 14.5,
                          height: 1.45,
                          color: p.textSecondary,
                        ),
                      ),
                      const SizedBox(height: 22),

                      // Clean Feature Card
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: p.card,
                          borderRadius: BorderRadius.circular(22),
                          border: Border.all(color: p.border),
                          boxShadow: p.isDark
                              ? null
                              : <BoxShadow>[
                                  BoxShadow(
                                    color: p.primary.withValues(alpha: 0.08),
                                    blurRadius: 18,
                                    offset: const Offset(0, 6),
                                  ),
                                ],
                        ),
                        child: Column(
                          children: <Widget>[
                            _FeatureLine(
                              icon: Icons.cloud_done_rounded,
                              color: p.primary,
                              text: 'Đăng nhập Google & lưu toàn bộ dữ liệu trên Google Drive',
                            ),
                            const SizedBox(height: 12),
                            _FeatureLine(
                              icon: Icons.mic_rounded,
                              color: p.gold,
                              text: 'Gọi thoại AI & chấm phát âm bằng Mic thật (>70% qua)',
                            ),
                            const SizedBox(height: 12),
                            _FeatureLine(
                              icon: Icons.shuffle_rounded,
                              color: p.success,
                              text: 'Bài Test đầu vào mỗi lần 1 đề riêng & Lộ trình theo tuần',
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),

                      // Real Google OAuth Sign-In Button
                      SizedBox(
                        width: double.infinity,
                        height: 54,
                        child: ElevatedButton(
                          onPressed: widget.viewModel.isBusy
                              ? null
                              : _handleRealGoogleSignIn,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                            foregroundColor: const Color(0xFF1F2937),
                            elevation: 3,
                            side: BorderSide(color: p.border),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Container(
                                width: 28,
                                height: 28,
                                decoration: BoxDecoration(
                                  color: const Color(0xFF4285F4),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                alignment: Alignment.center,
                                child: const Text(
                                  'G',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w900,
                                    fontSize: 16,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 12),
                              const Text(
                                'Đăng nhập bằng Google',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      if (known.isNotEmpty) ...<Widget>[
                        const SizedBox(height: 18),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            'Tiếp tục tài khoản gần đây:',
                            style: TextStyle(
                              fontSize: 12.5,
                              color: p.textSecondary,
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        ...known.map(
                          (acc) => Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: InkWell(
                              borderRadius: BorderRadius.circular(14),
                              onTap: () =>
                                  widget.viewModel.signInWithGoogleProfile(acc),
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 14,
                                  vertical: 10,
                                ),
                                decoration: BoxDecoration(
                                  color: p.card,
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(color: p.border),
                                ),
                                child: Row(
                                  children: <Widget>[
                                    CircleAvatar(
                                      radius: 17,
                                      backgroundColor: p.primary,
                                      child: Text(
                                        acc.initials,
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.w800,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: <Widget>[
                                          Text(
                                            acc.displayName,
                                            style: TextStyle(
                                              fontWeight: FontWeight.w700,
                                              fontSize: 14,
                                              color: p.textPrimary,
                                            ),
                                          ),
                                          Text(
                                            acc.email,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                              fontSize: 12,
                                              color: p.textSecondary,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Icon(
                                      Icons.arrow_forward_ios_rounded,
                                      size: 14,
                                      color: p.primary,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],

                      const SizedBox(height: 10),
                      TextButton(
                        onPressed: _showRestoreSyncDialog,
                        child: Text(
                          'Khôi phục bằng mã sao lưu',
                          style: TextStyle(color: p.primary, fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FeatureLine extends StatelessWidget {
  const _FeatureLine({
    required this.icon,
    required this.color,
    required this.text,
  });

  final IconData icon;
  final Color color;
  final String text;

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    return Row(
      children: <Widget>[
        Icon(icon, color: color, size: 21),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            text,
            style: TextStyle(
              fontSize: 13.5,
              fontWeight: FontWeight.w600,
              color: p.textPrimary,
            ),
          ),
        ),
      ],
    );
  }
}
