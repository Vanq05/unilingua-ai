import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:unilingua_ai/data/repositories/curriculum_repository.dart';
import 'package:unilingua_ai/data/services/ai_tutor_service.dart';
import 'package:unilingua_ai/data/services/app_update_service.dart';
import 'package:unilingua_ai/data/services/central_drive_server_service.dart';
import 'package:unilingua_ai/data/services/google_auth_service.dart';
import 'package:unilingua_ai/data/services/progress_storage_service.dart';
import 'package:unilingua_ai/data/services/secret_vault.dart';
import 'package:unilingua_ai/data/services/speech_tts_service.dart';
import 'package:unilingua_ai/data/services/voice_recorder_service.dart';
import 'package:unilingua_ai/domain/models/learning_models.dart';
import 'package:unilingua_ai/main.dart';
import 'package:unilingua_ai/ui/screens/forgot_password_screen.dart';
import 'package:unilingua_ai/ui/screens/interactive_lesson_screen.dart';
import 'package:unilingua_ai/ui/screens/phonetics_grid_screen.dart';
import 'package:unilingua_ai/ui/view_models/learning_view_model.dart';

class _FakeProgressStorage extends ProgressStorageService {
  String? _activeEmail;
  bool _isDark = false;
  bool _notifEnabled = true;
  final Map<String, StudentProgressState> _store =
      <String, StudentProgressState>{};
  final List<GoogleUserProfile> _accounts = <GoogleUserProfile>[];
  final Map<String, List<DirectChatMessage>> _chatCache =
      <String, List<DirectChatMessage>>{};

  @override
  Future<bool> loadIsDarkMode() async => _isDark;

  @override
  Future<void> saveIsDarkMode(bool isDark) async {
    _isDark = isDark;
  }

  @override
  Future<bool> loadNotificationsEnabled() async => _notifEnabled;

  @override
  Future<void> saveNotificationsEnabled(bool enabled) async {
    _notifEnabled = enabled;
  }

  static String _pairKey(String a, String b) {
    final pair = <String>[a.trim().toLowerCase(), b.trim().toLowerCase()]..sort();
    return '${pair[0]}__${pair[1]}';
  }

  @override
  Future<List<DirectChatMessage>> loadCachedChatMessages(
    String userA,
    String userB,
  ) async =>
      List<DirectChatMessage>.from(
        _chatCache[_pairKey(userA, userB)] ?? const <DirectChatMessage>[],
      );

  @override
  Future<void> saveCachedChatMessages(
    String userA,
    String userB,
    List<DirectChatMessage> messages,
  ) async {
    _chatCache[_pairKey(userA, userB)] = List<DirectChatMessage>.from(messages);
  }

  @override
  Future<String?> loadActiveEmail() async => _activeEmail;

  @override
  Future<void> saveActiveEmail(String? email) async {
    _activeEmail = email;
  }

  @override
  Future<List<GoogleUserProfile>> loadKnownGoogleAccounts() async => _accounts;

  @override
  Future<void> upsertKnownGoogleAccount(GoogleUserProfile profile) async {
    _accounts.removeWhere(
      (a) => a.email.toLowerCase() == profile.email.toLowerCase(),
    );
    _accounts.insert(0, profile);
  }

  @override
  Future<StudentProgressState?> loadProgressForEmail(String email) async =>
      _store[email.toLowerCase()];

  @override
  Future<void> saveProgress(StudentProgressState state) async {
    final key = state.user.email.toLowerCase();
    _store[key] = state;
    _activeEmail = key;
    await upsertKnownGoogleAccount(state.user);
  }
}

class _FakeAiTutorService extends AiTutorService {
  @override
  Future<void> ensureModelInitialized() async {}

  @override
  Future<String> completeText({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.65,
  }) async {
    return jsonEncode(<String, dynamic>{
      'speakingScore': 72,
      'writingScore': 70,
      'aiDiagnosticSummary': 'Bạn có nền tảng cơ bản tốt.',
      'speakingFeedbackVi': 'Câu nói rõ ràng.',
      'writingFeedbackVi': 'Viết đúng ý.',
      'keyStrengths': <String>['Đọc hiểu nhanh'],
      'criticalGaps': <String>['Phản xạ giao tiếp'],
      'roadmapPhases': CurriculumRepository.buildAdaptiveRoadmap(
        cefr: 'B1',
        dailyMinutes: 30,
        targetWeeks: 8,
        lScore: 75,
        sScore: 72,
        rScore: 80,
        wScore: 70,
      ).map((p) => p.toJson()).toList(),
    });
  }
}

class _FakeUpdateService extends AppUpdateService {
  const _FakeUpdateService();

  @override
  Future<AppUpdateInfo?> checkForUpdate() async => null;
}

class _FakeCentralServer extends CentralDriveServerService {
  _FakeCentralServer();

  final Map<
          String,
          ({
            String email,
            String password,
            String fullName,
            String username,
          })> accounts =
      <String,
          ({
            String email,
            String password,
            String fullName,
            String username,
          })>{};
  final Map<String, String> otpStore = <String, String>{};
  final List<({String a, String b, String status})> friendships =
      <({String a, String b, String status})>[];
  final List<DirectChatMessage> directMessages = <DirectChatMessage>[];
  int _mockClock = 1700000000000;

  @override
  bool get isConfigured => true;

  @override
  bool get isSupabaseConfigured => false;

  @override
  Stream<DirectChatMessage> subscribeDirectMessages({
    required String currentUser,
    required String friendUser,
  }) =>
      const Stream<DirectChatMessage>.empty();

  @override
  Future<StudentProgressState?> loadUserState(String email) async => null;

  @override
  Future<bool> saveUserState(StudentProgressState state) async => true;

  @override
  Future<GasAuthApiResponse> registerAccount({
    required String email,
    required String password,
    required String fullName,
    String username = '',
  }) async {
    final key = email.trim().toLowerCase();
    final handle = (username.trim().isNotEmpty
            ? username.trim().toLowerCase()
            : key.split('@').first)
        .replaceAll(RegExp(r'[^a-z0-9._]'), '');
    if (accounts.containsKey(key)) {
      return const GasAuthApiResponse(
        ok: false,
        message: 'Email này đã được đăng ký.',
      );
    }
    if (accounts.values.any((a) => a.username == handle)) {
      return GasAuthApiResponse(
        ok: false,
        message: 'Username @$handle đã có người sử dụng.',
      );
    }
    accounts[key] = (
      email: key,
      password: password,
      fullName: fullName,
      username: handle,
    );
    return GasAuthApiResponse(
      ok: true,
      message: 'Đăng ký thành công!',
      email: key,
      username: handle,
      fullName: fullName,
      createdAt: '2026-11-24T00:00:00.000Z',
    );
  }

  @override
  Future<GasAuthApiResponse> loginAccount({
    required String email,
    required String password,
  }) async {
    final id = email.trim().toLowerCase().replaceFirst(RegExp(r'^@+'), '');
    final match = accounts.values.where(
      (a) => a.email == id || a.username == id,
    );
    if (match.isEmpty || match.first.password != password) {
      return const GasAuthApiResponse(
        ok: false,
        message: 'Tài khoản hoặc mật khẩu không chính xác.',
      );
    }
    final acc = match.first;
    return GasAuthApiResponse(
      ok: true,
      message: 'Đăng nhập thành công!',
      email: acc.email,
      username: acc.username,
      fullName: acc.fullName,
      createdAt: '2026-11-24T00:00:00.000Z',
    );
  }

  @override
  Future<GasAuthApiResponse> changePassword({
    required String email,
    required String oldPassword,
    required String newPassword,
  }) async {
    final key = email.trim().toLowerCase();
    final acc = accounts[key];
    if (acc == null || acc.password != oldPassword) {
      return const GasAuthApiResponse(
        ok: false,
        message: 'Mật khẩu hiện tại không đúng.',
      );
    }
    accounts[key] = (
      email: acc.email,
      password: newPassword,
      fullName: acc.fullName,
      username: acc.username,
    );
    return const GasAuthApiResponse(ok: true, message: 'Đổi mật khẩu thành công.');
  }

  @override
  Future<GasAuthApiResponse> forgotPassword({required String email}) async {
    final key = email.trim().toLowerCase();
    if (!accounts.containsKey(key)) {
      return const GasAuthApiResponse(
        ok: false,
        message: 'Email này chưa được đăng ký trong hệ thống.',
      );
    }
    otpStore[key] = '654321';
    return GasAuthApiResponse(
      ok: true,
      message: 'Mã OTP 6 số đã được gửi tới hộp thư Gmail $key.',
    );
  }

  @override
  Future<GasAuthApiResponse> resetPassword({
    required String email,
    required String otp,
    required String newPassword,
  }) async {
    final key = email.trim().toLowerCase();
    if (otpStore[key] != otp) {
      return const GasAuthApiResponse(
        ok: false,
        message: 'Mã OTP không chính xác.',
      );
    }
    final acc = accounts[key];
    if (acc != null) {
      accounts[key] = (
        email: acc.email,
        password: newPassword,
        fullName: acc.fullName,
        username: acc.username,
      );
    }
    otpStore.remove(key);
    return const GasAuthApiResponse(
      ok: true,
      message: 'Đặt lại mật khẩu thành công!',
    );
  }

  @override
  Future<GasAuthApiResponse> updateProfile({
    required String email,
    required String fullName,
    required String username,
  }) async {
    final key = email.trim().toLowerCase();
    final acc = accounts[key];
    if (acc == null) {
      return const GasAuthApiResponse(ok: false, message: 'Không tìm thấy user.');
    }
    final cleanHandle = username.trim().toLowerCase();
    if (accounts.values.any((a) => a.email != key && a.username == cleanHandle)) {
      return GasAuthApiResponse(
        ok: false,
        message: 'Username @$cleanHandle đã thuộc về người khác.',
      );
    }
    final oldHandle = acc.username;
    accounts[key] = (
      email: acc.email,
      password: acc.password,
      fullName: fullName.trim(),
      username: cleanHandle,
    );
    if (oldHandle != cleanHandle) {
      for (var i = 0; i < friendships.length; i++) {
        final f = friendships[i];
        friendships[i] = (
          a: f.a == oldHandle ? cleanHandle : f.a,
          b: f.b == oldHandle ? cleanHandle : f.b,
          status: f.status,
        );
      }
    }
    return GasAuthApiResponse(
      ok: true,
      message: 'Cập nhật hồ sơ thành công!',
      email: acc.email,
      username: cleanHandle,
      fullName: fullName.trim(),
    );
  }

  String _friendshipStatus(String me, String peer) {
    for (final f in friendships) {
      if ((f.a == me && f.b == peer) || (f.b == me && f.a == peer)) {
        if (f.status == 'accepted') return 'accepted';
        return f.a == me ? 'pending_sent' : 'pending_received';
      }
    }
    return 'none';
  }

  @override
  Future<({bool ok, List<SocialUserItem> users, String message})> searchUsers({
    required String query,
    required String currentUser,
  }) async {
    final q = query.trim().toLowerCase().replaceFirst(RegExp(r'^@+'), '');
    final me = currentUser.trim().toLowerCase();
    final out = <SocialUserItem>[];
    for (final a in accounts.values) {
      if (a.username == me) continue;
      if (a.username.contains(q) || a.fullName.toLowerCase().contains(q)) {
        out.add(
          SocialUserItem(
            username: a.username,
            fullName: a.fullName,
            email: a.email,
            friendshipStatus: _friendshipStatus(me, a.username),
          ),
        );
      }
    }
    return (ok: true, users: out, message: '');
  }

  @override
  Future<({bool ok, String message})> sendFriendRequest({
    required String fromUser,
    required String toUser,
  }) async {
    final f = fromUser.trim().toLowerCase();
    final t = toUser.trim().toLowerCase();
    friendships.add((a: f, b: t, status: 'pending'));
    return (ok: true, message: 'Đã gửi lời mời kết bạn tới @$t!');
  }

  @override
  Future<({bool ok, String message})> acceptFriendRequest({
    required String fromUser,
    required String toUser,
  }) async {
    final f = fromUser.trim().toLowerCase();
    final t = toUser.trim().toLowerCase();
    for (var i = 0; i < friendships.length; i++) {
      final row = friendships[i];
      if ((row.a == f && row.b == t) || (row.a == t && row.b == f)) {
        friendships[i] = (a: row.a, b: row.b, status: 'accepted');
      }
    }
    return (ok: true, message: 'Đã chấp nhận kết bạn với @$f!');
  }

  @override
  Future<
      ({
        bool ok,
        List<SocialUserItem> friends,
        List<SocialUserItem> pendingReceived,
        List<SocialUserItem> pendingSent,
      })> getFriends({required String username}) async {
    final me = username.trim().toLowerCase();
    final friends = <SocialUserItem>[];
    final pendingReceived = <SocialUserItem>[];
    final pendingSent = <SocialUserItem>[];

    for (final row in friendships) {
      if (row.a != me && row.b != me) continue;
      final peer = row.a == me ? row.b : row.a;
      final peerAcc = accounts.values.where((x) => x.username == peer);
      final name = peerAcc.isNotEmpty ? peerAcc.first.fullName : peer;
      final mail = peerAcc.isNotEmpty ? peerAcc.first.email : '';
      if (row.status == 'accepted') {
        friends.add(
          SocialUserItem(
            username: peer,
            fullName: name,
            email: mail,
            friendshipStatus: 'accepted',
          ),
        );
      } else if (row.b == me) {
        pendingReceived.add(
          SocialUserItem(
            username: peer,
            fullName: name,
            email: mail,
            friendshipStatus: 'pending_received',
          ),
        );
      } else {
        pendingSent.add(
          SocialUserItem(
            username: peer,
            fullName: name,
            email: mail,
            friendshipStatus: 'pending_sent',
          ),
        );
      }
    }
    return (
      ok: true,
      friends: friends,
      pendingReceived: pendingReceived,
      pendingSent: pendingSent,
    );
  }

  @override
  Future<({bool ok, DirectChatMessage? message, String error})> sendMessage({
    required String sender,
    required String receiver,
    required String content,
  }) async {
    _mockClock += 1000;
    final msg = DirectChatMessage(
      sender: sender.trim().toLowerCase(),
      receiver: receiver.trim().toLowerCase(),
      content: content.trim(),
      timestamp: _mockClock,
    );
    directMessages.add(msg);
    return (ok: true, message: msg, error: '');
  }

  @override
  Future<({bool ok, List<DirectChatMessage> messages})> getMessages({
    required String currentUser,
    required String friendUser,
    required int lastTimestamp,
  }) async {
    final u1 = currentUser.trim().toLowerCase();
    final u2 = friendUser.trim().toLowerCase();
    final filtered = directMessages
        .where(
          (m) =>
              m.timestamp > lastTimestamp &&
              ((m.sender == u1 && m.receiver == u2) ||
                  (m.sender == u2 && m.receiver == u1)),
        )
        .toList();
    return (ok: true, messages: filtered);
  }
}

class _FakeGoogleAuthService extends GoogleAuthService {
  @override
  Future<GoogleAuthResult?> signInSilently() async => null;

  @override
  Future<GoogleAuthResult> signInWithGoogle() async =>
      const GoogleAuthResult(errorReason: 'mock');

  @override
  Future<void> signOut() async {}
}

void main() {
  test('SecretVault decodes hidden endpoint, API key, and Drive Server URL', () {
    expect(SecretVault.baseUrl.startsWith('https://'), isTrue);
    expect(SecretVault.apiKey.startsWith('sk-'), isTrue);
    expect(
      SecretVault.driveServerUrl.startsWith('https://script.google.com/macros/s/'),
      isTrue,
    );
  });

  test('CentralDriveServerService SHA-256 salted digest matches GAS & FIPS 180-4', () {
    expect(
      CentralDriveServerService.sha256Hex('abc'),
      equals('ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'),
    );
    expect(
      CentralDriveServerService.hashPasswordSha256('123456'),
      equals('cff891c12c0b8c71732c1ba4d41e59608aa323ce8dc0a01b85f88dcb7e1d6257'),
    );
  });

  test('VoiceRecorderService normalizes Vietnamese proper names and places', () {
    expect(
      VoiceRecorderService.normalizeVietnameseProperNouns(
        'ten van',
        userDisplayName: 'Vang',
      ),
      equals('my name is Vang'),
    );
    expect(
      VoiceRecorderService.normalizeVietnameseProperNouns(
        'Hello my name is van and I am from tynguah',
        userDisplayName: 'Vang',
      ),
      equals('Hello my name is Vang and I am from Thai Nguyen'),
    );
  });

  test('Tailored Placement Exam generator creates unique non-repeating English exams', () {
    final examBeg = CurriculumRepository.generateUniquePlacementExam(
      seed: 101,
      selfAssessedLevel: GoogleUserProfile.levelBeginner,
      age: 19,
    );
    final examAdv = CurriculumRepository.generateUniquePlacementExam(
      seed: 202,
      selfAssessedLevel: GoogleUserProfile.levelAdvanced,
      age: 25,
    );

    expect(examBeg.questions.length, equals(10));
    expect(examAdv.questions.length, equals(10));
    expect(examBeg.questions.map((q) => q.id).toSet().length, equals(10));
    expect(examAdv.questions.map((q) => q.id).toSet().length, equals(10));
    expect(examBeg.questions.every((q) => q.promptVi.isNotEmpty), isTrue);
    expect(examBeg.examCode != examAdv.examCode, isTrue);
  });

  testWidgets(
      'SHA-256 Register -> Profile Setup -> Tailored Placement -> 5-Tab Shell -> Change Password -> Forgot Password OTP',
      (tester) async {
    tester.view.physicalSize = const Size(1080, 2400);
    tester.view.devicePixelRatio = 2.0;
    addTearDown(tester.view.reset);

    final fakeServer = _FakeCentralServer();
    await fakeServer.registerAccount(
      email: 'minhanh@gmail.com',
      password: 'password123',
      fullName: 'Minh Anh',
      username: 'minhanh99',
    );
    await fakeServer.registerAccount(
      email: 'linh@gmail.com',
      password: 'password123',
      fullName: 'Nguyễn Linh',
      username: 'linh2026',
    );
    final storage = _FakeProgressStorage();
    final vm = LearningViewModel(
      storage: storage,
      googleAuth: _FakeGoogleAuthService(),
      centralServer: fakeServer,
      aiTutor: _FakeAiTutorService(),
      updateService: const _FakeUpdateService(),
      enableAutoSyncTimer: false,
    );
    await vm.initialize();

    await tester.pumpWidget(UniLinguaApp(viewModel: vm));
    await tester.pumpAndSettle();

    // 1. Register Screen with FullName, @username, Email & SHA-256 Password
    expect(find.text('Đăng nhập bằng Tài khoản'), findsOneWidget);
    await tester.tap(find.text('Đăng ký mới'));
    await tester.pumpAndSettle();

    await tester.enterText(
      find.byKey(const Key('auth_fullname_field')),
      'Vũ Hồng Vang',
    );
    await tester.enterText(
      find.byKey(const Key('auth_handle_field')),
      'vang2026',
    );
    await tester.enterText(
      find.byKey(const Key('auth_username_field')),
      'vang@gmail.com',
    );
    await tester.enterText(
      find.byKey(const Key('auth_password_field')),
      '123456',
    );
    await tester.tap(find.byKey(const Key('auth_submit_button')));
    await tester.pumpAndSettle();

    expect(vm.state!.user.effectiveUsername, equals('vang2026'));

    // Seed incoming friend request from @linh2026 to @vang2026
    await fakeServer.sendFriendRequest(
      fromUser: 'linh2026',
      toUser: 'vang2026',
    );

    // Verify password was stored as SHA-256 hash, NOT plain text
    expect(
      vm.state!.user.passwordHash,
      equals('cff891c12c0b8c71732c1ba4d41e59608aa323ce8dc0a01b85f88dcb7e1d6257'),
    );

    // 2. Initial Profile Setup (Name, Age, Level)
    expect(find.text('Thiết lập Hồ sơ Ban đầu'), findsOneWidget);
    await tester.enterText(find.byKey(const Key('profile_name_field')), 'Vang');
    await tester.enterText(find.byKey(const Key('profile_age_field')), '21');
    await tester.tap(find.text(GoogleUserProfile.levelBasic));
    await tester.pumpAndSettle();

    await tester.ensureVisible(find.byKey(const Key('profile_setup_continue_btn')));
    await tester.tap(find.byKey(const Key('profile_setup_continue_btn')));
    await tester.pumpAndSettle();

    // 3. Tailored Placement Test
    expect(find.text('Kiểm tra Trình độ Đầu vào'), findsOneWidget);

    final exam = vm.createUniquePlacementExam();
    await vm.submitPlacementExam(
      PlacementSubmissionPayload(
        selectedAnswers: <String, int>{
          for (final q in exam.questions) q.id: q.correctIndex,
        },
        listeningDictationInput: exam.dictationAudio,
        speakingIntroAnswer: 'My name is Vang from Thai Nguyen.',
        speakingOpinionAnswer: 'I study on weekends.',
        writingEssayAnswer: 'I want to improve my speaking fluency.',
      ),
      examSet: exam,
    );
    await tester.pumpAndSettle();

    vm.completePlacementReview();
    await tester.pumpAndSettle();

    // 4. Cá nhân Tab (Zalo/Telegram layout, no Quản trị tài khoản)
    await tester.tap(find.text('Cá nhân'));
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('profile_drive_sync_card')), findsOneWidget);
    expect(find.text('@vang2026'), findsOneWidget);
    expect(find.textContaining('Quản trị Tài khoản'), findsNothing);
    expect(find.byKey(const Key('profile_logout_btn')), findsOneWidget);

    // Edit display name & @username
    final editAccountTile = find.byKey(const Key('profile_edit_account_tile'));
    await tester.ensureVisible(editAccountTile);
    await tester.pumpAndSettle();
    await tester.tap(editAccountTile);
    await tester.pumpAndSettle();
    await tester.enterText(
      find.byKey(const Key('edit_profile_fullname_field')),
      'Vang Pro',
    );
    await tester.enterText(
      find.byKey(const Key('edit_profile_username_field')),
      'vangpro99',
    );
    await tester.tap(find.byKey(const Key('edit_profile_save_btn')));
    await tester.pumpAndSettle();
    expect(vm.state!.user.effectiveUsername, equals('vangpro99'));
    expect(find.text('@vangpro99'), findsOneWidget);
    await tester.pump(const Duration(seconds: 5));
    await tester.pumpAndSettle();

    // Change Password
    final changePwdTile = find.byKey(const Key('profile_change_password_tile'));
    await tester.ensureVisible(changePwdTile);
    await tester.pumpAndSettle();
    await tester.tap(changePwdTile);
    await tester.pumpAndSettle();

    expect(find.text('Cập nhật mật khẩu'), findsOneWidget);
    await tester.enterText(find.byKey(const Key('old_password_field')), '123456');
    await tester.enterText(find.byKey(const Key('new_password_field')), '654321');
    await tester.enterText(find.byKey(const Key('confirm_password_field')), '654321');
    await tester.tap(find.byKey(const Key('change_password_submit_btn')));
    await tester.pumpAndSettle();

    expect(
      vm.state!.user.passwordHash,
      equals(CentralDriveServerService.hashPasswordSha256('654321')),
    );
    expect(find.textContaining('Đổi mật khẩu thành công'), findsOneWidget);
    await tester.pump(const Duration(seconds: 5));
    await tester.pumpAndSettle();

    // 4b. Tab "Trò chuyện": Search @minhanh99, accept @linh2026, send & poll chat message
    await tester.tap(find.text('Trò chuyện'));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('chat_refresh_friends_btn')));
    await tester.pumpAndSettle();

    expect(find.byKey(const Key('accept_friend_req_linh2026')), findsOneWidget);
    await tester.enterText(
      find.byKey(const Key('chat_search_user_field')),
      'minhanh99',
    );
    await tester.tap(find.byKey(const Key('chat_search_user_btn')));
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('send_friend_req_minhanh99')), findsOneWidget);
    await tester.tap(find.byKey(const Key('send_friend_req_minhanh99')));
    await tester.pumpAndSettle();
    await tester.pump(const Duration(seconds: 5));
    await tester.pumpAndSettle();

    await tester.tap(find.byKey(const Key('accept_friend_req_linh2026')));
    await tester.pumpAndSettle();
    await tester.pump(const Duration(seconds: 5));
    await tester.pumpAndSettle();

    final friendTile = find.byKey(const Key('friend_chat_tile_linh2026'));
    await tester.ensureVisible(friendTile);
    await tester.pumpAndSettle();
    expect(friendTile, findsOneWidget);
    await tester.tap(friendTile);
    await tester.pumpAndSettle();

    await tester.enterText(
      find.byKey(const Key('chat_room_message_field')),
      'Hello Linh!',
    );
    await tester.tap(find.byKey(const Key('chat_room_send_btn')));
    await tester.pumpAndSettle();
    expect(find.text('Hello Linh!'), findsOneWidget);

    // Simulate incoming message & verify Smart Polling 3s delta sync delivers it
    await fakeServer.sendMessage(
      sender: 'linh2026',
      receiver: 'vangpro99',
      content: 'Hi Vang!',
    );
    await tester.pump(const Duration(seconds: 4));
    await tester.pumpAndSettle();
    expect(find.text('Hi Vang!'), findsOneWidget);

    // Close ChatRoomScreen so Smart Polling timer disposes cleanly
    await tester.pageBack();
    await tester.pumpAndSettle();

    // 5. Bài tập -> Translate toggle -> Lesson 1 Exit to Home
    await tester.tap(find.text('Bài tập'));
    await tester.pumpAndSettle();
    final translateBtn = find.text('Dịch sang tiếng Việt').first;
    await tester.ensureVisible(translateBtn);
    await tester.pumpAndSettle();
    await tester.tap(translateBtn);
    await tester.pumpAndSettle();
    expect(find.textContaining('🇻🇳'), findsWidgets);

    final areOption = find.text('are').first;
    await tester.ensureVisible(areOption);
    await tester.pumpAndSettle();
    await tester.tap(areOption);
    await tester.pumpAndSettle();

    final submitBtn = find.byKey(const Key('daily_quiz_submit_btn'));
    await tester.ensureVisible(submitBtn);
    await tester.pumpAndSettle();
    await tester.tap(submitBtn);
    await tester.pumpAndSettle();

    expect(find.text('Tiếp tục câu khác'), findsOneWidget);
    expect(find.text('Hoàn thành & Rời đi'), findsOneWidget);

    final exitBtn = find.text('Hoàn thành & Rời đi');
    await tester.ensureVisible(exitBtn);
    await tester.pumpAndSettle();
    await tester.tap(exitBtn);
    await tester.pumpAndSettle();

    expect(find.text('Đánh Giá Năng Lực Bản Thân'), findsOneWidget);

    // 6. Test Forgot Password Gmail-only OTP via ViewModel & server store
    final otpRes = await vm.requestPasswordResetOtp(email: 'vang@gmail.com');
    expect(otpRes.ok, isTrue);
    final serverOtp = fakeServer.otpStore['vang@gmail.com'];
    expect(serverOtp, equals('654321'));

    final badReset = await vm.resetPasswordWithOtp(
      email: 'vang@gmail.com',
      otp: '000000',
      newPassword: 'newpass999',
    );
    expect(badReset.ok, isFalse);

    final resetRes = await vm.resetPasswordWithOtp(
      email: 'vang@gmail.com',
      otp: serverOtp!,
      newPassword: 'newpass999',
    );
    expect(resetRes.ok, isTrue);
    expect(fakeServer.accounts['vang@gmail.com']?.password, equals('newpass999'));
  });

  testWidgets(
      'ForgotPasswordScreen sends OTP via Gmail and never reveals OTP in UI',
      (tester) async {
    tester.view.physicalSize = const Size(1080, 2400);
    tester.view.devicePixelRatio = 2.0;
    addTearDown(tester.view.reset);

    final fakeServer = _FakeCentralServer();
    await fakeServer.registerAccount(
      email: 'student@gmail.com',
      password: 'oldpassword',
      fullName: 'Student',
    );

    final vm = LearningViewModel(
      storage: _FakeProgressStorage(),
      googleAuth: _FakeGoogleAuthService(),
      centralServer: fakeServer,
      aiTutor: _FakeAiTutorService(),
      updateService: const _FakeUpdateService(),
      enableAutoSyncTimer: false,
    );

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: Builder(
            builder: (ctx) => Center(
              child: ElevatedButton(
                key: const Key('open_forgot_btn'),
                onPressed: () {
                  Navigator.of(ctx).push(
                    MaterialPageRoute<void>(
                      builder: (_) => ForgotPasswordScreen(viewModel: vm),
                    ),
                  );
                },
                child: const Text('Open Forgot'),
              ),
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    await tester.tap(find.byKey(const Key('open_forgot_btn')));
    await tester.pumpAndSettle();

    await tester.enterText(
      find.byKey(const Key('forgot_email_field')),
      'student@gmail.com',
    );
    await tester.tap(find.byKey(const Key('forgot_send_otp_btn')));
    await tester.pumpAndSettle();

    expect(find.textContaining('Kiểm tra hộp thư Gmail'), findsOneWidget);
    // Strict security check: the server OTP must NEVER appear anywhere in UI
    expect(find.textContaining('654321'), findsNothing);

    await tester.enterText(find.byKey(const Key('forgot_otp_field')), '654321');
    await tester.enterText(
      find.byKey(const Key('forgot_new_password_field')),
      'securepass2026',
    );
    await tester.enterText(
      find.byKey(const Key('forgot_confirm_password_field')),
      'securepass2026',
    );
    await tester.tap(find.byKey(const Key('forgot_reset_submit_btn')));
    await tester.pumpAndSettle();
    await tester.pump(const Duration(seconds: 5));
    await tester.pumpAndSettle();

    expect(
      fakeServer.accounts['student@gmail.com']?.password,
      equals('securepass2026'),
    );
  });

  test('SecretVault decodes Supabase URL and anon key cleanly', () {
    expect(
      SecretVault.supabaseUrl,
      equals('https://csbqlkldnuiyztfayigb.supabase.co'),
    );
    expect(SecretVault.supabaseAnonKey.startsWith('eyJ'), isTrue);
  });

  test('VoicePersona differentiates child, female, and adult male voices', () {
    expect(VoicePersona.values.length, equals(6));
    expect(VoicePersona.junior.pitch, greaterThan(VoicePersona.bea.pitch));
    expect(VoicePersona.bea.pitch, greaterThan(VoicePersona.falstaff.pitch));
    expect(
      VoicePersona.forContext('business office meeting'),
      equals(VoicePersona.falstaff),
    );
    expect(
      VoicePersona.forContext('family kid school'),
      equals(VoicePersona.junior),
    );
  });

  testWidgets(
      'InteractiveLessonScreen & PhoneticsGridScreen render Duolingo 3D Word Bank, Pairs & IPA grid',
      (tester) async {
    tester.view.physicalSize = const Size(1080, 2400);
    tester.view.devicePixelRatio = 2.0;
    addTearDown(tester.view.reset);

    final vm = LearningViewModel(
      storage: _FakeProgressStorage(),
      googleAuth: _FakeGoogleAuthService(),
      centralServer: _FakeCentralServer(),
      aiTutor: _FakeAiTutorService(),
      updateService: const _FakeUpdateService(),
      enableAutoSyncTimer: false,
    );

    await tester.pumpWidget(
      MaterialApp(
        home: InteractiveLessonScreen(viewModel: vm, unitIndex: 0),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('Dịch câu này'), findsOneWidget);
    // Tap tokens 0..4 ('Làm ơn', 'cho', 'nước', 'và', 'trà')
    for (var i = 0; i < 5; i++) {
      await tester.tap(find.byKey(Key('word_bank_token_$i')));
      await tester.pumpAndSettle();
    }
    await tester.tap(find.byKey(const Key('interactive_check_btn')));
    await tester.pumpAndSettle();
    expect(find.text('Làm tốt lắm!'), findsOneWidget);

    await tester.tap(find.byKey(const Key('duolingo_feedback_continue_btn')));
    await tester.pumpAndSettle();
    expect(find.text('Nhấn vào các cặp tương ứng'), findsOneWidget);

    // Verify PhoneticsGridScreen with 6 character voices & IPA tiles
    await tester.pumpWidget(
      MaterialApp(
        home: PhoneticsGridScreen(tts: vm.tts),
      ),
    );
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('voice_persona_junior')), findsOneWidget);
    expect(find.byKey(const Key('voice_persona_falstaff')), findsOneWidget);
    await tester.tap(find.byKey(const Key('voice_persona_junior')));
    await tester.pumpAndSettle();
    expect(vm.tts.activePersona, equals(VoicePersona.junior));
    expect(find.byKey(const Key('ipa_tile_fish')), findsOneWidget);
  });
}
