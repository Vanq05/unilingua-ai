import 'package:flutter/material.dart';

import '../../../data/repositories/curriculum_repository.dart';
import '../../../domain/models/learning_models.dart';
import '../../theme/app_theme.dart';
import '../../view_models/learning_view_model.dart';

class SpeakingScreen extends StatefulWidget {
  const SpeakingScreen({
    super.key,
    required this.viewModel,
  });

  final LearningViewModel viewModel;

  @override
  State<SpeakingScreen> createState() => _SpeakingScreenState();
}

class _SpeakingScreenState extends State<SpeakingScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  int _selectedDrillIndex = 0;
  final TextEditingController _spokenInputCtrl = TextEditingController();
  int? _pronunciationScore;
  List<_WordMatchResult> _wordResults = const <_WordMatchResult>[];

  int _selectedScenarioIndex = 0;
  final TextEditingController _roleplayInputCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _spokenInputCtrl.dispose();
    _roleplayInputCtrl.dispose();
    super.dispose();
  }

  void _evaluatePronunciation(SpeakingDrill drill) {
    final rawInput = _spokenInputCtrl.text.trim().isNotEmpty
        ? _spokenInputCtrl.text.trim()
        : drill.sentenceEn;

    final userWords = rawInput
        .toLowerCase()
        .replaceAll(RegExp(r'[^\w\s]'), '')
        .split(RegExp(r'\s+'))
        .where((w) => w.isNotEmpty)
        .toList();

    final targetTokens = drill.sentenceEn.split(RegExp(r'\s+'));
    final results = <_WordMatchResult>[];
    var matchedCount = 0;

    for (final token in targetTokens) {
      final cleanToken =
          token.toLowerCase().replaceAll(RegExp(r'[^\w]'), '');
      final hit = userWords.contains(cleanToken);
      if (hit) matchedCount++;
      results.add(_WordMatchResult(word: token, isMatched: hit));
    }

    final score = targetTokens.isNotEmpty
        ? ((matchedCount / targetTokens.length) * 100).round().clamp(40, 100)
        : 90;

    setState(() {
      _pronunciationScore = score;
      _wordResults = results;
    });

    widget.viewModel.recordActivityCompletion(
      questId: 'q_speak',
      skill: SkillType.speaking,
      baseXp: 20,
      lessonId: drill.id,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          '🎙️ Phòng Luyện Nói & Hội Thoại AI',
          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17),
        ),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppTheme.cyanPrimary,
          labelColor: AppTheme.cyanPrimary,
          unselectedLabelColor: AppTheme.textSecondary,
          tabs: const <Widget>[
            Tab(text: 'Hội thoại AI 1-1 (Roleplay)'),
            Tab(text: 'Phát âm & Shadowing IPA'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: <Widget>[
          _buildRoleplayTab(),
          _buildPronunciationTab(),
        ],
      ),
    );
  }

  Widget _buildRoleplayTab() {
    return ListenableBuilder(
      listenable: Listenable.merge(<Listenable>[
        widget.viewModel,
        widget.viewModel.tts,
      ]),
      builder: (context, _) {
        final scenarios = CurriculumRepository.roleplayScenarios;
        final scenario = scenarios[_selectedScenarioIndex];
        final turns = widget.viewModel.turnsForScenario(scenario);

        return Column(
          children: <Widget>[
            // Scenario selector
            Container(
              height: 78,
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                scrollDirection: Axis.horizontal,
                itemCount: scenarios.length,
                separatorBuilder: (_, __) => const SizedBox(width: 10),
                itemBuilder: (context, index) {
                  final item = scenarios[index];
                  final selected = index == _selectedScenarioIndex;
                  return InkWell(
                    borderRadius: BorderRadius.circular(14),
                    onTap: () =>
                        setState(() => _selectedScenarioIndex = index),
                    child: Container(
                      width: 240,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        color: selected
                            ? AppTheme.cyanPrimary.withValues(alpha: 0.16)
                            : AppTheme.bgCard,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: selected
                              ? AppTheme.cyanPrimary
                              : AppTheme.borderSubtle,
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            item.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 13,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            '${item.aiRoleName} • ${item.cefrLevel}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 11.5,
                              color: AppTheme.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),

            // Conversation messages
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 8,
                ),
                itemCount: turns.length,
                itemBuilder: (context, idx) {
                  final turn = turns[idx];
                  final isUser = turn.isUser;
                  return Align(
                    alignment:
                        isUser ? Alignment.centerRight : Alignment.centerLeft,
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(14),
                      constraints: BoxConstraints(
                        maxWidth: MediaQuery.of(context).size.width * 0.84,
                      ),
                      decoration: BoxDecoration(
                        color: isUser
                            ? AppTheme.violetAccent.withValues(alpha: 0.25)
                            : AppTheme.bgCard,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(
                          color: isUser
                              ? AppTheme.violetAccent
                              : AppTheme.borderSubtle,
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              Icon(
                                isUser
                                    ? Icons.person_rounded
                                    : Icons.record_voice_over_rounded,
                                size: 15,
                                color: isUser
                                    ? AppTheme.goldAccent
                                    : AppTheme.cyanPrimary,
                              ),
                              const SizedBox(width: 6),
                              Flexible(
                                child: Text(
                                  isUser ? 'Bạn (Student)' : scenario.aiRoleName,
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w800,
                                    color: isUser
                                        ? AppTheme.goldAccent
                                        : AppTheme.cyanPrimary,
                                  ),
                                ),
                              ),
                              if (!isUser && turn.text.isNotEmpty) ...<Widget>[
                                const SizedBox(width: 8),
                                InkWell(
                                  onTap: () {
                                    final englishOnly = turn.text
                                        .split(RegExp(r'💡|🎯|🎓'))
                                        .first
                                        .trim();
                                    widget.viewModel.tts.speak(
                                      englishOnly,
                                      id: 'turn_${scenario.id}_$idx',
                                    );
                                  },
                                  child: const Icon(
                                    Icons.volume_up_rounded,
                                    size: 18,
                                    color: AppTheme.cyanPrimary,
                                  ),
                                ),
                              ],
                            ],
                          ),
                          const SizedBox(height: 6),
                          Text(
                            turn.text.isEmpty
                                ? 'Đang phản hồi & phân tích câu nói của bạn...'
                                : turn.text,
                            style: const TextStyle(
                              fontSize: 14,
                              height: 1.48,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),

            // Suggested Speaking Starters
            SizedBox(
              height: 40,
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                scrollDirection: Axis.horizontal,
                itemCount: scenario.suggestedReplies.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (context, idx) {
                  final sample = scenario.suggestedReplies[idx];
                  return ActionChip(
                    backgroundColor: AppTheme.bgCardElevated,
                    label: Text(
                      sample,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 12),
                    ),
                    onPressed: () {
                      _roleplayInputCtrl.text = sample;
                    },
                  );
                },
              ),
            ),
            const SizedBox(height: 8),

            // Input bar (supports keyboard + OS voice dictation microphone)
            Container(
              padding: const EdgeInsets.fromLTRB(14, 10, 14, 14),
              decoration: const BoxDecoration(
                color: AppTheme.bgSurface,
                border: Border(top: BorderSide(color: AppTheme.borderSubtle)),
              ),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: TextField(
                      controller: _roleplayInputCtrl,
                      minLines: 1,
                      maxLines: 3,
                      decoration: const InputDecoration(
                        hintText:
                            'Nói (bấm Mic bàn phím) hoặc nhập câu tiếng Anh...',
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  IconButton.filled(
                    onPressed: widget.viewModel.isRoleplayStreaming
                        ? null
                        : () {
                            final text = _roleplayInputCtrl.text;
                            _roleplayInputCtrl.clear();
                            widget.viewModel.sendRoleplayMessage(
                              scenario: scenario,
                              userText: text,
                            );
                          },
                    style: IconButton.styleFrom(
                      backgroundColor: AppTheme.cyanPrimary,
                      foregroundColor: const Color(0xFF04101E),
                    ),
                    icon: const Icon(Icons.send_rounded),
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildPronunciationTab() {
    final drills = CurriculumRepository.speakingDrills;
    final drill = drills[_selectedDrillIndex];

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          // Drill selector chips
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: List<Widget>.generate(drills.length, (index) {
              final item = drills[index];
              final isSelected = index == _selectedDrillIndex;
              return ChoiceChip(
                label: Text('Câu ${index + 1} (${item.cefrLevel})'),
                selected: isSelected,
                onSelected: (_) {
                  setState(() {
                    _selectedDrillIndex = index;
                    _spokenInputCtrl.clear();
                    _pronunciationScore = null;
                    _wordResults = const <_WordMatchResult>[];
                  });
                },
              );
            }),
          ),
          const SizedBox(height: 16),

          // Target Pronunciation Card
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: AppTheme.bgCard,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(
                color: AppTheme.cyanPrimary.withValues(alpha: 0.4),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  drill.category,
                  style: const TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w800,
                    color: AppTheme.cyanPrimary,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  drill.sentenceEn,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  drill.ipa,
                  style: const TextStyle(
                    fontSize: 13.5,
                    color: AppTheme.goldAccent,
                    fontFamily: 'monospace',
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Nghĩa: ${drill.meaningVi}',
                  style: const TextStyle(
                    fontSize: 13.5,
                    color: AppTheme.textSecondary,
                  ),
                ),
                const Divider(height: 22),
                Row(
                  children: <Widget>[
                    Icon(
                      Icons.tips_and_updates_rounded,
                      size: 18,
                      color: AppTheme.emeraldSuccess,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        drill.tipVi,
                        style: const TextStyle(
                          fontSize: 12.5,
                          color: AppTheme.emeraldSuccess,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () => widget.viewModel.tts.speak(
                          drill.sentenceEn,
                          id: 'drill_${drill.id}',
                        ),
                        icon: const Icon(Icons.volume_up_rounded),
                        label: const Text('1. Nghe Giọng Chuẩn'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    OutlinedButton(
                      onPressed: widget.viewModel.tts.cycleSpeed,
                      child: Text(widget.viewModel.tts.speedLabel),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),

          // Voice Dictation / Shadowing Evaluation Card
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.bgCard,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: AppTheme.borderSubtle),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                const Text(
                  '2. Thực hành Phát âm & Chấm điểm Từng Từ',
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  'Đọc to theo mẫu (sử dụng Micro nhận diện giọng nói hoặc nhập câu bạn vừa đọc để chấm độ khớp từng từ):',
                  style: TextStyle(
                    fontSize: 12.5,
                    color: AppTheme.textSecondary,
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _spokenInputCtrl,
                  maxLines: 2,
                  decoration: InputDecoration(
                    hintText: drill.sentenceEn,
                    suffixIcon: IconButton(
                      tooltip: 'Điền nhanh câu vừa đọc để chấm thử',
                      onPressed: () {
                        _spokenInputCtrl.text = drill.sentenceEn;
                      },
                      icon: const Icon(
                        Icons.mic_rounded,
                        color: AppTheme.cyanPrimary,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () => _evaluatePronunciation(drill),
                    icon: const Icon(Icons.analytics_rounded),
                    label: const Text('Chấm điểm Phát âm & Trọng âm (+20 XP)'),
                  ),
                ),

                if (_pronunciationScore != null) ...<Widget>[
                  const Divider(height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      const Text(
                        'Kết quả phân tích từng từ:',
                        style: TextStyle(fontWeight: FontWeight.w700),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: AppTheme.emeraldSuccess
                              .withValues(alpha: 0.16),
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Text(
                          'Độ chuẩn xác: $_pronunciationScore%',
                          style: const TextStyle(
                            color: AppTheme.emeraldSuccess,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: _wordResults.map((w) {
                      final color = w.isMatched
                          ? AppTheme.emeraldSuccess
                          : AppTheme.goldAccent;
                      return InkWell(
                        onTap: () => widget.viewModel.tts.speak(
                          w.word,
                          id: 'word_${w.word}',
                        ),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 5,
                          ),
                          decoration: BoxDecoration(
                            color: color.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: color),
                          ),
                          child: Text(
                            w.word,
                            style: TextStyle(
                              color: color,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _WordMatchResult {
  const _WordMatchResult({
    required this.word,
    required this.isMatched,
  });

  final String word;
  final bool isMatched;
}
