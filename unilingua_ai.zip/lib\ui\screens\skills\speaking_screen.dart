import 'dart:async';

import 'package:flutter/material.dart';

import '../../../data/repositories/curriculum_repository.dart';
import '../../../data/services/speech_tts_service.dart';
import '../../../data/services/voice_recorder_service.dart';
import '../../../domain/models/learning_models.dart';
import '../../theme/app_theme.dart';
import '../../view_models/learning_view_model.dart';
import '../../widgets/lesson_helpers.dart';

class SpeakingScreen extends StatefulWidget {
  const SpeakingScreen({
    super.key,
    required this.viewModel,
    this.onExitToHome,
  });

  final LearningViewModel viewModel;
  final VoidCallback? onExitToHome;

  @override
  State<SpeakingScreen> createState() => _SpeakingScreenState();
}

class _SpeakingScreenState extends State<SpeakingScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  // --- Tab 1: AI Hands-Free Voice Call state ---
  int _selectedScenarioIndex = 0;
  bool _isCallActive = false;
  bool _isCallPaused = false;
  bool _showCallSummary = false;
  int _callSeconds = 0;
  Timer? _callTimer;
  Timer? _silenceSendTimer;
  Timer? _micRestartTimer;
  String _pendingCallUtterance = '';
  bool _isSendingCallUtterance = false;
  bool _wasAiSpeaking = false;
  VoicePersona _activeCallPersona = VoicePersona.bea;

  // --- Tab 2: Pronunciation Coach (>70% pass threshold) ---
  int _selectedDrillIndex = 0;
  String _lastDrillSpokenText = '';
  int? _pronunciationPercent;
  List<_PronunciationWordAnalysis> _wordAnalysis =
      const <_PronunciationWordAnalysis>[];
  final Set<String> _passedDrillIds = <String>{};
  bool _isHoldingDrillMic = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _tabController.addListener(() {
      if (_tabController.indexIsChanging) {
        _stopActiveCallResources();
        widget.viewModel.voiceRecorder.stopListening();
        widget.viewModel.tts.stop();
      }
    });
    widget.viewModel.tts.addListener(_handleTtsStateChanged);
  }

  @override
  void dispose() {
    widget.viewModel.tts.removeListener(_handleTtsStateChanged);
    _stopActiveCallResources();
    _tabController.dispose();
    super.dispose();
  }

  void _stopActiveCallResources() {
    _callTimer?.cancel();
    _callTimer = null;
    _silenceSendTimer?.cancel();
    _silenceSendTimer = null;
    _micRestartTimer?.cancel();
    _micRestartTimer = null;
  }

  void _handleTtsStateChanged() {
    final nowSpeaking = widget.viewModel.tts.isSpeaking;
    if (_wasAiSpeaking && !nowSpeaking) {
      // AI just finished speaking -> automatically re-open hands-free mic!
      if (mounted &&
          _isCallActive &&
          !_isCallPaused &&
          !widget.viewModel.isRoleplayStreaming) {
        _scheduleContinuousCallMic();
      }
    }
    _wasAiSpeaking = nowSpeaking;
  }

  String get _formattedCallTime {
    final m = (_callSeconds ~/ 60).toString().padLeft(2, '0');
    final s = (_callSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  RoleplayScenario get _currentScenario =>
      CurriculumRepository.roleplayScenarios[_selectedScenarioIndex];

  void _startHandsFreeCall(RoleplayScenario scenario) {
    _stopActiveCallResources();
    widget.viewModel.voiceRecorder.stopListening();
    widget.viewModel.tts.stop();
    widget.viewModel.resetRoleplayScenario(scenario);

    final persona = VoicePersona.forContext(scenario.title);
    setState(() {
      _activeCallPersona = persona;
      _isCallActive = true;
      _isCallPaused = false;
      _showCallSummary = false;
      _callSeconds = 0;
      _pendingCallUtterance = '';
      _isSendingCallUtterance = false;
    });

    _callTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && _isCallActive && !_isCallPaused) {
        setState(() => _callSeconds++);
      }
    });

    // AI greets aloud like answering a real phone call
    final englishOnly =
        scenario.openingLineEn.split(RegExp(r'🇻🇳|💡')).first.trim();
    widget.viewModel.tts.speak(
      englishOnly,
      id: 'call_open_${scenario.id}',
      persona: persona,
    );

    // Fallback: if TTS finishes immediately (e.g. muted/simulator), open mic automatically
    _micRestartTimer = Timer(const Duration(milliseconds: 900), () {
      if (!mounted || !_isCallActive || _isCallPaused) return;
      if (!widget.viewModel.tts.isSpeaking &&
          !widget.viewModel.voiceRecorder.isMicListening('speaking_call_mic')) {
        _openContinuousCallMic(scenario);
      }
    });
  }

  void _togglePauseHandsFreeCall(RoleplayScenario scenario) {
    if (!_isCallActive) return;
    if (_isCallPaused) {
      setState(() => _isCallPaused = false);
      _scheduleContinuousCallMic();
    } else {
      _silenceSendTimer?.cancel();
      _micRestartTimer?.cancel();
      widget.viewModel.voiceRecorder.stopListening();
      widget.viewModel.tts.stop();
      setState(() {
        _isCallPaused = true;
        _pendingCallUtterance = '';
      });
    }
  }

  void _endHandsFreeCall() {
    _stopActiveCallResources();
    widget.viewModel.voiceRecorder.stopListening();
    widget.viewModel.tts.stop();
    setState(() {
      _isCallActive = false;
      _isCallPaused = false;
      _showCallSummary = true;
      _pendingCallUtterance = '';
      _isSendingCallUtterance = false;
    });
  }

  void _scheduleContinuousCallMic() {
    _micRestartTimer?.cancel();
    _micRestartTimer = Timer(const Duration(milliseconds: 450), () {
      if (!mounted ||
          !_isCallActive ||
          _isCallPaused ||
          widget.viewModel.tts.isSpeaking ||
          widget.viewModel.isRoleplayStreaming ||
          _isSendingCallUtterance) {
        return;
      }
      _openContinuousCallMic(_currentScenario);
    });
  }

  Future<void> _openContinuousCallMic(RoleplayScenario scenario) async {
    if (!mounted || !_isCallActive || _isCallPaused) return;
    if (widget.viewModel.voiceRecorder.isMicListening('speaking_call_mic')) {
      return;
    }
    _pendingCallUtterance = '';
    await widget.viewModel.voiceRecorder.startListening(
      micId: 'speaking_call_mic',
      userDisplayName: widget.viewModel.state?.user.displayName,
      onTranscript: (words, isFinal) {
        if (!mounted || !_isCallActive || _isCallPaused) return;
        final trimmed = words.trim();
        if (trimmed.isEmpty) return;
        _pendingCallUtterance = trimmed;
        _silenceSendTimer?.cancel();
        if (isFinal) {
          _autoSendCallUtterance(scenario);
        } else {
          _silenceSendTimer = Timer(const Duration(milliseconds: 1800), () {
            if (mounted && _isCallActive && !_isCallPaused) {
              _autoSendCallUtterance(scenario);
            }
          });
        }
      },
    );
  }

  Future<void> _autoSendCallUtterance(RoleplayScenario scenario) async {
    if (_isSendingCallUtterance || !_isCallActive || _isCallPaused) return;
    _silenceSendTimer?.cancel();
    final captured = _pendingCallUtterance.trim();
    if (captured.isEmpty) return;

    _isSendingCallUtterance = true;
    _pendingCallUtterance = '';
    final spoken = await widget.viewModel.voiceRecorder.stopListening();
    if (!mounted || !_isCallActive) {
      _isSendingCallUtterance = false;
      return;
    }

    final finalText = spoken.trim().isNotEmpty ? spoken.trim() : captured;
    await widget.viewModel.sendRoleplayMessage(
      scenario: scenario,
      userText: finalText,
      autoSpeakReply: true,
      persona: _activeCallPersona,
    );
    _isSendingCallUtterance = false;

    // Fallback auto-reopen mic if TTS didn't start or finished instantly
    if (mounted && _isCallActive && !_isCallPaused) {
      _micRestartTimer?.cancel();
      _micRestartTimer = Timer(const Duration(milliseconds: 1200), () {
        if (!mounted || !_isCallActive || _isCallPaused) return;
        if (!widget.viewModel.tts.isSpeaking &&
            !widget.viewModel.isRoleplayStreaming &&
            !widget.viewModel.voiceRecorder
                .isMicListening('speaking_call_mic')) {
          _openContinuousCallMic(scenario);
        }
      });
    }
  }

  Future<void> _startDrillMic(SpeakingDrill drill) async {
    await widget.viewModel.tts.stop();
    setState(() {
      _lastDrillSpokenText = '';
    });
    await widget.viewModel.voiceRecorder.startListening(
      micId: 'speaking_drill_mic',
      userDisplayName: widget.viewModel.state?.user.displayName,
      onTranscript: (words, isFinal) {
        if (!mounted) return;
        setState(() => _lastDrillSpokenText = words);
      },
    );
  }

  Future<void> _stopDrillMicAndGrade(SpeakingDrill drill) async {
    final spoken = await widget.viewModel.voiceRecorder.stopListening();
    if (!mounted) return;
    final finalText =
        spoken.isNotEmpty ? spoken : _lastDrillSpokenText.trim();
    if (finalText.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Chưa nghe thấy giọng nói, bạn bấm Mic nói rõ hơn nhé!'),
        ),
      );
      return;
    }
    _gradePronunciation(drill, finalText);
  }

  void _gradePronunciation(SpeakingDrill drill, String spokenText) {
    final normalizedSpoken =
        VoiceRecorderService.normalizeVietnameseProperNouns(
      spokenText,
      userDisplayName: widget.viewModel.state?.user.displayName,
    );
    final spokenTokens = normalizedSpoken
        .toLowerCase()
        .replaceAll(RegExp(r"[^\w\s']"), '')
        .split(RegExp(r'\s+'))
        .where((w) => w.isNotEmpty)
        .toList();

    final targetTokens = drill.sentenceEn.split(RegExp(r'\s+'));
    final results = <_PronunciationWordAnalysis>[];
    var totalScore = 0.0;
    const vnProperNouns = <String>{
      'vang',
      'thai',
      'nguyen',
      'hanoi',
      'linh',
      'minh',
      'nam',
      'hoa',
      'vietnam',
    };

    for (final rawWord in targetTokens) {
      final cleanTarget =
          rawWord.toLowerCase().replaceAll(RegExp(r"[^\w']"), '');
      var bestSim = 0.0;
      for (final uWord in spokenTokens) {
        final sim = _wordSimilarity(cleanTarget, uWord);
        if (sim > bestSim) bestSim = sim;
      }
      final threshold = vnProperNouns.contains(cleanTarget) ? 0.55 : 0.78;
      final isCorrect = bestSim >= threshold;
      totalScore += isCorrect ? 1.0 : bestSim * 0.5;
      results.add(
        _PronunciationWordAnalysis(
          word: rawWord,
          cleanWord: cleanTarget,
          isCorrect: isCorrect,
          fixHintVi: isCorrect ? '' : _buildPronunciationFixTip(cleanTarget),
        ),
      );
    }

    final percent = targetTokens.isNotEmpty
        ? ((totalScore / targetTokens.length) * 100).round().clamp(0, 100)
        : 0;

    final passed = percent > 70;
    setState(() {
      _lastDrillSpokenText = spokenText;
      _pronunciationPercent = percent;
      _wordAnalysis = results;
      if (passed) {
        _passedDrillIds.add(drill.id);
      }
    });

    if (passed) {
      widget.viewModel.recordActivityCompletion(
        questId: 'q_speak',
        skill: SkillType.speaking,
        baseXp: 25,
        lessonId: drill.id,
        skillBoost: 3,
      );
    }
  }

  double _wordSimilarity(String a, String b) {
    if (a == b) return 1.0;
    if (a.isEmpty || b.isEmpty) return 0.0;
    final dist = _levenshtein(a, b);
    final maxLen = a.length > b.length ? a.length : b.length;
    return (1.0 - dist / maxLen).clamp(0.0, 1.0);
  }

  int _levenshtein(String s, String t) {
    final m = s.length;
    final n = t.length;
    final dp = List<List<int>>.generate(
      m + 1,
      (_) => List<int>.filled(n + 1, 0),
    );
    for (var i = 0; i <= m; i++) {
      dp[i][0] = i;
    }
    for (var j = 0; j <= n; j++) {
      dp[0][j] = j;
    }
    for (var i = 1; i <= m; i++) {
      for (var j = 1; j <= n; j++) {
        final cost = s[i - 1] == t[j - 1] ? 0 : 1;
        final del = dp[i - 1][j] + 1;
        final ins = dp[i][j - 1] + 1;
        final sub = dp[i - 1][j - 1] + cost;
        var minVal = del < ins ? del : ins;
        if (sub < minVal) minVal = sub;
        dp[i][j] = minVal;
      }
    }
    return dp[m][n];
  }

  String _buildPronunciationFixTip(String word) {
    if (word.endsWith('s') || word.endsWith('ce') || word.endsWith('se')) {
      return 'Nhớ bật nhẹ âm gió /s/ hoặc /z/ ở cuối từ "$word".';
    }
    if (word.endsWith('t') || word.endsWith('d') || word.endsWith('ed')) {
      return 'Bật rõ âm bật hơi cuối /t/ hoặc /d/ khi kết thúc từ "$word".';
    }
    if (word.contains('th')) {
      return 'Đặt nhẹ đầu lưỡi giữa hai hàm răng rồi thổi hơi cho âm "th" trong "$word".';
    }
    if (word.length >= 6) {
      return 'Đọc chậm tách từng âm tiết và bấm vào từ "$word" để nghe mẫu chuẩn.';
    }
    return 'Bấm vào từ màu đỏ "$word" để nghe máy đọc riêng rồi nói rõ hơn.';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          '🎙️ Luyện Nói & Gọi Thoại AI',
          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17),
        ),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppPalette.of(context).primary,
          labelColor: AppPalette.of(context).primary,
          unselectedLabelColor: AppPalette.of(context).textSecondary,
          tabs: <Widget>[
            Tab(text: '📞 Gọi thoại AI'),
            Tab(text: '🎯 Luyện Phát âm (>70%)'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: <Widget>[
          _buildVoiceCallTab(),
          _buildPronunciationTab(),
        ],
      ),
    );
  }

  Widget _buildVoiceCallTab() {
    return ListenableBuilder(
      listenable: Listenable.merge(<Listenable>[
        widget.viewModel,
        widget.viewModel.tts,
        widget.viewModel.voiceRecorder,
      ]),
      builder: (context, _) {
        final scenarios = CurriculumRepository.roleplayScenarios;
        final scenario = scenarios[_selectedScenarioIndex];
        final turns = widget.viewModel.turnsForScenario(scenario);
        final isListening =
            widget.viewModel.voiceRecorder.isMicListening('speaking_call_mic');
        final isAiSpeaking = widget.viewModel.tts.isSpeaking;
        final isStreaming = widget.viewModel.isRoleplayStreaming;
        final p = AppPalette.of(context);

        // STATE 1: ACTIVE REAL-TIME HANDS-FREE VOICE CALL (NO TEXT/SUBTITLES!)
        if (_isCallActive) {
          final statusText = _isCallPaused
              ? '⏸️ Cuộc gọi đang tạm dừng'
              : isStreaming
                  ? '🧠 AI đang suy nghĩ...'
                  : isAiSpeaking
                      ? '🔊 AI đang nói...'
                      : isListening
                          ? '🎙️ Mic đang mở — Hãy nói tự nhiên...'
                          : '🟢 Kết nối rảnh tay đang hoạt động';

          final ringColor = _isCallPaused
              ? p.textSecondary
              : isAiSpeaking
                  ? AppTheme.emeraldSuccess
                  : isListening
                      ? p.primary
                      : AppTheme.violetAccent;

          return Container(
            key: const Key('speaking_active_call_view'),
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(24, 24, 24, 32),
            child: Column(
              children: <Widget>[
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    color: ringColor.withValues(alpha: 0.14),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(
                    '📞 Đang gọi • $_formattedCallTime',
                    style: TextStyle(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w800,
                      color: ringColor,
                    ),
                  ),
                ),
                const Spacer(),
                // Animated Caller Avatar (Zero Transcript Text on Screen!)
                AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  width: (isListening || isAiSpeaking) && !_isCallPaused
                      ? 156
                      : 136,
                  height: (isListening || isAiSpeaking) && !_isCallPaused
                      ? 156
                      : 136,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: ringColor.withValues(alpha: 0.14),
                    border: Border.all(
                      color: ringColor.withValues(alpha: 0.45),
                      width: 2.5,
                    ),
                  ),
                  alignment: Alignment.center,
                  child: Container(
                    width: 108,
                    height: 108,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: ringColor.withValues(alpha: 0.24),
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      _activeCallPersona.emoji,
                      style: const TextStyle(fontSize: 48),
                    ),
                  ),
                ),
                const SizedBox(height: 22),
                Text(
                  scenario.aiRoleName,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    color: p.textPrimary,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  '${_activeCallPersona.name} • ${_activeCallPersona.roleVi}',
                  style: TextStyle(
                    fontSize: 13.5,
                    fontWeight: FontWeight.w600,
                    color: p.textSecondary,
                  ),
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 9,
                  ),
                  decoration: BoxDecoration(
                    color: p.card,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: p.border),
                  ),
                  child: Text(
                    statusText,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w700,
                      color: p.textPrimary,
                    ),
                  ),
                ),
                const Spacer(),
                // ONLY 2 Call Control Buttons: Pause/Mute & End Call
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        SizedBox(
                          width: 72,
                          height: 72,
                          child: FilledButton(
                            key: const Key('speaking_pause_call_btn'),
                            onPressed: () =>
                                _togglePauseHandsFreeCall(scenario),
                            style: FilledButton.styleFrom(
                              shape: const CircleBorder(),
                              backgroundColor: _isCallPaused
                                  ? p.primary
                                  : p.cardElevated,
                              foregroundColor: _isCallPaused
                                  ? Colors.white
                                  : p.textPrimary,
                              padding: EdgeInsets.zero,
                            ),
                            child: Icon(
                              _isCallPaused
                                  ? Icons.play_arrow_rounded
                                  : Icons.pause_rounded,
                              size: 32,
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          _isCallPaused ? 'Tiếp tục' : 'Tạm dừng',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: p.textSecondary,
                          ),
                        ),
                      ],
                    ),
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        SizedBox(
                          width: 72,
                          height: 72,
                          child: FilledButton(
                            key: const Key('speaking_end_call_btn'),
                            onPressed: _endHandsFreeCall,
                            style: FilledButton.styleFrom(
                              shape: const CircleBorder(),
                              backgroundColor: AppTheme.coralDanger,
                              foregroundColor: Colors.white,
                              padding: EdgeInsets.zero,
                            ),
                            child: const Icon(
                              Icons.call_end_rounded,
                              size: 32,
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'Kết thúc cuộc gọi',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: AppTheme.coralDanger,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          );
        }

        // STATE 2: POST-CALL TRANSCRIPT & AI FEEDBACK SUMMARY
        if (_showCallSummary) {
          final userTurnCount = turns.where((t) => t.isUser).length;
          final feedbackTips = <String>[];
          for (final t in turns) {
            if (!t.isUser &&
                (t.text.contains('💡') || t.text.contains('🎯'))) {
              final tipPart = t.text.split(RegExp(r'💡|🎯')).last.trim();
              if (tipPart.isNotEmpty) {
                feedbackTips.add(tipPart);
              }
            }
          }

          return Column(
            key: const Key('speaking_call_summary_view'),
            children: <Widget>[
              // Summary Header + AI Review Card
              Container(
                width: double.infinity,
                margin: const EdgeInsets.fromLTRB(14, 12, 14, 8),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: p.card,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: AppTheme.emeraldSuccess.withValues(alpha: 0.45),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        const Icon(
                          Icons.fact_check_rounded,
                          color: AppTheme.emeraldSuccess,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Tổng kết cuộc gọi • $_formattedCallTime',
                            style: TextStyle(
                              fontSize: 15.5,
                              fontWeight: FontWeight.w900,
                              color: p.textPrimary,
                            ),
                          ),
                        ),
                        TextButton.icon(
                          key: const Key('speaking_new_call_btn'),
                          onPressed: () {
                            setState(() {
                              _showCallSummary = false;
                              _callSeconds = 0;
                            });
                          },
                          icon: const Icon(Icons.call_rounded, size: 17),
                          label: const Text('Gọi mới'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      key: const Key('speaking_call_feedback_card'),
                      feedbackTips.isNotEmpty
                          ? '✨ Nhận xét & Gợi ý sửa lỗi AI:\n• ${feedbackTips.join('\n• ')}'
                          : userTurnCount > 0
                              ? '✨ Nhận xét AI: Bạn đã giao tiếp $userTurnCount lượt tự nhiên trong $_formattedCallTime! Hãy nghe lại từng lượt bên dưới để luyện ngữ điệu chuẩn hơn.'
                              : '✨ Nhận xét AI: Bạn chưa nói câu nào trong cuộc gọi vừa rồi. Hãy bấm "Gọi mới" và nói tự nhiên ngay sau khi AI chào nhé!',
                      style: TextStyle(
                        fontSize: 13,
                        height: 1.45,
                        color: p.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Lịch sử hội thoại (Transcript)',
                    style: TextStyle(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w800,
                      color: p.textSecondary,
                    ),
                  ),
                ),
              ),
              Expanded(
                child: ListView.builder(
                  key: const Key('speaking_call_transcript_list'),
                  padding: const EdgeInsets.fromLTRB(14, 6, 14, 24),
                  itemCount: turns.length,
                  itemBuilder: (context, idx) {
                    final turn = turns[idx];
                    final isUser = turn.isUser;
                    return Align(
                      alignment: isUser
                          ? Alignment.centerRight
                          : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.all(12),
                        constraints: BoxConstraints(
                          maxWidth: MediaQuery.of(context).size.width * 0.84,
                        ),
                        decoration: BoxDecoration(
                          color: isUser
                              ? AppTheme.violetAccent.withValues(alpha: 0.2)
                              : p.card,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: isUser ? AppTheme.violetAccent : p.border,
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: <Widget>[
                                Text(
                                  isUser ? 'Bạn' : scenario.aiRoleName,
                                  style: TextStyle(
                                    fontSize: 11.5,
                                    fontWeight: FontWeight.w800,
                                    color: isUser
                                        ? AppTheme.goldAccent
                                        : p.primary,
                                  ),
                                ),
                                if (!isUser && turn.text.isNotEmpty) ...<Widget>[
                                  const SizedBox(width: 8),
                                  InkWell(
                                    onTap: () {
                                      final en = turn.text
                                          .split(RegExp(r'🇻🇳|💡|🎯|🎓'))
                                          .first
                                          .trim();
                                      widget.viewModel.tts.speak(
                                        en,
                                        id: 'call_turn_$idx',
                                        persona: _activeCallPersona,
                                      );
                                    },
                                    child: Icon(
                                      Icons.volume_up_rounded,
                                      size: 16,
                                      color: p.primary,
                                    ),
                                  ),
                                ],
                              ],
                            ),
                            const SizedBox(height: 4),
                            Text(
                              turn.text,
                              style: TextStyle(
                                fontSize: 13.5,
                                height: 1.4,
                                color: p.textPrimary,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        }

        // STATE 3: PRE-CALL LOBBY (Choose Scenario & Tap "Bắt đầu gọi")
        final previewPersona = VoicePersona.forContext(scenario.title);
        return SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Text(
                'Chọn tình huống hội thoại',
                style: TextStyle(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w800,
                  color: p.textSecondary,
                ),
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: List<Widget>.generate(scenarios.length, (index) {
                  final item = scenarios[index];
                  final selected = index == _selectedScenarioIndex;
                  return ChoiceChip(
                    label: Text(
                      item.title,
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w700,
                        color: selected
                            ? const Color(0xFF04101E)
                            : p.textPrimary,
                      ),
                    ),
                    selected: selected,
                    selectedColor: p.primary,
                    onSelected: (_) {
                      widget.viewModel.tts.stop();
                      widget.viewModel.voiceRecorder.stopListening();
                      setState(() {
                        _selectedScenarioIndex = index;
                      });
                    },
                  );
                }),
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  color: p.card,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: p.border),
                ),
                child: Column(
                  children: <Widget>[
                    CircleAvatar(
                      radius: 42,
                      backgroundColor: p.primary.withValues(alpha: 0.14),
                      child: Text(
                        previewPersona.emoji,
                        style: const TextStyle(fontSize: 40),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Text(
                      scenario.aiRoleName,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.w900,
                        color: p.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'Giọng AI: ${previewPersona.name} (${previewPersona.roleVi})',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: p.primary,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Chế độ gọi điện rảnh tay: Mic tự động mở liên tục để nghe bạn nói và AI trả lời ngay bằng giọng nói. Toàn bộ Transcript và nhận xét sửa lỗi sẽ hiển thị sau khi kết thúc cuộc gọi.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 13,
                        height: 1.45,
                        color: p.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 22),
                    SizedBox(
                      width: double.infinity,
                      height: 54,
                      child: FilledButton.icon(
                        key: const Key('speaking_start_call_btn'),
                        onPressed: () => _startHandsFreeCall(scenario),
                        style: FilledButton.styleFrom(
                          backgroundColor: AppTheme.emeraldSuccess,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                        icon: const Icon(Icons.call_rounded, size: 22),
                        label: const Text(
                          'Bắt đầu gọi',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildPronunciationTab() {
    return ListenableBuilder(
      listenable: Listenable.merge(<Listenable>[
        widget.viewModel,
        widget.viewModel.tts,
        widget.viewModel.voiceRecorder,
      ]),
      builder: (context, _) {
        final drills = CurriculumRepository.speakingDrills;
        final drill = drills[_selectedDrillIndex];
        final isListening =
            widget.viewModel.voiceRecorder.isMicListening('speaking_drill_mic');
        final liveText = isListening
            ? widget.viewModel.voiceRecorder.liveTranscript
            : _lastDrillSpokenText;
        final wrongWords =
            _wordAnalysis.where((w) => !w.isCorrect).toList();
        final passed = (_pronunciationPercent ?? 0) > 70;

        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              // Drill selector chips showing checkmark when >70% passed
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: List<Widget>.generate(drills.length, (index) {
                  final item = drills[index];
                  final isSelected = index == _selectedDrillIndex;
                  final isDone = _passedDrillIds.contains(item.id);
                  return ChoiceChip(
                    label: Text(
                      '${isDone ? "✓ " : ""}Câu ${index + 1} (${item.cefrLevel})',
                    ),
                    selected: isSelected,
                    selectedColor: isDone
                        ? AppTheme.emeraldSuccess
                        : AppPalette.of(context).primary,
                    labelStyle: TextStyle(
                      fontWeight: FontWeight.w800,
                      color: isSelected
                          ? const Color(0xFF04101E)
                          : (isDone
                              ? AppTheme.emeraldSuccess
                              : AppPalette.of(context).textPrimary),
                    ),
                    onSelected: (_) {
                      widget.viewModel.voiceRecorder.stopListening();
                      setState(() {
                        _selectedDrillIndex = index;
                        _lastDrillSpokenText = '';
                        _pronunciationPercent = null;
                        _wordAnalysis = const <_PronunciationWordAnalysis>[];
                      });
                    },
                  );
                }),
              ),
              const SizedBox(height: 14),

              // Target Sentence Card
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppPalette.of(context).card,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: AppPalette.of(context).primary.withValues(alpha: 0.4),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Text(
                          drill.category,
                          style: TextStyle(),
                        ),
                        const Spacer(),
                        TextButton.icon(
                          onPressed: widget.viewModel.tts.cycleSpeed,
                          icon: Icon(Icons.speed_rounded, size: 15),
                          label: Text(
                            widget.viewModel.tts.speedLabel,
                            style: TextStyle(fontSize: 12),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    TranslatablePromptBlock(
                      promptEn: drill.sentenceEn,
                      promptVi: drill.meaningVi,
                      textStyle: TextStyle(
                        fontSize: 18.5,
                        fontWeight: FontWeight.w900,
                        height: 1.38,
                        color: AppPalette.of(context).textPrimary,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      drill.ipa,
                      style: const TextStyle(
                        fontSize: 13,
                        color: AppTheme.goldAccent,
                        fontFamily: 'monospace',
                      ),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: () => widget.viewModel.tts.speak(
                          drill.sentenceEn,
                          id: 'drill_${drill.id}',
                        ),
                        icon: Icon(Icons.volume_up_rounded),
                        label: Text('Nghe giọng mẫu chuẩn'),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 18),

              // Real Microphone Capture + Live Transcript Box
              Center(
                child: Column(
                  children: <Widget>[
                    _InteractiveMicButton(
                      isListening: isListening,
                      isDisabled: false,
                      onTapToggle: () {
                        if (isListening) {
                          _stopDrillMicAndGrade(drill);
                        } else {
                          _startDrillMic(drill);
                        }
                      },
                      onHoldStart: () {
                        _isHoldingDrillMic = true;
                        _startDrillMic(drill);
                      },
                      onHoldEnd: () {
                        if (_isHoldingDrillMic) {
                          _isHoldingDrillMic = false;
                          _stopDrillMicAndGrade(drill);
                        }
                      },
                    ),
                    const SizedBox(height: 8),
                    Text(
                      isListening
                          ? 'Đang thu âm... thả tay hoặc chạm Mic để chấm điểm'
                          : 'Chạm Mic để nói/dừng • Hoặc ấn giữ để nói liên tục (Đạt >70% để qua)',
                      textAlign: TextAlign.center,
                      style: TextStyle(),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),

              // Live Transcript Line directly underneath Mic
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppPalette.of(context).bg,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: isListening
                        ? AppTheme.coralDanger
                        : AppPalette.of(context).border,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'Câu bạn vừa nói:',
                      style: TextStyle(
                        fontSize: 11.5,
                        color: AppPalette.of(context).textSecondary,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      liveText.isNotEmpty
                          ? '"$liveText"'
                          : widget.viewModel.voiceRecorder.statusMessage
                                  .isNotEmpty
                              ? widget.viewModel.voiceRecorder.statusMessage
                              : '(Chưa thu âm — bấm nút Mic bên trên để nói)',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: liveText.isNotEmpty
                            ? AppPalette.of(context).textPrimary
                            : AppPalette.of(context).textSecondary,
                      ),
                    ),
                  ],
                ),
              ),

              // Score Result & Red Highlight Pronunciation Correction
              if (_pronunciationPercent != null) ...<Widget>[
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppPalette.of(context).card,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(
                      color: passed
                          ? AppTheme.emeraldSuccess
                          : AppTheme.coralDanger,
                      width: 1.6,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          SizedBox(
                            width: 54,
                            height: 54,
                            child: Stack(
                              alignment: Alignment.center,
                              children: <Widget>[
                                CircularProgressIndicator(
                                  value: (_pronunciationPercent! / 100)
                                      .clamp(0.0, 1.0),
                                  strokeWidth: 6,
                                  backgroundColor: AppPalette.of(context).bg,
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    passed
                                        ? AppTheme.emeraldSuccess
                                        : AppTheme.coralDanger,
                                  ),
                                ),
                                Text(
                                  '$_pronunciationPercent%',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w900,
                                    fontSize: 13.5,
                                    color: passed
                                        ? AppTheme.emeraldSuccess
                                        : AppTheme.coralDanger,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  passed
                                      ? '✅ ĐẠT! Bạn đã qua câu này (+25 XP)'
                                      : '❌ Chưa qua (Cần vượt 70%)',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w900,
                                    fontSize: 15,
                                    color: passed
                                        ? AppTheme.emeraldSuccess
                                        : AppTheme.coralDanger,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  passed
                                      ? 'Phát âm rất tốt! Bạn có thể chuyển sang câu tiếp theo.'
                                      : 'Bấm vào các từ màu đỏ bên dưới để nghe mẫu rồi nói lại nhé.',
                                  style: TextStyle(),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      // Color-coded words (Green = good, RED = inaccurate)
                      Wrap(
                        spacing: 6,
                        runSpacing: 8,
                        children: _wordAnalysis.map((w) {
                          final color = w.isCorrect
                              ? AppTheme.emeraldSuccess
                              : AppTheme.coralDanger;
                          return InkWell(
                            borderRadius: BorderRadius.circular(8),
                            onTap: () => widget.viewModel.tts.speak(
                              w.cleanWord,
                              id: 'fix_${w.cleanWord}',
                            ),
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 5,
                              ),
                              decoration: BoxDecoration(
                                color: color.withValues(alpha: 0.16),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: color),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[
                                  Text(
                                    w.word,
                                    style: TextStyle(
                                      color: color,
                                      fontWeight: FontWeight.w800,
                                      fontSize: 14,
                                    ),
                                  ),
                                  if (!w.isCorrect) ...<Widget>[
                                    const SizedBox(width: 4),
                                    Icon(
                                      Icons.volume_up_rounded,
                                      size: 14,
                                      color: color,
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          );
                        }).toList(),
                      ),

                      // Specific correction tips for red words
                      if (wrongWords.isNotEmpty) ...<Widget>[
                        const Divider(height: 22),
                        Text(
                          '🔧 Cần sửa phát âm (chữ đỏ):',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                            color: AppTheme.coralDanger,
                          ),
                        ),
                        const SizedBox(height: 6),
                        ...wrongWords.take(4).map(
                              (w) => Padding(
                                padding: const EdgeInsets.only(bottom: 4),
                                child: Text(
                                  '• ${w.word}: ${w.fixHintVi}',
                                  style: TextStyle(),
                                ),
                              ),
                            ),
                      ],

                      if (passed) ...<Widget>[
                        const SizedBox(height: 16),
                        LessonCompletionCard(
                          title: '🎉 ĐẠT ($_pronunciationPercent%) • Qua câu này!',
                          subtitle:
                              'Phát âm rất tốt (+25 XP)! Bạn muốn luyện tiếp câu khác hay hoàn thành và quay về Trang chủ?',
                          onContinueNext: () {
                            setState(() {
                              _selectedDrillIndex =
                                  (_selectedDrillIndex + 1) % drills.length;
                              _lastDrillSpokenText = '';
                              _pronunciationPercent = null;
                              _wordAnalysis =
                                  const <_PronunciationWordAnalysis>[];
                            });
                          },
                          onFinishAndExit: () {
                            widget.viewModel.voiceRecorder.stopListening();
                            widget.viewModel.tts.stop();
                            if (widget.onExitToHome != null) {
                              widget.onExitToHome!();
                            } else if (Navigator.of(context).canPop()) {
                              Navigator.of(context).pop();
                            }
                          },
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ],
          ),
        );
      },
    );
  }
}

class _InteractiveMicButton extends StatelessWidget {
  const _InteractiveMicButton({
    required this.isListening,
    required this.isDisabled,
    required this.onTapToggle,
    required this.onHoldStart,
    required this.onHoldEnd,
  });

  final bool isListening;
  final bool isDisabled;
  final VoidCallback onTapToggle;
  final VoidCallback onHoldStart;
  final VoidCallback onHoldEnd;

  @override
  Widget build(BuildContext context) {
    final bgColor = isListening ? AppTheme.coralDanger : AppPalette.of(context).primary;
    return GestureDetector(
      onTap: isDisabled ? null : onTapToggle,
      onLongPressStart: isDisabled ? null : (_) => onHoldStart(),
      onLongPressEnd: isDisabled ? null : (_) => onHoldEnd(),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        width: isListening ? 78 : 70,
        height: isListening ? 78 : 70,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: isDisabled ? AppPalette.of(context).border : bgColor,
          boxShadow: <BoxShadow>[
            BoxShadow(
              color: bgColor.withValues(alpha: isListening ? 0.55 : 0.3),
              blurRadius: isListening ? 24 : 14,
              spreadRadius: isListening ? 4 : 1,
            ),
          ],
        ),
        child: Icon(
          isListening ? Icons.stop_rounded : Icons.mic_rounded,
          size: 34,
          color: isListening ? Colors.white : const Color(0xFF04101E),
        ),
      ),
    );
  }
}

class _PronunciationWordAnalysis {
  const _PronunciationWordAnalysis({
    required this.word,
    required this.cleanWord,
    required this.isCorrect,
    required this.fixHintVi,
  });

  final String word;
  final String cleanWord;
  final bool isCorrect;
  final String fixHintVi;
}
