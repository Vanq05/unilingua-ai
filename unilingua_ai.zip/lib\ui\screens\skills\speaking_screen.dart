import 'dart:async';

import 'package:flutter/material.dart';

import '../../../data/repositories/curriculum_repository.dart';
import '../../../domain/models/learning_models.dart';
import '../../theme/app_theme.dart';
import '../../view_models/learning_view_model.dart';

class SpeakingScreen extends StatefulWidget {
  const SpeakingScreen({
    super.key,
    required this.viewModel,
  });

  final LearningViewModel viewModel;

  @override
  State<SpeakingScreen> createState() => _SpeakingScreenState();
}

class _SpeakingScreenState extends State<SpeakingScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  // --- Tab 1: AI Voice Call state ---
  int _selectedScenarioIndex = 0;
  bool _isCallActive = false;
  int _callSeconds = 0;
  Timer? _callTimer;
  String _lastCallSpokenText = '';
  bool _isHoldingCallMic = false;

  // --- Tab 2: Pronunciation Coach (>70% pass threshold) ---
  int _selectedDrillIndex = 0;
  String _lastDrillSpokenText = '';
  int? _pronunciationPercent;
  List<_PronunciationWordAnalysis> _wordAnalysis =
      const <_PronunciationWordAnalysis>[];
  final Set<String> _passedDrillIds = <String>{};
  bool _isHoldingDrillMic = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _tabController.addListener(() {
      if (_tabController.indexIsChanging) {
        widget.viewModel.voiceRecorder.stopListening();
        widget.viewModel.tts.stop();
      }
    });
  }

  @override
  void dispose() {
    _callTimer?.cancel();
    _tabController.dispose();
    super.dispose();
  }

  String get _formattedCallTime {
    final m = (_callSeconds ~/ 60).toString().padLeft(2, '0');
    final s = (_callSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  void _toggleCallSession(RoleplayScenario scenario) {
    if (_isCallActive) {
      _callTimer?.cancel();
      widget.viewModel.voiceRecorder.stopListening();
      widget.viewModel.tts.stop();
      setState(() {
        _isCallActive = false;
        _callSeconds = 0;
      });
    } else {
      setState(() {
        _isCallActive = true;
        _callSeconds = 0;
        _lastCallSpokenText = '';
      });
      _callTimer?.cancel();
      _callTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (mounted && _isCallActive) {
          setState(() => _callSeconds++);
        }
      });
      // AI greets aloud like answering a phone call
      final englishOnly =
          scenario.openingLineEn.split(RegExp(r'🇻🇳|💡')).first.trim();
      widget.viewModel.tts.speak(englishOnly, id: 'call_open_${scenario.id}');
    }
  }

  Future<void> _startCallMic(RoleplayScenario scenario) async {
    await widget.viewModel.tts.stop();
    if (!_isCallActive) {
      setState(() {
        _isCallActive = true;
        _callSeconds = 0;
      });
      _callTimer?.cancel();
      _callTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (mounted && _isCallActive) {
          setState(() => _callSeconds++);
        }
      });
    }
    setState(() => _lastCallSpokenText = '');
    await widget.viewModel.voiceRecorder.startListening(
      onTranscript: (words, isFinal) {
        if (!mounted) return;
        setState(() => _lastCallSpokenText = words);
      },
    );
  }

  Future<void> _stopCallMicAndSend(RoleplayScenario scenario) async {
    final spoken = await widget.viewModel.voiceRecorder.stopListening();
    if (!mounted) return;
    final finalText =
        spoken.isNotEmpty ? spoken : _lastCallSpokenText.trim();
    if (finalText.isEmpty) return;

    setState(() => _lastCallSpokenText = finalText);
    await widget.viewModel.sendRoleplayMessage(
      scenario: scenario,
      userText: finalText,
      autoSpeakReply: true,
    );
  }

  Future<void> _startDrillMic(SpeakingDrill drill) async {
    await widget.viewModel.tts.stop();
    setState(() {
      _lastDrillSpokenText = '';
    });
    await widget.viewModel.voiceRecorder.startListening(
      onTranscript: (words, isFinal) {
        if (!mounted) return;
        setState(() => _lastDrillSpokenText = words);
      },
    );
  }

  Future<void> _stopDrillMicAndGrade(SpeakingDrill drill) async {
    final spoken = await widget.viewModel.voiceRecorder.stopListening();
    if (!mounted) return;
    final finalText =
        spoken.isNotEmpty ? spoken : _lastDrillSpokenText.trim();
    if (finalText.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Chưa nghe thấy giọng nói, bạn bấm Mic nói rõ hơn nhé!'),
        ),
      );
      return;
    }
    _gradePronunciation(drill, finalText);
  }

  void _gradePronunciation(SpeakingDrill drill, String spokenText) {
    final spokenTokens = spokenText
        .toLowerCase()
        .replaceAll(RegExp(r"[^\w\s']"), '')
        .split(RegExp(r'\s+'))
        .where((w) => w.isNotEmpty)
        .toList();

    final targetTokens = drill.sentenceEn.split(RegExp(r'\s+'));
    final results = <_PronunciationWordAnalysis>[];
    var totalScore = 0.0;

    for (final rawWord in targetTokens) {
      final cleanTarget =
          rawWord.toLowerCase().replaceAll(RegExp(r"[^\w']"), '');
      var bestSim = 0.0;
      for (final uWord in spokenTokens) {
        final sim = _wordSimilarity(cleanTarget, uWord);
        if (sim > bestSim) bestSim = sim;
      }
      final isCorrect = bestSim >= 0.78;
      totalScore += isCorrect ? 1.0 : bestSim * 0.5;
      results.add(
        _PronunciationWordAnalysis(
          word: rawWord,
          cleanWord: cleanTarget,
          isCorrect: isCorrect,
          fixHintVi: isCorrect ? '' : _buildPronunciationFixTip(cleanTarget),
        ),
      );
    }

    final percent = targetTokens.isNotEmpty
        ? ((totalScore / targetTokens.length) * 100).round().clamp(0, 100)
        : 0;

    final passed = percent > 70;
    setState(() {
      _lastDrillSpokenText = spokenText;
      _pronunciationPercent = percent;
      _wordAnalysis = results;
      if (passed) {
        _passedDrillIds.add(drill.id);
      }
    });

    if (passed) {
      widget.viewModel.recordActivityCompletion(
        questId: 'q_speak',
        skill: SkillType.speaking,
        baseXp: 25,
        lessonId: drill.id,
        skillBoost: 3,
      );
    }
  }

  double _wordSimilarity(String a, String b) {
    if (a == b) return 1.0;
    if (a.isEmpty || b.isEmpty) return 0.0;
    final dist = _levenshtein(a, b);
    final maxLen = a.length > b.length ? a.length : b.length;
    return (1.0 - dist / maxLen).clamp(0.0, 1.0);
  }

  int _levenshtein(String s, String t) {
    final m = s.length;
    final n = t.length;
    final dp = List<List<int>>.generate(
      m + 1,
      (_) => List<int>.filled(n + 1, 0),
    );
    for (var i = 0; i <= m; i++) {
      dp[i][0] = i;
    }
    for (var j = 0; j <= n; j++) {
      dp[0][j] = j;
    }
    for (var i = 1; i <= m; i++) {
      for (var j = 1; j <= n; j++) {
        final cost = s[i - 1] == t[j - 1] ? 0 : 1;
        final del = dp[i - 1][j] + 1;
        final ins = dp[i][j - 1] + 1;
        final sub = dp[i - 1][j - 1] + cost;
        var minVal = del < ins ? del : ins;
        if (sub < minVal) minVal = sub;
        dp[i][j] = minVal;
      }
    }
    return dp[m][n];
  }

  String _buildPronunciationFixTip(String word) {
    if (word.endsWith('s') || word.endsWith('ce') || word.endsWith('se')) {
      return 'Nhớ bật nhẹ âm gió /s/ hoặc /z/ ở cuối từ "$word".';
    }
    if (word.endsWith('t') || word.endsWith('d') || word.endsWith('ed')) {
      return 'Bật rõ âm bật hơi cuối /t/ hoặc /d/ khi kết thúc từ "$word".';
    }
    if (word.contains('th')) {
      return 'Đặt nhẹ đầu lưỡi giữa hai hàm răng rồi thổi hơi cho âm "th" trong "$word".';
    }
    if (word.length >= 6) {
      return 'Đọc chậm tách từng âm tiết và bấm vào từ "$word" để nghe mẫu chuẩn.';
    }
    return 'Bấm vào từ màu đỏ "$word" để nghe máy đọc riêng rồi nói rõ hơn.';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          '🎙️ Luyện Nói & Gọi Thoại AI',
          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17),
        ),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppPalette.of(context).primary,
          labelColor: AppPalette.of(context).primary,
          unselectedLabelColor: AppPalette.of(context).textSecondary,
          tabs: <Widget>[
            Tab(text: '📞 Gọi thoại AI'),
            Tab(text: '🎯 Luyện Phát âm (>70%)'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: <Widget>[
          _buildVoiceCallTab(),
          _buildPronunciationTab(),
        ],
      ),
    );
  }

  Widget _buildVoiceCallTab() {
    return ListenableBuilder(
      listenable: Listenable.merge(<Listenable>[
        widget.viewModel,
        widget.viewModel.tts,
        widget.viewModel.voiceRecorder,
      ]),
      builder: (context, _) {
        final scenarios = CurriculumRepository.roleplayScenarios;
        final scenario = scenarios[_selectedScenarioIndex];
        final turns = widget.viewModel.turnsForScenario(scenario);
        final isListening = widget.viewModel.voiceRecorder.isListening;
        final isAiSpeaking = widget.viewModel.tts.isSpeaking;
        final liveText = isListening
            ? widget.viewModel.voiceRecorder.liveTranscript
            : _lastCallSpokenText;

        return Column(
          children: <Widget>[
            // Compact topic pills
            SizedBox(
              height: 52,
              child: ListView.separated(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                scrollDirection: Axis.horizontal,
                itemCount: scenarios.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (context, index) {
                  final item = scenarios[index];
                  final selected = index == _selectedScenarioIndex;
                  return ChoiceChip(
                    label: Text(
                      item.title,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: selected
                            ? const Color(0xFF04101E)
                            : AppPalette.of(context).textPrimary,
                      ),
                    ),
                    selected: selected,
                    selectedColor: AppPalette.of(context).primary,
                    onSelected: (_) {
                      widget.viewModel.tts.stop();
                      widget.viewModel.voiceRecorder.stopListening();
                      setState(() {
                        _selectedScenarioIndex = index;
                        _lastCallSpokenText = '';
                      });
                    },
                  );
                },
              ),
            ),

            // Voice Call Header Card (Phone Call Experience)
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: <Color>[AppPalette.of(context).cardElevated, AppPalette.of(context).card]),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: (isListening || isAiSpeaking)
                      ? AppPalette.of(context).primary
                      : AppPalette.of(context).border,
                ),
              ),
              child: Row(
                children: <Widget>[
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppPalette.of(context).primary.withValues(alpha: 0.18),
                      border: Border.all(
                        color: isAiSpeaking
                            ? AppTheme.emeraldSuccess
                            : AppPalette.of(context).primary,
                        width: 2,
                      ),
                    ),
                    child: Icon(
                      isAiSpeaking
                          ? Icons.graphic_eq_rounded
                          : Icons.support_agent_rounded,
                      color: isAiSpeaking
                          ? AppTheme.emeraldSuccess
                          : AppPalette.of(context).primary,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          scenario.aiRoleName,
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 14.5,
                          ),
                        ),
                        Text(
                          isListening
                              ? '🎙️ Đang nghe bạn nói...'
                              : isAiSpeaking
                                  ? '🔊 AI đang nói...'
                                  : _isCallActive
                                      ? '🟢 Đang kết nối • $_formattedCallTime'
                                      : 'Bấm Gọi hoặc chạm Mic để nói chuyện ngay',
                          style: TextStyle(
                            fontSize: 12,
                            color: isListening
                                ? AppTheme.coralDanger
                                : isAiSpeaking
                                    ? AppTheme.emeraldSuccess
                                    : AppPalette.of(context).textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                  FilledButton.icon(
                    onPressed: () => _toggleCallSession(scenario),
                    style: FilledButton.styleFrom(
                      backgroundColor: _isCallActive
                          ? AppTheme.coralDanger
                          : AppTheme.emeraldSuccess,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 8,
                      ),
                    ),
                    icon: Icon(
                      _isCallActive ? Icons.call_end_rounded : Icons.call_rounded,
                      size: 18,
                    ),
                    label: Text(
                      _isCallActive ? 'Kết thúc' : 'Gọi AI',
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Live conversation transcript
            Expanded(
              child: ListView.builder(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                itemCount: turns.length,
                itemBuilder: (context, idx) {
                  final turn = turns[idx];
                  final isUser = turn.isUser;
                  return Align(
                    alignment:
                        isUser ? Alignment.centerRight : Alignment.centerLeft,
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(12),
                      constraints: BoxConstraints(
                        maxWidth: MediaQuery.of(context).size.width * 0.84,
                      ),
                      decoration: BoxDecoration(
                        color: isUser
                            ? AppTheme.violetAccent.withValues(alpha: 0.25)
                            : AppPalette.of(context).card,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: isUser
                              ? AppTheme.violetAccent
                              : AppPalette.of(context).border,
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              Text(
                                isUser ? 'Bạn' : scenario.aiRoleName,
                                style: TextStyle(
                                  fontSize: 11.5,
                                  fontWeight: FontWeight.w800,
                                  color: isUser
                                      ? AppTheme.goldAccent
                                      : AppPalette.of(context).primary,
                                ),
                              ),
                              if (!isUser && turn.text.isNotEmpty) ...<Widget>[
                                const SizedBox(width: 8),
                                InkWell(
                                  onTap: () {
                                    final en = turn.text
                                        .split(RegExp(r'🇻🇳|💡|🎯|🎓'))
                                        .first
                                        .trim();
                                    widget.viewModel.tts.speak(
                                      en,
                                      id: 'call_turn_$idx',
                                    );
                                  },
                                  child: Icon(),
                                ),
                              ],
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text(
                            turn.text.isEmpty ? 'AI đang trả lời...' : turn.text,
                            style: TextStyle(fontSize: 14, height: 1.4),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),

            // Bottom Real-Mic Call Control Dock (Tap OR Hold to speak + live transcript line)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
              decoration: BoxDecoration(
                color: AppPalette.of(context).surface,
                border: Border(top: BorderSide(color: AppPalette.of(context).border)),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  // Live spoken transcript line
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 10,
                    ),
                    decoration: BoxDecoration(
                      color: AppPalette.of(context).card,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isListening
                            ? AppTheme.coralDanger
                            : AppPalette.of(context).border,
                      ),
                    ),
                    child: Text(
                      liveText.isNotEmpty
                          ? '🗣️ Bạn nói: "$liveText"'
                          : widget.viewModel.voiceRecorder.statusMessage
                                  .isNotEmpty
                              ? widget.viewModel.voiceRecorder.statusMessage
                              : 'Câu bạn nói sẽ hiện thành chữ ở đây...',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 13.5,
                        fontWeight: liveText.isNotEmpty
                            ? FontWeight.w700
                            : FontWeight.w400,
                        color: liveText.isNotEmpty
                            ? AppPalette.of(context).textPrimary
                            : AppPalette.of(context).textSecondary,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  _InteractiveMicButton(
                    isListening: isListening,
                    isDisabled: widget.viewModel.isRoleplayStreaming,
                    onTapToggle: () {
                      if (isListening) {
                        _stopCallMicAndSend(scenario);
                      } else {
                        _startCallMic(scenario);
                      }
                    },
                    onHoldStart: () {
                      _isHoldingCallMic = true;
                      _startCallMic(scenario);
                    },
                    onHoldEnd: () {
                      if (_isHoldingCallMic) {
                        _isHoldingCallMic = false;
                        _stopCallMicAndSend(scenario);
                      }
                    },
                  ),
                  const SizedBox(height: 6),
                  Text(
                    isListening
                        ? 'Đang thu âm... thả tay hoặc chạm Mic để gửi cho AI'
                        : 'Chạm Mic để nói/dừng • Hoặc ấn giữ để nói liên tục',
                    style: TextStyle(),
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildPronunciationTab() {
    return ListenableBuilder(
      listenable: Listenable.merge(<Listenable>[
        widget.viewModel,
        widget.viewModel.tts,
        widget.viewModel.voiceRecorder,
      ]),
      builder: (context, _) {
        final drills = CurriculumRepository.speakingDrills;
        final drill = drills[_selectedDrillIndex];
        final isListening = widget.viewModel.voiceRecorder.isListening;
        final liveText = isListening
            ? widget.viewModel.voiceRecorder.liveTranscript
            : _lastDrillSpokenText;
        final wrongWords =
            _wordAnalysis.where((w) => !w.isCorrect).toList();
        final passed = (_pronunciationPercent ?? 0) > 70;

        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              // Drill selector chips showing checkmark when >70% passed
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: List<Widget>.generate(drills.length, (index) {
                  final item = drills[index];
                  final isSelected = index == _selectedDrillIndex;
                  final isDone = _passedDrillIds.contains(item.id);
                  return ChoiceChip(
                    label: Text(
                      '${isDone ? "✓ " : ""}Câu ${index + 1} (${item.cefrLevel})',
                    ),
                    selected: isSelected,
                    selectedColor: isDone
                        ? AppTheme.emeraldSuccess
                        : AppPalette.of(context).primary,
                    labelStyle: TextStyle(
                      fontWeight: FontWeight.w800,
                      color: isSelected
                          ? const Color(0xFF04101E)
                          : (isDone
                              ? AppTheme.emeraldSuccess
                              : AppPalette.of(context).textPrimary),
                    ),
                    onSelected: (_) {
                      widget.viewModel.voiceRecorder.stopListening();
                      setState(() {
                        _selectedDrillIndex = index;
                        _lastDrillSpokenText = '';
                        _pronunciationPercent = null;
                        _wordAnalysis = const <_PronunciationWordAnalysis>[];
                      });
                    },
                  );
                }),
              ),
              const SizedBox(height: 14),

              // Target Sentence Card
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppPalette.of(context).card,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: AppPalette.of(context).primary.withValues(alpha: 0.4),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Text(
                          drill.category,
                          style: TextStyle(),
                        ),
                        const Spacer(),
                        TextButton.icon(
                          onPressed: widget.viewModel.tts.cycleSpeed,
                          icon: Icon(Icons.speed_rounded, size: 15),
                          label: Text(
                            widget.viewModel.tts.speedLabel,
                            style: TextStyle(fontSize: 12),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      drill.sentenceEn,
                      style: TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.w900,
                        height: 1.38,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      drill.ipa,
                      style: TextStyle(
                        fontSize: 13,
                        color: AppTheme.goldAccent,
                        fontFamily: 'monospace',
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      drill.meaningVi,
                      style: TextStyle(),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: () => widget.viewModel.tts.speak(
                          drill.sentenceEn,
                          id: 'drill_${drill.id}',
                        ),
                        icon: Icon(Icons.volume_up_rounded),
                        label: Text('Nghe giọng mẫu chuẩn'),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 18),

              // Real Microphone Capture + Live Transcript Box
              Center(
                child: Column(
                  children: <Widget>[
                    _InteractiveMicButton(
                      isListening: isListening,
                      isDisabled: false,
                      onTapToggle: () {
                        if (isListening) {
                          _stopDrillMicAndGrade(drill);
                        } else {
                          _startDrillMic(drill);
                        }
                      },
                      onHoldStart: () {
                        _isHoldingDrillMic = true;
                        _startDrillMic(drill);
                      },
                      onHoldEnd: () {
                        if (_isHoldingDrillMic) {
                          _isHoldingDrillMic = false;
                          _stopDrillMicAndGrade(drill);
                        }
                      },
                    ),
                    const SizedBox(height: 8),
                    Text(
                      isListening
                          ? 'Đang thu âm... thả tay hoặc chạm Mic để chấm điểm'
                          : 'Chạm Mic để nói/dừng • Hoặc ấn giữ để nói liên tục (Đạt >70% để qua)',
                      textAlign: TextAlign.center,
                      style: TextStyle(),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),

              // Live Transcript Line directly underneath Mic
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppPalette.of(context).bg,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: isListening
                        ? AppTheme.coralDanger
                        : AppPalette.of(context).border,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      liveText.isNotEmpty
                          ? '"$liveText"'
                          : widget.viewModel.voiceRecorder.statusMessage
                                  .isNotEmpty
                              ? widget.viewModel.voiceRecorder.statusMessage
                              : '(Chưa thu âm — bấm nút Mic bên trên để nói)',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: liveText.isNotEmpty
                            ? AppPalette.of(context).textPrimary
                            : AppPalette.of(context).textSecondary,
                      ),
                    ),
                  ],
                ),
              ),

              // Score Result & Red Highlight Pronunciation Correction
              if (_pronunciationPercent != null) ...<Widget>[
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppPalette.of(context).card,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(
                      color: passed
                          ? AppTheme.emeraldSuccess
                          : AppTheme.coralDanger,
                      width: 1.6,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          SizedBox(
                            width: 54,
                            height: 54,
                            child: Stack(
                              alignment: Alignment.center,
                              children: <Widget>[
                                CircularProgressIndicator(
                                  value: (_pronunciationPercent! / 100)
                                      .clamp(0.0, 1.0),
                                  strokeWidth: 6,
                                  backgroundColor: AppPalette.of(context).bg,
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    passed
                                        ? AppTheme.emeraldSuccess
                                        : AppTheme.coralDanger,
                                  ),
                                ),
                                Text(
                                  '$_pronunciationPercent%',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w900,
                                    fontSize: 13.5,
                                    color: passed
                                        ? AppTheme.emeraldSuccess
                                        : AppTheme.coralDanger,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  passed
                                      ? '✅ ĐẠT! Bạn đã qua câu này (+25 XP)'
                                      : '❌ Chưa qua (Cần vượt 70%)',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w900,
                                    fontSize: 15,
                                    color: passed
                                        ? AppTheme.emeraldSuccess
                                        : AppTheme.coralDanger,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  passed
                                      ? 'Phát âm rất tốt! Bạn có thể chuyển sang câu tiếp theo.'
                                      : 'Bấm vào các từ màu đỏ bên dưới để nghe mẫu rồi nói lại nhé.',
                                  style: TextStyle(),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      // Color-coded words (Green = good, RED = inaccurate)
                      Wrap(
                        spacing: 6,
                        runSpacing: 8,
                        children: _wordAnalysis.map((w) {
                          final color = w.isCorrect
                              ? AppTheme.emeraldSuccess
                              : AppTheme.coralDanger;
                          return InkWell(
                            borderRadius: BorderRadius.circular(8),
                            onTap: () => widget.viewModel.tts.speak(
                              w.cleanWord,
                              id: 'fix_${w.cleanWord}',
                            ),
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 5,
                              ),
                              decoration: BoxDecoration(
                                color: color.withValues(alpha: 0.16),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: color),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[
                                  Text(
                                    w.word,
                                    style: TextStyle(
                                      color: color,
                                      fontWeight: FontWeight.w800,
                                      fontSize: 14,
                                    ),
                                  ),
                                  if (!w.isCorrect) ...<Widget>[
                                    const SizedBox(width: 4),
                                    Icon(
                                      Icons.volume_up_rounded,
                                      size: 14,
                                      color: color,
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          );
                        }).toList(),
                      ),

                      // Specific correction tips for red words
                      if (wrongWords.isNotEmpty) ...<Widget>[
                        const Divider(height: 22),
                        Text(
                          '🔧 Cần sửa phát âm (chữ đỏ):',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                            color: AppTheme.coralDanger,
                          ),
                        ),
                        const SizedBox(height: 6),
                        ...wrongWords.take(4).map(
                              (w) => Padding(
                                padding: const EdgeInsets.only(bottom: 4),
                                child: Text(
                                  '• ${w.word}: ${w.fixHintVi}',
                                  style: TextStyle(),
                                ),
                              ),
                            ),
                      ],

                      if (passed &&
                          _selectedDrillIndex < drills.length - 1) ...<Widget>[
                        const SizedBox(height: 14),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            onPressed: () {
                              setState(() {
                                _selectedDrillIndex++;
                                _lastDrillSpokenText = '';
                                _pronunciationPercent = null;
                                _wordAnalysis =
                                    const <_PronunciationWordAnalysis>[];
                              });
                            },
                            icon: Icon(Icons.arrow_forward_rounded),
                            label: Text('Sang câu tiếp theo →'),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ],
          ),
        );
      },
    );
  }
}

class _InteractiveMicButton extends StatelessWidget {
  const _InteractiveMicButton({
    required this.isListening,
    required this.isDisabled,
    required this.onTapToggle,
    required this.onHoldStart,
    required this.onHoldEnd,
  });

  final bool isListening;
  final bool isDisabled;
  final VoidCallback onTapToggle;
  final VoidCallback onHoldStart;
  final VoidCallback onHoldEnd;

  @override
  Widget build(BuildContext context) {
    final bgColor = isListening ? AppTheme.coralDanger : AppPalette.of(context).primary;
    return GestureDetector(
      onTap: isDisabled ? null : onTapToggle,
      onLongPressStart: isDisabled ? null : (_) => onHoldStart(),
      onLongPressEnd: isDisabled ? null : (_) => onHoldEnd(),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        width: isListening ? 78 : 70,
        height: isListening ? 78 : 70,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: isDisabled ? AppPalette.of(context).border : bgColor,
          boxShadow: <BoxShadow>[
            BoxShadow(
              color: bgColor.withValues(alpha: isListening ? 0.55 : 0.3),
              blurRadius: isListening ? 24 : 14,
              spreadRadius: isListening ? 4 : 1,
            ),
          ],
        ),
        child: Icon(
          isListening ? Icons.stop_rounded : Icons.mic_rounded,
          size: 34,
          color: isListening ? Colors.white : const Color(0xFF04101E),
        ),
      ),
    );
  }
}

class _PronunciationWordAnalysis {
  const _PronunciationWordAnalysis({
    required this.word,
    required this.cleanWord,
    required this.isCorrect,
    required this.fixHintVi,
  });

  final String word;
  final String cleanWord;
  final bool isCorrect;
  final String fixHintVi;
}
