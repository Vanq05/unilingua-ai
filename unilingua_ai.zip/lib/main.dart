import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'ui/screens/google_auth_screen.dart';
import 'ui/screens/home_shell_screen.dart';
import 'ui/screens/placement_test_screen.dart';
import 'ui/screens/profile_setup_screen.dart';
import 'ui/theme/app_theme.dart';
import 'ui/view_models/learning_view_model.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  final viewModel = LearningViewModel()..initialize();
  runApp(UniLinguaApp(viewModel: viewModel));
}

class UniLinguaApp extends StatelessWidget {
  const UniLinguaApp({
    super.key,
    required this.viewModel,
  });

  final LearningViewModel viewModel;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: viewModel,
      builder: (context, _) {
        final isDark = viewModel.isDarkMode;
        SystemChrome.setSystemUIOverlayStyle(
          SystemUiOverlayStyle(
            statusBarColor: Colors.transparent,
            statusBarIconBrightness:
                isDark ? Brightness.light : Brightness.dark,
          ),
        );

        Widget home;
        if (viewModel.isInitializing) {
          home = Scaffold(
            body: Center(
              child: CircularProgressIndicator(
                color: isDark
                    ? AppPalette.dark.primary
                    : AppPalette.light.primary,
              ),
            ),
          );
        } else if (!viewModel.isSignedIn) {
          home = GoogleAuthScreen(viewModel: viewModel);
        } else if (!viewModel.state!.user.hasCompletedProfileSetup) {
          home = InitialProfileSetupScreen(viewModel: viewModel);
        } else if (!viewModel.state!.hasCompletedPlacement ||
            viewModel.isReviewingPlacementResult) {
          home = PlacementTestScreen(viewModel: viewModel);
        } else {
          home = HomeShellScreen(viewModel: viewModel);
        }

        return MaterialApp(
          title: 'UniLingua AI',
          debugShowCheckedModeBanner: false,
          theme: AppTheme.lightTheme,
          darkTheme: AppTheme.darkTheme,
          themeMode: isDark ? ThemeMode.dark : ThemeMode.light,
          home: home,
        );
      },
    );
  }
}
