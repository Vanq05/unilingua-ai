import 'dart:async';

import 'package:flutter/material.dart';

import '../../data/services/central_drive_server_service.dart';
import '../theme/app_theme.dart';
import '../view_models/learning_view_model.dart';

/// Tab "Trò chuyện":
/// - Tìm kiếm người dùng theo `@username` hoặc tên hiển thị & gửi lời mời kết bạn
/// - Duyệt lời mời kết bạn đang chờ (`pending_received`)
/// - Danh sách bạn bè (`accepted`) mở phòng chat riêng `ChatRoomScreen`
class ChatListScreen extends StatefulWidget {
  const ChatListScreen({
    super.key,
    required this.viewModel,
  });

  final LearningViewModel viewModel;

  @override
  State<ChatListScreen> createState() => _ChatListScreenState();
}

class _ChatListScreenState extends State<ChatListScreen> {
  final TextEditingController _searchCtrl = TextEditingController();

  bool _loadingFriends = false;
  bool _searching = false;
  bool _hasSearched = false;
  List<SocialUserItem> _friends = const <SocialUserItem>[];
  List<SocialUserItem> _pendingReceived = const <SocialUserItem>[];
  List<SocialUserItem> _searchResults = const <SocialUserItem>[];

  @override
  void initState() {
    super.initState();
    _loadFriends();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadFriends() async {
    if (!mounted) return;
    setState(() => _loadingFriends = true);
    final res = await widget.viewModel.fetchFriendsOverview();
    if (!mounted) return;
    setState(() {
      _loadingFriends = false;
      if (res.ok) {
        _friends = res.friends;
        _pendingReceived = res.pendingReceived;
      }
    });
  }

  Future<void> _searchUsers() async {
    final q = _searchCtrl.text.trim();
    if (q.isEmpty) {
      setState(() {
        _hasSearched = false;
        _searchResults = const <SocialUserItem>[];
      });
      return;
    }
    FocusScope.of(context).unfocus();
    setState(() {
      _searching = true;
      _hasSearched = true;
    });
    final res = await widget.viewModel.searchSocialUsers(q);
    if (!mounted) return;
    setState(() {
      _searching = false;
      _searchResults = res.users;
    });
  }

  Future<void> _sendRequest(SocialUserItem user) async {
    final res = await widget.viewModel.sendFriendRequest(user.username);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(res.message)),
    );
    await _searchUsers();
    await _loadFriends();
  }

  Future<void> _acceptRequest(SocialUserItem user) async {
    final res = await widget.viewModel.acceptFriendRequest(user.username);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(res.message)),
    );
    await _loadFriends();
    if (_hasSearched) {
      await _searchUsers();
    }
  }

  void _openRoom(SocialUserItem friend) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => ChatRoomScreen(
          viewModel: widget.viewModel,
          friend: friend,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    final myHandle = widget.viewModel.state?.user.effectiveUsername ?? '';

    return SafeArea(
      child: RefreshIndicator(
        onRefresh: _loadFriends,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
          children: <Widget>[
            // Header
            Row(
              children: <Widget>[
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        '💬 Trò chuyện',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          color: p.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'Username của bạn: @$myHandle',
                        style: TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w700,
                          color: p.primary,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  key: const Key('chat_refresh_friends_btn'),
                  tooltip: 'Làm mới danh sách bạn bè',
                  onPressed: _loadingFriends ? null : _loadFriends,
                  icon: _loadingFriends
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : Icon(Icons.refresh_rounded, color: p.primary),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // Search bar (@username or full name)
            Row(
              children: <Widget>[
                Expanded(
                  child: TextField(
                    key: const Key('chat_search_user_field'),
                    controller: _searchCtrl,
                    textInputAction: TextInputAction.search,
                    onSubmitted: (_) => _searchUsers(),
                    decoration: const InputDecoration(
                      prefixIcon: Icon(Icons.person_search_rounded),
                      hintText: 'Tìm bạn theo @username hoặc tên...',
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                SizedBox(
                  height: 48,
                  child: ElevatedButton(
                    key: const Key('chat_search_user_btn'),
                    onPressed: _searching ? null : _searchUsers,
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                    ),
                    child: _searching
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : const Text('Tìm'),
                  ),
                ),
              ],
            ),

            // Search Results Section
            if (_hasSearched) ...<Widget>[
              const SizedBox(height: 16),
              Row(
                children: <Widget>[
                  Text(
                    'Kết quả tìm kiếm (${_searchResults.length})',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                      color: p.textSecondary,
                    ),
                  ),
                  const Spacer(),
                  TextButton(
                    onPressed: () {
                      _searchCtrl.clear();
                      setState(() {
                        _hasSearched = false;
                        _searchResults = const <SocialUserItem>[];
                      });
                    },
                    child: const Text('Đóng'),
                  ),
                ],
              ),
              if (_searchResults.isEmpty && !_searching)
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: p.card,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: p.border),
                  ),
                  child: Text(
                    'Không tìm thấy người dùng nào khớp với "${_searchCtrl.text.trim()}".',
                    style: TextStyle(fontSize: 13, color: p.textSecondary),
                  ),
                )
              else
                for (final u in _searchResults) ...<Widget>[
                  _buildSearchResultTile(p, u),
                  const SizedBox(height: 8),
                ],
            ],

            // Incoming Friend Requests Section
            if (_pendingReceived.isNotEmpty) ...<Widget>[
              const SizedBox(height: 18),
              Text(
                'Lời mời kết bạn chờ duyệt (${_pendingReceived.length})',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: p.gold,
                ),
              ),
              const SizedBox(height: 8),
              for (final req in _pendingReceived) ...<Widget>[
                Material(
                  color: p.card,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                    side: BorderSide(color: p.gold.withValues(alpha: 0.6)),
                  ),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: p.gold.withValues(alpha: 0.16),
                      child: Text(
                        req.initials,
                        style: TextStyle(
                          fontWeight: FontWeight.w900,
                          color: p.gold,
                        ),
                      ),
                    ),
                    title: Text(
                      req.fullName.isNotEmpty ? req.fullName : req.username,
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        color: p.textPrimary,
                      ),
                    ),
                    subtitle: Text(
                      '@${req.username}',
                      style: TextStyle(color: p.primary, fontSize: 12.5),
                    ),
                    trailing: ElevatedButton(
                      key: Key('accept_friend_req_${req.username}'),
                      onPressed: () => _acceptRequest(req),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: p.success,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 8,
                        ),
                      ),
                      child: const Text('Chấp nhận'),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
              ],
            ],

            // Friends List Section
            const SizedBox(height: 18),
            Text(
              'Bạn bè (${_friends.length})',
              style: TextStyle(
                fontSize: 14.5,
                fontWeight: FontWeight.w900,
                color: p.textPrimary,
              ),
            ),
            const SizedBox(height: 8),
            if (_friends.isEmpty && !_loadingFriends)
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: p.card,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: p.border),
                ),
                child: Column(
                  children: <Widget>[
                    Icon(
                      Icons.forum_outlined,
                      size: 38,
                      color: p.primary.withValues(alpha: 0.7),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Chưa có bạn bè nào',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 15,
                        color: p.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Nhập @username ở ô tìm kiếm phía trên để kết bạn và nhắn tin tốc độ cao qua Google Sheets!',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 12.5,
                        height: 1.4,
                        color: p.textSecondary,
                      ),
                    ),
                  ],
                ),
              )
            else
              for (final friend in _friends) ...<Widget>[
                Material(
                  color: p.card,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                    side: BorderSide(color: p.border),
                  ),
                  child: ListTile(
                    key: Key('friend_chat_tile_${friend.username}'),
                    onTap: () => _openRoom(friend),
                    leading: CircleAvatar(
                      radius: 22,
                      backgroundColor: p.primary,
                      child: Text(
                        friend.initials,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                    title: Text(
                      friend.fullName.isNotEmpty
                          ? friend.fullName
                          : friend.username,
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 15,
                        color: p.textPrimary,
                      ),
                    ),
                    subtitle: Text(
                      '@${friend.username} • Chạm để nhắn tin',
                      style: TextStyle(
                        fontSize: 12.5,
                        color: p.textSecondary,
                      ),
                    ),
                    trailing: Icon(
                      Icons.chat_bubble_outline_rounded,
                      color: p.primary,
                    ),
                  ),
                ),
                const SizedBox(height: 8),
              ],
          ],
        ),
      ),
    );
  }

  Widget _buildSearchResultTile(AppPalette p, SocialUserItem user) {
    Widget trailing;
    switch (user.friendshipStatus) {
      case 'accepted':
        trailing = OutlinedButton.icon(
          onPressed: () => _openRoom(user),
          icon: const Icon(Icons.chat_rounded, size: 16),
          label: const Text('Nhắn tin'),
        );
        break;
      case 'pending_sent':
        trailing = Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: p.cardElevated,
            borderRadius: BorderRadius.circular(999),
          ),
          child: Text(
            'Đã gửi lời mời',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: p.textSecondary,
            ),
          ),
        );
        break;
      case 'pending_received':
        trailing = ElevatedButton(
          onPressed: () => _acceptRequest(user),
          style: ElevatedButton.styleFrom(backgroundColor: p.success),
          child: const Text('Chấp nhận'),
        );
        break;
      default:
        trailing = ElevatedButton.icon(
          key: Key('send_friend_req_${user.username}'),
          onPressed: () => _sendRequest(user),
          icon: const Icon(Icons.person_add_alt_1_rounded, size: 16),
          label: const Text('Kết bạn'),
        );
        break;
    }

    return Material(
      color: p.card,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: p.border),
      ),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: p.primary.withValues(alpha: 0.14),
          child: Text(
            user.initials,
            style: TextStyle(fontWeight: FontWeight.w900, color: p.primary),
          ),
        ),
        title: Text(
          user.fullName.isNotEmpty ? user.fullName : user.username,
          style: TextStyle(fontWeight: FontWeight.w800, color: p.textPrimary),
        ),
        subtitle: Text(
          '@${user.username}',
          style: TextStyle(fontSize: 12.5, color: p.primary),
        ),
        trailing: trailing,
      ),
    );
  }
}

/// Phòng chat riêng (`ChatRoomScreen`) với:
/// - **Local Cache**: Tải & hiển thị lịch sử ngay lập tức khi mở phòng chat.
/// - **Smart Polling**: Kiểm tra tin nhắn mới mỗi **3 giây** khi đang nhắn tin sôi nổi,
///   và tự động giãn ra **12 giây** nếu 3 nhịp liên tiếp không có tin mới (tạm dừng hoàn toàn khi thoát màn hình).
class ChatRoomScreen extends StatefulWidget {
  const ChatRoomScreen({
    super.key,
    required this.viewModel,
    required this.friend,
  });

  final LearningViewModel viewModel;
  final SocialUserItem friend;

  @override
  State<ChatRoomScreen> createState() => _ChatRoomScreenState();
}

class _ChatRoomScreenState extends State<ChatRoomScreen> {
  final TextEditingController _msgCtrl = TextEditingController();
  final ScrollController _scrollCtrl = ScrollController();

  List<DirectChatMessage> _messages = <DirectChatMessage>[];
  bool _loadingCache = true;
  bool _sending = false;
  bool _polling = false;
  int _idlePolls = 0;
  Timer? _pollTimer;
  StreamSubscription<DirectChatMessage>? _realtimeSub;

  int get _lastTimestamp =>
      _messages.isEmpty ? 0 : _messages.last.timestamp;

  int get _currentIntervalSeconds => _idlePolls >= 3 ? 12 : 3;

  @override
  void initState() {
    super.initState();
    _initRoom();
  }

  @override
  void dispose() {
    _realtimeSub?.cancel();
    _realtimeSub = null;
    _pollTimer?.cancel();
    _pollTimer = null;
    _msgCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  Future<void> _initRoom() async {
    final cached = await widget.viewModel
        .loadCachedDirectMessages(widget.friend.username);
    if (!mounted) return;
    setState(() {
      _messages = List<DirectChatMessage>.from(cached);
      _loadingCache = false;
    });
    _scrollToBottom();
    _realtimeSub = widget.viewModel
        .subscribeDirectMessages(widget.friend.username)
        .listen((incoming) async {
      if (!mounted) return;
      final merged = _mergeMessages(_messages, <DirectChatMessage>[incoming]);
      setState(() {
        _messages = merged;
        _idlePolls = 0;
      });
      await widget.viewModel.saveCachedDirectMessages(
        widget.friend.username,
        merged,
      );
      _scrollToBottom();
    });
    await _pollOnce();
  }

  void _scheduleNextPoll() {
    _pollTimer?.cancel();
    if (!mounted) return;
    _pollTimer = Timer(
      Duration(seconds: _currentIntervalSeconds),
      _pollOnce,
    );
  }

  Future<void> _pollOnce() async {
    if (!mounted || _polling) return;
    _polling = true;
    try {
      final res = await widget.viewModel.pollNewDirectMessages(
        friendUsername: widget.friend.username,
        lastTimestamp: _lastTimestamp,
      );
      if (!mounted) return;

      if (res.ok && res.newMessages.isNotEmpty) {
        final merged = _mergeMessages(_messages, res.newMessages);
        setState(() {
          _messages = merged;
          _idlePolls = 0;
        });
        await widget.viewModel.saveCachedDirectMessages(
          widget.friend.username,
          merged,
        );
        _scrollToBottom();
      } else {
        setState(() => _idlePolls = _idlePolls + 1);
      }
    } finally {
      _polling = false;
      _scheduleNextPoll();
    }
  }

  List<DirectChatMessage> _mergeMessages(
    List<DirectChatMessage> current,
    List<DirectChatMessage> incoming,
  ) {
    final map = <String, DirectChatMessage>{};
    for (final m in current) {
      map['${m.sender}|${m.timestamp}|${m.content}'] = m;
    }
    for (final m in incoming) {
      map['${m.sender}|${m.timestamp}|${m.content}'] = m;
    }
    final list = map.values.toList()
      ..sort((a, b) => a.timestamp.compareTo(b.timestamp));
    return list;
  }

  Future<void> _sendMessage() async {
    final txt = _msgCtrl.text.trim();
    if (txt.isEmpty || _sending) return;

    _msgCtrl.clear();
    setState(() {
      _sending = true;
      _idlePolls = 0; // Reset về nhịp nhanh 3s khi người dùng vừa gửi tin
    });
    _pollTimer?.cancel();

    final res = await widget.viewModel.sendDirectMessage(
      receiverUsername: widget.friend.username,
      content: txt,
    );
    if (!mounted) return;

    if (res.ok) {
      final me = widget.viewModel.state?.user.effectiveUsername ?? '';
      final sentItem = res.message ??
          DirectChatMessage(
            sender: me,
            receiver: widget.friend.username,
            content: txt,
            timestamp: DateTime.now().millisecondsSinceEpoch,
          );
      final merged = _mergeMessages(_messages, <DirectChatMessage>[sentItem]);
      setState(() {
        _sending = false;
        _messages = merged;
      });
      await widget.viewModel.saveCachedDirectMessages(
        widget.friend.username,
        merged,
      );
      _scrollToBottom();
    } else {
      setState(() => _sending = false);
      _msgCtrl.text = txt;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            res.error.isNotEmpty ? res.error : 'Không gửi được tin nhắn.',
          ),
        ),
      );
    }

    _scheduleNextPoll();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || !_scrollCtrl.hasClients) return;
      _scrollCtrl.animateTo(
        _scrollCtrl.position.maxScrollExtent,
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOut,
      );
    });
  }

  String _formatTime(int tsMs) {
    if (tsMs <= 0) return '';
    final dt = DateTime.fromMillisecondsSinceEpoch(tsMs);
    final h = dt.hour.toString().padLeft(2, '0');
    final m = dt.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    final me = (widget.viewModel.state?.user.effectiveUsername ?? '')
        .trim()
        .toLowerCase();

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              widget.friend.fullName.isNotEmpty
                  ? widget.friend.fullName
                  : widget.friend.username,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
            ),
            Text(
              '@${widget.friend.username} • Đồng bộ ${_currentIntervalSeconds}s',
              style: TextStyle(
                fontSize: 11.5,
                color: p.textSecondary,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        actions: <Widget>[
          IconButton(
            tooltip: 'Kiểm tra tin mới ngay',
            onPressed: _polling ? null : _pollOnce,
            icon: const Icon(Icons.sync_rounded),
          ),
        ],
      ),
      body: Column(
        children: <Widget>[
          if (_loadingCache) const LinearProgressIndicator(minHeight: 2),
          Expanded(
            child: _messages.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Text(
                        'Hãy gửi lời chào tới @${widget.friend.username} để bắt đầu cuộc trò chuyện!',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: p.textSecondary),
                      ),
                    ),
                  )
                : ListView.builder(
                    controller: _scrollCtrl,
                    padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
                    itemCount: _messages.length,
                    itemBuilder: (context, idx) {
                      final m = _messages[idx];
                      final isMe = m.sender.toLowerCase() == me;
                      return Align(
                        alignment:
                            isMe ? Alignment.centerRight : Alignment.centerLeft,
                        child: Container(
                          margin: const EdgeInsets.only(bottom: 8),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 10,
                          ),
                          constraints: BoxConstraints(
                            maxWidth: MediaQuery.of(context).size.width * 0.78,
                          ),
                          decoration: BoxDecoration(
                            color: isMe ? p.primary : p.card,
                            borderRadius: BorderRadius.only(
                              topLeft: const Radius.circular(16),
                              topRight: const Radius.circular(16),
                              bottomLeft: Radius.circular(isMe ? 16 : 4),
                              bottomRight: Radius.circular(isMe ? 4 : 16),
                            ),
                            border: isMe ? null : Border.all(color: p.border),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                m.content,
                                style: TextStyle(
                                  fontSize: 14.5,
                                  color: isMe ? Colors.white : p.textPrimary,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                _formatTime(m.timestamp),
                                style: TextStyle(
                                  fontSize: 10.5,
                                  color: isMe
                                      ? Colors.white70
                                      : p.textSecondary,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
          SafeArea(
            top: false,
            child: Container(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
              decoration: BoxDecoration(
                color: p.surface,
                border: Border(top: BorderSide(color: p.border)),
              ),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: TextField(
                      key: const Key('chat_room_message_field'),
                      controller: _msgCtrl,
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => _sendMessage(),
                      decoration: const InputDecoration(
                        hintText: 'Nhập tin nhắn...',
                        contentPadding: EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 10,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    key: const Key('chat_room_send_btn'),
                    onPressed: _sending ? null : _sendMessage,
                    style: IconButton.styleFrom(
                      backgroundColor: p.primary,
                      foregroundColor: Colors.white,
                    ),
                    icon: _sending
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : const Icon(Icons.send_rounded),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
