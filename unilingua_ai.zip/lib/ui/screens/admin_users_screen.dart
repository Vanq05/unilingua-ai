import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../data/services/central_drive_server_service.dart';
import '../theme/app_theme.dart';
import '../view_models/learning_view_model.dart';

/// Account Administration Console (synced directly with Google Sheets
/// `UniLingua_Users_Dashboard` -> sheet `Users` & Drive JSON DB).
class AdminUsersScreen extends StatefulWidget {
  const AdminUsersScreen({
    super.key,
    required this.viewModel,
  });

  final LearningViewModel viewModel;

  @override
  State<AdminUsersScreen> createState() => _AdminUsersScreenState();
}

class _AdminUsersScreenState extends State<AdminUsersScreen> {
  final TextEditingController _pinCtrl = TextEditingController();
  final TextEditingController _searchCtrl = TextEditingController();

  bool _unlocked = false;
  bool _loading = false;
  String? _errorText;
  String _activePin = '';
  String _dashboardUrl = '';
  String _searchQuery = '';
  List<AdminUserRecord> _users = const <AdminUserRecord>[];

  @override
  void initState() {
    super.initState();
    if (widget.viewModel.isCurrentUserAdmin) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          _loadUsers(pin: '');
        }
      });
    }
  }

  @override
  void dispose() {
    _pinCtrl.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadUsers({required String pin}) async {
    setState(() {
      _loading = true;
      _errorText = null;
    });
    final res = await widget.viewModel.adminListUsers(adminPin: pin);
    if (!mounted) return;
    setState(() {
      _loading = false;
      if (res.ok) {
        _unlocked = true;
        _activePin = pin;
        _users = res.users;
        _dashboardUrl = res.dashboardUrl;
      } else {
        _errorText = res.message.isNotEmpty
            ? res.message
            : 'Không thể xác thực quyền quản trị.';
      }
    });
  }

  Future<void> _toggleRole(AdminUserRecord user) async {
    final nextRole = user.isAdmin ? 'user' : 'admin';
    setState(() => _loading = true);
    final res = await widget.viewModel.adminUpdateUser(
      adminPin: _activePin,
      targetEmail: user.email,
      newRole: nextRole,
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(res.message)),
    );
    if (res.ok) {
      await _loadUsers(pin: _activePin);
    } else {
      setState(() => _loading = false);
    }
  }

  Future<void> _openEditDialog(AdminUserRecord user) async {
    final nameCtrl = TextEditingController(text: user.fullName);
    final passCtrl = TextEditingController();
    final saved = await showDialog<bool>(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: Text('Sửa tài khoản\n${user.email}'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                TextField(
                  controller: nameCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Họ và tên (FullName)',
                    prefixIcon: Icon(Icons.person_outline_rounded),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: passCtrl,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'Đặt mật khẩu mới (để trống nếu giữ nguyên)',
                    prefixIcon: Icon(Icons.lock_reset_rounded),
                  ),
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(false),
              child: const Text('Hủy'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.of(ctx).pop(true),
              child: const Text('Lưu thay đổi'),
            ),
          ],
        );
      },
    );

    if (saved != true || !mounted) {
      nameCtrl.dispose();
      passCtrl.dispose();
      return;
    }

    final trimmedPass = passCtrl.text.trim();
    if (trimmedPass.isNotEmpty && trimmedPass.length < 6) {
      nameCtrl.dispose();
      passCtrl.dispose();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Mật khẩu mới cần tối thiểu 6 ký tự.')),
      );
      return;
    }

    setState(() => _loading = true);
    final res = await widget.viewModel.adminUpdateUser(
      adminPin: _activePin,
      targetEmail: user.email,
      newFullName: nameCtrl.text.trim(),
      newPassword: trimmedPass.isEmpty ? null : trimmedPass,
    );
    nameCtrl.dispose();
    passCtrl.dispose();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(res.message)),
    );
    if (res.ok) {
      await _loadUsers(pin: _activePin);
    } else {
      setState(() => _loading = false);
    }
  }

  Future<void> _confirmDelete(AdminUserRecord user) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: const Text('Xóa tài khoản?'),
          content: Text(
            'Bạn chắc chắn muốn xóa tài khoản ${user.email} khỏi Google Sheets và Google Drive? Thao tác này không thể hoàn tác.',
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(false),
              child: const Text('Hủy'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.of(ctx).pop(true),
              child: const Text('Xóa vĩnh viễn'),
            ),
          ],
        );
      },
    );
    if (confirmed != true || !mounted) return;

    setState(() => _loading = true);
    final res = await widget.viewModel.adminDeleteUser(
      adminPin: _activePin,
      targetEmail: user.email,
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(res.message)),
    );
    if (res.ok) {
      await _loadUsers(pin: _activePin);
    } else {
      setState(() => _loading = false);
    }
  }

  Future<void> _openDashboardUrl() async {
    if (_dashboardUrl.isEmpty) return;
    try {
      await launchUrl(
        Uri.parse(_dashboardUrl),
        mode: LaunchMode.externalApplication,
      );
    } catch (_) {
      if (!mounted) return;
      Clipboard.setData(ClipboardData(text: _dashboardUrl));
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Đã sao chép link Google Sheets vào bộ nhớ tạm!'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    final filtered = _users.where((u) {
      final q = _searchQuery.trim().toLowerCase();
      if (q.isEmpty) return true;
      return u.email.toLowerCase().contains(q) ||
          u.fullName.toLowerCase().contains(q) ||
          u.role.toLowerCase().contains(q);
    }).toList();

    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        title: const Text('Quản trị Tài khoản (Admin)'),
        actions: <Widget>[
          if (_unlocked)
            IconButton(
              key: const Key('admin_refresh_btn'),
              tooltip: 'Tải lại từ Google Sheets',
              onPressed: _loading ? null : () => _loadUsers(pin: _activePin),
              icon: const Icon(Icons.refresh_rounded),
            ),
        ],
      ),
      body: SafeArea(
        child: !_unlocked ? _buildPinGate(p) : _buildUsersBody(p, filtered),
      ),
    );
  }

  Widget _buildPinGate(AppPalette p) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 440),
          child: Material(
            color: p.card,
            borderRadius: BorderRadius.circular(22),
            child: Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: p.border, width: 1.5),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  CircleAvatar(
                    radius: 28,
                    backgroundColor: p.gold.withValues(alpha: 0.16),
                    child: Icon(
                      Icons.admin_panel_settings_rounded,
                      size: 32,
                      color: p.gold,
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    'Bảng Quản Trị Tài Khoản',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      color: p.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Nhập mã PIN quản trị để xem danh sách tài khoản trên Google Sheets, cấp/thu hồi quyền Admin, đặt lại mật khẩu SHA-256 hoặc xóa tài khoản.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 13.5,
                      height: 1.45,
                      color: p.textSecondary,
                    ),
                  ),
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: p.surface,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: p.border),
                    ),
                    child: Text(
                      '📊 Quản lý trực tiếp trên Drive: Thư mục UniLingua_Server_DB → Google Sheet "UniLingua_Users_Dashboard" (tab Users & OTP_Codes).',
                      style: TextStyle(
                        fontSize: 12.5,
                        height: 1.4,
                        color: p.textSecondary,
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    key: const Key('admin_pin_field'),
                    controller: _pinCtrl,
                    obscureText: true,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      prefixIcon: Icon(Icons.key_rounded),
                      hintText: 'Nhập mã PIN Quản trị (mặc định: 2026)',
                    ),
                  ),
                  if (_errorText != null) ...<Widget>[
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: p.danger.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: p.danger),
                      ),
                      child: Text(
                        _errorText!,
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: p.danger,
                        ),
                      ),
                    ),
                  ],
                  const SizedBox(height: 16),
                  SizedBox(
                    height: 50,
                    child: ElevatedButton.icon(
                      key: const Key('admin_unlock_btn'),
                      onPressed: _loading
                          ? null
                          : () => _loadUsers(pin: _pinCtrl.text.trim()),
                      icon: _loading
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : const Icon(Icons.lock_open_rounded),
                      label: const Text('Mở khóa Bảng Quản Trị'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildUsersBody(AppPalette p, List<AdminUserRecord> filtered) {
    final adminCount = _users.where((u) => u.isAdmin).length;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
      children: <Widget>[
        Material(
          color: p.card,
          borderRadius: BorderRadius.circular(18),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: p.border, width: 1.5),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Icon(Icons.table_chart_rounded, color: p.success),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Tổng: ${_users.length} tài khoản ($adminCount Admin)',
                        style: TextStyle(
                          fontSize: 15.5,
                          fontWeight: FontWeight.w900,
                          color: p.textPrimary,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  'Dữ liệu đồng bộ trực tiếp với Google Sheet "UniLingua_Users_Dashboard" trong Google Drive (UniLingua_Server_DB).',
                  style: TextStyle(fontSize: 12.5, color: p.textSecondary),
                ),
                if (_dashboardUrl.isNotEmpty) ...<Widget>[
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: <Widget>[
                      OutlinedButton.icon(
                        onPressed: _openDashboardUrl,
                        icon: const Icon(Icons.open_in_new_rounded, size: 17),
                        label: const Text('Mở Google Sheets'),
                      ),
                      OutlinedButton.icon(
                        onPressed: () {
                          Clipboard.setData(ClipboardData(text: _dashboardUrl));
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Đã sao chép link Google Sheets!'),
                            ),
                          );
                        },
                        icon: const Icon(Icons.copy_rounded, size: 17),
                        label: const Text('Sao chép Link'),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          key: const Key('admin_search_field'),
          controller: _searchCtrl,
          onChanged: (v) => setState(() => _searchQuery = v),
          decoration: const InputDecoration(
            prefixIcon: Icon(Icons.search_rounded),
            hintText: 'Tìm tài khoản theo Email, Tên hoặc Quyền...',
          ),
        ),
        if (_loading) ...<Widget>[
          const SizedBox(height: 12),
          const LinearProgressIndicator(),
        ],
        if (_errorText != null) ...<Widget>[
          const SizedBox(height: 10),
          Text(
            _errorText!,
            style: TextStyle(color: p.danger, fontWeight: FontWeight.w700),
          ),
        ],
        const SizedBox(height: 12),
        if (filtered.isEmpty)
          Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Text(
                'Không có tài khoản nào khớp từ khóa.',
                style: TextStyle(color: p.textSecondary),
              ),
            ),
          )
        else
          for (final u in filtered) ...<Widget>[
            Material(
              color: p.card,
              borderRadius: BorderRadius.circular(16),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: u.isAdmin ? p.gold : p.border,
                    width: u.isAdmin ? 1.8 : 1.2,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        CircleAvatar(
                          radius: 20,
                          backgroundColor: (u.isAdmin ? p.gold : p.primary)
                              .withValues(alpha: 0.16),
                          child: Text(
                            (u.fullName.isNotEmpty
                                    ? u.fullName[0]
                                    : u.email.isNotEmpty
                                        ? u.email[0]
                                        : 'U')
                                .toUpperCase(),
                            style: TextStyle(
                              fontWeight: FontWeight.w900,
                              color: u.isAdmin ? p.gold : p.primary,
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                u.fullName.isNotEmpty
                                    ? u.fullName
                                    : '(Chưa đặt tên)',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontSize: 14.5,
                                  color: p.textPrimary,
                                ),
                              ),
                              Text(
                                u.email,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: 12.5,
                                  color: p.textSecondary,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: (u.isAdmin ? p.gold : p.primary)
                                .withValues(alpha: 0.14),
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Text(
                            u.role.toUpperCase(),
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w900,
                              color: u.isAdmin ? p.gold : p.primary,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 8,
                      runSpacing: 6,
                      children: <Widget>[
                        OutlinedButton.icon(
                          onPressed: _loading ? null : () => _toggleRole(u),
                          icon: const Icon(Icons.swap_horiz_rounded, size: 16),
                          label: Text(
                            u.isAdmin ? 'Hạ xuống User' : 'Cấp quyền Admin',
                          ),
                        ),
                        OutlinedButton.icon(
                          onPressed:
                              _loading ? null : () => _openEditDialog(u),
                          icon: const Icon(Icons.edit_rounded, size: 16),
                          label: const Text('Sửa / Đổi MK'),
                        ),
                        TextButton.icon(
                          onPressed: _loading ? null : () => _confirmDelete(u),
                          icon: Icon(
                            Icons.delete_outline_rounded,
                            size: 17,
                            color: p.danger,
                          ),
                          label: Text(
                            'Xóa',
                            style: TextStyle(color: p.danger),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
          ],
      ],
    );
  }
}
