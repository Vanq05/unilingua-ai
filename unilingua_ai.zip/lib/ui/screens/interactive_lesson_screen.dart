import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../data/services/speech_tts_service.dart';
import '../../domain/models/learning_models.dart';
import '../theme/app_theme.dart';
import '../view_models/learning_view_model.dart';
import '../widgets/duolingo_kit.dart';

enum _MiniGameType {
  wordBank,
  tapPairs,
  listening,
  flashcardSpeak,
  roleplay,
}

class _LessonStep {
  const _LessonStep({
    required this.type,
    required this.persona,
    required this.titleVi,
    required this.promptEn,
    required this.correctAnswer,
    required this.explanationVi,
    this.wordBankTokens = const <String>[],
    this.pairs = const <MapEntry<String, String>>[],
    this.options = const <String>[],
    this.illustrationEmoji = '🍵',
    this.flashcardVi = '',
  });

  final _MiniGameType type;
  final VoicePersona persona;
  final String titleVi;
  final String promptEn;
  final String correctAnswer;
  final String explanationVi;
  final List<String> wordBankTokens;
  final List<MapEntry<String, String>> pairs;
  final List<String> options;
  final String illustrationEmoji;
  final String flashcardVi;
}

/// Duolingo-style 5-Mini-Game Interactive Lesson Screen:
/// 1. Word-Bank 3D chip translation
/// 2. Tap-the-Pairs 2-column matching
/// 3. Listening + 🐢 Slow audio
/// 4. Visual Flashcard Speaking Drill
/// 5. Contextual Character Roleplay
/// Ends with a Streak Celebration Screen!
class InteractiveLessonScreen extends StatefulWidget {
  const InteractiveLessonScreen({
    super.key,
    required this.viewModel,
    this.unitIndex = 0,
    this.unitTitle = 'Phần 1, Cửa 1: Mời khách & Giao tiếp',
  });

  final LearningViewModel viewModel;
  final int unitIndex;
  final String unitTitle;

  @override
  State<InteractiveLessonScreen> createState() =>
      _InteractiveLessonScreenState();
}

class _InteractiveLessonScreenState extends State<InteractiveLessonScreen> {
  late final List<_LessonStep> _steps;

  int _stepIndex = 0;
  int _combo = 0;
  int _maxCombo = 0;
  int _correctCount = 0;
  bool _completed = false;

  // Step feedback state
  bool _checked = false;
  bool _lastCorrect = false;

  // Word bank state
  final List<int> _selectedTokenIndices = <int>[];

  // Tap-the-pairs state
  int? _selectedLeftIdx;
  int? _selectedRightIdx;
  final Set<int> _matchedLeftIndices = <int>{};
  final Set<int> _matchedRightIndices = <int>{};
  int? _wrongLeftIdx;
  int? _wrongRightIdx;
  late List<int> _shuffledRightOrder;

  // Listening & Roleplay selection
  String? _selectedOption;

  // Speaking drill transcript
  String _spokenWords = '';

  @override
  void initState() {
    super.initState();
    _steps = _buildUnitSteps(widget.unitIndex);
    _prepareStep(0);
  }

  List<_LessonStep> _buildUnitSteps(int unit) {
    final sets = <List<_LessonStep>>[
      // Unit 0: Hospitality & Everyday Drinks (inspired by user's Duolingo video!)
      const <_LessonStep>[
        _LessonStep(
          type: _MiniGameType.wordBank,
          persona: VoicePersona.bea,
          titleVi: 'Dịch câu này',
          promptEn: 'Water and tea, please.',
          correctAnswer: 'Làm ơn cho nước và trà',
          wordBankTokens: <String>[
            'Làm ơn',
            'cho',
            'nước',
            'và',
            'trà',
            'hay',
            'sữa',
          ],
          explanationVi:
              '"Water" = nước, "and" = và, "tea" = trà, "please" = làm ơn/vui lòng khi gọi đồ lịch sự.',
        ),
        _LessonStep(
          type: _MiniGameType.tapPairs,
          persona: VoicePersona.zari,
          titleVi: 'Nhấn vào các cặp tương ứng',
          promptEn: 'Match English words with Vietnamese meanings',
          correctAnswer: 'Hoàn thành 4/4 cặp từ',
          pairs: <MapEntry<String, String>>[
            MapEntry<String, String>('water', 'nước'),
            MapEntry<String, String>('tea', 'trà'),
            MapEntry<String, String>('sugar', 'đường'),
            MapEntry<String, String>('milk', 'sữa'),
          ],
          explanationVi:
              'Ghi nhớ nhóm từ vựng đồ uống cơ bản giúp bạn gọi món tự tin ở quán cà phê.',
        ),
        _LessonStep(
          type: _MiniGameType.listening,
          persona: VoicePersona.junior,
          titleVi: 'Nghe và chọn câu đúng',
          promptEn: 'I would like milk with sugar.',
          correctAnswer: 'I would like milk with sugar.',
          options: <String>[
            'I would like milk with sugar.',
            'I like water without ice.',
            'Where is the green tea?',
          ],
          explanationVi:
              'Junior (giọng bé trai) đọc "I would like..." (Tôi muốn...) — cách gọi món lịch sự hơn "I want".',
        ),
        _LessonStep(
          type: _MiniGameType.flashcardSpeak,
          persona: VoicePersona.lily,
          titleVi: 'Dịch nghĩa & Đọc to',
          promptEn: 'Tea with sugar',
          flashcardVi: 'Trà có đường',
          illustrationEmoji: '🍵',
          correctAnswer: 'Tea with sugar',
          explanationVi:
              'Phát âm rõ âm /t/ ở "tea" và âm /ʃ/ (cong môi) ở "sugar".',
        ),
        _LessonStep(
          type: _MiniGameType.roleplay,
          persona: VoicePersona.oscar,
          titleVi: 'Hãy trả lời Oscar',
          promptEn: 'Welcome! Would you like tea or coffee?',
          correctAnswer: 'Tea, please. Thank you!',
          options: <String>[
            'Tea, please. Thank you!',
            'Goodbye, see you tomorrow.',
            'My name is student.',
          ],
          explanationVi:
              'Oscar (nam trưởng thành) hỏi bạn muốn trà hay cà phê — đáp lại tự nhiên là "Tea, please. Thank you!".',
        ),
      ],
      // Unit 1: Campus & Office English (with Falstaff adult male & Bea)
      const <_LessonStep>[
        _LessonStep(
          type: _MiniGameType.wordBank,
          persona: VoicePersona.falstaff,
          titleVi: 'Dịch câu này',
          promptEn: 'We have a meeting at nine.',
          correctAnswer: 'Chúng tôi có cuộc họp lúc chín giờ',
          wordBankTokens: <String>[
            'Chúng tôi',
            'có',
            'cuộc họp',
            'lúc',
            'chín giờ',
            'bữa trưa',
            'hôm qua',
          ],
          explanationVi:
              'Falstaff (nam trung niên công sở) dùng "at nine" để chỉ mốc giờ chính xác.',
        ),
        _LessonStep(
          type: _MiniGameType.tapPairs,
          persona: VoicePersona.bea,
          titleVi: 'Nhấn vào các cặp tương ứng',
          promptEn: 'Match workplace vocabulary',
          correctAnswer: 'Hoàn thành 4/4 cặp từ',
          pairs: <MapEntry<String, String>>[
            MapEntry<String, String>('deadline', 'hạn chót'),
            MapEntry<String, String>('schedule', 'lịch trình'),
            MapEntry<String, String>('colleague', 'đồng nghiệp'),
            MapEntry<String, String>('project', 'dự án'),
          ],
          explanationVi:
              'Bộ từ vựng công sở và học tập đại học tần suất cao.',
        ),
        _LessonStep(
          type: _MiniGameType.listening,
          persona: VoicePersona.oscar,
          titleVi: 'Nghe và chọn câu đúng',
          promptEn: 'Could you send me the report today?',
          correctAnswer: 'Could you send me the report today?',
          options: <String>[
            'Could you send me the report today?',
            'Did you see my passport yesterday?',
            'We are traveling to Hanoi next week.',
          ],
          explanationVi:
              '"Could you..." là cấu trúc nhờ vả lịch sự trong môi trường làm việc.',
        ),
        _LessonStep(
          type: _MiniGameType.flashcardSpeak,
          persona: VoicePersona.zari,
          titleVi: 'Dịch nghĩa & Đọc to',
          promptEn: 'Good morning everyone',
          flashcardVi: 'Chào buổi sáng mọi người',
          illustrationEmoji: '☀️',
          correctAnswer: 'Good morning everyone',
          explanationVi:
              'Nối âm nhẹ giữa "morning" và "everyone" để câu nói trôi chảy hơn.',
        ),
        _LessonStep(
          type: _MiniGameType.roleplay,
          persona: VoicePersona.falstaff,
          titleVi: 'Hãy trả lời Falstaff',
          promptEn: 'Are you ready for the presentation?',
          correctAnswer: 'Yes, I prepared my slides carefully.',
          options: <String>[
            'Yes, I prepared my slides carefully.',
            'No, I like drinking cold water.',
            'It is raining outside.',
          ],
          explanationVi:
              'Trả lời trực tiếp và chuyên nghiệp khi được hỏi về bài thuyết trình.',
        ),
      ],
    ];
    return sets[unit % sets.length];
  }

  void _prepareStep(int idx) {
    _stepIndex = idx;
    _checked = false;
    _lastCorrect = false;
    _selectedTokenIndices.clear();
    _selectedLeftIdx = null;
    _selectedRightIdx = null;
    _matchedLeftIndices.clear();
    _matchedRightIndices.clear();
    _wrongLeftIdx = null;
    _wrongRightIdx = null;
    _selectedOption = null;
    _spokenWords = '';

    final step = _steps[idx];
    if (step.type == _MiniGameType.tapPairs) {
      // Deterministic non-trivial shuffle so pairs aren't aligned row-by-row
      _shuffledRightOrder = <int>[2, 0, 3, 1].take(step.pairs.length).toList();
    } else {
      _shuffledRightOrder = const <int>[];
    }

    // Automatically speak prompt in the character's persona voice
    if (step.type == _MiniGameType.wordBank ||
        step.type == _MiniGameType.listening ||
        step.type == _MiniGameType.roleplay) {
      widget.viewModel.tts.speak(
        step.promptEn,
        id: 'step_$idx',
        persona: step.persona,
      );
    }
  }

  bool get _canCheck {
    final step = _steps[_stepIndex];
    switch (step.type) {
      case _MiniGameType.wordBank:
        return _selectedTokenIndices.isNotEmpty;
      case _MiniGameType.tapPairs:
        return _matchedLeftIndices.length == step.pairs.length;
      case _MiniGameType.listening:
      case _MiniGameType.roleplay:
        return _selectedOption != null;
      case _MiniGameType.flashcardSpeak:
        return _spokenWords.trim().isNotEmpty;
    }
  }

  void _checkAnswer({bool forceSuccess = false}) {
    final step = _steps[_stepIndex];
    bool isCorrect = forceSuccess;

    if (!forceSuccess) {
      switch (step.type) {
        case _MiniGameType.wordBank:
          final built = _selectedTokenIndices
              .map((i) => step.wordBankTokens[i])
              .join(' ')
              .trim()
              .toLowerCase();
          isCorrect = built == step.correctAnswer.trim().toLowerCase();
          break;
        case _MiniGameType.tapPairs:
          isCorrect = _matchedLeftIndices.length == step.pairs.length;
          break;
        case _MiniGameType.listening:
        case _MiniGameType.roleplay:
          isCorrect = _selectedOption == step.correctAnswer;
          break;
        case _MiniGameType.flashcardSpeak:
          final spoken = _spokenWords.toLowerCase();
          final targetWords = step.correctAnswer
              .toLowerCase()
              .replaceAll(RegExp(r'[^a-z0-9\s]'), '')
              .split(RegExp(r'\s+'))
              .where((w) => w.isNotEmpty)
              .toList();
          final hits = targetWords.where((w) => spoken.contains(w)).length;
          isCorrect = hits >= (targetWords.length / 2).ceil();
          break;
      }
    }

    HapticFeedback.mediumImpact();
    setState(() {
      _checked = true;
      _lastCorrect = isCorrect;
      if (isCorrect) {
        _correctCount++;
        _combo++;
        if (_combo > _maxCombo) _maxCombo = _combo;
      } else {
        _combo = 0;
      }
    });
  }

  Future<void> _nextStep() async {
    widget.viewModel.tts.stop();
    widget.viewModel.voiceRecorder.stopListening();
    if (_stepIndex + 1 < _steps.length) {
      setState(() => _prepareStep(_stepIndex + 1));
    } else {
      await widget.viewModel.recordActivityCompletion(
        questId: 'q_daily',
        skill: SkillType.speaking,
        baseXp: 40,
        skillBoost: 3,
      );
      if (!mounted) return;
      setState(() => _completed = true);
    }
  }

  void _onTapLeftPair(int leftIdx) {
    final step = _steps[_stepIndex];
    widget.viewModel.tts.speak(
      step.pairs[leftIdx].key,
      id: 'pair_$leftIdx',
      persona: step.persona,
    );
    setState(() {
      _selectedLeftIdx = leftIdx;
      _wrongLeftIdx = null;
      _wrongRightIdx = null;
    });
    _tryMatchPair();
  }

  void _onTapRightPair(int rightDisplayPos) {
    setState(() {
      _selectedRightIdx = rightDisplayPos;
      _wrongLeftIdx = null;
      _wrongRightIdx = null;
    });
    _tryMatchPair();
  }

  void _tryMatchPair() {
    if (_selectedLeftIdx == null || _selectedRightIdx == null) return;
    final leftIdx = _selectedLeftIdx!;
    final rightDisplayPos = _selectedRightIdx!;
    final actualRightIdx = _shuffledRightOrder[rightDisplayPos];

    if (leftIdx == actualRightIdx) {
      HapticFeedback.lightImpact();
      setState(() {
        _matchedLeftIndices.add(leftIdx);
        _matchedRightIndices.add(rightDisplayPos);
        _selectedLeftIdx = null;
        _selectedRightIdx = null;
      });
      if (_matchedLeftIndices.length == _steps[_stepIndex].pairs.length) {
        _checkAnswer(forceSuccess: true);
      }
    } else {
      HapticFeedback.heavyImpact();
      setState(() {
        _wrongLeftIdx = leftIdx;
        _wrongRightIdx = rightDisplayPos;
        _selectedLeftIdx = null;
        _selectedRightIdx = null;
        _combo = 0;
      });
    }
  }

  @override
  void dispose() {
    widget.viewModel.tts.stop();
    widget.viewModel.voiceRecorder.stopListening();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    if (_completed) {
      return _buildCelebrationView(p);
    }

    final step = _steps[_stepIndex];
    final progress = (_stepIndex + (_checked ? 1 : 0.2)) / _steps.length;

    return Scaffold(
      backgroundColor: p.bg,
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(6, 8, 8, 4),
              child: ComboProgressBar(
                progress: progress,
                combo: _combo,
                onClose: () => Navigator.of(context).pop(),
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(18, 10, 18, 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    Text(
                      step.titleVi,
                      style: TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.w900,
                        color: p.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 16),
                    _buildStepContent(p, step),
                  ],
                ),
              ),
            ),
            if (_checked)
              LessonFeedbackSheet(
                isCorrect: _lastCorrect,
                correctAnswer: step.correctAnswer,
                explanationVi: step.explanationVi,
                onContinue: _nextStep,
              )
            else
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 8, 18, 18),
                child: Tactile3DButton(
                  key: const Key('interactive_check_btn'),
                  label: 'KIỂM TRA',
                  color: p.success,
                  onPressed: _canCheck ? () => _checkAnswer() : null,
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildStepContent(AppPalette p, _LessonStep step) {
    switch (step.type) {
      case _MiniGameType.wordBank:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            CharacterSpeechBubble(
              persona: step.persona,
              textEn: step.promptEn,
              tts: widget.viewModel.tts,
              showBadgeNewWord: true,
            ),
            const SizedBox(height: 22),
            // Answer Drop-Slot Container
            Container(
              constraints: const BoxConstraints(minHeight: 74),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: p.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: p.border, width: 1.5),
              ),
              child: _selectedTokenIndices.isEmpty
                  ? Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Chạm các thẻ từ bên dưới để ghép câu dịch...',
                        style: TextStyle(
                          fontSize: 13.5,
                          color: p.textSecondary,
                        ),
                      ),
                    )
                  : Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: _selectedTokenIndices.map((tokenIdx) {
                        return Tactile3DChip(
                          label: step.wordBankTokens[tokenIdx],
                          selected: true,
                          onTap: _checked
                              ? null
                              : () => setState(
                                    () => _selectedTokenIndices.remove(tokenIdx),
                                  ),
                        );
                      }).toList(),
                    ),
            ),
            const SizedBox(height: 22),
            Wrap(
              spacing: 8,
              runSpacing: 10,
              alignment: WrapAlignment.center,
              children: List<Widget>.generate(step.wordBankTokens.length, (i) {
                final used = _selectedTokenIndices.contains(i);
                return Tactile3DChip(
                  key: Key('word_bank_token_$i'),
                  label: step.wordBankTokens[i],
                  dimmed: used,
                  onTap: _checked
                      ? null
                      : () => setState(() => _selectedTokenIndices.add(i)),
                );
              }),
            ),
          ],
        );

      case _MiniGameType.tapPairs:
        return Column(
          children: List<Widget>.generate(step.pairs.length, (row) {
            final rightActualIdx = _shuffledRightOrder[row];
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: Tactile3DChip(
                      key: Key('pair_left_$row'),
                      label: step.pairs[row].key,
                      selected: _selectedLeftIdx == row,
                      matched: _matchedLeftIndices.contains(row),
                      wrongFlash: _wrongLeftIdx == row,
                      onTap: () => _onTapLeftPair(row),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Tactile3DChip(
                      key: Key('pair_right_$row'),
                      label: step.pairs[rightActualIdx].value,
                      selected: _selectedRightIdx == row,
                      matched: _matchedRightIndices.contains(row),
                      wrongFlash: _wrongRightIdx == row,
                      onTap: () => _onTapRightPair(row),
                    ),
                  ),
                ],
              ),
            );
          }),
        );

      case _MiniGameType.listening:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Tactile3DButton(
                  label: 'NGHE (${step.persona.name})',
                  icon: Icons.volume_up_rounded,
                  color: p.primary,
                  onPressed: () => widget.viewModel.tts.speak(
                    step.promptEn,
                    id: 'listen_norm',
                    persona: step.persona,
                  ),
                ),
                const SizedBox(width: 10),
                Tactile3DButton(
                  label: '🐢 CHẬM',
                  color: p.gold,
                  onPressed: () => widget.viewModel.tts.speakSlow(
                    step.promptEn,
                    id: 'listen_slow',
                    persona: step.persona,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              '${step.persona.emoji} Giọng đọc: ${step.persona.name} (${step.persona.roleLabelVi})',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12.5, color: p.textSecondary),
            ),
            const SizedBox(height: 20),
            for (var i = 0; i < step.options.length; i++) ...<Widget>[
              Tactile3DChip(
                key: Key('listen_opt_$i'),
                label: step.options[i],
                selected: _selectedOption == step.options[i],
                onTap: _checked
                    ? null
                    : () => setState(() => _selectedOption = step.options[i]),
              ),
              const SizedBox(height: 12),
            ],
          ],
        );

      case _MiniGameType.flashcardSpeak:
        return ListenableBuilder(
          listenable: widget.viewModel.voiceRecorder,
          builder: (context, _) {
            final listening = widget.viewModel.voiceRecorder
                .isMicListening('interactive_speak_mic');
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: p.card,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: p.border, width: 1.8),
                  ),
                  child: Column(
                    children: <Widget>[
                      Text(
                        step.illustrationEmoji,
                        style: const TextStyle(fontSize: 64),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        step.flashcardVi,
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                          color: p.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Đọc câu tiếng Anh: "${step.promptEn}"',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: p.primary,
                        ),
                      ),
                      const SizedBox(height: 12),
                      OutlinedButton.icon(
                        onPressed: () => widget.viewModel.tts.speak(
                          step.promptEn,
                          id: 'flash_sample',
                          persona: step.persona,
                        ),
                        icon: const Icon(Icons.volume_up_rounded, size: 18),
                        label: Text(
                          'Nghe mẫu (${step.persona.emoji} ${step.persona.name})',
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                Tactile3DButton(
                  label: listening ? 'ĐANG NGHE... BẤM DỪNG' : 'NHẤN ĐỂ NÓI',
                  icon: listening ? Icons.stop_rounded : Icons.mic_rounded,
                  color: listening ? p.danger : p.primary,
                  onPressed: () async {
                    final rec = widget.viewModel.voiceRecorder;
                    if (listening) {
                      await rec.stopListening();
                    } else {
                      await rec.startListening(
                        micId: 'interactive_speak_mic',
                        userDisplayName:
                            widget.viewModel.state?.user.displayName,
                        onTranscript: (words, _) {
                          if (!mounted) return;
                          setState(() => _spokenWords = words);
                        },
                      );
                    }
                  },
                ),
                if (_spokenWords.isNotEmpty) ...<Widget>[
                  const SizedBox(height: 12),
                  Text(
                    '🎤 Bạn đã đọc: "$_spokenWords"',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      color: p.primary,
                    ),
                  ),
                ],
                const SizedBox(height: 10),
                TextButton(
                  onPressed: _checked
                      ? null
                      : () => _checkAnswer(forceSuccess: true),
                  child: Text(
                    'Tạm bỏ qua bài nói lúc này',
                    style: TextStyle(color: p.textSecondary, fontSize: 13),
                  ),
                ),
              ],
            );
          },
        );

      case _MiniGameType.roleplay:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            CharacterSpeechBubble(
              persona: step.persona,
              textEn: step.promptEn,
              tts: widget.viewModel.tts,
            ),
            const SizedBox(height: 22),
            for (var i = 0; i < step.options.length; i++) ...<Widget>[
              Tactile3DChip(
                key: Key('roleplay_opt_$i'),
                label: '🗣️  ${step.options[i]}',
                selected: _selectedOption == step.options[i],
                onTap: _checked
                    ? null
                    : () {
                        widget.viewModel.tts.speak(
                          step.options[i],
                          id: 'rp_opt_$i',
                          persona: VoicePersona.bea,
                        );
                        setState(() => _selectedOption = step.options[i]);
                      },
              ),
              const SizedBox(height: 12),
            ],
          ],
        );
    }
  }

  Widget _buildCelebrationView(AppPalette p) {
    final accuracy = ((_correctCount / _steps.length) * 100).round();
    final streak = widget.viewModel.state?.streakDays ?? 1;

    return Scaffold(
      backgroundColor: p.bg,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              const Text(
                '🔥',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 78),
              ),
              const SizedBox(height: 12),
              Text(
                'Streak đã bừng sáng!',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.w900,
                  color: p.gold,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                '$streak ngày streak liên tiếp • ${widget.unitTitle}',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: p.textSecondary,
                ),
              ),
              const SizedBox(height: 26),
              Row(
                children: <Widget>[
                  Expanded(
                    child: _StatBadgeCard(
                      label: 'TỔNG KN',
                      value: '+40 ⚡',
                      color: p.gold,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _StatBadgeCard(
                      label: 'CHÍNH XÁC',
                      value: '$accuracy%',
                      color: p.success,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _StatBadgeCard(
                      label: 'COMBO MAX',
                      value: 'x$_maxCombo',
                      color: p.primary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 32),
              Tactile3DButton(
                label: 'TIẾP TỤC',
                color: p.primary,
                onPressed: () => Navigator.of(context).pop(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatBadgeCard extends StatelessWidget {
  const _StatBadgeCard({
    required this.label,
    required this.value,
    required this.color,
  });

  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
      decoration: BoxDecoration(
        color: p.card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: color, width: 2),
      ),
      child: Column(
        children: <Widget>[
          Text(
            label,
            style: TextStyle(
              fontSize: 10.5,
              fontWeight: FontWeight.w900,
              color: color,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w900,
              color: p.textPrimary,
            ),
          ),
        ],
      ),
    );
  }
}
