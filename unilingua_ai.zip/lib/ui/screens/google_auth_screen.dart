import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../view_models/learning_view_model.dart';
import 'forgot_password_screen.dart';

/// Duolingo-style Email/Account & SHA-256 Password Login / Registration screen.
/// All user accounts and progress sync automatically to Google Sheets + Drive Server.
class GoogleAuthScreen extends StatefulWidget {
  const GoogleAuthScreen({
    super.key,
    required this.viewModel,
  });

  final LearningViewModel viewModel;

  @override
  State<GoogleAuthScreen> createState() => _GoogleAuthScreenState();
}

class _GoogleAuthScreenState extends State<GoogleAuthScreen> {
  final TextEditingController _fullNameCtrl = TextEditingController();
  final TextEditingController _usernameCtrl = TextEditingController();
  final TextEditingController _passwordCtrl = TextEditingController();

  bool _isRegisterMode = false;
  bool _obscurePassword = true;
  String? _errorText;

  @override
  void dispose() {
    _fullNameCtrl.dispose();
    _usernameCtrl.dispose();
    _passwordCtrl.dispose();
    super.dispose();
  }

  Future<void> _submitAuth() async {
    FocusScope.of(context).unfocus();
    setState(() => _errorText = null);

    final res = await widget.viewModel.signInOrRegisterWithPassword(
      username: _usernameCtrl.text,
      password: _passwordCtrl.text,
      isRegister: _isRegisterMode,
      fullName: _fullNameCtrl.text,
    );

    if (!mounted) return;
    if (!res.ok) {
      setState(() => _errorText = res.message);
    }
  }

  void _openForgotPassword() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => ForgotPasswordScreen(
          viewModel: widget.viewModel,
          initialEmail: _usernameCtrl.text.trim(),
        ),
      ),
    );
  }

  Future<void> _showRestoreSyncDialog() async {
    final p = AppPalette.of(context);
    final codeCtrl = TextEditingController();
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: p.card,
        title: const Text('Khôi phục bằng mã sao lưu'),
        content: TextField(
          controller: codeCtrl,
          maxLines: 3,
          decoration: const InputDecoration(
            hintText: 'Dán mã sao lưu của bạn vào đây...',
          ),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Hủy'),
          ),
          ElevatedButton(
            onPressed: () async {
              final ok = await widget.viewModel
                  .importCloudSyncCode(codeCtrl.text.trim());
              if (!mounted) return;
              Navigator.of(ctx).pop();
              if (!ok) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Mã sao lưu không hợp lệ.')),
                );
              }
            },
            child: const Text('Khôi phục'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    final known = widget.viewModel.knownAccounts;

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: p.isDark
                ? const <Color>[Color(0xFF1E1B4B), Color(0xFF070B19)]
                : const <Color>[
                    Color(0xFFD8F3FF),
                    Color(0xFFEFF8FF),
                    Color(0xFFFFFFFF),
                  ],
          ),
        ),
        child: SafeArea(
          child: Stack(
            children: <Widget>[
              Positioned(
                top: 8,
                right: 12,
                child: IconButton(
                  tooltip: p.isDark
                      ? 'Chuyển sang giao diện Sáng'
                      : 'Chuyển sang giao diện Tối',
                  onPressed: () => widget.viewModel.setDarkMode(!p.isDark),
                  icon: Icon(
                    p.isDark ? Icons.wb_sunny_rounded : Icons.dark_mode_rounded,
                    color: p.primary,
                  ),
                ),
              ),
              Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 22,
                    vertical: 18,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Container(
                        width: 96,
                        height: 96,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(26),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: p.primary.withValues(alpha: 0.28),
                              blurRadius: 24,
                              offset: const Offset(0, 8),
                            ),
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(26),
                          child: Image.asset(
                            'assets/icon/app_icon.png',
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(
                              color: p.cardElevated,
                              child: Icon(
                                Icons.school_rounded,
                                size: 48,
                                color: p.primary,
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),
                      Text(
                        'UniLingua AI',
                        style: TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.w900,
                          color: p.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Học tiếng Anh thông minh phong cách Duolingo\nTự động đồng bộ dữ liệu lên Google Drive',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 13.5,
                          height: 1.4,
                          color: p.textSecondary,
                        ),
                      ),
                      const SizedBox(height: 20),

                      // Login / Register Card
                      Container(
                        padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          color: p.card,
                          borderRadius: BorderRadius.circular(24),
                          border: Border.all(color: p.border, width: 1.2),
                          boxShadow: p.isDark
                              ? null
                              : <BoxShadow>[
                                  BoxShadow(
                                    color: p.primary.withValues(alpha: 0.08),
                                    blurRadius: 18,
                                    offset: const Offset(0, 6),
                                  ),
                                ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            // Mode Switcher Pills
                            Container(
                              padding: const EdgeInsets.all(4),
                              decoration: BoxDecoration(
                                color: p.bg,
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: p.border),
                              ),
                              child: Row(
                                children: <Widget>[
                                  Expanded(
                                    child: GestureDetector(
                                      onTap: () => setState(() {
                                        _isRegisterMode = false;
                                        _errorText = null;
                                      }),
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                          vertical: 10,
                                        ),
                                        decoration: BoxDecoration(
                                          color: !_isRegisterMode
                                              ? p.primary
                                              : Colors.transparent,
                                          borderRadius:
                                              BorderRadius.circular(10),
                                        ),
                                        alignment: Alignment.center,
                                        child: Text(
                                          'Đăng nhập',
                                          style: TextStyle(
                                            fontWeight: FontWeight.w800,
                                            fontSize: 14,
                                            color: !_isRegisterMode
                                                ? Colors.white
                                                : p.textSecondary,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: GestureDetector(
                                      onTap: () => setState(() {
                                        _isRegisterMode = true;
                                        _errorText = null;
                                      }),
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                          vertical: 10,
                                        ),
                                        decoration: BoxDecoration(
                                          color: _isRegisterMode
                                              ? p.success
                                              : Colors.transparent,
                                          borderRadius:
                                              BorderRadius.circular(10),
                                        ),
                                        alignment: Alignment.center,
                                        child: Text(
                                          'Đăng ký mới',
                                          style: TextStyle(
                                            fontWeight: FontWeight.w800,
                                            fontSize: 14,
                                            color: _isRegisterMode
                                                ? Colors.white
                                                : p.textSecondary,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 16),

                            if (_isRegisterMode) ...<Widget>[
                              Text(
                                'Họ và tên (FullName)',
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 13,
                                  color: p.textPrimary,
                                ),
                              ),
                              const SizedBox(height: 6),
                              TextField(
                                key: const Key('auth_fullname_field'),
                                controller: _fullNameCtrl,
                                textInputAction: TextInputAction.next,
                                decoration: const InputDecoration(
                                  prefixIcon: Icon(Icons.badge_outlined),
                                  hintText: 'Nhập họ và tên (vd: Vũ Hồng Vang)',
                                ),
                              ),
                              const SizedBox(height: 12),
                            ],

                            Text(
                              'Email hoặc Tài khoản',
                              style: TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 13,
                                color: p.textPrimary,
                              ),
                            ),
                            const SizedBox(height: 6),
                            TextField(
                              key: const Key('auth_username_field'),
                              controller: _usernameCtrl,
                              keyboardType: TextInputType.emailAddress,
                              textInputAction: TextInputAction.next,
                              autocorrect: false,
                              decoration: const InputDecoration(
                                prefixIcon: Icon(Icons.email_outlined),
                                hintText: 'Nhập Email hoặc tài khoản (vd: ten@gmail.com)',
                              ),
                            ),
                            const SizedBox(height: 12),

                            Text(
                              'Mật khẩu',
                              style: TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 13,
                                color: p.textPrimary,
                              ),
                            ),
                            const SizedBox(height: 6),
                            TextField(
                              key: const Key('auth_password_field'),
                              controller: _passwordCtrl,
                              obscureText: _obscurePassword,
                              onSubmitted: (_) => _submitAuth(),
                              decoration: InputDecoration(
                                prefixIcon:
                                    const Icon(Icons.lock_outline_rounded),
                                hintText: _isRegisterMode
                                    ? 'Nhập mật khẩu (tối thiểu 6 ký tự)'
                                    : 'Nhập mật khẩu',
                                suffixIcon: IconButton(
                                  onPressed: () => setState(
                                    () => _obscurePassword = !_obscurePassword,
                                  ),
                                  icon: Icon(
                                    _obscurePassword
                                        ? Icons.visibility_outlined
                                        : Icons.visibility_off_outlined,
                                  ),
                                ),
                              ),
                            ),

                            if (!_isRegisterMode)
                              Align(
                                alignment: Alignment.centerRight,
                                child: TextButton(
                                  key: const Key('auth_forgot_password_btn'),
                                  onPressed: widget.viewModel.isBusy
                                      ? null
                                      : _openForgotPassword,
                                  child: Text(
                                    'Quên mật khẩu?',
                                    style: TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w700,
                                      color: p.primary,
                                    ),
                                  ),
                                ),
                              ),

                            if (_errorText != null) ...<Widget>[
                              const SizedBox(height: 12),
                              Container(
                                width: double.infinity,
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: p.danger.withValues(alpha: 0.12),
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(color: p.danger),
                                ),
                                child: Text(
                                  _errorText!,
                                  style: TextStyle(
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w700,
                                    color: p.danger,
                                  ),
                                ),
                              ),
                            ],

                            const SizedBox(height: 18),
                            SizedBox(
                              width: double.infinity,
                              height: 52,
                              child: ElevatedButton(
                                key: const Key('auth_submit_button'),
                                onPressed: widget.viewModel.isBusy
                                    ? null
                                    : _submitAuth,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor:
                                      _isRegisterMode ? p.success : p.primary,
                                  foregroundColor: Colors.white,
                                ),
                                child: widget.viewModel.isBusy
                                    ? const SizedBox(
                                        width: 22,
                                        height: 22,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2.5,
                                          color: Colors.white,
                                        ),
                                      )
                                    : Text(
                                        _isRegisterMode
                                            ? 'Tạo tài khoản & Thiết lập hồ sơ'
                                            : 'Đăng nhập bằng Tài khoản',
                                        style: const TextStyle(
                                          fontSize: 15.5,
                                          fontWeight: FontWeight.w800,
                                        ),
                                      ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      if (known.isNotEmpty) ...<Widget>[
                        const SizedBox(height: 18),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            'Tài khoản đã dùng trên máy (chạm để điền nhanh):',
                            style: TextStyle(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w600,
                              color: p.textSecondary,
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        ...known.map(
                          (acc) => Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: InkWell(
                              borderRadius: BorderRadius.circular(14),
                              onTap: () {
                                setState(() {
                                  _isRegisterMode = false;
                                  _usernameCtrl.text = acc.effectiveUsername;
                                  _errorText = null;
                                });
                              },
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 14,
                                  vertical: 10,
                                ),
                                decoration: BoxDecoration(
                                  color: p.card,
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(color: p.border),
                                ),
                                child: Row(
                                  children: <Widget>[
                                    CircleAvatar(
                                      radius: 17,
                                      backgroundColor: p.primary,
                                      child: Text(
                                        acc.initials,
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.w800,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: <Widget>[
                                          Text(
                                            '${acc.displayName} (${acc.selfAssessedLevel})',
                                            style: TextStyle(
                                              fontWeight: FontWeight.w700,
                                              fontSize: 14,
                                              color: p.textPrimary,
                                            ),
                                          ),
                                          Text(
                                            'Tài khoản: ${acc.effectiveUsername}',
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                              fontSize: 12,
                                              color: p.textSecondary,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Icon(
                                      Icons.arrow_forward_ios_rounded,
                                      size: 14,
                                      color: p.primary,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],

                      const SizedBox(height: 10),
                      TextButton(
                        onPressed: _showRestoreSyncDialog,
                        child: Text(
                          'Khôi phục bằng mã sao lưu',
                          style: TextStyle(color: p.primary, fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
