import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../view_models/learning_view_model.dart';

/// Change Password Screen for authenticated users:
/// 3 inputs: Current Password, New Password, Confirm New Password (hashed with SHA-256).
class ChangePasswordScreen extends StatefulWidget {
  const ChangePasswordScreen({
    super.key,
    required this.viewModel,
  });

  final LearningViewModel viewModel;

  @override
  State<ChangePasswordScreen> createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends State<ChangePasswordScreen> {
  final TextEditingController _oldPassCtrl = TextEditingController();
  final TextEditingController _newPassCtrl = TextEditingController();
  final TextEditingController _confirmPassCtrl = TextEditingController();

  bool _obscureAll = true;
  String? _errorText;

  @override
  void dispose() {
    _oldPassCtrl.dispose();
    _newPassCtrl.dispose();
    _confirmPassCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    FocusScope.of(context).unfocus();
    setState(() => _errorText = null);

    if (_newPassCtrl.text != _confirmPassCtrl.text) {
      setState(() => _errorText = 'Xác nhận mật khẩu mới không khớp.');
      return;
    }

    final res = await widget.viewModel.changePassword(
      oldPassword: _oldPassCtrl.text,
      newPassword: _newPassCtrl.text,
    );
    if (!mounted) return;
    if (res.ok) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(res.message)),
      );
      Navigator.of(context).pop();
    } else {
      setState(() => _errorText = res.message);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.viewModel,
      builder: (context, _) {
        final p = AppPalette.of(context);
        final user = widget.viewModel.state?.user;
        final busy = widget.viewModel.isBusy;

        return Scaffold(
          appBar: AppBar(
            title: const Text(
              'Đổi mật khẩu',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18),
            ),
          ),
          body: SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: p.card,
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: p.border),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    Text(
                      'Tài khoản: ${user?.email ?? ""}',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 13.5,
                        color: p.primary,
                      ),
                    ),
                    const SizedBox(height: 16),

                    Text(
                      'Mật khẩu hiện tại',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 13,
                        color: p.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 6),
                    TextField(
                      key: const Key('old_password_field'),
                      controller: _oldPassCtrl,
                      obscureText: _obscureAll,
                      textInputAction: TextInputAction.next,
                      decoration: InputDecoration(
                        prefixIcon: const Icon(Icons.lock_outline_rounded),
                        hintText: 'Nhập mật khẩu hiện tại',
                        suffixIcon: IconButton(
                          onPressed: () =>
                              setState(() => _obscureAll = !_obscureAll),
                          icon: Icon(
                            _obscureAll
                                ? Icons.visibility_outlined
                                : Icons.visibility_off_outlined,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),

                    Text(
                      'Mật khẩu mới',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 13,
                        color: p.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 6),
                    TextField(
                      key: const Key('new_password_field'),
                      controller: _newPassCtrl,
                      obscureText: _obscureAll,
                      textInputAction: TextInputAction.next,
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.lock_rounded),
                        hintText: 'Tối thiểu 6 ký tự',
                      ),
                    ),
                    const SizedBox(height: 14),

                    Text(
                      'Xác nhận mật khẩu mới',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 13,
                        color: p.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 6),
                    TextField(
                      key: const Key('confirm_password_field'),
                      controller: _confirmPassCtrl,
                      obscureText: _obscureAll,
                      onSubmitted: (_) => busy ? null : _submit(),
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.verified_outlined),
                        hintText: 'Nhập lại mật khẩu mới',
                      ),
                    ),

                    if (_errorText != null) ...<Widget>[
                      const SizedBox(height: 14),
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: p.danger.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: p.danger),
                        ),
                        child: Text(
                          _errorText!,
                          style: TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w700,
                            color: p.danger,
                          ),
                        ),
                      ),
                    ],

                    const SizedBox(height: 20),
                    SizedBox(
                      height: 52,
                      child: ElevatedButton(
                        key: const Key('change_password_submit_btn'),
                        onPressed: busy ? null : _submit,
                        child: busy
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2.2,
                                  color: Colors.white,
                                ),
                              )
                            : const Text('Cập nhật mật khẩu'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
