import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../data/services/speech_tts_service.dart';
import '../theme/app_theme.dart';
import '../widgets/duolingo_kit.dart';

class _IpaSoundItem {
  const _IpaSoundItem({
    required this.symbol,
    required this.word,
    required this.sampleSentence,
    required this.tipVi,
  });

  final String symbol;
  final String word;
  final String sampleSentence;
  final String tipVi;
}

/// Duolingo-inspired 3-Column IPA Phonetics Grid with multi-character voices
/// (Nam/Nữ/Bé trai/Bé gái/Người lớn) and per-sound mastery progress bars.
class PhoneticsGridScreen extends StatefulWidget {
  const PhoneticsGridScreen({
    super.key,
    required this.tts,
  });

  final SpeechTtsService tts;

  @override
  State<PhoneticsGridScreen> createState() => _PhoneticsGridScreenState();
}

class _PhoneticsGridScreenState extends State<PhoneticsGridScreen> {
  static const List<_IpaSoundItem> _sounds = <_IpaSoundItem>[
    _IpaSoundItem(
      symbol: 'f',
      word: 'fish',
      sampleSentence: 'Fresh fish for Friday.',
      tipVi: 'Răng trên chạm nhẹ môi dưới rồi thổi hơi ra.',
    ),
    _IpaSoundItem(
      symbol: 'g',
      word: 'go',
      sampleSentence: 'Let us go to the garden.',
      tipVi: 'Nâng cuống lưỡi chạm vòm mềm và bật âm hữu thanh.',
    ),
    _IpaSoundItem(
      symbol: 'h',
      word: 'home',
      sampleSentence: 'Hello, welcome home.',
      tipVi: 'Thở hơi nhẹ từ cổ họng, không rung dây thanh.',
    ),
    _IpaSoundItem(
      symbol: 'θ',
      word: 'think',
      sampleSentence: 'Thank you for thinking.',
      tipVi: 'Đặt đầu lưỡi giữa hai hàm răng và thổi hơi nhẹ.',
    ),
    _IpaSoundItem(
      symbol: 'ʃ',
      word: 'ship',
      sampleSentence: 'She sells seashells.',
      tipVi: 'Chu môi tròn về phía trước, đẩy luồng hơi êm.',
    ),
    _IpaSoundItem(
      symbol: 'tʃ',
      word: 'chair',
      sampleSentence: 'Choose a comfortable chair.',
      tipVi: 'Bật nhanh âm /t/ nối liền sang âm /ʃ/.',
    ),
    _IpaSoundItem(
      symbol: 'dʒ',
      word: 'jump',
      sampleSentence: 'Junior likes orange juice.',
      tipVi: 'Giống /tʃ/ nhưng rung cổ họng (hữu thanh).',
    ),
    _IpaSoundItem(
      symbol: 'r',
      word: 'red',
      sampleSentence: 'Read the red book right now.',
      tipVi: 'Cuộn nhẹ đầu lưỡi vào trong, không chạm vòm miệng.',
    ),
    _IpaSoundItem(
      symbol: 'l',
      word: 'lion',
      sampleSentence: 'Listen to the lovely music.',
      tipVi: 'Đầu lưỡi chạm chân răng trên, hơi thoát hai bên lưỡi.',
    ),
    _IpaSoundItem(
      symbol: 'æ',
      word: 'cat',
      sampleSentence: 'That black cat is happy.',
      tipVi: 'Mở rộng miệng như đọc "a" nhưng giữ âm hướng về "e".',
    ),
    _IpaSoundItem(
      symbol: 'iː',
      word: 'see',
      sampleSentence: 'Please drink green tea.',
      tipVi: 'Kéo khóe miệng cười rộng, kéo dài âm "i".',
    ),
    _IpaSoundItem(
      symbol: 'uː',
      word: 'food',
      sampleSentence: 'Good afternoon at school.',
      tipVi: 'Tròn môi nhỏ và kéo dài âm "u".',
    ),
  ];

  final Map<String, double> _mastery = <String, double>{
    'f': 0.55,
    'g': 0.40,
    'h': 0.70,
    'θ': 0.25,
    'ʃ': 0.35,
    'tʃ': 0.30,
    'dʒ': 0.20,
    'r': 0.45,
    'l': 0.60,
    'æ': 0.30,
    'iː': 0.65,
    'uː': 0.50,
  };

  _IpaSoundItem _selected = _sounds.first;

  void _practiceSound(_IpaSoundItem item, {bool slow = false}) {
    HapticFeedback.selectionClick();
    setState(() {
      _selected = item;
      final cur = _mastery[item.symbol] ?? 0.2;
      _mastery[item.symbol] = (cur + 0.15).clamp(0.0, 1.0);
    });
    widget.tts.speak(
      '${item.word}. ${item.sampleSentence}',
      id: 'ipa_${item.symbol}_${slow ? "s" : "n"}',
      slow: slow,
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    return Scaffold(
      backgroundColor: p.bg,
      appBar: AppBar(
        title: const Text(
          '🔤 Bảng Phát Âm IPA',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 28),
          children: <Widget>[
            Text(
              'Chọn giọng đọc nhân vật (Nam / Nữ / Trẻ nhỏ / Người lớn):',
              style: TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w800,
                color: p.textSecondary,
              ),
            ),
            const SizedBox(height: 8),
            VoicePersonaPickerBar(
              tts: widget.tts,
              sampleText: _selected.sampleSentence,
            ),
            const SizedBox(height: 14),

            // Selected IPA Detail Card
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: p.card,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: p.primary, width: 1.6),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: p.primary.withValues(alpha: 0.16),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          '/${_selected.symbol}/',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w900,
                            color: p.primary,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              _selected.word,
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w900,
                                color: p.textPrimary,
                              ),
                            ),
                            Text(
                              _selected.sampleSentence,
                              style: TextStyle(
                                fontSize: 13,
                                color: p.textSecondary,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    '💡 Cách đặt khẩu hình: ${_selected.tipVi}',
                    style: TextStyle(
                      fontSize: 12.5,
                      color: p.textPrimary,
                      height: 1.4,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: Tactile3DButton(
                          label: 'NGHE CHUẨN',
                          icon: Icons.volume_up_rounded,
                          color: p.primary,
                          height: 44,
                          onPressed: () => _practiceSound(_selected),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Tactile3DButton(
                          label: '🐢 NGHE CHẬM',
                          color: p.gold,
                          height: 44,
                          onPressed: () =>
                              _practiceSound(_selected, slow: true),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // 3-Column IPA Grid
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _sounds.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                crossAxisSpacing: 10,
                mainAxisSpacing: 12,
                childAspectRatio: 0.96,
              ),
              itemBuilder: (context, idx) {
                final item = _sounds[idx];
                final selected = item.symbol == _selected.symbol;
                final progress = _mastery[item.symbol] ?? 0.25;
                return GestureDetector(
                  key: Key('ipa_tile_${item.word}'),
                  onTap: () => _practiceSound(item),
                  child: Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: selected
                          ? p.primary.withValues(alpha: 0.14)
                          : p.card,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: selected ? p.primary : p.border,
                        width: selected ? 2 : 1.5,
                      ),
                      boxShadow: <BoxShadow>[
                        BoxShadow(
                          color: selected ? p.primary : p.border,
                          offset: const Offset(0, 3),
                          blurRadius: 0,
                        ),
                      ],
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Text(
                          item.symbol,
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w900,
                            color: selected ? p.primary : p.textPrimary,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          item.word,
                          style: TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w700,
                            color: p.textSecondary,
                          ),
                        ),
                        const SizedBox(height: 8),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(999),
                          child: LinearProgressIndicator(
                            value: progress,
                            minHeight: 6,
                            backgroundColor: p.border.withValues(alpha: 0.5),
                            valueColor: AlwaysStoppedAnimation<Color>(
                              progress >= 0.85 ? p.gold : p.success,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
