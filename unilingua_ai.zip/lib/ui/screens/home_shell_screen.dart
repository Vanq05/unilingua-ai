import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../data/repositories/curriculum_repository.dart';
import '../../data/services/app_update_service.dart';
import '../../domain/models/learning_models.dart';
import '../theme/app_theme.dart';
import '../view_models/learning_view_model.dart';
import '../widgets/competency_overview_card.dart';
import '../widgets/duolingo_kit.dart';
import 'change_password_screen.dart';
import 'chat_tab_screen.dart';
import 'daily_workout_sheet.dart';
import 'interactive_lesson_screen.dart';
import 'phonetics_grid_screen.dart';
import 'placement_test_screen.dart';
import 'skills/listening_screen.dart';
import 'skills/reading_screen.dart';
import 'skills/speaking_screen.dart';
import 'skills/writing_screen.dart';

/// Main Duolingo-style 5-Tab Shell:
/// 0: Trang chủ (Overview, Competency Radar, Daily Quests, Drive Sync Pill)
/// 1: Bài tập (Daily 5-question Workout, Vocab, Listening, Speaking, Reading, Writing)
/// 2: Lộ trình (Adaptive Weekly Path, Daily Schedule & Placement Retake)
/// 3: Trò chuyện bạn bè (Peer/Study Buddy English Chat + Mic with VN Proper Nouns)
/// 4: Profile (Personal Info, Edit Profile, Auto Google Drive Sync Status, Theme, Update, Logout)
class HomeShellScreen extends StatefulWidget {
  const HomeShellScreen({
    super.key,
    required this.viewModel,
  });

  final LearningViewModel viewModel;

  @override
  State<HomeShellScreen> createState() => _HomeShellScreenState();
}

class _HomeShellScreenState extends State<HomeShellScreen> {
  int _currentTab = 0;
  // Sub-module index inside Tab 1 ("Bài tập"):
  // 0: Bài tập 5 câu (Bài 1), 1: Nghe, 2: Nói AI, 3: Đọc, 4: Viết AI
  int _exerciseModeIndex = 0;

  void _openExerciseModule(int modeIndex) {
    widget.viewModel.tts.stop();
    widget.viewModel.voiceRecorder.stopListening();
    setState(() {
      _exerciseModeIndex = modeIndex;
      _currentTab = 1;
    });
  }

  void _navigateToSkillExercise(SkillType skill) {
    switch (skill) {
      case SkillType.listening:
        _openExerciseModule(1);
        break;
      case SkillType.speaking:
        _openExerciseModule(2);
        break;
      case SkillType.reading:
        _openExerciseModule(3);
        break;
      case SkillType.writing:
        _openExerciseModule(4);
        break;
    }
  }

  void _exitExerciseToHome() {
    widget.viewModel.tts.stop();
    widget.viewModel.voiceRecorder.stopListening();
    setState(() => _currentTab = 0);
  }

  void _openRetakePlacement() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => PlacementTestScreen(
          viewModel: widget.viewModel,
          isRetake: true,
        ),
      ),
    );
  }

  Future<void> _showEditAccountProfileDialog(GoogleUserProfile user) async {
    final msg = await showDialog<String>(
      context: context,
      builder: (_) => _EditAccountProfileDialog(
        viewModel: widget.viewModel,
        initialFullName: user.displayName,
        initialUsername: user.effectiveUsername,
      ),
    );
    if (msg != null && msg.isNotEmpty && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(msg)),
      );
    }
  }

  Future<void> _showEditProfileDialog(GoogleUserProfile user) async {
    final p = AppPalette.of(context);
    final nameCtrl = TextEditingController(text: user.displayName);
    final ageCtrl = TextEditingController(text: '${user.age}');
    var chosenLevel = user.selfAssessedLevel;

    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          backgroundColor: p.card,
          title: const Text(
            'Chỉnh sửa Hồ sơ Học tập',
            style: TextStyle(fontWeight: FontWeight.w800),
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                TextField(
                  controller: nameCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Tên của bạn',
                    prefixIcon: Icon(Icons.person_outline_rounded),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: ageCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Tuổi',
                    prefixIcon: Icon(Icons.cake_outlined),
                  ),
                ),
                const SizedBox(height: 14),
                Text(
                  'Trình độ hiện tại:',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                    color: p.textSecondary,
                  ),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: GoogleUserProfile.levelOptions.map((lvl) {
                    final selected = chosenLevel == lvl;
                    return ChoiceChip(
                      label: Text(
                        lvl,
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          color: selected ? Colors.white : p.textPrimary,
                        ),
                      ),
                      selected: selected,
                      selectedColor: p.primary,
                      onSelected: (_) =>
                          setDialogState(() => chosenLevel = lvl),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: const Text('Hủy'),
            ),
            ElevatedButton(
              onPressed: () async {
                final age = int.tryParse(ageCtrl.text.trim()) ?? user.age;
                await widget.viewModel.updateUserProfileInfo(
                  displayName: nameCtrl.text,
                  age: age,
                  selfAssessedLevel: chosenLevel,
                );
                if (!ctx.mounted) return;
                Navigator.of(ctx).pop();
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Đã cập nhật hồ sơ & tự đồng bộ Google Drive!'),
                  ),
                );
              },
              child: const Text('Lưu thay đổi'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      _buildHomeTab(),
      _buildExercisesHubTab(),
      _buildRoadmapTab(),
      _buildFriendsChatTab(),
      _buildProfileTab(),
    ];

    return ListenableBuilder(
      listenable: widget.viewModel,
      builder: (context, _) {
        final p = AppPalette.of(context);
        final boost = widget.viewModel.latestSkillBoost;
        final state = widget.viewModel.state!;

        return Scaffold(
          body: Column(
            children: <Widget>[
              if (boost != null && _currentTab != 0)
                SafeArea(
                  bottom: false,
                  child: Container(
                    margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: p.success.withValues(alpha: 0.14),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: p.success),
                    ),
                    child: Row(
                      children: <Widget>[
                        SizedBox(
                          width: 34,
                          height: 34,
                          child: Stack(
                            alignment: Alignment.center,
                            children: <Widget>[
                              CircularProgressIndicator(
                                value: (boost.newScore / 100).clamp(0.0, 1.0),
                                strokeWidth: 4,
                                backgroundColor: p.surface,
                                valueColor:
                                    AlwaysStoppedAnimation<Color>(p.success),
                              ),
                              Text(
                                '${boost.newScore}%',
                                style: TextStyle(
                                  fontSize: 9.5,
                                  fontWeight: FontWeight.w900,
                                  color: p.success,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            '🎉 ${boost.skill.shortVi}: ${boost.previousScore}% (${boost.newScore}%, +${boost.delta}%) • Tổng ${state.overallCompetencyPercent}%',
                            style: TextStyle(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w800,
                              color: p.success,
                            ),
                          ),
                        ),
                        IconButton(
                          visualDensity: VisualDensity.compact,
                          onPressed: widget.viewModel.clearLatestSkillBoost,
                          icon: Icon(
                            Icons.close_rounded,
                            size: 16,
                            color: p.success,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              Expanded(
                child: IndexedStack(
                  index: _currentTab,
                  children: pages,
                ),
              ),
            ],
          ),
          bottomNavigationBar: NavigationBar(
            height: 68,
            selectedIndex: _currentTab,
            labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
            onDestinationSelected: (idx) {
              widget.viewModel.tts.stop();
              widget.viewModel.voiceRecorder.stopListening();
              setState(() => _currentTab = idx);
            },
            backgroundColor: p.surface,
            indicatorColor: p.primary.withValues(alpha: 0.16),
            destinations: <NavigationDestination>[
              NavigationDestination(
                icon: const Icon(Icons.home_outlined),
                selectedIcon: Icon(Icons.home_rounded, color: p.primary),
                label: 'Trang chủ',
              ),
              NavigationDestination(
                icon: const Icon(Icons.fitness_center_outlined),
                selectedIcon:
                    Icon(Icons.fitness_center_rounded, color: p.primary),
                label: 'Bài tập',
              ),
              NavigationDestination(
                icon: const Icon(Icons.map_outlined),
                selectedIcon: Icon(Icons.map_rounded, color: p.primary),
                label: 'Lộ trình',
              ),
              NavigationDestination(
                icon: const Icon(Icons.forum_outlined),
                selectedIcon: Icon(Icons.forum_rounded, color: p.primary),
                label: 'Trò chuyện',
              ),
              NavigationDestination(
                icon: const Icon(Icons.person_outline_rounded),
                selectedIcon: Icon(Icons.person_rounded, color: p.primary),
                label: 'Cá nhân',
              ),
            ],
          ),
        );
      },
    );
  }

  // ==================== TAB 0: TRANG CHỦ ====================

  Widget _buildHomeTab() {
    return ListenableBuilder(
      listenable: widget.viewModel,
      builder: (context, _) {
        final p = AppPalette.of(context);
        final state = widget.viewModel.state!;
        final boost = widget.viewModel.latestSkillBoost;
        final update = widget.viewModel.availableUpdate;

        return SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                // Header: Avatar + Greeting + Auto Google Drive Status Badge + Streak
                Row(
                  children: <Widget>[
                    Expanded(
                      child: InkWell(
                        borderRadius: BorderRadius.circular(14),
                        onTap: () => setState(() => _currentTab = 4),
                        child: Row(
                          children: <Widget>[
                            CircleAvatar(
                              radius: 22,
                              backgroundColor: p.primary,
                              child: Text(
                                state.user.initials,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    'Chào ${state.user.displayName}!',
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      fontSize: 16,
                                      color: p.textPrimary,
                                    ),
                                  ),
                                  Text(
                                    '⚡ Supabase Realtime • @${state.user.effectiveUsername}',
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w700,
                                      color: p.primary,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFF6B35).withValues(alpha: 0.14),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Row(
                        children: <Widget>[
                          const Icon(
                            Icons.local_fire_department_rounded,
                            color: Color(0xFFFF6B35),
                            size: 16,
                          ),
                          const SizedBox(width: 3),
                          Text(
                            '${state.streakDays}',
                            style: const TextStyle(
                              fontWeight: FontWeight.w900,
                              fontSize: 12.5,
                              color: Color(0xFFFF6B35),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: p.gold.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        '${state.totalXp} XP',
                        style: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 12,
                          color: p.gold,
                        ),
                      ),
                    ),
                  ],
                ),

                if (update != null) ...<Widget>[
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 10,
                    ),
                    decoration: BoxDecoration(
                      color: p.success.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: p.success),
                    ),
                    child: Row(
                      children: <Widget>[
                        Icon(Icons.system_update_rounded, color: p.success),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'Có bản mới v${update.latestVersion} (Cài đè trực tiếp)',
                            style: TextStyle(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w700,
                              color: p.textPrimary,
                            ),
                          ),
                        ),
                        TextButton(
                          onPressed: widget.viewModel.openAvailableUpdate,
                          child: Text(
                            'Cập nhật',
                            style: TextStyle(
                              color: p.success,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
                const SizedBox(height: 14),

                // Duolingo-style Unit Header + Winding 3D Lesson Path
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: p.success,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: <BoxShadow>[
                      BoxShadow(
                        color: const Color(0xFF3E9400),
                        offset: const Offset(0, 4),
                        blurRadius: 0,
                      ),
                    ],
                  ),
                  child: Row(
                    children: <Widget>[
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              'PHẦN 1, CỬA 1',
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 11.5,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 0.8,
                              ),
                            ),
                            SizedBox(height: 2),
                            Text(
                              'Học tương tác kiểu Duolingo (5 Mini-Game)',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 15.5,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ],
                        ),
                      ),
                      IconButton.filled(
                        key: const Key('home_open_ipa_btn'),
                        tooltip: 'Bảng Phát Âm IPA',
                        onPressed: () {
                          Navigator.of(context).push(
                            MaterialPageRoute<void>(
                              builder: (_) => PhoneticsGridScreen(
                                tts: widget.viewModel.tts,
                              ),
                            ),
                          );
                        },
                        style: IconButton.styleFrom(
                          backgroundColor: Colors.white.withValues(alpha: 0.22),
                          foregroundColor: Colors.white,
                        ),
                        icon: const Icon(Icons.record_voice_over_rounded),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),

                // Winding 3D Lesson Nodes
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 16,
                  ),
                  decoration: BoxDecoration(
                    color: p.card,
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: p.border, width: 1.4),
                  ),
                  child: Column(
                    children: <Widget>[
                      _WindingPathNode(
                        nodeKey: const Key('home_duolingo_node_0'),
                        alignment: const Alignment(-0.45, 0),
                        emoji: '🍵',
                        title: 'Cửa 1: Mời khách & Đồ uống',
                        subtitle: 'Word Bank • Nối cặp • Nghe chậm • Nói',
                        color: p.success,
                        onTap: () {
                          Navigator.of(context).push(
                            MaterialPageRoute<void>(
                              builder: (_) => InteractiveLessonScreen(
                                viewModel: widget.viewModel,
                                unitIndex: 0,
                                unitTitle: 'Phần 1, Cửa 1: Mời khách & Đồ uống',
                              ),
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 12),
                      _WindingPathNode(
                        nodeKey: const Key('home_duolingo_node_1'),
                        alignment: const Alignment(0.45, 0),
                        emoji: '💼',
                        title: 'Cửa 2: Công sở & Thuyết trình',
                        subtitle: 'Giọng Nam trầm Falstaff • Roleplay AI',
                        color: p.primary,
                        onTap: () {
                          Navigator.of(context).push(
                            MaterialPageRoute<void>(
                              builder: (_) => InteractiveLessonScreen(
                                viewModel: widget.viewModel,
                                unitIndex: 1,
                                unitTitle: 'Phần 1, Cửa 2: Công sở & Thuyết trình',
                              ),
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 12),
                      _WindingPathNode(
                        nodeKey: const Key('home_ipa_node'),
                        alignment: const Alignment(-0.2, 0),
                        emoji: '🔤',
                        title: 'Lưới Phát Âm IPA (12 âm chuẩn)',
                        subtitle: '6 giọng đọc Nam/Nữ/Trẻ nhỏ/Người lớn',
                        color: p.secondary,
                        onTap: () {
                          Navigator.of(context).push(
                            MaterialPageRoute<void>(
                              builder: (_) => PhoneticsGridScreen(
                                tts: widget.viewModel.tts,
                              ),
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),

                // Multi-Character Contextual Voice Selector
                Text(
                  '🎙️ Chọn Giọng Đọc Nhân Vật (chạm để nghe thử)',
                  style: TextStyle(
                    fontSize: 13.5,
                    fontWeight: FontWeight.w800,
                    color: p.textSecondary,
                  ),
                ),
                const SizedBox(height: 8),
                VoicePersonaPickerBar(tts: widget.viewModel.tts),
                const SizedBox(height: 16),

                // Competency Radar & Overall Progress Card
                CompetencyOverviewCard(
                  listeningScore: state.listeningSkillScore,
                  speakingScore: state.speakingSkillScore,
                  readingScore: state.readingSkillScore,
                  writingScore: state.writingSkillScore,
                  cefrLevel: state.currentCefr,
                  estimatedIelts: state.currentIelts,
                  estimatedToeic: state.currentToeic,
                  latestBoost: boost,
                  onDismissBoost: widget.viewModel.clearLatestSkillBoost,
                  onSkillTap: _navigateToSkillExercise,
                ),
                const SizedBox(height: 16),

                // Duolingo-style Quick 4-Skill Launch Grid (Lives on Home, NOT duplicated in Taskbar!)
                Text(
                  '🎯 Luyện 4 Kỹ Năng Trọng Tâm',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    color: p.textPrimary,
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: _HomeSkillLaunchCard(
                        icon: Icons.headphones_rounded,
                        title: 'Nghe (Listen)',
                        subtitle: 'Audio & Câu hỏi Anh ngữ',
                        color: const Color(0xFF0284C7),
                        onTap: () => _openExerciseModule(1),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _HomeSkillLaunchCard(
                        icon: Icons.mic_rounded,
                        title: 'Nói AI (Speak)',
                        subtitle: 'Chấm phát âm & Tên Việt',
                        color: const Color(0xFFF59E0B),
                        onTap: () => _openExerciseModule(2),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: _HomeSkillLaunchCard(
                        icon: Icons.menu_book_rounded,
                        title: 'Đọc (Read)',
                        subtitle: 'Song ngữ & Từ vựng',
                        color: const Color(0xFF10B981),
                        onTap: () => _openExerciseModule(3),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _HomeSkillLaunchCard(
                        icon: Icons.edit_note_rounded,
                        title: 'Viết AI (Write)',
                        subtitle: 'Sửa câu & Chấm Band',
                        color: const Color(0xFF6366F1),
                        onTap: () => _openExerciseModule(4),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                // Daily Quests Card
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: p.card,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: p.border),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: Row(
                              children: <Widget>[
                                Flexible(
                                  child: Text(
                                    '✅ Nhiệm vụ hôm nay',
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      fontSize: 15.5,
                                      fontWeight: FontWeight.w800,
                                      color: p.textPrimary,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 8,
                                    vertical: 2,
                                  ),
                                  decoration: BoxDecoration(
                                    color: p.primary.withValues(alpha: 0.14),
                                    borderRadius: BorderRadius.circular(999),
                                  ),
                                  child: Text(
                                    '${state.completedQuestsCount}/${state.dailyQuests.length}',
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w800,
                                      color: p.primary,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          TextButton(
                            onPressed: () => _openExerciseModule(0),
                            child: const Text(
                              'Làm Bài 1 ngay',
                              style: TextStyle(
                                fontSize: 12.5,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const Divider(height: 12),
                      ...state.dailyQuests.map(
                        (quest) => InkWell(
                          borderRadius: BorderRadius.circular(10),
                          onTap: () => _navigateToSkillExercise(quest.skill),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8),
                            child: Row(
                              children: <Widget>[
                                Icon(
                                  quest.isCompleted
                                      ? Icons.check_circle_rounded
                                      : Icons.radio_button_unchecked_rounded,
                                  size: 22,
                                  color: quest.isCompleted
                                      ? p.success
                                      : p.textSecondary,
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    quest.title,
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w700,
                                      decoration: quest.isCompleted
                                          ? TextDecoration.lineThrough
                                          : null,
                                      color: quest.isCompleted
                                          ? p.textSecondary
                                          : p.textPrimary,
                                    ),
                                  ),
                                ),
                                Text(
                                  quest.isCompleted ? 'Xong' : 'Bắt đầu',
                                  style: TextStyle(
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w800,
                                    color: quest.isCompleted
                                        ? p.success
                                        : p.primary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ==================== TAB 1: BÀI TẬP (HUB TẤT CẢ BÀI TẬP) ====================

  Widget _buildExercisesHubTab() {
    final p = AppPalette.of(context);
    const modes = <({String label, IconData icon})>[
      (label: 'Bài 1 • Hằng ngày', icon: Icons.local_fire_department_rounded),
      (label: 'Nghe', icon: Icons.headphones_rounded),
      (label: 'Nói AI', icon: Icons.mic_rounded),
      (label: 'Đọc', icon: Icons.menu_book_rounded),
      (label: 'Viết AI', icon: Icons.edit_note_rounded),
    ];

    Widget activeView;
    switch (_exerciseModeIndex) {
      case 1:
        activeView = ListeningScreen(
          viewModel: widget.viewModel,
          onExitToHome: _exitExerciseToHome,
        );
        break;
      case 2:
        activeView = SpeakingScreen(
          viewModel: widget.viewModel,
          onExitToHome: _exitExerciseToHome,
        );
        break;
      case 3:
        activeView = ReadingScreen(
          viewModel: widget.viewModel,
          onExitToHome: _exitExerciseToHome,
        );
        break;
      case 4:
        activeView = WritingScreen(
          viewModel: widget.viewModel,
          onExitToHome: _exitExerciseToHome,
        );
        break;
      default:
        activeView = DailyWorkoutScreen(
          viewModel: widget.viewModel,
          embedded: true,
          onExitToHome: _exitExerciseToHome,
        );
    }

    return SafeArea(
      child: Column(
        children: <Widget>[
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 8),
            decoration: BoxDecoration(
              color: p.surface,
              border: Border(bottom: BorderSide(color: p.border)),
            ),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: List<Widget>.generate(modes.length, (idx) {
                  final m = modes[idx];
                  final selected = _exerciseModeIndex == idx;
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      avatar: Icon(
                        m.icon,
                        size: 16,
                        color: selected ? Colors.white : p.primary,
                      ),
                      label: Text(
                        m.label,
                        style: TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w800,
                          color: selected ? Colors.white : p.textPrimary,
                        ),
                      ),
                      selected: selected,
                      selectedColor: p.primary,
                      onSelected: (_) => _openExerciseModule(idx),
                    ),
                  );
                }),
              ),
            ),
          ),
          Expanded(child: activeView),
        ],
      ),
    );
  }

  // ==================== TAB 2: LỘ TRÌNH ====================

  Widget _buildRoadmapTab() {
    return ListenableBuilder(
      listenable: widget.viewModel,
      builder: (context, _) {
        final p = AppPalette.of(context);
        final state = widget.viewModel.state!;
        final placement = state.placementResult;

        return SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            '🗺️ Lộ trình Học Tập Cá Nhân',
                            style: TextStyle(
                              fontSize: 19,
                              fontWeight: FontWeight.w900,
                              color: p.textPrimary,
                            ),
                          ),
                          Text(
                            'Dành riêng cho ${state.user.displayName} (${state.user.age} tuổi • ${state.user.selfAssessedLevel})',
                            style: TextStyle(
                              fontSize: 12.5,
                              color: p.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ),
                    OutlinedButton.icon(
                      onPressed: _openRetakePlacement,
                      icon: const Icon(Icons.shuffle_rounded, size: 17),
                      label: const Text('Test lại'),
                    ),
                  ],
                ),
                const SizedBox(height: 14),

                Text(
                  'Số tuần hoàn thành mục tiêu:',
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 13.5,
                    color: p.textPrimary,
                  ),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: CurriculumRepository.targetWeekOptions.map((weeks) {
                    final selected = state.user.targetWeeks == weeks;
                    return ChoiceChip(
                      visualDensity: VisualDensity.compact,
                      label: Text(
                        '$weeks tuần',
                        style: TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w800,
                          color: selected ? Colors.white : p.textPrimary,
                        ),
                      ),
                      selected: selected,
                      selectedColor: p.primary,
                      onSelected: (_) =>
                          widget.viewModel.updateStudyPlan(targetWeeks: weeks),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 12),

                Text(
                  'Thời lượng học mỗi ngày:',
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 13.5,
                    color: p.textPrimary,
                  ),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children:
                      CurriculumRepository.dailyMinuteOptions.map((mins) {
                    final selected = state.user.dailyTargetMinutes == mins;
                    return ChoiceChip(
                      visualDensity: VisualDensity.compact,
                      label: Text(
                        '$mins phút/ngày',
                        style: TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w800,
                          color: selected ? Colors.white : p.textPrimary,
                        ),
                      ),
                      selected: selected,
                      selectedColor: p.secondary,
                      onSelected: (_) => widget.viewModel
                          .updateStudyPlan(dailyTargetMinutes: mins),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 16),

                if (placement != null &&
                    placement.dailySchedule.isNotEmpty) ...<Widget>[
                  Text(
                    '⏱️ Lịch chia thời gian hôm nay (${state.user.dailyTargetMinutes} phút):',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      color: p.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 8),
                  ...placement.dailySchedule.map(
                    (slot) => Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(14),
                        onTap: () => _navigateToSkillExercise(slot.skill),
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: p.card,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: p.border),
                          ),
                          child: Row(
                            children: <Widget>[
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 6,
                                ),
                                decoration: BoxDecoration(
                                  color: p.primary.withValues(alpha: 0.12),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Text(
                                  '${slot.minutes}p',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w900,
                                    color: p.primary,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Text(
                                      slot.activityTitle,
                                      style: TextStyle(
                                        fontWeight: FontWeight.w800,
                                        fontSize: 13.5,
                                        color: p.textPrimary,
                                      ),
                                    ),
                                    Text(
                                      slot.detail,
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: p.textSecondary,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Icon(Icons.play_circle_fill_rounded,
                                  color: p.primary),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                ],

                Text(
                  '🏁 Các chặng Lộ trình (${state.user.targetWeeks} tuần):',
                  style: TextStyle(
                    fontSize: 15.5,
                    fontWeight: FontWeight.w800,
                    color: p.textPrimary,
                  ),
                ),
                const SizedBox(height: 10),
                if (placement != null)
                  ...placement.roadmapPhases.asMap().entries.map((entry) {
                    final idx = entry.key;
                    final phase = entry.value;
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Container(
                        padding: const EdgeInsets.all(15),
                        decoration: BoxDecoration(
                          color: p.card,
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(
                            color: idx == 0 ? p.primary : p.border,
                            width: idx == 0 ? 1.6 : 1,
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Row(
                              children: <Widget>[
                                CircleAvatar(
                                  radius: 13,
                                  backgroundColor:
                                      idx == 0 ? p.primary : p.cardElevated,
                                  child: Text(
                                    '${idx + 1}',
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w900,
                                      color: idx == 0
                                          ? Colors.white
                                          : p.textPrimary,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    phase.weekRange,
                                    style: TextStyle(
                                      color: p.primary,
                                      fontWeight: FontWeight.w800,
                                      fontSize: 12.5,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),
                            Text(
                              phase.title,
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w800,
                                color: p.textPrimary,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              phase.focusGoal,
                              style: TextStyle(
                                fontSize: 13,
                                color: p.textSecondary,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              '🎯 Cột mốc: ${phase.milestone}',
                              style: TextStyle(
                                fontSize: 12.5,
                                fontWeight: FontWeight.w700,
                                color: p.success,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }),
              ],
            ),
          ),
        );
      },
    );
  }

  // ==================== TAB 3: TRÒ CHUYỆN ====================

  Widget _buildFriendsChatTab() {
    return ChatListScreen(viewModel: widget.viewModel);
  }

  // ==================== TAB 4: CÁ NHÂN (ZALO/TELEGRAM MINIMALIST) ====================

  Widget _buildProfileTab() {
    return ListenableBuilder(
      listenable: widget.viewModel,
      builder: (context, _) {
        final p = AppPalette.of(context);
        final state = widget.viewModel.state!;
        final user = state.user;
        final isDark = widget.viewModel.isDarkMode;
        final notificationsEnabled = widget.viewModel.notificationsEnabled;
        final syncCode = widget.viewModel.exportCloudSyncCode();
        final handleText = '@${user.effectiveUsername}';

        return SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 32),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                // Header nổi bật (Zalo/Telegram style)
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: p.card,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: p.border, width: 1.2),
                  ),
                  child: Row(
                    children: <Widget>[
                      CircleAvatar(
                        radius: 32,
                        backgroundColor: p.primary,
                        child: Text(
                          user.initials,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            fontSize: 22,
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              user.displayName,
                              style: TextStyle(
                                fontSize: 19,
                                fontWeight: FontWeight.w900,
                                color: p.textPrimary,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Row(
                              children: <Widget>[
                                Flexible(
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 10,
                                      vertical: 3,
                                    ),
                                    decoration: BoxDecoration(
                                      color: p.primary.withValues(alpha: 0.12),
                                      borderRadius: BorderRadius.circular(999),
                                    ),
                                    child: Text(
                                      handleText,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontSize: 13,
                                        fontWeight: FontWeight.w800,
                                        color: p.primary,
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 4),
                                IconButton(
                                  key: const Key('profile_copy_username_btn'),
                                  visualDensity: VisualDensity.compact,
                                  tooltip: 'Sao chép @username',
                                  onPressed: () {
                                    Clipboard.setData(
                                      ClipboardData(text: handleText),
                                    );
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text('Đã sao chép $handleText'),
                                      ),
                                    );
                                  },
                                  icon: Icon(
                                    Icons.copy_rounded,
                                    size: 17,
                                    color: p.primary,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 2),
                            Text(
                              user.email,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 12,
                                color: p.textSecondary,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),

                // Nhóm thẻ 1: Tài khoản
                Padding(
                  padding: const EdgeInsets.only(left: 6, bottom: 8),
                  child: Text(
                    'Tài khoản',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      color: p.textSecondary,
                    ),
                  ),
                ),
                Material(
                  color: p.card,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                    side: BorderSide(color: p.border),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Column(
                    children: <Widget>[
                      ListTile(
                        key: const Key('profile_edit_account_tile'),
                        leading: Icon(Icons.manage_accounts_rounded, color: p.primary),
                        title: Text(
                          'Chỉnh sửa thông tin cá nhân',
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 14.5,
                            color: p.textPrimary,
                          ),
                        ),
                        subtitle: Text(
                          'Đổi Tên hiển thị, @username ($handleText)',
                          style: TextStyle(fontSize: 12, color: p.textSecondary),
                        ),
                        trailing: Icon(
                          Icons.chevron_right_rounded,
                          color: p.textSecondary,
                        ),
                        onTap: () => _showEditAccountProfileDialog(user),
                      ),
                      const Divider(height: 1),
                      ListTile(
                        key: const Key('profile_change_password_tile'),
                        leading: Icon(Icons.lock_reset_rounded, color: p.primary),
                        title: Text(
                          'Đổi mật khẩu',
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 14.5,
                            color: p.textPrimary,
                          ),
                        ),
                        subtitle: Text(
                          'Bảo mật SHA-256 & đồng bộ Google Sheets',
                          style: TextStyle(fontSize: 12, color: p.textSecondary),
                        ),
                        trailing: Icon(
                          Icons.chevron_right_rounded,
                          color: p.textSecondary,
                        ),
                        onTap: () {
                          Navigator.of(context).push(
                            MaterialPageRoute<void>(
                              builder: (_) => ChangePasswordScreen(
                                viewModel: widget.viewModel,
                              ),
                            ),
                          );
                        },
                      ),
                      const Divider(height: 1),
                      ListTile(
                        leading: Icon(Icons.school_outlined, color: p.secondary),
                        title: Text(
                          'Hồ sơ học tập (${user.age} tuổi • ${user.selfAssessedLevel})',
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 14,
                            color: p.textPrimary,
                          ),
                        ),
                        subtitle: Text(
                          'CEFR ${state.currentCefr} • Chạm để sửa hoặc làm lại Placement Test',
                          style: TextStyle(fontSize: 12, color: p.textSecondary),
                        ),
                        onTap: () => _showEditProfileDialog(user),
                        trailing: IconButton(
                          tooltip: 'Làm lại bài kiểm tra đầu vào',
                          onPressed: _openRetakePlacement,
                          icon: Icon(Icons.shuffle_rounded, color: p.gold),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),

                // Nhóm thẻ 2: Ứng dụng
                Padding(
                  padding: const EdgeInsets.only(left: 6, bottom: 8),
                  child: Text(
                    'Ứng dụng',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      color: p.textSecondary,
                    ),
                  ),
                ),
                Material(
                  color: p.card,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                    side: BorderSide(color: p.border),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Column(
                    children: <Widget>[
                      SwitchListTile(
                        key: const Key('profile_notification_switch_tile'),
                        secondary: Icon(
                          notificationsEnabled
                              ? Icons.notifications_active_rounded
                              : Icons.notifications_off_outlined,
                          color: p.primary,
                        ),
                        title: Text(
                          'Cài đặt thông báo',
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 14.5,
                            color: p.textPrimary,
                          ),
                        ),
                        subtitle: Text(
                          notificationsEnabled
                              ? 'Nhận nhắc nhở học tập & tin nhắn bạn bè'
                              : 'Đang tắt thông báo',
                          style: TextStyle(fontSize: 12, color: p.textSecondary),
                        ),
                        value: notificationsEnabled,
                        activeColor: p.primary,
                        onChanged: widget.viewModel.setNotificationsEnabled,
                      ),
                      const Divider(height: 1),
                      SwitchListTile(
                        key: const Key('profile_theme_switch_tile'),
                        secondary: Icon(
                          isDark
                              ? Icons.dark_mode_rounded
                              : Icons.wb_sunny_rounded,
                          color: isDark ? p.gold : p.primary,
                        ),
                        title: Text(
                          'Giao diện Sáng / Tối',
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 14.5,
                            color: p.textPrimary,
                          ),
                        ),
                        subtitle: Text(
                          isDark ? 'Chế độ Tối 🌙' : 'Chế độ Sáng ☀️',
                          style: TextStyle(fontSize: 12, color: p.textSecondary),
                        ),
                        value: isDark,
                        activeColor: p.primary,
                        onChanged: widget.viewModel.setDarkMode,
                      ),
                      const Divider(height: 1),
                      ListTile(
                        leading: Icon(Icons.copy_rounded, color: p.secondary),
                        title: Text(
                          'Sao chép Mã Sao Lưu tiến trình',
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 14,
                            color: p.textPrimary,
                          ),
                        ),
                        onTap: () {
                          Clipboard.setData(ClipboardData(text: syncCode));
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Đã sao chép mã sao lưu tiến trình!'),
                            ),
                          );
                        },
                      ),
                      const Divider(height: 1),
                      ListTile(
                        leading: Icon(
                          Icons.system_update_rounded,
                          color: p.success,
                        ),
                        title: Text(
                          'Kiểm tra cập nhật (v${AppUpdateService.currentVersion})',
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 14,
                            color: p.textPrimary,
                          ),
                        ),
                        onTap: () async {
                          final update =
                              await widget.viewModel.checkForAppUpdate();
                          if (!mounted) return;
                          if (update != null) {
                            await widget.viewModel.openAvailableUpdate();
                          } else {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Bạn đang dùng bản mới nhất!'),
                              ),
                            );
                          }
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // Trạng thái Đồng bộ Google Drive gọn gàng
                Container(
                  key: const Key('profile_drive_sync_card'),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: p.primary.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: p.primary.withValues(alpha: 0.5)),
                  ),
                  child: Row(
                    children: <Widget>[
                      Icon(Icons.cloud_done_rounded, color: p.primary),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              widget.viewModel.driveSyncStatus,
                              style: TextStyle(
                                fontSize: 12.5,
                                fontWeight: FontWeight.w700,
                                color: p.textPrimary,
                              ),
                            ),
                            Text(
                              'Cập nhật: ${widget.viewModel.formattedLastDriveSync}',
                              style: TextStyle(
                                fontSize: 11.5,
                                color: p.textSecondary,
                              ),
                            ),
                          ],
                        ),
                      ),
                      TextButton(
                        onPressed: widget.viewModel.isSyncingDrive
                            ? null
                            : () async {
                                final ok = await widget.viewModel
                                    .syncNowToGoogleDrive();
                                if (!mounted) return;
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                      ok
                                          ? '☁️ Đã đồng bộ Google Drive thành công!'
                                          : 'Đã lưu cục bộ — sẽ đồng bộ khi có mạng.',
                                    ),
                                  ),
                                );
                              },
                        child: const Text('Đồng bộ'),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 22),

                // Cuối trang: Nút Đăng xuất màu đỏ nổi bật
                SizedBox(
                  height: 52,
                  child: ElevatedButton.icon(
                    key: const Key('profile_logout_btn'),
                    onPressed: widget.viewModel.signOut,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: p.danger,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                    icon: const Icon(Icons.logout_rounded),
                    label: const Text(
                      'Đăng xuất',
                      style: TextStyle(
                        fontSize: 15.5,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _HomeSkillLaunchCard extends StatelessWidget {
  const _HomeSkillLaunchCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: p.card,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: color.withValues(alpha: 0.4)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.14),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 22),
            ),
            const SizedBox(height: 10),
            Text(
              title,
              style: TextStyle(
                fontWeight: FontWeight.w900,
                fontSize: 14,
                color: p.textPrimary,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              subtitle,
              style: TextStyle(
                fontSize: 11.5,
                color: p.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}


class _EditAccountProfileDialog extends StatefulWidget {
  const _EditAccountProfileDialog({
    required this.viewModel,
    required this.initialFullName,
    required this.initialUsername,
  });

  final LearningViewModel viewModel;
  final String initialFullName;
  final String initialUsername;

  @override
  State<_EditAccountProfileDialog> createState() =>
      _EditAccountProfileDialogState();
}

class _EditAccountProfileDialogState extends State<_EditAccountProfileDialog> {
  late final TextEditingController _nameCtrl;
  late final TextEditingController _handleCtrl;
  String? _dialogError;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController(text: widget.initialFullName);
    _handleCtrl = TextEditingController(text: widget.initialUsername);
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _handleCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    return AlertDialog(
      backgroundColor: p.card,
      title: const Text(
        'Chỉnh sửa thông tin cá nhân',
        style: TextStyle(fontWeight: FontWeight.w800),
      ),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            TextField(
              key: const Key('edit_profile_fullname_field'),
              controller: _nameCtrl,
              decoration: const InputDecoration(
                labelText: 'Tên hiển thị (FullName)',
                prefixIcon: Icon(Icons.person_outline_rounded),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              key: const Key('edit_profile_username_field'),
              controller: _handleCtrl,
              autocorrect: false,
              decoration: const InputDecoration(
                labelText: 'Username (@không dấu)',
                prefixIcon: Icon(Icons.alternate_email_rounded),
              ),
            ),
            if (_dialogError != null) ...<Widget>[
              const SizedBox(height: 10),
              Text(
                _dialogError!,
                style: TextStyle(
                  color: p.danger,
                  fontSize: 12.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ],
        ),
      ),
      actions: <Widget>[
        TextButton(
          onPressed: _saving ? null : () => Navigator.of(context).pop(),
          child: const Text('Hủy'),
        ),
        ElevatedButton(
          key: const Key('edit_profile_save_btn'),
          onPressed: _saving
              ? null
              : () async {
                  setState(() {
                    _saving = true;
                    _dialogError = null;
                  });
                  final res = await widget.viewModel.updateAccountProfile(
                    fullName: _nameCtrl.text,
                    username: _handleCtrl.text,
                  );
                  if (!mounted) return;
                  if (res.ok) {
                    Navigator.of(context).pop(res.message);
                  } else {
                    setState(() {
                      _saving = false;
                      _dialogError = res.message;
                    });
                  }
                },
          child: _saving
              ? const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white,
                  ),
                )
              : const Text('Lưu thay đổi'),
        ),
      ],
    );
  }
}


class _WindingPathNode extends StatelessWidget {
  const _WindingPathNode({
    required this.nodeKey,
    required this.alignment,
    required this.emoji,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  final Key nodeKey;
  final Alignment alignment;
  final String emoji;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    return Align(
      alignment: alignment,
      child: GestureDetector(
        key: nodeKey,
        onTap: () {
          HapticFeedback.lightImpact();
          onTap();
        },
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Container(
              width: 58,
              height: 58,
              decoration: BoxDecoration(
                color: color,
                shape: BoxShape.circle,
                boxShadow: <BoxShadow>[
                  BoxShadow(
                    color: color.withValues(alpha: 0.45),
                    offset: const Offset(0, 5),
                    blurRadius: 0,
                  ),
                ],
              ),
              alignment: Alignment.center,
              child: Text(emoji, style: const TextStyle(fontSize: 26)),
            ),
            const SizedBox(width: 12),
            ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 210),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    title,
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      fontSize: 14,
                      color: p.textPrimary,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 11.5,
                      color: p.textSecondary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
