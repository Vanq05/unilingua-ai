import 'package:flutter/material.dart';

import '../../../domain/models/learning_models.dart';
import '../../theme/app_theme.dart';
import '../../view_models/learning_view_model.dart';
import '../../widgets/lesson_helpers.dart';

class ListeningScreen extends StatefulWidget {
  const ListeningScreen({
    super.key,
    required this.viewModel,
    this.onExitToHome,
  });

  final LearningViewModel viewModel;
  final VoidCallback? onExitToHome;

  @override
  State<ListeningScreen> createState() => _ListeningScreenState();
}

class _ListeningScreenState extends State<ListeningScreen> {
  int _selectedLessonIndex = 0;
  bool _showTranscript = false;
  bool _showTranslation = false;
  final TextEditingController _dictationCtrl = TextEditingController();
  double? _dictationAccuracy;
  final Map<int, int> _quizAnswers = <int, int>{};

  @override
  void dispose() {
    _dictationCtrl.dispose();
    super.dispose();
  }

  void _selectLesson(int index) {
    widget.viewModel.tts.stop();
    setState(() {
      _selectedLessonIndex = index;
      _showTranscript = false;
      _showTranslation = false;
      _dictationCtrl.clear();
      _dictationAccuracy = null;
      _quizAnswers.clear();
    });
  }

  void _checkDictation(String target) {
    final userWords = _dictationCtrl.text
        .toLowerCase()
        .replaceAll(RegExp(r'[^\w\s]'), '')
        .trim()
        .split(RegExp(r'\s+'))
        .where((w) => w.isNotEmpty)
        .toList();
    final targetWords = target
        .toLowerCase()
        .replaceAll(RegExp(r'[^\w\s]'), '')
        .trim()
        .split(RegExp(r'\s+'))
        .where((w) => w.isNotEmpty)
        .toList();

    if (targetWords.isEmpty) return;
    var matched = 0;
    for (final tw in targetWords) {
      if (userWords.contains(tw)) matched++;
    }
    final acc = (matched / targetWords.length).clamp(0.0, 1.0);
    setState(() {
      _dictationAccuracy = acc;
    });

    if (acc >= 0.6) {
      widget.viewModel.recordActivityCompletion(
        questId: 'q_listen',
        skill: SkillType.listening,
        baseXp: 25,
      );
    }
  }

  Future<void> _showAiTopicDialog() async {
    final ctrl = TextEditingController(
      text: 'Ordering food at a restaurant',
    );
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppPalette.of(context).card,
        title: Text('✨ AI Tạo Bài Nghe Mới'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              'Nhập chủ đề giao tiếp bạn muốn nghe:',
              style: TextStyle(
                fontSize: 13,
                color: AppPalette.of(context).textSecondary,
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: ctrl,
              decoration: InputDecoration(
                hintText: 'VD: Hỏi đường, Mua quần áo, Đi du lịch...',
              ),
            ),
          ],
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text('Hủy'),
          ),
          ElevatedButton.icon(
            onPressed: () async {
              final topic = ctrl.text.trim();
              Navigator.of(ctx).pop();
              if (topic.isEmpty) return;
              final created =
                  await widget.viewModel.generateAiListeningLesson(topic);
              if (!mounted) return;
              if (created != null) {
                _selectLesson(0);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Đã tạo bài nghe AI: ${created.title}'),
                  ),
                );
              }
            },
            icon: Icon(Icons.auto_awesome_rounded, size: 18),
            label: Text('Tạo Bài Nghe'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge(<Listenable>[
        widget.viewModel,
        widget.viewModel.tts,
      ]),
      builder: (context, _) {
        final lessons = widget.viewModel.listeningLessons;
        final safeIndex =
            _selectedLessonIndex.clamp(0, lessons.length - 1);
        final lesson = lessons[safeIndex];
        final isPlayingLecture = widget.viewModel.tts.isSpeaking &&
            widget.viewModel.tts.currentSpeakingId == 'lec_${lesson.id}';

        return Scaffold(
          appBar: AppBar(
            title: Text(
              '🎧 Phòng Luyện Nghe (Listening Lab)',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17),
            ),
            actions: <Widget>[
              Padding(
                padding: const EdgeInsets.only(right: 12),
                child: TextButton.icon(
                  onPressed: widget.viewModel.isGeneratingAiContent
                      ? null
                      : _showAiTopicDialog,
                  icon: widget.viewModel.isGeneratingAiContent
                      ? const SizedBox(
                          width: 14,
                          height: 14,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : Icon(
                          Icons.auto_awesome_rounded,
                          color: AppTheme.goldAccent,
                          size: 18,
                        ),
                  label: Text(
                    'AI Tạo Bài',
                    style: TextStyle(
                      color: AppTheme.goldAccent,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
            ],
          ),
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                // Horizontal lesson selector
                SizedBox(
                  height: 82,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: lessons.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 10),
                    itemBuilder: (context, index) {
                      final item = lessons[index];
                      final isSelected = index == safeIndex;
                      return InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: () => _selectLesson(index),
                        child: Container(
                          width: 230,
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? AppPalette.of(context).primary.withValues(alpha: 0.16)
                                : AppPalette.of(context).card,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: isSelected
                                  ? AppPalette.of(context).primary
                                  : AppPalette.of(context).border,
                              width: isSelected ? 1.6 : 1,
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                item.title,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontSize: 13.5,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '${item.cefrLevel} • ${item.category}',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 16),

                // Main Audio Player Card
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: <Color>[AppPalette.of(context).cardElevated, AppPalette.of(context).card]),
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(
                      color: AppPalette.of(context).primary.withValues(alpha: 0.4),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color:
                                  AppPalette.of(context).primary.withValues(alpha: 0.15),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              'CEFR ${lesson.cefrLevel}',
                              style: TextStyle(),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              lesson.category,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(
                        lesson.title,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: () => widget.viewModel.tts.speak(
                                lesson.audioTranscript,
                                id: 'lec_${lesson.id}',
                              ),
                              icon: Icon(
                                isPlayingLecture
                                    ? Icons.stop_circle_rounded
                                    : Icons.play_circle_fill_rounded,
                              ),
                              label: Text(
                                isPlayingLecture
                                    ? 'Dừng phát Audio'
                                    : 'Phát Audio Bài Giảng',
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          OutlinedButton.icon(
                            onPressed: widget.viewModel.tts.cycleSpeed,
                            icon: Icon(Icons.speed_rounded, size: 18),
                            label: Text(widget.viewModel.tts.speedLabel),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 10,
                        children: <Widget>[
                          FilterChip(
                            label: Text('Hiện Transcript Tiếng Anh'),
                            selected: _showTranscript,
                            onSelected: (v) =>
                                setState(() => _showTranscript = v),
                          ),
                          FilterChip(
                            label: Text('Hiện Dịch Tiếng Việt'),
                            selected: _showTranslation,
                            onSelected: (v) =>
                                setState(() => _showTranslation = v),
                          ),
                        ],
                      ),
                      if (_showTranscript) ...<Widget>[
                        const Divider(height: 20),
                        Text(
                          lesson.audioTranscript,
                          style: TextStyle(),
                        ),
                      ],
                      if (_showTranslation) ...<Widget>[
                        const SizedBox(height: 10),
                        Text(
                          lesson.vietnameseTranslation,
                          style: TextStyle(),
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(height: 18),

                // Dictation Practice Card
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppPalette.of(context).card,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: AppPalette.of(context).border),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Icon(
                            Icons.keyboard_voice_rounded,
                            color: AppTheme.goldAccent,
                            size: 20,
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'Luyện Nghe Chép Chính Tả (Dictation Mode)',
                              style: TextStyle(
                                fontWeight: FontWeight.w800,
                                fontSize: 15,
                              ),
                            ),
                          ),
                          IconButton(
                            onPressed: () => widget.viewModel.tts.speak(
                              lesson.dictationSentence,
                              id: 'dict_${lesson.id}',
                            ),
                            icon: Icon(
                              Icons.volume_up_rounded,
                              color: AppPalette.of(context).primary,
                            ),
                            tooltip: 'Nghe câu chép chính tả',
                          ),
                        ],
                      ),
                      Text(
                        'Bấm loa nghe câu mẫu rồi gõ lại:',
                        style: TextStyle(
                          fontSize: 12.5,
                          color: AppPalette.of(context).textSecondary,
                        ),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: _dictationCtrl,
                        decoration: InputDecoration(
                          hintText: 'Gõ lại câu tiếng Anh bạn vừa nghe...',
                        ),
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: <Widget>[
                          ElevatedButton(
                            onPressed: () =>
                                _checkDictation(lesson.dictationSentence),
                            child: Text('Kiểm tra Chính tả'),
                          ),
                          const SizedBox(width: 12),
                          if (_dictationAccuracy != null)
                            Expanded(
                              child: Text(
                                'Độ chính xác: ${(_dictationAccuracy! * 100).round()}%\nĐáp án: "${lesson.dictationSentence}"',
                                style: TextStyle(
                                  fontSize: 12.5,
                                  fontWeight: FontWeight.w700,
                                  color: _dictationAccuracy! >= 0.7
                                      ? AppTheme.emeraldSuccess
                                      : AppTheme.goldAccent,
                                ),
                              ),
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),

                // Comprehension Quiz
                Text(
                  'Listening Comprehension Questions',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    color: AppPalette.of(context).textPrimary,
                  ),
                ),
                const SizedBox(height: 10),
                ...List<Widget>.generate(lesson.questions.length, (qIdx) {
                  final q = lesson.questions[qIdx];
                  final selected = _quizAnswers[qIdx];

                  return Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppPalette.of(context).card,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: AppPalette.of(context).border),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          TranslatablePromptBlock(
                            promptEn: 'Question ${qIdx + 1}: ${q.question}',
                            promptVi: q.questionVi,
                            textStyle: TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 14.5,
                              color: AppPalette.of(context).textPrimary,
                            ),
                          ),
                          const SizedBox(height: 10),
                          ...List<Widget>.generate(q.options.length, (optIdx) {
                            final isChosen = selected == optIdx;
                            final isRight = optIdx == q.correctIndex;
                            Color border = AppPalette.of(context).border;
                            if (selected != null) {
                              if (isRight) {
                                border = AppTheme.emeraldSuccess;
                              } else if (isChosen) {
                                border = AppTheme.coralDanger;
                              }
                            }
                            return Padding(
                              padding: const EdgeInsets.only(bottom: 8),
                              child: InkWell(
                                borderRadius: BorderRadius.circular(12),
                                onTap: () {
                                  setState(() => _quizAnswers[qIdx] = optIdx);
                                  if (_quizAnswers.length ==
                                      lesson.questions.length) {
                                    widget.viewModel.recordActivityCompletion(
                                      questId: 'q_listen',
                                      skill: SkillType.listening,
                                      baseXp: 35,
                                      lessonId: lesson.id,
                                    );
                                  }
                                },
                                child: Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: AppPalette.of(context).bg,
                                    borderRadius: BorderRadius.circular(12),
                                    border:
                                        Border.all(color: border, width: 1.4),
                                  ),
                                  child: Row(
                                    children: <Widget>[
                                      Text(
                                        '${String.fromCharCode(65 + optIdx)}. ',
                                        style: TextStyle(
                                          fontWeight: FontWeight.w800,
                                          color: AppPalette.of(context).primary,
                                        ),
                                      ),
                                      Expanded(
                                        child: Text(
                                          q.options[optIdx],
                                          style: TextStyle(
                                            fontSize: 13.5,
                                            color: AppPalette.of(context)
                                                .textPrimary,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          }),
                          if (selected != null) ...<Widget>[
                            const SizedBox(height: 6),
                            Text(
                              '💡 Giải thích: ${q.explanationVi}',
                              style: const TextStyle(
                                fontSize: 12.5,
                                color: AppTheme.goldAccent,
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  );
                }),

                if (lesson.questions.isNotEmpty &&
                    _quizAnswers.length == lesson.questions.length) ...<Widget>[
                  LessonCompletionCard(
                    title: '🎉 Hoàn thành ${lesson.title}!',
                    subtitle:
                        'Bạn đã trả lời xong toàn bộ câu hỏi nghe hiểu (+35 XP). Bạn muốn học tiếp bài nghe khác hay về Trang chủ?',
                    onContinueNext: () {
                      final nextIdx = (safeIndex + 1) % lessons.length;
                      _selectLesson(nextIdx);
                    },
                    onFinishAndExit: () {
                      widget.viewModel.tts.stop();
                      if (widget.onExitToHome != null) {
                        widget.onExitToHome!();
                      } else if (Navigator.of(context).canPop()) {
                        Navigator.of(context).pop();
                      }
                    },
                  ),
                  const SizedBox(height: 18),
                ],

                // Key Vocabulary from Listening
                if (lesson.keyVocab.isNotEmpty) ...<Widget>[
                  const SizedBox(height: 6),
                  Text(
                    'Từ vựng Học thuật trong Bài Nghe (Bấm + để lưu Flashcard)',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 10),
                  ...lesson.keyVocab.map(
                    (v) => Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: AppPalette.of(context).card,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: AppPalette.of(context).border),
                        ),
                        child: Row(
                          children: <Widget>[
                            IconButton(
                              onPressed: () => widget.viewModel.tts.speak(
                                v.word,
                                id: 'voc_${v.word}',
                              ),
                              icon: Icon(
                                Icons.volume_up_rounded,
                                color: AppPalette.of(context).primary,
                              ),
                            ),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    '${v.word}  ${v.ipa} (${v.partOfSpeech})',
                                    style: TextStyle(
                                      fontWeight: FontWeight.w800,
                                      fontSize: 14,
                                    ),
                                  ),
                                  Text(
                                    v.meaningVi,
                                    style: TextStyle(
                                      color: AppTheme.goldAccent,
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                  Text(
                                    v.exampleEn,
                                    style: TextStyle(),
                                  ),
                                ],
                              ),
                            ),
                            IconButton(
                              onPressed: () {
                                widget.viewModel.saveVocabFlashcard(v);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                      'Đã lưu "${v.word}" vào Sổ tay Flashcard (+5 XP)',
                                    ),
                                  ),
                                );
                              },
                              icon: Icon(
                                Icons.bookmark_add_outlined,
                                color: AppTheme.emeraldSuccess,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}
