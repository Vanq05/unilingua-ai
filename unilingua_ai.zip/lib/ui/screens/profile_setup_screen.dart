import 'package:flutter/material.dart';

import '../../data/repositories/curriculum_repository.dart';
import '../../domain/models/learning_models.dart';
import '../theme/app_theme.dart';
import '../view_models/learning_view_model.dart';

/// Initial Profile Setup shown right after first-time login/registration:
/// collects Name, Age, and Current Level (Mất gốc / Có biết cơ bản / Đã giỏi),
/// then launches an age-and-level tailored Placement Test.
class InitialProfileSetupScreen extends StatefulWidget {
  const InitialProfileSetupScreen({
    super.key,
    required this.viewModel,
  });

  final LearningViewModel viewModel;

  @override
  State<InitialProfileSetupScreen> createState() =>
      _InitialProfileSetupScreenState();
}

class _InitialProfileSetupScreenState extends State<InitialProfileSetupScreen> {
  late TextEditingController _nameCtrl;
  late TextEditingController _ageCtrl;
  String _selectedLevel = GoogleUserProfile.levelBeginner;
  int _selectedDailyMinutes = 30;
  int _selectedWeeks = 8;
  String? _validationError;

  @override
  void initState() {
    super.initState();
    final user = widget.viewModel.state?.user;
    _nameCtrl = TextEditingController(
      text: (user?.displayName.isNotEmpty == true)
          ? user!.displayName
          : (user?.effectiveUsername ?? ''),
    );
    _ageCtrl = TextEditingController(text: '${user?.age ?? 20}');
    _selectedLevel = user?.selfAssessedLevel ?? GoogleUserProfile.levelBeginner;
    _selectedDailyMinutes = user?.dailyTargetMinutes ?? 30;
    _selectedWeeks = user?.targetWeeks ?? 8;
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _ageCtrl.dispose();
    super.dispose();
  }

  Future<void> _submitProfile() async {
    final name = _nameCtrl.text.trim();
    final age = int.tryParse(_ageCtrl.text.trim());
    if (name.isEmpty) {
      setState(() => _validationError = 'Vui lòng nhập tên của bạn.');
      return;
    }
    if (age == null || age < 6 || age > 99) {
      setState(() => _validationError = 'Vui lòng nhập độ tuổi hợp lệ (6–99).');
      return;
    }
    setState(() => _validationError = null);

    await widget.viewModel.completeInitialProfileSetup(
      displayName: name,
      age: age,
      selfAssessedLevel: _selectedLevel,
      dailyTargetMinutes: _selectedDailyMinutes,
      targetWeeks: _selectedWeeks,
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Thiết lập Hồ sơ Ban đầu',
          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: widget.viewModel.signOut,
            child: Text(
              'Đổi tài khoản',
              style: TextStyle(color: p.danger, fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              // Hero greeting banner
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: <Color>[p.heroStart, p.heroEnd],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(22),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'Chào bạn mới! 🎉',
                      style: TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(height: 6),
                    Text(
                      'Hãy cho UniLingua biết Tên, Tuổi và Trình độ hiện tại để tạo ngay bài Test đầu vào & lộ trình phù hợp nhất.',
                      style: TextStyle(
                        fontSize: 13.5,
                        height: 1.45,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Name & Age fields
              Row(
                children: <Widget>[
                  Expanded(
                    flex: 2,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          'Tên của bạn',
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                            color: p.textPrimary,
                          ),
                        ),
                        const SizedBox(height: 6),
                        TextField(
                          key: const Key('profile_name_field'),
                          controller: _nameCtrl,
                          decoration: const InputDecoration(
                            prefixIcon: Icon(Icons.badge_outlined),
                            hintText: 'VD: Vang',
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          'Tuổi',
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                            color: p.textPrimary,
                          ),
                        ),
                        const SizedBox(height: 6),
                        TextField(
                          key: const Key('profile_age_field'),
                          controller: _ageCtrl,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            prefixIcon: Icon(Icons.cake_outlined),
                            hintText: '20',
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // 3 Level Cards (Mất gốc / Có biết cơ bản / Đã giỏi)
              Text(
                'Trình độ tiếng Anh hiện tại của bạn:',
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 15,
                  color: p.textPrimary,
                ),
              ),
              const SizedBox(height: 10),

              _LevelOptionCard(
                icon: Icons.eco_rounded,
                title: GoogleUserProfile.levelBeginner,
                subtitle:
                    'Mới bắt đầu hoặc quên gần hết. Muốn học từ phát âm & câu giao tiếp A1 dễ hiểu.',
                color: p.success,
                isSelected: _selectedLevel == GoogleUserProfile.levelBeginner,
                onTap: () => setState(
                  () => _selectedLevel = GoogleUserProfile.levelBeginner,
                ),
              ),
              const SizedBox(height: 10),
              _LevelOptionCard(
                icon: Icons.rocket_launch_rounded,
                title: GoogleUserProfile.levelBasic,
                subtitle:
                    'Đã biết từ vựng, chia thì đơn giản. Muốn nghe nói tự tin A2 - B1.',
                color: p.primary,
                isSelected: _selectedLevel == GoogleUserProfile.levelBasic,
                onTap: () => setState(
                  () => _selectedLevel = GoogleUserProfile.levelBasic,
                ),
              ),
              const SizedBox(height: 10),
              _LevelOptionCard(
                icon: Icons.workspace_premium_rounded,
                title: GoogleUserProfile.levelAdvanced,
                subtitle:
                    'Nền tảng tốt. Muốn luyện phản xạ nâng cao, phỏng vấn & chuẩn B1 - B2.',
                color: p.gold,
                isSelected: _selectedLevel == GoogleUserProfile.levelAdvanced,
                onTap: () => setState(
                  () => _selectedLevel = GoogleUserProfile.levelAdvanced,
                ),
              ),
              const SizedBox(height: 18),

              // Target weeks & minutes per day
              Text(
                'Mục tiêu lộ trình:',
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 14.5,
                  color: p.textPrimary,
                ),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: CurriculumRepository.targetWeekOptions.map((weeks) {
                  final selected = _selectedWeeks == weeks;
                  return ChoiceChip(
                    label: Text(
                      '$weeks tuần',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        color: selected ? Colors.white : p.textPrimary,
                      ),
                    ),
                    selected: selected,
                    selectedColor: p.primary,
                    onSelected: (_) => setState(() => _selectedWeeks = weeks),
                  );
                }).toList(),
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: CurriculumRepository.dailyMinuteOptions.map((mins) {
                  final selected = _selectedDailyMinutes == mins;
                  return ChoiceChip(
                    label: Text(
                      '$mins phút / ngày',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        color: selected ? Colors.white : p.textPrimary,
                      ),
                    ),
                    selected: selected,
                    selectedColor: p.secondary,
                    onSelected: (_) =>
                        setState(() => _selectedDailyMinutes = mins),
                  );
                }).toList(),
              ),

              if (_validationError != null) ...<Widget>[
                const SizedBox(height: 12),
                Text(
                  _validationError!,
                  style: TextStyle(
                    color: p.danger,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],

              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton.icon(
                  key: const Key('profile_setup_continue_btn'),
                  onPressed: _submitProfile,
                  icon: const Icon(Icons.auto_awesome_rounded),
                  label: const Text(
                    'Tạo Bài Kiểm Tra Đầu Vào Phù Hợp',
                    style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w800),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _LevelOptionCard extends StatelessWidget {
  const _LevelOptionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.isSelected,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final bool isSelected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: isSelected ? color.withValues(alpha: 0.14) : p.card,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: isSelected ? color : p.border,
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Row(
          children: <Widget>[
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.16),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: color, size: 26),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 15.5,
                      fontWeight: FontWeight.w900,
                      color: p.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 12.5,
                      height: 1.35,
                      color: p.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              isSelected
                  ? Icons.check_circle_rounded
                  : Icons.radio_button_unchecked_rounded,
              color: isSelected ? color : p.textSecondary,
            ),
          ],
        ),
      ),
    );
  }
}
