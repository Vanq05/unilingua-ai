import 'package:flutter/material.dart';

/// Adaptive color palette supporting both Fresh Sky-Blue Light Mode (default)
/// and Midnight Dark Mode.
@immutable
class AppPalette {
  const AppPalette({
    required this.isDark,
    required this.bg,
    required this.surface,
    required this.card,
    required this.cardElevated,
    required this.primary,
    required this.secondary,
    required this.gold,
    required this.success,
    required this.danger,
    required this.textPrimary,
    required this.textSecondary,
    required this.border,
    required this.heroStart,
    required this.heroEnd,
  });

  final bool isDark;
  final Color bg;
  final Color surface;
  final Color card;
  final Color cardElevated;
  final Color primary;
  final Color secondary;
  final Color gold;
  final Color success;
  final Color danger;
  final Color textPrimary;
  final Color textSecondary;
  final Color border;
  final Color heroStart;
  final Color heroEnd;

  static const AppPalette light = AppPalette(
    isDark: false,
    bg: Color(0xFFEFF8FF), // Fresh crystal sky-blue background
    surface: Color(0xFFFFFFFF),
    card: Color(0xFFFFFFFF),
    cardElevated: Color(0xFFE0F2FE),
    primary: Color(0xFF0284C7), // Clear ocean sky blue
    secondary: Color(0xFF06B6D4), // Fresh turquoise cyan
    gold: Color(0xFFF59E0B),
    success: Color(0xFF10B981),
    danger: Color(0xFFEF4444),
    textPrimary: Color(0xFF0F172A),
    textSecondary: Color(0xFF475569),
    border: Color(0xFFBAE6FD),
    heroStart: Color(0xFF0284C7),
    heroEnd: Color(0xFF06B6D4),
  );

  static const AppPalette dark = AppPalette(
    isDark: true,
    bg: Color(0xFF070B19),
    surface: Color(0xFF10172A),
    card: Color(0xFF161F38),
    cardElevated: Color(0xFF1E294B),
    primary: Color(0xFF00E5FF),
    secondary: Color(0xFF7C3AED),
    gold: Color(0xFFFFB800),
    success: Color(0xFF10B981),
    danger: Color(0xFFF43F5E),
    textPrimary: Color(0xFFF8FAFC),
    textSecondary: Color(0xFF94A3B8),
    border: Color(0xFF263354),
    heroStart: Color(0xFF1E1B4B),
    heroEnd: Color(0xFF0F172A),
  );

  static AppPalette of(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    return brightness == Brightness.dark ? dark : light;
  }
}

class AppTheme {
  const AppTheme._();

  // Backwards-compatible static tokens (still clean across sub-widgets)
  static const Color bgDeep = Color(0xFF070B19);
  static const Color bgSurface = Color(0xFF10172A);
  static const Color bgCard = Color(0xFF161F38);
  static const Color bgCardElevated = Color(0xFF1E294B);

  static const Color cyanPrimary = Color(0xFF0284C7);
  static const Color violetAccent = Color(0xFF6366F1);
  static const Color goldAccent = Color(0xFFF59E0B);
  static const Color emeraldSuccess = Color(0xFF10B981);
  static const Color coralDanger = Color(0xFFEF4444);

  static const Color textPrimary = Color(0xFF0F172A);
  static const Color textSecondary = Color(0xFF475569);
  static const Color borderSubtle = Color(0xFFBAE6FD);

  /// Default Fresh Sky-Blue Light Theme (Tươi sáng, trong xanh)
  static ThemeData get lightTheme {
    const p = AppPalette.light;
    final base = ThemeData.light(useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: p.bg,
      primaryColor: p.primary,
      colorScheme: ColorScheme.light(
        primary: p.primary,
        secondary: p.secondary,
        tertiary: p.gold,
        surface: p.surface,
        error: p.danger,
        onPrimary: Colors.white,
        onSurface: p.textPrimary,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: p.bg,
        foregroundColor: p.textPrimary,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        centerTitle: false,
      ),
      cardTheme: CardThemeData(
        color: p.card,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: p.border, width: 1),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: p.surface,
        hintStyle: TextStyle(color: p.textSecondary, fontSize: 14),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: p.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: p.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: p.primary, width: 1.8),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: p.primary,
          foregroundColor: Colors.white,
          elevation: 0,
          textStyle: const TextStyle(
            fontWeight: FontWeight.w800,
            fontSize: 15,
          ),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: p.primary,
          side: BorderSide(color: p.border, width: 1.2),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: p.surface,
        indicatorColor: p.primary.withValues(alpha: 0.14),
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          final selected = states.contains(WidgetState.selected);
          return TextStyle(
            fontSize: 10.5,
            fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
            color: selected ? p.primary : p.textSecondary,
          );
        }),
      ),
    );
  }

  /// Midnight Dark Theme
  static ThemeData get darkTheme {
    const p = AppPalette.dark;
    final base = ThemeData.dark(useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: p.bg,
      primaryColor: p.primary,
      colorScheme: ColorScheme.dark(
        primary: p.primary,
        secondary: p.secondary,
        tertiary: p.gold,
        surface: p.surface,
        error: p.danger,
        onPrimary: const Color(0xFF04101E),
        onSurface: p.textPrimary,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: p.bg,
        foregroundColor: p.textPrimary,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        centerTitle: false,
      ),
      cardTheme: CardThemeData(
        color: p.card,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: p.border, width: 1),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: p.surface,
        hintStyle: TextStyle(color: p.textSecondary, fontSize: 14),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: p.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: p.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: p.primary, width: 1.6),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: p.primary,
          foregroundColor: const Color(0xFF04101E),
          elevation: 0,
          textStyle: const TextStyle(
            fontWeight: FontWeight.w800,
            fontSize: 15,
          ),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: p.surface,
        indicatorColor: p.primary.withValues(alpha: 0.18),
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          final selected = states.contains(WidgetState.selected);
          return TextStyle(
            fontSize: 10.5,
            fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
            color: selected ? p.primary : p.textSecondary,
          );
        }),
      ),
    );
  }
}
