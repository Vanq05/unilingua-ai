import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../data/services/speech_tts_service.dart';
import '../theme/app_theme.dart';

/// Duolingo-style 3D tactile button with darker 4px bottom lip that depresses on tap.
class Tactile3DButton extends StatefulWidget {
  const Tactile3DButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.color = const Color(0xFF58CC02),
    this.textColor = Colors.white,
    this.icon,
    this.height = 52,
    this.outlined = false,
  });

  final String label;
  final VoidCallback? onPressed;
  final Color color;
  final Color textColor;
  final IconData? icon;
  final double height;
  final bool outlined;

  @override
  State<Tactile3DButton> createState() => _Tactile3DButtonState();
}

class _Tactile3DButtonState extends State<Tactile3DButton> {
  bool _pressed = false;

  Color _darken(Color c, [double amount = 0.22]) {
    final hsl = HSLColor.fromColor(c);
    return hsl
        .withLightness((hsl.lightness - amount).clamp(0.0, 1.0))
        .toColor();
  }

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    final enabled = widget.onPressed != null;
    final bg = widget.outlined
        ? p.card
        : (enabled ? widget.color : p.border.withValues(alpha: 0.45));
    final lipColor = widget.outlined
        ? (enabled ? widget.color : p.border)
        : (enabled ? _darken(widget.color) : p.border);
    final fg = widget.outlined
        ? (enabled ? widget.color : p.textSecondary)
        : (enabled ? widget.textColor : p.textSecondary);

    return GestureDetector(
      onTapDown: enabled ? (_) => setState(() => _pressed = true) : null,
      onTapCancel: enabled ? () => setState(() => _pressed = false) : null,
      onTapUp: enabled
          ? (_) {
              setState(() => _pressed = false);
              HapticFeedback.lightImpact();
              widget.onPressed?.call();
            }
          : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        height: widget.height,
        margin: EdgeInsets.only(top: _pressed ? 3 : 0),
        padding: const EdgeInsets.symmetric(horizontal: 18),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: lipColor,
            width: widget.outlined ? 2 : 1,
          ),
          boxShadow: _pressed
              ? const <BoxShadow>[]
              : <BoxShadow>[
                  BoxShadow(
                    color: lipColor,
                    offset: const Offset(0, 4),
                    blurRadius: 0,
                  ),
                ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            if (widget.icon != null) ...<Widget>[
              Icon(widget.icon, color: fg, size: 20),
              const SizedBox(width: 8),
            ],
            Flexible(
              child: Text(
                widget.label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: fg,
                  fontWeight: FontWeight.w900,
                  fontSize: 14.5,
                  letterSpacing: 0.4,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Tactile 3D selectable chip for Word-Bank sentence building & Tap-the-Pairs tiles.
class Tactile3DChip extends StatelessWidget {
  const Tactile3DChip({
    super.key,
    required this.label,
    required this.onTap,
    this.selected = false,
    this.matched = false,
    this.wrongFlash = false,
    this.dimmed = false,
  });

  final String label;
  final VoidCallback? onTap;
  final bool selected;
  final bool matched;
  final bool wrongFlash;
  final bool dimmed;

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    Color borderColor = p.border;
    Color bgColor = p.card;
    Color textColor = p.textPrimary;

    if (wrongFlash) {
      borderColor = p.danger;
      bgColor = p.danger.withValues(alpha: 0.16);
      textColor = p.danger;
    } else if (matched) {
      borderColor = p.success.withValues(alpha: 0.4);
      bgColor = p.success.withValues(alpha: 0.08);
      textColor = p.textSecondary.withValues(alpha: 0.45);
    } else if (selected) {
      borderColor = p.primary;
      bgColor = p.primary.withValues(alpha: 0.16);
      textColor = p.primary;
    } else if (dimmed) {
      borderColor = p.border.withValues(alpha: 0.4);
      bgColor = p.surface.withValues(alpha: 0.5);
      textColor = Colors.transparent;
    }

    return GestureDetector(
      onTap: (onTap == null || matched || dimmed)
          ? null
          : () {
              HapticFeedback.selectionClick();
              onTap!();
            },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: borderColor, width: selected ? 2 : 1.5),
          boxShadow: (matched || dimmed)
              ? const <BoxShadow>[]
              : <BoxShadow>[
                  BoxShadow(
                    color: borderColor,
                    offset: const Offset(0, 3),
                    blurRadius: 0,
                  ),
                ],
        ),
        child: Text(
          label,
          textAlign: TextAlign.center,
          style: TextStyle(
            color: textColor,
            fontWeight: FontWeight.w800,
            fontSize: 14.5,
          ),
        ),
      ),
    );
  }
}

/// Lesson top bar with rounded progress track that turns glowing gold on Combo >= 3.
class ComboProgressBar extends StatelessWidget {
  const ComboProgressBar({
    super.key,
    required this.progress,
    required this.combo,
    required this.onClose,
  });

  final double progress;
  final int combo;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    final isHot = combo >= 3;
    final barColor = isHot ? p.gold : p.success;

    return Row(
      children: <Widget>[
        IconButton(
          onPressed: onClose,
          icon: Icon(Icons.close_rounded, color: p.textSecondary, size: 26),
        ),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              if (isHot)
                Padding(
                  padding: const EdgeInsets.only(bottom: 3),
                  child: Row(
                    children: <Widget>[
                      Icon(Icons.bolt_rounded, color: p.gold, size: 15),
                      Text(
                        'COMBO x$combo',
                        style: TextStyle(
                          fontSize: 11.5,
                          fontWeight: FontWeight.w900,
                          color: p.gold,
                          letterSpacing: 0.6,
                        ),
                      ),
                    ],
                  ),
                ),
              ClipRRect(
                borderRadius: BorderRadius.circular(999),
                child: LinearProgressIndicator(
                  value: progress.clamp(0.05, 1.0),
                  minHeight: 14,
                  backgroundColor: p.border.withValues(alpha: 0.45),
                  valueColor: AlwaysStoppedAnimation<Color>(barColor),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 12),
      ],
    );
  }
}

/// Character Mascot + Speech Bubble with normal & 🐢 slow audio buttons.
class CharacterSpeechBubble extends StatelessWidget {
  const CharacterSpeechBubble({
    super.key,
    required this.persona,
    required this.textEn,
    required this.tts,
    this.hintVi,
    this.showBadgeNewWord = false,
  });

  final VoicePersona persona;
  final String textEn;
  final SpeechTtsService tts;
  final String? hintVi;
  final bool showBadgeNewWord;

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        if (showBadgeNewWord)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Icon(Icons.auto_awesome_rounded, color: p.secondary, size: 16),
                const SizedBox(width: 4),
                Text(
                  'TỪ MỚI',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    color: p.secondary,
                    letterSpacing: 0.6,
                  ),
                ),
              ],
            ),
          ),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Column(
              children: <Widget>[
                Container(
                  width: 62,
                  height: 62,
                  decoration: BoxDecoration(
                    color: persona.accentColor.withValues(alpha: 0.16),
                    shape: BoxShape.circle,
                    border: Border.all(color: persona.accentColor, width: 2.5),
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    persona.emoji,
                    style: const TextStyle(fontSize: 32),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  persona.name,
                  style: TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w900,
                    color: persona.accentColor,
                  ),
                ),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: p.card,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: p.border, width: 1.6),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        InkWell(
                          borderRadius: BorderRadius.circular(10),
                          onTap: () => tts.speak(
                            textEn,
                            id: 'char_${persona.name}_norm',
                            persona: persona,
                          ),
                          child: Container(
                            padding: const EdgeInsets.all(7),
                            decoration: BoxDecoration(
                              color: p.primary.withValues(alpha: 0.16),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Icon(
                              Icons.volume_up_rounded,
                              color: p.primary,
                              size: 20,
                            ),
                          ),
                        ),
                        const SizedBox(width: 6),
                        InkWell(
                          borderRadius: BorderRadius.circular(10),
                          onTap: () => tts.speakSlow(
                            textEn,
                            id: 'char_${persona.name}_slow',
                            persona: persona,
                          ),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 6,
                            ),
                            decoration: BoxDecoration(
                              color: p.gold.withValues(alpha: 0.14),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: <Widget>[
                                const Text('🐢', style: TextStyle(fontSize: 13)),
                                const SizedBox(width: 4),
                                Text(
                                  'Chậm',
                                  style: TextStyle(
                                    fontSize: 11.5,
                                    fontWeight: FontWeight.w800,
                                    color: p.gold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const Spacer(),
                        Text(
                          persona.roleLabelVi.split('•').first.trim(),
                          style: TextStyle(
                            fontSize: 10.5,
                            fontWeight: FontWeight.w700,
                            color: p.textSecondary,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Text(
                      textEn,
                      style: TextStyle(
                        fontSize: 16.5,
                        fontWeight: FontWeight.w800,
                        color: p.textPrimary,
                        height: 1.35,
                      ),
                    ),
                    if (hintVi != null && hintVi!.isNotEmpty) ...<Widget>[
                      const SizedBox(height: 6),
                      Text(
                        '💡 Gợi ý: $hintVi',
                        style: TextStyle(
                          fontSize: 12.5,
                          color: p.textSecondary,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

/// Full-width Duolingo bottom feedback drawer (Correct / Wrong + Explain + Continue).
class LessonFeedbackSheet extends StatefulWidget {
  const LessonFeedbackSheet({
    super.key,
    required this.isCorrect,
    required this.correctAnswer,
    required this.explanationVi,
    required this.onContinue,
  });

  final bool isCorrect;
  final String correctAnswer;
  final String explanationVi;
  final VoidCallback onContinue;

  @override
  State<LessonFeedbackSheet> createState() => _LessonFeedbackSheetState();
}

class _LessonFeedbackSheetState extends State<LessonFeedbackSheet> {
  bool _showExplain = false;

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    final accent = widget.isCorrect ? p.success : p.danger;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 22),
      decoration: BoxDecoration(
        color: p.surface,
        border: Border(top: BorderSide(color: accent, width: 2)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(
                widget.isCorrect
                    ? Icons.check_circle_rounded
                    : Icons.cancel_rounded,
                color: accent,
                size: 26,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  widget.isCorrect ? 'Làm tốt lắm!' : 'Chưa đúng lắm!',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    color: accent,
                  ),
                ),
              ),
            ],
          ),
          if (!widget.isCorrect) ...<Widget>[
            const SizedBox(height: 6),
            Text(
              'Đáp án đúng: ${widget.correctAnswer}',
              style: TextStyle(
                fontSize: 13.5,
                fontWeight: FontWeight.w800,
                color: p.textPrimary,
              ),
            ),
          ],
          if (_showExplain) ...<Widget>[
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: p.card,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: p.border),
              ),
              child: Text(
                widget.explanationVi,
                style: TextStyle(
                  fontSize: 12.5,
                  height: 1.4,
                  color: p.textSecondary,
                ),
              ),
            ),
          ],
          const SizedBox(height: 12),
          Tactile3DButton(
            label: _showExplain ? 'ẨN GIẢI THÍCH' : 'GIẢI THÍCH ĐÁP ÁN',
            color: accent,
            outlined: true,
            height: 44,
            onPressed: () => setState(() => _showExplain = !_showExplain),
          ),
          const SizedBox(height: 10),
          Tactile3DButton(
            key: const Key('duolingo_feedback_continue_btn'),
            label: 'TIẾP TỤC',
            color: accent,
            onPressed: widget.onContinue,
          ),
        ],
      ),
    );
  }
}

/// Horizontal selector bar to pick & preview any of the 6 character voices.
class VoicePersonaPickerBar extends StatelessWidget {
  const VoicePersonaPickerBar({
    super.key,
    required this.tts,
    this.sampleText = 'Hello! Let us practice English together today.',
  });

  final SpeechTtsService tts;
  final String sampleText;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: tts,
      builder: (context, _) {
        final p = AppPalette.of(context);
        return SizedBox(
          height: 62,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: VoicePersona.values.length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (context, idx) {
              final persona = VoicePersona.values[idx];
              final selected = tts.activePersona == persona;
              return GestureDetector(
                key: Key('voice_persona_${persona.name}'),
                onTap: () {
                  HapticFeedback.selectionClick();
                  tts.setPersona(persona);
                  tts.speak(
                    sampleText,
                    id: 'preview_${persona.name}',
                    persona: persona,
                  );
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 120),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    color: selected
                        ? persona.accentColor.withValues(alpha: 0.18)
                        : p.card,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: selected ? persona.accentColor : p.border,
                      width: selected ? 2 : 1.2,
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Text(persona.emoji, style: const TextStyle(fontSize: 22)),
                      const SizedBox(width: 8),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            persona.name,
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w900,
                              color: selected
                                  ? persona.accentColor
                                  : p.textPrimary,
                            ),
                          ),
                          Text(
                            persona.roleLabelVi,
                            style: TextStyle(
                              fontSize: 10.5,
                              color: p.textSecondary,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }
}
