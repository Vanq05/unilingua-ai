import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../domain/models/learning_models.dart';
import '../theme/app_theme.dart';

/// Beautiful, easy-to-read Competency Assessment Card featuring:
/// - Overall Competency Ring + CEFR / IELTS / TOEIC badge
/// - Custom-painted 4-Skill Radar Chart (Listening, Speaking, Reading, Writing)
/// - 4 sleek tappable Skill Cards with level labels & instant post-study boost badges (+3% ↗)
class CompetencyOverviewCard extends StatelessWidget {
  const CompetencyOverviewCard({
    super.key,
    required this.listeningScore,
    required this.speakingScore,
    required this.readingScore,
    required this.writingScore,
    required this.cefrLevel,
    required this.estimatedIelts,
    required this.estimatedToeic,
    this.latestBoost,
    this.onDismissBoost,
    this.onSkillTap,
    this.title = 'Đánh Giá Năng Lực Bản Thân',
  });

  final int listeningScore;
  final int speakingScore;
  final int readingScore;
  final int writingScore;
  final String cefrLevel;
  final String estimatedIelts;
  final int estimatedToeic;
  final SkillProgressDelta? latestBoost;
  final VoidCallback? onDismissBoost;
  final void Function(SkillType skill)? onSkillTap;
  final String title;

  int get _overallPercent =>
      ((listeningScore + speakingScore + readingScore + writingScore) / 4)
          .round();

  String _tierLabel(int score) {
    if (score >= 85) return 'Xuất sắc';
    if (score >= 70) return 'Tốt';
    if (score >= 55) return 'Khá';
    if (score >= 40) return 'Cơ bản';
    return 'Mới bắt đầu';
  }

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: p.card,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: p.border, width: 1.2),
        boxShadow: p.isDark
            ? null
            : <BoxShadow>[
                BoxShadow(
                  color: p.primary.withValues(alpha: 0.09),
                  blurRadius: 20,
                  offset: const Offset(0, 8),
                ),
              ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          // Header row
          Row(
            children: <Widget>[
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: p.primary.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  Icons.insights_rounded,
                  color: p.primary,
                  size: 20,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      title,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                        color: p.textPrimary,
                      ),
                    ),
                    Text(
                      'Trình độ $cefrLevel • IELTS ~$estimatedIelts • TOEIC ~$estimatedToeic',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: p.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          // Instant post-study boost pill
          if (latestBoost != null) ...<Widget>[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: p.success.withValues(alpha: 0.13),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: p.success.withValues(alpha: 0.5)),
              ),
              child: Row(
                children: <Widget>[
                  Icon(Icons.trending_up_rounded, size: 18, color: p.success),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Vừa tăng năng lực ${latestBoost!.skill.shortVi}: ${latestBoost!.previousScore}% → ${latestBoost!.newScore}% (+${latestBoost!.delta}%)',
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w800,
                        color: p.success,
                      ),
                    ),
                  ),
                  if (onDismissBoost != null)
                    InkWell(
                      onTap: onDismissBoost,
                      child: Icon(
                        Icons.close_rounded,
                        size: 16,
                        color: p.success,
                      ),
                    ),
                ],
              ),
            ),
          ],

          const SizedBox(height: 16),

          // Visual Centerpiece: Overall Ring + 4-Skill Radar Chart
          Row(
            children: <Widget>[
              // Left: Overall Score Ring
              Expanded(
                child: Column(
                  children: <Widget>[
                    SizedBox(
                      width: 104,
                      height: 104,
                      child: Stack(
                        alignment: Alignment.center,
                        children: <Widget>[
                          SizedBox(
                            width: 104,
                            height: 104,
                            child: CircularProgressIndicator(
                              value: (_overallPercent / 100).clamp(0.0, 1.0),
                              strokeWidth: 10,
                              strokeCap: StrokeCap.round,
                              backgroundColor:
                                  p.primary.withValues(alpha: 0.12),
                              valueColor:
                                  AlwaysStoppedAnimation<Color>(p.primary),
                            ),
                          ),
                          Column(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              Text(
                                '$_overallPercent%',
                                style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.w900,
                                  color: p.primary,
                                ),
                              ),
                              Text(
                                _tierLabel(_overallPercent),
                                style: TextStyle(
                                  fontSize: 11.5,
                                  fontWeight: FontWeight.w700,
                                  color: p.textSecondary,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: p.gold.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        'Tổng quan • $cefrLevel',
                        style: TextStyle(
                          fontSize: 11.5,
                          fontWeight: FontWeight.w800,
                          color: p.gold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // Right: 4-Skill Diamond Radar Chart
              Expanded(
                child: SizedBox(
                  height: 146,
                  child: CustomPaint(
                    painter: _FourSkillRadarPainter(
                      listening: listeningScore / 100.0,
                      speaking: speakingScore / 100.0,
                      reading: readingScore / 100.0,
                      writing: writingScore / 100.0,
                      primaryColor: p.primary,
                      gridColor: p.border,
                      labelColor: p.textPrimary,
                    ),
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),

          // 4 Tappable Skill Detail Cards (2x2 Grid)
          Row(
            children: <Widget>[
              Expanded(
                child: _SkillTile(
                  icon: Icons.headphones_rounded,
                  label: 'Nghe',
                  score: listeningScore,
                  tier: _tierLabel(listeningScore),
                  color: const Color(0xFF0284C7),
                  delta: latestBoost?.skill == SkillType.listening
                      ? latestBoost!.delta
                      : null,
                  onTap: onSkillTap != null
                      ? () => onSkillTap!(SkillType.listening)
                      : null,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _SkillTile(
                  icon: Icons.mic_rounded,
                  label: 'Nói',
                  score: speakingScore,
                  tier: _tierLabel(speakingScore),
                  color: const Color(0xFFF59E0B),
                  delta: latestBoost?.skill == SkillType.speaking
                      ? latestBoost!.delta
                      : null,
                  onTap: onSkillTap != null
                      ? () => onSkillTap!(SkillType.speaking)
                      : null,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: <Widget>[
              Expanded(
                child: _SkillTile(
                  icon: Icons.menu_book_rounded,
                  label: 'Đọc',
                  score: readingScore,
                  tier: _tierLabel(readingScore),
                  color: const Color(0xFF10B981),
                  delta: latestBoost?.skill == SkillType.reading
                      ? latestBoost!.delta
                      : null,
                  onTap: onSkillTap != null
                      ? () => onSkillTap!(SkillType.reading)
                      : null,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _SkillTile(
                  icon: Icons.edit_note_rounded,
                  label: 'Viết',
                  score: writingScore,
                  tier: _tierLabel(writingScore),
                  color: const Color(0xFF6366F1),
                  delta: latestBoost?.skill == SkillType.writing
                      ? latestBoost!.delta
                      : null,
                  onTap: onSkillTap != null
                      ? () => onSkillTap!(SkillType.writing)
                      : null,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _SkillTile extends StatelessWidget {
  const _SkillTile({
    required this.icon,
    required this.label,
    required this.score,
    required this.tier,
    required this.color,
    this.delta,
    this.onTap,
  });

  final IconData icon;
  final String label;
  final int score;
  final String tier;
  final Color color;
  final int? delta;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: p.isDark ? p.surface : color.withValues(alpha: 0.06),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: color.withValues(alpha: p.isDark ? 0.35 : 0.25),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                Icon(icon, size: 17, color: color),
                const SizedBox(width: 6),
                Text(
                  label,
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 13.5,
                    color: p.textPrimary,
                  ),
                ),
                const Spacer(),
                Text(
                  '$score%',
                  style: TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 14,
                    color: color,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(999),
              child: LinearProgressIndicator(
                value: (score / 100).clamp(0.0, 1.0),
                minHeight: 6,
                backgroundColor: color.withValues(alpha: 0.16),
                valueColor: AlwaysStoppedAnimation<Color>(color),
              ),
            ),
            const SizedBox(height: 6),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Text(
                  tier,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: p.textSecondary,
                  ),
                ),
                if (delta != null && delta! > 0)
                  Text(
                    '+$delta% ↗',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      color: p.success,
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _FourSkillRadarPainter extends CustomPainter {
  _FourSkillRadarPainter({
    required this.listening,
    required this.speaking,
    required this.reading,
    required this.writing,
    required this.primaryColor,
    required this.gridColor,
    required this.labelColor,
  });

  final double listening;
  final double speaking;
  final double reading;
  final double writing;
  final Color primaryColor;
  final Color gridColor;
  final Color labelColor;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = math.min(size.width, size.height) * 0.34;

    final gridPaint = Paint()
      ..color = gridColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0;

    // 3 concentric diamond grids (33%, 66%, 100%)
    for (final factor in <double>[0.35, 0.68, 1.0]) {
      final r = radius * factor;
      final path = Path()
        ..moveTo(center.dx, center.dy - r)
        ..lineTo(center.dx + r, center.dy)
        ..lineTo(center.dx, center.dy + r)
        ..lineTo(center.dx - r, center.dy)
        ..close();
      canvas.drawPath(path, gridPaint);
    }

    // Cross axes
    canvas.drawLine(
      Offset(center.dx, center.dy - radius),
      Offset(center.dx, center.dy + radius),
      gridPaint,
    );
    canvas.drawLine(
      Offset(center.dx - radius, center.dy),
      Offset(center.dx + radius, center.dy),
      gridPaint,
    );

    // Data polygon (Top=Nghe, Right=Nói, Bottom=Đọc, Left=Viết)
    final lR = radius * listening.clamp(0.18, 1.0);
    final sR = radius * speaking.clamp(0.18, 1.0);
    final rR = radius * reading.clamp(0.18, 1.0);
    final wR = radius * writing.clamp(0.18, 1.0);

    final dataPath = Path()
      ..moveTo(center.dx, center.dy - lR)
      ..lineTo(center.dx + sR, center.dy)
      ..lineTo(center.dx, center.dy + rR)
      ..lineTo(center.dx - wR, center.dy)
      ..close();

    final fillPaint = Paint()
      ..color = primaryColor.withValues(alpha: 0.24)
      ..style = PaintingStyle.fill;
    final strokePaint = Paint()
      ..color = primaryColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.2;

    canvas.drawPath(dataPath, fillPaint);
    canvas.drawPath(dataPath, strokePaint);

    // Vertex dots
    final dotPaint = Paint()..color = primaryColor;
    for (final pt in <Offset>[
      Offset(center.dx, center.dy - lR),
      Offset(center.dx + sR, center.dy),
      Offset(center.dx, center.dy + rR),
      Offset(center.dx - wR, center.dy),
    ]) {
      canvas.drawCircle(pt, 3.8, dotPaint);
    }

    // Labels around diamond
    _drawLabel(canvas, 'Nghe', Offset(center.dx, center.dy - radius - 14));
    _drawLabel(canvas, 'Nói', Offset(center.dx + radius + 16, center.dy));
    _drawLabel(canvas, 'Đọc', Offset(center.dx, center.dy + radius + 14));
    _drawLabel(canvas, 'Viết', Offset(center.dx - radius - 16, center.dy));
  }

  void _drawLabel(Canvas canvas, String text, Offset pos) {
    final tp = TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(
          color: labelColor,
          fontSize: 11,
          fontWeight: FontWeight.w800,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, Offset(pos.dx - tp.width / 2, pos.dy - tp.height / 2));
  }

  @override
  bool shouldRepaint(covariant _FourSkillRadarPainter oldDelegate) =>
      oldDelegate.listening != listening ||
      oldDelegate.speaking != speaking ||
      oldDelegate.reading != reading ||
      oldDelegate.writing != writing ||
      oldDelegate.primaryColor != primaryColor;
}
