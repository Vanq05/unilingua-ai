import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

/// Displays an English question/prompt with an adjacent "Dịch sang tiếng Việt"
/// toggle button that reveals the Vietnamese translation only when tapped.
class TranslatablePromptBlock extends StatefulWidget {
  const TranslatablePromptBlock({
    super.key,
    required this.promptEn,
    required this.promptVi,
    this.textStyle,
  });

  final String promptEn;
  final String promptVi;
  final TextStyle? textStyle;

  @override
  State<TranslatablePromptBlock> createState() =>
      _TranslatablePromptBlockState();
}

class _TranslatablePromptBlockState extends State<TranslatablePromptBlock> {
  bool _showVi = false;

  @override
  void didUpdateWidget(covariant TranslatablePromptBlock oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.promptEn != widget.promptEn) {
      _showVi = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    final hasVi = widget.promptVi.trim().isNotEmpty;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Expanded(
              child: Text(
                widget.promptEn,
                style: widget.textStyle ??
                    TextStyle(
                      fontSize: 15.5,
                      fontWeight: FontWeight.w800,
                      height: 1.4,
                      color: p.textPrimary,
                    ),
              ),
            ),
            if (hasVi) ...<Widget>[
              const SizedBox(width: 8),
              OutlinedButton.icon(
                onPressed: () => setState(() => _showVi = !_showVi),
                style: OutlinedButton.styleFrom(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  minimumSize: Size.zero,
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  side: BorderSide(
                    color: _showVi ? p.primary : p.border,
                  ),
                  backgroundColor: _showVi
                      ? p.primary.withValues(alpha: 0.1)
                      : Colors.transparent,
                ),
                icon: Icon(
                  Icons.translate_rounded,
                  size: 14,
                  color: p.primary,
                ),
                label: Text(
                  _showVi ? 'Ẩn tiếng Việt' : 'Dịch sang tiếng Việt',
                  style: TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w700,
                    color: p.primary,
                  ),
                ),
              ),
            ],
          ],
        ),
        if (_showVi && hasVi) ...<Widget>[
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            decoration: BoxDecoration(
              color: p.primary.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: p.primary.withValues(alpha: 0.3)),
            ),
            child: Text(
              '🇻🇳 ${widget.promptVi}',
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                height: 1.38,
                color: p.textPrimary,
              ),
            ),
          ),
        ],
      ],
    );
  }
}

/// Clear Duolingo-style post-lesson completion banner giving the user 2 explicit actions:
/// - "Tiếp tục câu khác" (automatically advances to the next lesson/question set)
/// - "Hoàn thành & Rời đi" (exits back to Trang chủ)
class LessonCompletionCard extends StatelessWidget {
  const LessonCompletionCard({
    super.key,
    required this.title,
    required this.subtitle,
    required this.onContinueNext,
    required this.onFinishAndExit,
    this.continueLabel = 'Tiếp tục câu khác',
  });

  final String title;
  final String subtitle;
  final VoidCallback onContinueNext;
  final VoidCallback onFinishAndExit;
  final String continueLabel;

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: p.success.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: p.success, width: 1.6),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(Icons.celebration_rounded, color: p.success, size: 24),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    color: p.success,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            subtitle,
            style: TextStyle(
              fontSize: 13,
              height: 1.4,
              color: p.textPrimary,
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: <Widget>[
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: onFinishAndExit,
                  style: OutlinedButton.styleFrom(
                    foregroundColor: p.textPrimary,
                    side: BorderSide(color: p.border, width: 1.4),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 12,
                    ),
                  ),
                  icon: const Icon(Icons.home_rounded, size: 18),
                  label: const Text(
                    'Hoàn thành & Rời đi',
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: onContinueNext,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: p.success,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 12,
                    ),
                  ),
                  icon: const Icon(Icons.skip_next_rounded, size: 19),
                  label: Text(
                    continueLabel,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
