import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';

import '../../data/repositories/curriculum_repository.dart';
import '../../data/services/ai_tutor_service.dart';
import '../../data/services/app_update_service.dart';
import '../../data/services/central_drive_server_service.dart';
import '../../data/services/google_auth_service.dart';
import '../../data/services/google_drive_database_service.dart';
import '../../data/services/progress_storage_service.dart';
import '../../data/services/speech_tts_service.dart';
import '../../data/services/voice_recorder_service.dart';
import '../../domain/models/learning_models.dart';

class RoleplayTurn {
  const RoleplayTurn({
    required this.isUser,
    required this.text,
  });

  final bool isUser;
  final String text;
}

class LearningViewModel extends ChangeNotifier {
  LearningViewModel({
    ProgressStorageService? storage,
    GoogleAuthService? googleAuth,
    GoogleDriveDatabaseService? driveDb,
    CentralDriveServerService? centralServer,
    AiTutorService? aiTutor,
    SpeechTtsService? tts,
    VoiceRecorderService? voiceRecorder,
    AppUpdateService? updateService,
    this.enableAutoSyncTimer = true,
  })  : _storage = storage ?? const ProgressStorageService(),
        _googleAuth = googleAuth ?? GoogleAuthService(),
        _driveDb = driveDb ?? const GoogleDriveDatabaseService(),
        _centralServer = centralServer ?? const CentralDriveServerService(),
        _aiTutor = aiTutor ?? AiTutorService(),
        tts = tts ?? SpeechTtsService(),
        voiceRecorder = voiceRecorder ?? VoiceRecorderService(),
        _updateService = updateService ?? const AppUpdateService();

  final ProgressStorageService _storage;
  final GoogleAuthService _googleAuth;
  final GoogleDriveDatabaseService _driveDb;
  final CentralDriveServerService _centralServer;
  final AiTutorService _aiTutor;
  final SpeechTtsService tts;
  final VoiceRecorderService voiceRecorder;
  final AppUpdateService _updateService;
  final bool enableAutoSyncTimer;

  bool _isInitializing = true;
  bool _isBusy = false;
  bool _isDarkMode = false; // Default: Fresh Sky-Blue Light Mode!
  bool _notificationsEnabled = true;
  StudentProgressState? _state;
  List<GoogleUserProfile> _knownAccounts = const <GoogleUserProfile>[];
  AppUpdateInfo? _availableUpdate;
  SkillProgressDelta? _latestSkillBoost;

  // Google Drive Cloud Database + Periodic Auto-Sync state
  String? _driveAccessToken;
  String _driveSyncStatus = '☁️ Tự động đồng bộ Google Drive (Sẵn sàng)';
  bool _isSyncingDrive = false;
  Timer? _autoSyncTimer;
  DateTime? _lastDriveSyncAt;
  int _autoSyncCount = 0;

  // Keeps the newly registered student on the Placement Result & Roadmap screen
  // until they finish reviewing their diagnostic report and tap "Start Learning".
  bool _isReviewingPlacementResult = false;
  bool _isGradingPlacementExam = false;

  // Dynamic lessons & quizzes (built-in + AI generated during session)
  final List<ListeningLesson> _customListeningLessons = <ListeningLesson>[];
  final List<ReadingPassage> _customReadingPassages = <ReadingPassage>[];
  List<DailyQuizQuestion> _dailyQuizQuestions =
      CurriculumRepository.defaultDailyQuiz;
  int _dailyQuizSetCursor = 0;
  bool _isGeneratingAiContent = false;

  // Speaking Roleplay & Friends Chat state
  final Map<String, List<RoleplayTurn>> _roleplayHistories =
      <String, List<RoleplayTurn>>{};
  bool _isRoleplayStreaming = false;
  final Map<String, List<FriendChatMessage>> _friendChats =
      <String, List<FriendChatMessage>>{};
  bool _isFriendChatSending = false;

  // Writing grader state
  bool _isGradingWriting = false;

  bool get isInitializing => _isInitializing;
  bool get isBusy => _isBusy;
  bool get isDarkMode => _isDarkMode;
  bool get notificationsEnabled => _notificationsEnabled;
  bool get isSignedIn => _state != null;
  bool get isGoogleDriveConnected =>
      (_driveAccessToken != null && _driveAccessToken!.isNotEmpty) ||
      _centralServer.isConfigured;
  bool get isAutoSyncEnabled =>
      _centralServer.isConfigured ||
      (_driveAccessToken != null && _driveAccessToken!.isNotEmpty);
  String get driveSyncStatus => _driveSyncStatus;
  bool get isSyncingDrive => _isSyncingDrive;
  DateTime? get lastDriveSyncAt => _lastDriveSyncAt;
  int get autoSyncCount => _autoSyncCount;
  String get formattedLastDriveSync {
    final t = _lastDriveSyncAt;
    if (t == null) return 'Chưa có phiên đồng bộ trong lần mở này';
    final h = t.hour.toString().padLeft(2, '0');
    final m = t.minute.toString().padLeft(2, '0');
    final s = t.second.toString().padLeft(2, '0');
    return '$h:$m:$s';
  }

  StudentProgressState? get state => _state;
  List<GoogleUserProfile> get knownAccounts => _knownAccounts;
  AppUpdateInfo? get availableUpdate => _availableUpdate;
  SkillProgressDelta? get latestSkillBoost => _latestSkillBoost;
  bool get isReviewingPlacementResult => _isReviewingPlacementResult;
  bool get isGradingPlacementExam => _isGradingPlacementExam;
  bool get isGeneratingAiContent => _isGeneratingAiContent;
  bool get isRoleplayStreaming => _isRoleplayStreaming;
  bool get isFriendChatSending => _isFriendChatSending;
  bool get isGradingWriting => _isGradingWriting;

  @override
  void dispose() {
    _autoSyncTimer?.cancel();
    _autoSyncTimer = null;
    super.dispose();
  }

  void _startAutoSyncTimerIfNeeded() {
    if (!enableAutoSyncTimer) return;
    if (_state == null) return;
    if (!_centralServer.isConfigured &&
        (_driveAccessToken == null || _driveAccessToken!.isEmpty)) {
      return;
    }
    _autoSyncTimer?.cancel();
    _autoSyncTimer = Timer.periodic(const Duration(seconds: 45), (_) {
      if (_state != null && !_isSyncingDrive) {
        if (_centralServer.isConfigured) {
          unawaited(_syncStateToCentralServer(_state!));
        } else if (_driveAccessToken != null &&
            _driveAccessToken!.isNotEmpty) {
          unawaited(_syncStateToDriveInBackground(_state!));
        }
      }
    });
  }

  List<ListeningLesson> get listeningLessons => <ListeningLesson>[
        ..._customListeningLessons,
        ...CurriculumRepository.listeningLessons,
      ];

  List<ReadingPassage> get readingPassages => <ReadingPassage>[
        ..._customReadingPassages,
        ...CurriculumRepository.readingPassages,
      ];

  List<DailyQuizQuestion> get dailyQuizQuestions => _dailyQuizQuestions;

  Future<void> initialize() async {
    _isInitializing = true;
    notifyListeners();

    try {
      _isDarkMode = await _storage.loadIsDarkMode();
      _notificationsEnabled = await _storage.loadNotificationsEnabled();
      _knownAccounts = await _storage.loadKnownGoogleAccounts();

      // Silently restore real Google OAuth session & Google Drive token if available
      final silentGoogle = await _googleAuth.signInSilently();
      if (silentGoogle != null && silentGoogle.isSuccess) {
        _driveAccessToken = silentGoogle.accessToken;
        if (_driveAccessToken != null && _driveAccessToken!.isNotEmpty) {
          _driveSyncStatus = '☁️ Kết nối Google Drive Database';
        }
      }

      final activeEmail =
          silentGoogle?.profile?.email ?? await _storage.loadActiveEmail();
      if (activeEmail != null) {
        StudentProgressState? loaded;
        if (_centralServer.isConfigured) {
          loaded = await _centralServer.loadUserState(activeEmail);
          if (loaded != null) {
            _lastDriveSyncAt = DateTime.now();
            _autoSyncCount++;
            _driveSyncStatus = '☁️ Tự động đồng bộ Google Drive (Đang bật)';
          }
        }
        if (loaded == null &&
            _driveAccessToken != null &&
            _driveAccessToken!.isNotEmpty) {
          loaded = await _driveDb.loadFromGoogleDrive(_driveAccessToken!);
          if (loaded != null) {
            _lastDriveSyncAt = DateTime.now();
            _autoSyncCount++;
            _driveSyncStatus = '☁️ Đã đồng bộ Google Drive';
          }
        }
        loaded ??= await _storage.loadProgressForEmail(activeEmail);
        if (loaded != null) {
          // Ensure legacy accounts with placement results don't get stuck on profile setup
          final fixedUser = (!loaded.user.hasCompletedProfileSetup &&
                  loaded.placementResult != null)
              ? loaded.user.copyWith(hasCompletedProfileSetup: true)
              : loaded.user;
          _state = _refreshStreakAndDailyQuests(loaded.copyWith(user: fixedUser));
          _startAutoSyncTimerIfNeeded();
          await _persistState();
        }
      }
      unawaited(_aiTutor.ensureModelInitialized());
      unawaited(checkForAppUpdate());
    } finally {
      _isInitializing = false;
      notifyListeners();
    }
  }

  Future<void> setDarkMode(bool dark) async {
    if (_isDarkMode == dark) return;
    _isDarkMode = dark;
    notifyListeners();
    await _storage.saveIsDarkMode(dark);
  }

  Future<void> setNotificationsEnabled(bool enabled) async {
    if (_notificationsEnabled == enabled) return;
    _notificationsEnabled = enabled;
    notifyListeners();
    await _storage.saveNotificationsEnabled(enabled);
  }

  Future<void> _persistState() async {
    if (_state == null) return;
    await _storage.saveProgress(_state!);
    if (_centralServer.isConfigured) {
      unawaited(_syncStateToCentralServer(_state!));
    } else if (_driveAccessToken != null && _driveAccessToken!.isNotEmpty) {
      unawaited(_syncStateToDriveInBackground(_state!));
    }
  }

  Future<void> _syncStateToCentralServer(StudentProgressState snapshot) async {
    _isSyncingDrive = true;
    _driveSyncStatus = '⏳ Đang tự động đồng bộ lên Google Drive...';
    notifyListeners();
    final ok = await _centralServer.saveUserState(snapshot);
    _isSyncingDrive = false;
    if (ok) {
      _lastDriveSyncAt = DateTime.now();
      _autoSyncCount++;
      _driveSyncStatus =
          '☁️ Tự động đồng bộ Google Drive ($formattedLastDriveSync)';
    } else {
      _driveSyncStatus = '📱 Lưu trên máy (chờ kết nối Google Drive)';
    }
    notifyListeners();
  }

  Future<void> _syncStateToDriveInBackground(
      StudentProgressState snapshot) async {
    if (_driveAccessToken == null || _driveAccessToken!.isEmpty) return;
    _isSyncingDrive = true;
    _driveSyncStatus = '⏳ Đang lưu lên Google Drive...';
    notifyListeners();

    var ok = await _driveDb.saveToGoogleDrive(
      accessToken: _driveAccessToken!,
      state: snapshot,
    );
    if (!ok) {
      final refreshed = await _googleAuth.refreshAccessToken();
      if (refreshed != null && refreshed.isNotEmpty) {
        _driveAccessToken = refreshed;
        ok = await _driveDb.saveToGoogleDrive(
          accessToken: refreshed,
          state: snapshot,
        );
      }
    }
    _isSyncingDrive = false;
    if (ok) {
      _lastDriveSyncAt = DateTime.now();
      _autoSyncCount++;
      _driveSyncStatus = '☁️ Tự động đồng bộ Google Drive ($formattedLastDriveSync)';
    } else {
      _driveSyncStatus = '📱 Lưu trên máy (chờ mạng Drive)';
    }
    notifyListeners();
  }

  Future<bool> syncNowToGoogleDrive() async {
    if (_state == null) return false;
    if (_centralServer.isConfigured) {
      await _syncStateToCentralServer(_state!);
      return _driveSyncStatus.contains('Tự động đồng bộ Google Drive');
    }
    if (_driveAccessToken == null || _driveAccessToken!.isEmpty) {
      return false;
    }
    await _syncStateToDriveInBackground(_state!);
    return _driveSyncStatus.contains('Tự động đồng bộ Google Drive');
  }

  String _legacyFnvHash(String raw) {
    final trimmed = raw.trim();
    if (trimmed.isEmpty) return '';
    const int fnvOffset = 0x811c9dc5;
    const int fnvPrime = 0x01000193;
    var hash = fnvOffset;
    final bytes = utf8.encode('unilingua_salt_2026::$trimmed');
    for (final b in bytes) {
      hash ^= b;
      hash = (hash * fnvPrime) & 0xffffffff;
    }
    return 'ul_${hash.toRadixString(16).padLeft(8, '0')}_${trimmed.length}';
  }

  String _hashPasswordSha256(String raw) =>
      CentralDriveServerService.hashPasswordSha256(raw);

  bool _verifyPasswordHash(String rawPassword, String storedHash) {
    if (storedHash.isEmpty) return true;
    final sha256 = _hashPasswordSha256(rawPassword);
    if (storedHash == sha256) return true;
    // Legacy compatibility with prior FNV-1a hashes
    return storedHash == _legacyFnvHash(rawPassword);
  }

  static String normalizeHandle(String raw) {
    const src =
        'àáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵđ'
        'ÀÁẢÃẠĂẰẮẲẴẶÂẦẤẨẪẬÈÉẺẼẸÊỀẾỂỄỆÌÍỈĨỊÒÓỎÕỌÔỒỐỔỖỘƠỜỚỞỠỢÙÚỦŨỤƯỪỨỬỮỰỲÝỶỸỴĐ';
    const dst =
        'aaaaaaaaaaaaaaaaaeeeeeeeeeeeiiiiiooooooooooooooooouuuuuuuuuuuyyyyyd'
        'AAAAAAAAAAAAAAAAAEEEEEEEEEEEIIIIIOOOOOOOOOOOOOOOOOUUUUUUUUUUUYYYYYD';
    final buf = StringBuffer();
    for (final ch in raw.trim().split('')) {
      final idx = src.indexOf(ch);
      buf.write(idx >= 0 ? dst[idx] : ch);
    }
    return buf
        .toString()
        .toLowerCase()
        .replaceAll(RegExp(r'^@+'), '')
        .replaceAll(RegExp(r'[^a-z0-9._]'), '');
  }

  /// Authenticates or registers a user with Email/@username + SHA-256 Password,
  /// syncing with Google Sheets (`Users`) & Central Google Drive Server Database.
  Future<({bool ok, String message})> signInOrRegisterWithPassword({
    required String username,
    required String password,
    required bool isRegister,
    String fullName = '',
    String customUsername = '',
  }) async {
    final cleanUsername = username.trim().toLowerCase().replaceAll(
          RegExp(r'\s+'),
          '',
        );
    final rawPass = password.trim();
    if (cleanUsername.length < 3) {
      return (
        ok: false,
        message: 'Email hoặc @username cần ít nhất 3 ký tự.'
      );
    }
    if (isRegister && rawPass.length < 6) {
      return (ok: false, message: 'Mật khẩu đăng ký phải có ít nhất 6 ký tự.');
    }
    if (!isRegister && rawPass.length < 4) {
      return (ok: false, message: 'Mật khẩu phải có ít nhất 4 ký tự.');
    }

    _isBusy = true;
    _isReviewingPlacementResult = false;
    notifyListeners();

    try {
      var accountEmail = cleanUsername.contains('@')
          ? cleanUsername
          : '$cleanUsername@unilingua.app';
      final sha256Hash = _hashPasswordSha256(rawPass);
      final cleanFullName = fullName.trim().isNotEmpty
          ? fullName.trim()
          : (cleanUsername.contains('@')
              ? cleanUsername.split('@').first
              : username.trim());

      if (isRegister) {
        final rawHandle = customUsername.trim().isNotEmpty
            ? normalizeHandle(customUsername)
            : normalizeHandle(accountEmail.split('@').first);
        if (!RegExp(r'^[a-z0-9._]{3,30}$').hasMatch(rawHandle)) {
          return (
            ok: false,
            message:
                'Username phải gồm 3–30 ký tự không dấu (chữ cái, số, . hoặc _).'
          );
        }

        StudentProgressState? existing;
        if (_centralServer.isConfigured) {
          existing = await _centralServer.loadUserState(accountEmail);
        }
        existing ??= await _storage.loadProgressForEmail(accountEmail);
        if (existing != null) {
          return (
            ok: false,
            message:
                'Email "$accountEmail" đã tồn tại. Vui lòng chuyển sang Đăng nhập!'
          );
        }

        var role = 'user';
        var finalHandle = rawHandle;
        var createdAt = DateTime.now().toIso8601String();
        if (_centralServer.isConfigured) {
          final apiRes = await _centralServer.registerAccount(
            email: accountEmail,
            password: rawPass,
            fullName: cleanFullName,
            username: rawHandle,
          );
          if (!apiRes.isUnsupportedLegacyAction && !apiRes.ok) {
            return (
              ok: false,
              message: apiRes.message.isNotEmpty
                  ? apiRes.message
                  : 'Không thể đăng ký trên máy chủ.'
            );
          }
          if (apiRes.ok) {
            role = apiRes.role;
            if (apiRes.username.isNotEmpty) finalHandle = apiRes.username;
            if (apiRes.createdAt.isNotEmpty) createdAt = apiRes.createdAt;
          }
        }

        final profile = GoogleUserProfile(
          id: 'usr_$finalHandle',
          email: accountEmail,
          username: finalHandle,
          passwordHash: sha256Hash,
          role: role,
          createdAt: createdAt,
          displayName: cleanFullName,
          hasCompletedProfileSetup: false,
        );
        final today = StudentProgressState.todayKey();
        _state = StudentProgressState(
          user: profile,
          streakDays: 1,
          lastActiveDate: today,
          questsDate: today,
          dailyQuests: StudentProgressState.defaultQuestsForToday(),
          savedVocab: <VocabFlashcard>[
            ...CurriculumRepository.listeningLessons.first.keyVocab,
            ...CurriculumRepository.readingPassages.first.highlights,
          ],
        );
        _startAutoSyncTimerIfNeeded();
        await _persistState();
        _knownAccounts = await _storage.loadKnownGoogleAccounts();
        return (
          ok: true,
          message: 'Đăng ký thành công! Hãy thiết lập hồ sơ học tập của bạn.'
        );
      }

      // Login branch: supports logging in via Email OR @username
      if (_centralServer.isConfigured) {
        final apiRes = await _centralServer.loginAccount(
          email: cleanUsername.replaceFirst(RegExp(r'^@+'), ''),
          password: rawPass,
        );
        if (!apiRes.isUnsupportedLegacyAction) {
          if (apiRes.ok) {
            final resolvedEmail =
                apiRes.email.isNotEmpty ? apiRes.email : accountEmail;
            final resolvedHandle = apiRes.username.isNotEmpty
                ? apiRes.username
                : normalizeHandle(resolvedEmail.split('@').first);

            var existing = await _centralServer.loadUserState(resolvedEmail);
            existing ??= await _storage.loadProgressForEmail(resolvedEmail);

            if (existing != null) {
              _lastDriveSyncAt = DateTime.now();
              _autoSyncCount++;
              _driveSyncStatus =
                  '☁️ Tự động đồng bộ Google Drive ($formattedLastDriveSync)';
              final updatedUser = existing.user.copyWith(
                username: resolvedHandle,
                passwordHash: sha256Hash,
                role: apiRes.role,
                createdAt: apiRes.createdAt.isNotEmpty
                    ? apiRes.createdAt
                    : existing.user.createdAt,
                displayName: apiRes.fullName.isNotEmpty
                    ? apiRes.fullName
                    : existing.user.displayName,
                hasCompletedProfileSetup:
                    existing.user.hasCompletedProfileSetup ||
                        existing.placementResult != null,
              );
              _state = _refreshStreakAndDailyQuests(
                existing.copyWith(user: updatedUser),
              );
            } else {
              final today = StudentProgressState.todayKey();
              final profile = GoogleUserProfile(
                id: 'usr_$resolvedHandle',
                email: resolvedEmail,
                username: resolvedHandle,
                passwordHash: sha256Hash,
                role: apiRes.role,
                createdAt: apiRes.createdAt,
                displayName: apiRes.fullName.isNotEmpty
                    ? apiRes.fullName
                    : cleanFullName,
                hasCompletedProfileSetup: false,
              );
              _state = StudentProgressState(
                user: profile,
                streakDays: 1,
                lastActiveDate: today,
                questsDate: today,
                dailyQuests: StudentProgressState.defaultQuestsForToday(),
                savedVocab: <VocabFlashcard>[
                  ...CurriculumRepository.listeningLessons.first.keyVocab,
                  ...CurriculumRepository.readingPassages.first.highlights,
                ],
              );
            }
            _startAutoSyncTimerIfNeeded();
            await _persistState();
            _knownAccounts = await _storage.loadKnownGoogleAccounts();
            return (
              ok: true,
              message:
                  'Đăng nhập thành công! Dữ liệu đã đồng bộ từ Google Sheets & Drive.'
            );
          }

          final localFallback = await _storage.loadProgressForEmail(accountEmail);
          if (localFallback == null ||
              localFallback.user.passwordHash.length == 64) {
            return (
              ok: false,
              message: apiRes.message.isNotEmpty
                  ? apiRes.message
                  : 'Tài khoản hoặc mật khẩu chưa chính xác.'
            );
          }
        }
      }

      // Offline / local mock fallback (resolve @username via knownAccounts too)
      if (!cleanUsername.contains('@')) {
        final targetHandle = normalizeHandle(cleanUsername);
        for (final acc in _knownAccounts) {
          if (normalizeHandle(acc.effectiveUsername) == targetHandle) {
            accountEmail = acc.email;
            break;
          }
        }
      }
      var existing = await _storage.loadProgressForEmail(accountEmail);
      if (existing == null && _centralServer.isConfigured) {
        existing = await _centralServer.loadUserState(accountEmail);
      }
      if (existing == null) {
        return (
          ok: false,
          message:
              'Không tìm thấy tài khoản "$cleanUsername". Hãy chuyển sang "Đăng ký mới"!'
        );
      }

      final storedHash = existing.user.passwordHash;
      if (!_verifyPasswordHash(rawPass, storedHash)) {
        return (
          ok: false,
          message: 'Mật khẩu chưa đúng. Vui lòng kiểm tra lại!'
        );
      }

      final updatedUser = existing.user.copyWith(
        username: existing.user.username.isNotEmpty
            ? existing.user.username
            : normalizeHandle(existing.user.email.split('@').first),
        passwordHash: sha256Hash,
        hasCompletedProfileSetup: existing.user.hasCompletedProfileSetup ||
            existing.placementResult != null,
      );
      _state = _refreshStreakAndDailyQuests(existing.copyWith(user: updatedUser));
      _startAutoSyncTimerIfNeeded();
      await _persistState();
      _knownAccounts = await _storage.loadKnownGoogleAccounts();
      return (
        ok: true,
        message: 'Đăng nhập thành công! Dữ liệu đã đồng bộ từ Google Drive.'
      );
    } finally {
      _isBusy = false;
      notifyListeners();
    }
  }

  /// Changes the logged-in user's password after verifying their current SHA-256 password.
  Future<({bool ok, String message})> changePassword({
    required String oldPassword,
    required String newPassword,
  }) async {
    final current = _state;
    if (current == null) {
      return (ok: false, message: 'Bạn chưa đăng nhập.');
    }
    final oldRaw = oldPassword.trim();
    final newRaw = newPassword.trim();
    if (oldRaw.isEmpty) {
      return (ok: false, message: 'Vui lòng nhập mật khẩu hiện tại.');
    }
    if (newRaw.length < 6) {
      return (ok: false, message: 'Mật khẩu mới phải có ít nhất 6 ký tự.');
    }
    if (oldRaw == newRaw) {
      return (ok: false, message: 'Mật khẩu mới phải khác mật khẩu hiện tại.');
    }
    if (!_verifyPasswordHash(oldRaw, current.user.passwordHash)) {
      return (ok: false, message: 'Mật khẩu hiện tại không đúng.');
    }

    _isBusy = true;
    notifyListeners();
    try {
      if (_centralServer.isConfigured) {
        final apiRes = await _centralServer.changePassword(
          email: current.user.email,
          oldPassword: oldRaw,
          newPassword: newRaw,
        );
        if (!apiRes.isUnsupportedLegacyAction && !apiRes.ok) {
          return (
            ok: false,
            message: apiRes.message.isNotEmpty
                ? apiRes.message
                : 'Đổi mật khẩu thất bại.'
          );
        }
      }

      final newSha256 = _hashPasswordSha256(newRaw);
      _state = current.copyWith(
        user: current.user.copyWith(passwordHash: newSha256),
      );
      await _persistState();
      _knownAccounts = await _storage.loadKnownGoogleAccounts();
      return (
        ok: true,
        message: 'Đổi mật khẩu thành công & đã đồng bộ SHA-256 lên Google Drive!'
      );
    } finally {
      _isBusy = false;
      notifyListeners();
    }
  }

  /// Step 1 of Forgot Password: generates a 6-digit OTP (10-min expiry)
  /// on Google Apps Script and sends it strictly via Gmail (`MailApp.sendEmail`).
  /// Never exposes any OTP inside the app UI.
  Future<({bool ok, String message})> requestPasswordResetOtp({
    required String email,
  }) async {
    final cleanInput = email.trim().toLowerCase().replaceAll(RegExp(r'\s+'), '');
    if (cleanInput.isEmpty ||
        !cleanInput.contains('@') ||
        !cleanInput.contains('.')) {
      return (
        ok: false,
        message:
            'Vui lòng nhập đúng địa chỉ Email (Gmail) đã đăng ký để nhận mã OTP.',
      );
    }

    _isBusy = true;
    notifyListeners();
    try {
      if (!_centralServer.isConfigured) {
        return (
          ok: false,
          message:
              'Chưa kết nối máy chủ Google Apps Script để gửi mã OTP qua Gmail.',
        );
      }

      final apiRes = await _centralServer.forgotPassword(email: cleanInput);
      if (apiRes.isUnsupportedLegacyAction) {
        return (
          ok: false,
          message:
              'Máy chủ Apps Script chưa bật quyền gửi Email (MailApp). Vui lòng Deploy bản Code.gs mới để nhận OTP qua Gmail.',
        );
      }

      return (
        ok: apiRes.ok,
        message: apiRes.message.isNotEmpty
            ? apiRes.message
            : (apiRes.ok
                ? 'Mã OTP 6 số đã được gửi tới hộp thư Gmail $cleanInput (hiệu lực 10 phút).'
                : 'Không tìm thấy email $cleanInput trong hệ thống hoặc chưa gửi được Email.'),
      );
    } finally {
      _isBusy = false;
      notifyListeners();
    }
  }

  /// Step 2 of Forgot Password: verifies the 6-digit Gmail OTP on Google Apps Script
  /// and updates the SHA-256 password in Google Sheets & Drive JSON.
  Future<({bool ok, String message})> resetPasswordWithOtp({
    required String email,
    required String otp,
    required String newPassword,
  }) async {
    final cleanInput = email.trim().toLowerCase().replaceAll(RegExp(r'\s+'), '');
    final cleanOtp = otp.trim();
    final rawNewPass = newPassword.trim();
    if (cleanInput.isEmpty ||
        !cleanInput.contains('@') ||
        !cleanInput.contains('.')) {
      return (ok: false, message: 'Địa chỉ Email không hợp lệ.');
    }
    if (!RegExp(r'^\d{6}$').hasMatch(cleanOtp)) {
      return (ok: false, message: 'Mã OTP phải gồm đúng 6 chữ số.');
    }
    if (rawNewPass.length < 6) {
      return (ok: false, message: 'Mật khẩu mới phải có ít nhất 6 ký tự.');
    }

    _isBusy = true;
    notifyListeners();
    try {
      if (!_centralServer.isConfigured) {
        return (
          ok: false,
          message:
              'Chưa kết nối máy chủ Google Apps Script để xác thực OTP.',
        );
      }

      final apiRes = await _centralServer.resetPassword(
        email: cleanInput,
        otp: cleanOtp,
        newPassword: rawNewPass,
      );
      if (apiRes.isUnsupportedLegacyAction) {
        return (
          ok: false,
          message:
              'Máy chủ Apps Script chưa cập nhật chức năng xác thực OTP.',
        );
      }
      if (!apiRes.ok) {
        return (
          ok: false,
          message: apiRes.message.isNotEmpty
              ? apiRes.message
              : 'Mã OTP không chính xác hoặc đã hết hạn.'
        );
      }

      final localCopy = await _storage.loadProgressForEmail(cleanInput);
      if (localCopy != null) {
        await _storage.saveProgress(
          localCopy.copyWith(
            user: localCopy.user.copyWith(
              passwordHash: _hashPasswordSha256(rawNewPass),
              pendingOtpCode: '',
              pendingOtpExpiresAt: '',
            ),
          ),
        );
      }

      return (
        ok: true,
        message: apiRes.message.isNotEmpty
            ? '${apiRes.message} Bạn có thể đăng nhập bằng mật khẩu mới ngay!'
            : 'Đặt lại mật khẩu thành công! Bạn có thể đăng nhập ngay.'
      );
    } finally {
      _isBusy = false;
      notifyListeners();
    }
  }

  // ==================== PROFILE & SOCIAL / HIGH-SPEED CHAT ====================

  Future<({bool ok, String message})> updateAccountProfile({
    required String fullName,
    required String username,
  }) async {
    final current = _state;
    if (current == null) {
      return (ok: false, message: 'Bạn chưa đăng nhập.');
    }
    final cleanName = fullName.trim();
    final cleanHandle = normalizeHandle(username);
    if (cleanName.isEmpty) {
      return (ok: false, message: 'Tên hiển thị không được để trống.');
    }
    if (!RegExp(r'^[a-z0-9._]{3,30}$').hasMatch(cleanHandle)) {
      return (
        ok: false,
        message:
            'Username phải gồm 3–30 ký tự không dấu (chữ cái, số, . hoặc _).',
      );
    }

    _isBusy = true;
    notifyListeners();
    try {
      var updatedName = cleanName;
      var updatedHandle = cleanHandle;

      if (_centralServer.isConfigured) {
        final apiRes = await _centralServer.updateProfile(
          email: current.user.email,
          fullName: cleanName,
          username: cleanHandle,
        );
        if (!apiRes.isUnsupportedLegacyAction && !apiRes.ok) {
          return (
            ok: false,
            message: apiRes.message.isNotEmpty
                ? apiRes.message
                : 'Không thể cập nhật thông tin.'
          );
        }
        if (apiRes.ok) {
          if (apiRes.fullName.isNotEmpty) updatedName = apiRes.fullName;
          if (apiRes.username.isNotEmpty) updatedHandle = apiRes.username;
        }
      }

      _state = current.copyWith(
        user: current.user.copyWith(
          displayName: updatedName,
          username: updatedHandle,
        ),
      );
      await _persistState();
      _knownAccounts = await _storage.loadKnownGoogleAccounts();
      return (ok: true, message: 'Đã cập nhật hồ sơ cá nhân!');
    } finally {
      _isBusy = false;
      notifyListeners();
    }
  }

  Future<({bool ok, List<SocialUserItem> users, String message})>
      searchSocialUsers(String query) async {
    final me = _state?.user.effectiveUsername ?? '';
    return _centralServer.searchUsers(query: query, currentUser: me);
  }

  Future<({bool ok, String message})> sendFriendRequest(
      String toUsername) async {
    final me = _state?.user.effectiveUsername ?? '';
    return _centralServer.sendFriendRequest(
      fromUser: me,
      toUser: toUsername,
    );
  }

  Future<({bool ok, String message})> acceptFriendRequest(
      String fromUsername) async {
    final me = _state?.user.effectiveUsername ?? '';
    return _centralServer.acceptFriendRequest(
      fromUser: fromUsername,
      toUser: me,
    );
  }

  Future<
      ({
        bool ok,
        List<SocialUserItem> friends,
        List<SocialUserItem> pendingReceived,
        List<SocialUserItem> pendingSent,
      })> fetchFriendsOverview() async {
    final me = _state?.user.effectiveUsername ?? '';
    return _centralServer.getFriends(username: me);
  }

  Future<List<DirectChatMessage>> loadCachedDirectMessages(
      String friendUsername) async {
    final me = _state?.user.effectiveUsername ?? '';
    if (me.isEmpty) return const <DirectChatMessage>[];
    return _storage.loadCachedChatMessages(me, friendUsername);
  }

  Future<void> saveCachedDirectMessages(
    String friendUsername,
    List<DirectChatMessage> messages,
  ) async {
    final me = _state?.user.effectiveUsername ?? '';
    if (me.isEmpty) return;
    await _storage.saveCachedChatMessages(me, friendUsername, messages);
  }

  Future<({bool ok, DirectChatMessage? message, String error})>
      sendDirectMessage({
    required String receiverUsername,
    required String content,
  }) async {
    final me = _state?.user.effectiveUsername ?? '';
    if (me.isEmpty) {
      return (ok: false, message: null, error: 'Bạn chưa đăng nhập.');
    }
    return _centralServer.sendMessage(
      sender: me,
      receiver: receiverUsername,
      content: content,
    );
  }

  Future<({bool ok, List<DirectChatMessage> newMessages})>
      pollNewDirectMessages({
    required String friendUsername,
    required int lastTimestamp,
  }) async {
    final me = _state?.user.effectiveUsername ?? '';
    if (me.isEmpty) {
      return (ok: false, newMessages: const <DirectChatMessage>[]);
    }
    final res = await _centralServer.getMessages(
      currentUser: me,
      friendUser: friendUsername,
      lastTimestamp: lastTimestamp,
    );
    return (ok: res.ok, newMessages: res.messages);
  }

  /// Saves Name, Age, and Current Level right after first-time login,
  /// then prepares the tailored Placement Test.
  Future<void> completeInitialProfileSetup({
    required String displayName,
    required int age,
    required String selfAssessedLevel,
    int dailyTargetMinutes = 30,
    int targetWeeks = 8,
  }) async {
    if (_state == null) return;
    final cleanName = displayName.trim().isNotEmpty
        ? displayName.trim()
        : _state!.user.displayName;
    final clampedAge = age.clamp(6, 99);
    _state = _state!.copyWith(
      user: _state!.user.copyWith(
        displayName: cleanName,
        age: clampedAge,
        selfAssessedLevel: selfAssessedLevel,
        hasCompletedProfileSetup: true,
        dailyTargetMinutes: dailyTargetMinutes,
        targetWeeks: targetWeeks,
      ),
    );
    await _persistState();
    _knownAccounts = await _storage.loadKnownGoogleAccounts();
    notifyListeners();
  }

  Future<void> updateUserProfileInfo({
    String? displayName,
    int? age,
    String? selfAssessedLevel,
  }) async {
    if (_state == null) return;
    _state = _state!.copyWith(
      user: _state!.user.copyWith(
        displayName: displayName?.trim().isNotEmpty == true
            ? displayName!.trim()
            : _state!.user.displayName,
        age: age?.clamp(6, 99) ?? _state!.user.age,
        selfAssessedLevel:
            selfAssessedLevel ?? _state!.user.selfAssessedLevel,
      ),
    );
    await _persistState();
    _knownAccounts = await _storage.loadKnownGoogleAccounts();
    notifyListeners();
  }

  Future<AppUpdateInfo?> checkForAppUpdate() async {
    final info = await _updateService.checkForUpdate();
    _availableUpdate = info;
    notifyListeners();
    return info;
  }

  Future<bool> openAvailableUpdate() async {
    final info = _availableUpdate;
    if (info == null) return false;
    return _updateService.launchUpdateDownload(info.downloadUrl);
  }

  void clearLatestSkillBoost() {
    if (_latestSkillBoost == null) return;
    _latestSkillBoost = null;
    notifyListeners();
  }

  StudentProgressState _refreshStreakAndDailyQuests(
      StudentProgressState current) {
    final today = StudentProgressState.todayKey();
    var streak = current.streakDays;
    if (current.lastActiveDate.isNotEmpty && current.lastActiveDate != today) {
      final lastDate = DateTime.tryParse(current.lastActiveDate);
      final nowDate = DateTime.tryParse(today);
      if (lastDate != null && nowDate != null) {
        final diff = nowDate.difference(lastDate).inDays;
        if (diff == 1) {
          streak += 1;
        } else if (diff > 1) {
          streak = 1;
        }
      }
    }
    return current.copyWith(
      streakDays: streak < 1 ? 1 : streak,
      lastActiveDate: today,
      questsDate: today,
    );
  }

  /// Attempts REAL Google OAuth Sign-In (redirects to Google Account chooser,
  /// retrieves real Google Display Name, Email, Avatar, and Google Drive access token).
  Future<GoogleAuthResult> signInWithRealGoogle() async {
    _isBusy = true;
    notifyListeners();
    try {
      final outcome = await _googleAuth.signInWithGoogle();
      if (outcome.isSuccess && outcome.profile != null) {
        _driveAccessToken = outcome.accessToken;
        if (_driveAccessToken != null && _driveAccessToken!.isNotEmpty) {
          _driveSyncStatus = '☁️ Đang tải dữ liệu từ Google Drive...';
          notifyListeners();
        }
        await signInWithGoogleProfile(
          outcome.profile!,
          driveAccessToken: outcome.accessToken,
        );
      }
      return outcome;
    } finally {
      _isBusy = false;
      notifyListeners();
    }
  }

  /// Signs in with a Google profile and restores data from Google Drive Database
  /// (when OAuth token is present) or local storage.
  Future<void> signInWithGoogleProfile(
    GoogleUserProfile profile, {
    String? driveAccessToken,
  }) async {
    _isBusy = true;
    _isReviewingPlacementResult = false;
    notifyListeners();
    try {
      if (driveAccessToken != null && driveAccessToken.isNotEmpty) {
        _driveAccessToken = driveAccessToken;
      }

      StudentProgressState? existing;
      if (_centralServer.isConfigured) {
        existing = await _centralServer.loadUserState(profile.email);
        if (existing != null) {
          _driveSyncStatus = '☁️ Đã tải từ Google Drive Server';
        }
      }
      if (existing == null &&
          _driveAccessToken != null &&
          _driveAccessToken!.isNotEmpty) {
        existing = await _driveDb.loadFromGoogleDrive(_driveAccessToken!);
        if (existing != null) {
          _driveSyncStatus = '☁️ Đã đồng bộ Google Drive';
        }
      }
      existing ??= await _storage.loadProgressForEmail(profile.email);

      if (existing != null) {
        _state = _refreshStreakAndDailyQuests(
          existing.copyWith(
            user: profile.copyWith(
              targetWeeks: existing.user.targetWeeks,
              dailyTargetMinutes: existing.user.dailyTargetMinutes,
            ),
          ),
        );
      } else {
        final today = StudentProgressState.todayKey();
        _state = StudentProgressState(
          user: profile,
          streakDays: 1,
          lastActiveDate: today,
          questsDate: today,
          dailyQuests: StudentProgressState.defaultQuestsForToday(),
          savedVocab: <VocabFlashcard>[
            ...CurriculumRepository.listeningLessons.first.keyVocab,
            ...CurriculumRepository.readingPassages.first.highlights,
          ],
        );
      }
      await _persistState();
      _knownAccounts = await _storage.loadKnownGoogleAccounts();
    } finally {
      _isBusy = false;
      notifyListeners();
    }
  }

  Future<void> updateStudyPlan({
    int? dailyTargetMinutes,
    int? targetWeeks,
  }) async {
    if (_state == null) return;
    final nextMinutes = dailyTargetMinutes ?? _state!.user.dailyTargetMinutes;
    final nextWeeks = targetWeeks ?? _state!.user.targetWeeks;
    final updatedUser = _state!.user.copyWith(
      dailyTargetMinutes: nextMinutes,
      targetWeeks: nextWeeks,
    );

    var updatedPlacement = _state!.placementResult;
    if (updatedPlacement != null) {
      final weekLabels = CurriculumRepository.weekLabelsForTotal(nextWeeks);
      final rescaledPhases = List<RoadmapPhase>.generate(
        updatedPlacement.roadmapPhases.length,
        (i) {
          final p = updatedPlacement!.roadmapPhases[i];
          final label = i < weekLabels.length ? weekLabels[i] : p.weekRange;
          final suffix = p.weekRange.contains('•')
              ? ' • ${p.weekRange.split('•').last.trim()}'
              : '';
          return RoadmapPhase(
            weekRange: '$label$suffix',
            title: p.title,
            focusGoal: p.focusGoal,
            listeningTask: p.listeningTask,
            speakingTask: p.speakingTask,
            readingTask: p.readingTask,
            writingTask: p.writingTask,
            milestone: p.milestone,
          );
        },
      );
      final rescaledSchedule = CurriculumRepository.buildAdaptiveDailySchedule(
        totalMinutes: nextMinutes,
        lScore: _state!.listeningSkillScore,
        sScore: _state!.speakingSkillScore,
        rScore: _state!.readingSkillScore,
        wScore: _state!.writingSkillScore,
      );
      updatedPlacement = updatedPlacement.copyWith(
        roadmapPhases: rescaledPhases,
        dailySchedule: rescaledSchedule,
      );
    }

    _state = _state!.copyWith(
      user: updatedUser,
      placementResult: updatedPlacement,
    );
    await _persistState();
    _knownAccounts = await _storage.loadKnownGoogleAccounts();
    notifyListeners();
  }

  Future<void> signOut() async {
    _autoSyncTimer?.cancel();
    _autoSyncTimer = null;
    await tts.stop();
    await voiceRecorder.stopListening();
    await _googleAuth.signOut();
    await _storage.saveActiveEmail(null);
    _driveAccessToken = null;
    _driveSyncStatus = '☁️ Tự động đồng bộ Google Drive (Chờ đăng nhập)';
    _state = null;
    _isReviewingPlacementResult = false;
    notifyListeners();
  }

  void completePlacementReview() {
    _isReviewingPlacementResult = false;
    notifyListeners();
  }

  /// Generates a brand-new unique Placement Exam tailored to user's Age & Self-Assessed Level.
  PlacementExamSet createUniquePlacementExam() {
    final user = _state?.user;
    return CurriculumRepository.generateUniquePlacementExam(
      selfAssessedLevel:
          user?.selfAssessedLevel ?? GoogleUserProfile.levelBeginner,
      age: user?.age ?? 20,
    );
  }

  /// Grades the unique Placement Exam taken by the student and syncs to Google Drive.
  Future<PlacementTestResult> submitPlacementExam(
    PlacementSubmissionPayload submission, {
    PlacementExamSet? examSet,
  }) async {
    final current = _state!;
    _isGradingPlacementExam = true;
    _isReviewingPlacementResult = true;
    notifyListeners();

    try {
      var result = CurriculumRepository.evaluatePlacementSubmission(
        submission: submission,
        user: current.user,
        examSet: examSet,
      );

      final aiEnhanced = await _requestAiPlacementGradingAndRoadmap(
        baseResult: result,
        submission: submission,
        user: current.user,
      );
      if (aiEnhanced != null) {
        result = aiEnhanced;
      }

      final adaptiveQuests = StudentProgressState.adaptiveQuestsForToday(
        weakestSkill: result.weakestSkill,
        cefr: result.cefrLevel,
      );

      _state = current.copyWith(
        placementResult: result,
        listeningSkillScore: result.listeningScore,
        speakingSkillScore: result.speakingScore,
        readingSkillScore: result.readingScore,
        writingSkillScore: result.writingScore,
        dailyQuests: adaptiveQuests,
        totalXp: current.totalXp + 150,
        todayXp: current.todayXp + 150,
      );
      await _persistState();
      return result;
    } finally {
      _isGradingPlacementExam = false;
      notifyListeners();
    }
  }

  Future<PlacementTestResult?> _requestAiPlacementGradingAndRoadmap({
    required PlacementTestResult baseResult,
    required PlacementSubmissionPayload submission,
    required GoogleUserProfile user,
  }) async {
    try {
      final mistakeSummary = baseResult.mistakes.isEmpty
          ? 'Không sai câu trắc nghiệm nào!'
          : baseResult.mistakes
              .map((m) => '- [${m.skill.shortVi} | ${m.cefrDifficulty}] ${m.topicTag}')
              .join('\n');

      final raw = await _aiTutor
          .completeText(
            systemPrompt:
                'Bạn là gia sư tiếng Anh AI thân thiện giúp sinh viên học từ mất gốc (A1) đến giao tiếp tự tin (B2).\n'
                'Hãy chấm bài test đầu vào thật ngắn gọn, dễ hiểu, KHÔNG dùng thuật ngữ học thuật phức tạp.\n'
                'Trả về DUY NHẤT 1 JSON object hợp lệ:\n'
                '{\n'
                '  "speakingScore": 60,\n'
                '  "writingScore": 58,\n'
                '  "aiDiagnosticSummary": "Nhận xét ngắn gọn 3-4 câu dễ hiểu về trình độ hiện tại và nên bắt đầu học từ đâu",\n'
                '  "speakingFeedbackVi": "Nhận xét ngắn 1-2 câu về câu nói của bạn + 1 câu mẫu hay hơn",\n'
                '  "writingFeedbackVi": "Sửa lỗi ngắn gọn 1-2 câu cho đoạn viết của bạn",\n'
                '  "keyStrengths": ["Điểm mạnh 1"],\n'
                '  "criticalGaps": ["Điểm cần cải thiện 1", "Điểm cần cải thiện 2"],\n'
                '  "roadmapPhases": [\n'
                '    {\n'
                '      "weekRange": "Tuần 1 - 3",\n'
                '      "title": "...",\n'
                '      "focusGoal": "1 câu ngắn dễ hiểu",\n'
                '      "listeningTask": "1 câu ngắn",\n'
                '      "speakingTask": "1 câu ngắn",\n'
                '      "readingTask": "1 câu ngắn",\n'
                '      "writingTask": "1 câu ngắn",\n'
                '      "milestone": "1 câu ngắn"\n'
                '    }\n'
                '  ]\n'
                '}\n'
                'Lưu ý: roadmapPhases gồm đúng 4 giai đoạn (Tuần 1-3, 4-6, 7-9, 10-12), bắt đầu thật nhẹ nhàng phù hợp trình độ hiện tại (ưu tiên giao tiếp hàng ngày nếu trình độ A1-A2).',
            userPrompt:
                'Người học: ${user.displayName} (học ${user.dailyTargetMinutes} phút/ngày)\n'
                'Kết quả trắc nghiệm (A1 -> B1): đúng ${baseResult.objectiveCorrectCount}/${baseResult.objectiveTotalCount} câu\n'
                '- Nghe: ${baseResult.listeningScore}/100 (chép chính tả ${baseResult.dictationAccuracyPercent}%)\n'
                '- Đọc: ${baseResult.readingScore}/100\n'
                '- Các câu sai:\n$mistakeSummary\n'
                '- Nói thử 1: "${submission.speakingIntroAnswer.trim().isEmpty ? "(Bỏ qua)" : submission.speakingIntroAnswer.trim()}"\n'
                '- Nói thử 2: "${submission.speakingOpinionAnswer.trim().isEmpty ? "(Bỏ qua)" : submission.speakingOpinionAnswer.trim()}"\n'
                '- Viết thử: "${submission.writingEssayAnswer.trim().isEmpty ? "(Bỏ qua)" : submission.writingEssayAnswer.trim()}"',
            temperature: 0.55,
          )
          .timeout(const Duration(seconds: 28));

      final jsonStr = _extractJsonPayload(raw, isArray: false);
      final map = jsonDecode(jsonStr) as Map<String, dynamic>;

      final aiSpk = ((map['speakingScore'] as num?)?.toInt() ??
              baseResult.speakingScore)
          .clamp(25, 98);
      final aiWrt = ((map['writingScore'] as num?)?.toInt() ??
              baseResult.writingScore)
          .clamp(25, 98);

      // Blend AI production score with objective test scores for stability
      final finalSpk =
          ((baseResult.speakingScore * 0.35) + (aiSpk * 0.65)).round().clamp(25, 98);
      final finalWrt =
          ((baseResult.writingScore * 0.35) + (aiWrt * 0.65)).round().clamp(25, 98);
      final avg = ((baseResult.listeningScore +
                  finalSpk +
                  baseResult.readingScore +
                  finalWrt) /
              4)
          .round();
      final bands = CurriculumRepository.mapScoreToCefrIeltsToeic(avg);

      final parsedPhases = (map['roadmapPhases'] as List<dynamic>?)
              ?.whereType<Map<String, dynamic>>()
              .map(RoadmapPhase.fromJson)
              .where((p) => p.title.isNotEmpty)
              .toList() ??
          const <RoadmapPhase>[];

      final strengths = (map['keyStrengths'] as List<dynamic>?)
              ?.map((e) => e.toString())
              .where((s) => s.trim().isNotEmpty)
              .toList() ??
          baseResult.keyStrengths;

      final gaps = (map['criticalGaps'] as List<dynamic>?)
              ?.map((e) => e.toString())
              .where((s) => s.trim().isNotEmpty)
              .toList() ??
          baseResult.criticalGaps;

      final updatedSchedule = CurriculumRepository.buildAdaptiveDailySchedule(
        totalMinutes: user.dailyTargetMinutes,
        lScore: baseResult.listeningScore,
        sScore: finalSpk,
        rScore: baseResult.readingScore,
        wScore: finalWrt,
      );

      return baseResult.copyWith(
        speakingScore: finalSpk,
        writingScore: finalWrt,
        cefrLevel: bands.cefr,
        estimatedIelts: bands.ielts,
        estimatedToeic: bands.toeic,
        aiDiagnosticSummary:
            (map['aiDiagnosticSummary'] as String?)?.trim().isNotEmpty == true
                ? (map['aiDiagnosticSummary'] as String).trim()
                : baseResult.aiDiagnosticSummary,
        speakingFeedbackVi:
            (map['speakingFeedbackVi'] as String?)?.trim().isNotEmpty == true
                ? (map['speakingFeedbackVi'] as String).trim()
                : baseResult.speakingFeedbackVi,
        writingFeedbackVi:
            (map['writingFeedbackVi'] as String?)?.trim().isNotEmpty == true
                ? (map['writingFeedbackVi'] as String).trim()
                : baseResult.writingFeedbackVi,
        keyStrengths: strengths,
        criticalGaps: gaps,
        dailySchedule: updatedSchedule,
        roadmapPhases:
            parsedPhases.length >= 3 ? parsedPhases : baseResult.roadmapPhases,
        generatedByAi: true,
      );
    } catch (_) {
      return null;
    }
  }

  /// Awards XP, updates the corresponding Daily Quest, and boosts skill score.
  Future<void> recordActivityCompletion({
    required String questId,
    required SkillType skill,
    required int baseXp,
    String? lessonId,
    int skillBoost = 2,
  }) async {
    if (_state == null) return;
    final current = _state!;

    var bonusXp = baseXp;
    final updatedQuests = current.dailyQuests.map((q) {
      if (q.id == questId && !q.isCompleted) {
        final nextCount = q.currentCount + 1;
        if (nextCount >= q.targetCount) {
          bonusXp += q.xpReward;
        }
        return q.copyWith(currentCount: nextCount);
      }
      return q;
    }).toList();

    final completedIds = <String>{
      ...current.completedLessonIds,
      if (lessonId != null && lessonId.isNotEmpty) lessonId,
    }.toList();

    var lScore = current.listeningSkillScore;
    var sScore = current.speakingSkillScore;
    var rScore = current.readingSkillScore;
    var wScore = current.writingSkillScore;
    int prevScore;
    int nextScore;

    switch (skill) {
      case SkillType.listening:
        prevScore = lScore;
        lScore = (lScore + skillBoost).clamp(0, 100);
        nextScore = lScore;
        break;
      case SkillType.speaking:
        prevScore = sScore;
        sScore = (sScore + skillBoost).clamp(0, 100);
        nextScore = sScore;
        break;
      case SkillType.reading:
        prevScore = rScore;
        rScore = (rScore + skillBoost).clamp(0, 100);
        nextScore = rScore;
        break;
      case SkillType.writing:
        prevScore = wScore;
        wScore = (wScore + skillBoost).clamp(0, 100);
        nextScore = wScore;
        break;
    }

    _latestSkillBoost = SkillProgressDelta(
      skill: skill,
      previousScore: prevScore,
      newScore: nextScore,
      xpEarned: bonusXp,
      recordedAt: DateTime.now(),
    );

    _state = current.copyWith(
      totalXp: current.totalXp + bonusXp,
      todayXp: current.todayXp + bonusXp,
      dailyQuests: updatedQuests,
      dailyQuizCompletedToday:
          questId == 'q_quiz' ? true : current.dailyQuizCompletedToday,
      completedLessonIds: completedIds,
      listeningSkillScore: lScore,
      speakingSkillScore: sScore,
      readingSkillScore: rScore,
      writingSkillScore: wScore,
    );
    await _persistState();
    notifyListeners();
  }

  /// Saves or toggles mastery of a vocabulary flashcard in the user's personal deck.
  Future<void> saveVocabFlashcard(VocabFlashcard card) async {
    if (_state == null) return;
    final existing = _state!.savedVocab;
    final index = existing.indexWhere(
      (v) => v.word.toLowerCase() == card.word.toLowerCase(),
    );
    List<VocabFlashcard> updated;
    if (index >= 0) {
      updated = List<VocabFlashcard>.from(existing);
      updated[index] = card;
    } else {
      updated = <VocabFlashcard>[card, ...existing];
    }
    _state = _state!.copyWith(
      savedVocab: updated,
      totalXp: _state!.totalXp + 5,
      todayXp: _state!.todayXp + 5,
    );
    await _persistState();
    notifyListeners();
  }

  Future<void> toggleVocabMastery(String word) async {
    if (_state == null) return;
    final updated = _state!.savedVocab.map((v) {
      if (v.word.toLowerCase() == word.toLowerCase()) {
        return v.copyWith(isMastered: !v.isMastered);
      }
      return v;
    }).toList();
    _state = _state!.copyWith(savedVocab: updated);
    await _persistState();
    notifyListeners();
  }

  /// Switches immediately to another built-in Daily Workout quiz set when the user chooses "Tiếp tục câu khác".
  void switchToNextDailyQuizSet() {
    final allSets = <List<DailyQuizQuestion>>[
      CurriculumRepository.defaultDailyQuiz,
      ...CurriculumRepository.extraDailyQuizSets,
    ];
    _dailyQuizSetCursor = (_dailyQuizSetCursor + 1) % allSets.length;
    _dailyQuizQuestions = allSets[_dailyQuizSetCursor];
    notifyListeners();
  }

  /// Generates a fresh 5-question AI Daily Workout Quiz (in English + questionVi) tailored to CEFR.
  Future<bool> generateAiDailyWorkout() async {
    if (_state == null || _isGeneratingAiContent) return false;
    _isGeneratingAiContent = true;
    notifyListeners();

    try {
      final cefr = _state!.currentCefr;
      final raw = await _aiTutor.completeText(
        systemPrompt:
            'You generate 5 friendly, practical daily English multiple-choice questions for Vietnamese students. IMPORTANT: "question" and "options" MUST BE IN ENGLISH. Also provide "questionVi" as Vietnamese translation. Return ONLY a valid JSON array of 5 objects with keys: "question" (English), "questionVi" (Vietnamese translation), "options" (4 English choices), "correctIndex" (0-3), "explanationVi" (1 short easy sentence in Vietnamese), "skillTag".',
        userPrompt:
            'Create 5 practical English questions starting easy and progressing to CEFR $cefr (daily communication, basic grammar, useful vocabulary).',
        temperature: 0.7,
      );

      final jsonStr = _extractJsonPayload(raw, isArray: true);
      final decoded = jsonDecode(jsonStr) as List<dynamic>;
      final questions = decoded
          .whereType<Map<String, dynamic>>()
          .map(DailyQuizQuestion.fromJson)
          .where((q) => q.question.isNotEmpty && q.options.length >= 2)
          .toList();

      if (questions.isNotEmpty) {
        _dailyQuizQuestions = questions;
        return true;
      }
      return false;
    } catch (_) {
      return false;
    } finally {
      _isGeneratingAiContent = false;
      notifyListeners();
    }
  }

  /// Generates a custom AI Listening Lesson on any topic chosen by the student.
  Future<ListeningLesson?> generateAiListeningLesson(String topic) async {
    if (_state == null || _isGeneratingAiContent) return null;
    _isGeneratingAiContent = true;
    notifyListeners();

    try {
      final cefr = _state!.currentCefr;
      final raw = await _aiTutor.completeText(
        systemPrompt:
            'You create short, easy-to-follow English listening lessons for Vietnamese learners. IMPORTANT: MCQ "question" and "options" MUST BE IN ENGLISH, with "questionVi" in Vietnamese. Return ONLY a valid JSON object with keys: "title", "audioTranscript" (45-70 words simple natural English dialogue/story), "vietnameseTranslation", "dictationSentence" (1 short simple sentence), "keyVocab" (array of 2 objects with "word", "ipa", "partOfSpeech", "meaningVi", "exampleEn"), "questions" (array of 2 English MCQs with "question", "questionVi", "options" array of 4 English strings, "correctIndex" 0-3, "explanationVi").',
        userPrompt:
            'Generate a practical CEFR $cefr English listening lesson about "$topic". Keep vocabulary friendly and useful for daily communication.',
        temperature: 0.7,
      );

      final jsonStr = _extractJsonPayload(raw, isArray: false);
      final map = jsonDecode(jsonStr) as Map<String, dynamic>;

      final vocabList = (map['keyVocab'] as List<dynamic>?)
              ?.whereType<Map<String, dynamic>>()
              .map(VocabFlashcard.fromJson)
              .toList() ??
          const <VocabFlashcard>[];

      final qList = (map['questions'] as List<dynamic>?)
              ?.whereType<Map<String, dynamic>>()
              .map(
                (q) => ComprehensionMcq(
                  question: q['question'] as String? ?? '',
                  questionVi: q['questionVi'] as String? ?? '',
                  options: (q['options'] as List<dynamic>?)
                          ?.map((e) => e.toString())
                          .toList() ??
                      const <String>['A', 'B', 'C', 'D'],
                  correctIndex: q['correctIndex'] as int? ?? 0,
                  explanationVi: q['explanationVi'] as String? ?? '',
                ),
              )
              .toList() ??
          const <ComprehensionMcq>[];

      final lesson = ListeningLesson(
        id: 'ai_lis_${DateTime.now().millisecondsSinceEpoch}',
        title: map['title'] as String? ?? 'AI Listening: $topic',
        category: 'AI Listening • Practical',
        cefrLevel: cefr,
        durationLabel: '1 min',
        audioTranscript: map['audioTranscript'] as String? ?? '',
        vietnameseTranslation: map['vietnameseTranslation'] as String? ?? '',
        dictationSentence: map['dictationSentence'] as String? ?? '',
        keyVocab: vocabList,
        questions: qList,
      );

      if (lesson.audioTranscript.isNotEmpty) {
        _customListeningLessons.insert(0, lesson);
        return lesson;
      }
      return null;
    } catch (_) {
      return null;
    } finally {
      _isGeneratingAiContent = false;
      notifyListeners();
    }
  }

  /// Generates a custom AI Reading Passage on any topic.
  Future<ReadingPassage?> generateAiReadingPassage(String topic) async {
    if (_state == null || _isGeneratingAiContent) return null;
    _isGeneratingAiContent = true;
    notifyListeners();

    try {
      final cefr = _state!.currentCefr;
      final raw = await _aiTutor.completeText(
        systemPrompt:
            'You write short, beginner-friendly bilingual English reading articles for Vietnamese learners. IMPORTANT: MCQ "question" and "options" MUST BE IN ENGLISH, with "questionVi" in Vietnamese. Return ONLY a valid JSON object with keys: "title", "paragraphsEn" (array of 2 short simple English paragraphs), "paragraphsVi" (matching Vietnamese translations), "highlights" (array of 3 objects with "word", "ipa", "partOfSpeech", "meaningVi", "exampleEn"), "questions" (array of 2 English MCQs with "question", "questionVi", "options" array of 4 English strings, "correctIndex" 0-3, "explanationVi").',
        userPrompt:
            'Write a clear CEFR $cefr short English reading passage on "$topic" using practical everyday words.',
        temperature: 0.7,
      );

      final jsonStr = _extractJsonPayload(raw, isArray: false);
      final map = jsonDecode(jsonStr) as Map<String, dynamic>;

      final passage = ReadingPassage(
        id: 'ai_read_${DateTime.now().millisecondsSinceEpoch}',
        title: map['title'] as String? ?? 'AI Reading: $topic',
        majorTag: 'AI Reading • $cefr',
        cefrLevel: cefr,
        readingTimeLabel: '2 min read',
        paragraphsEn: (map['paragraphsEn'] as List<dynamic>?)
                ?.map((e) => e.toString())
                .toList() ??
            const <String>[],
        paragraphsVi: (map['paragraphsVi'] as List<dynamic>?)
                ?.map((e) => e.toString())
                .toList() ??
            const <String>[],
        highlights: (map['highlights'] as List<dynamic>?)
                ?.whereType<Map<String, dynamic>>()
                .map(VocabFlashcard.fromJson)
                .toList() ??
            const <VocabFlashcard>[],
        questions: (map['questions'] as List<dynamic>?)
                ?.whereType<Map<String, dynamic>>()
                .map(
                  (q) => ComprehensionMcq(
                    question: q['question'] as String? ?? '',
                    questionVi: q['questionVi'] as String? ?? '',
                    options: (q['options'] as List<dynamic>?)
                            ?.map((e) => e.toString())
                            .toList() ??
                        const <String>['A', 'B', 'C', 'D'],
                    correctIndex: q['correctIndex'] as int? ?? 0,
                    explanationVi: q['explanationVi'] as String? ?? '',
                  ),
                )
                .toList() ??
            const <ComprehensionMcq>[],
      );

      if (passage.paragraphsEn.isNotEmpty) {
        _customReadingPassages.insert(0, passage);
        return passage;
      }
      return null;
    } catch (_) {
      return null;
    } finally {
      _isGeneratingAiContent = false;
      notifyListeners();
    }
  }

  /// Friends Chat threads for "Trò chuyện bạn bè"
  List<FriendChatMessage> messagesForFriend(FriendChatContact contact) {
    return _friendChats.putIfAbsent(
      contact.id,
      () => List<FriendChatMessage>.from(contact.initialMessages),
    );
  }

  Future<void> sendFriendChatMessage({
    required FriendChatContact contact,
    required String textEn,
  }) async {
    final trimmed = textEn.trim();
    if (trimmed.isEmpty || _isFriendChatSending) return;

    final now = DateTime.now();
    final timeStr =
        '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
    final meName = _state?.user.displayName ?? 'Bạn';

    final list = List<FriendChatMessage>.from(messagesForFriend(contact))
      ..add(
        FriendChatMessage(
          senderName: meName,
          isMe: true,
          textEn: trimmed,
          timeLabel: timeStr,
        ),
      );
    _friendChats[contact.id] = list;
    _isFriendChatSending = true;
    notifyListeners();

    try {
      final raw = await _aiTutor
          .completeText(
            systemPrompt:
                '${contact.personaPrompt} Reply ONLY with valid JSON: {"replyEn": "<1-2 friendly natural English sentences>", "replyVi": "<Vietnamese translation>"}. Recognize Vietnamese proper names (like ${_state?.user.displayName ?? "Vang"}) and Vietnamese places accurately.',
            userPrompt:
                'User ($meName, level ${_state?.currentCefr ?? "A2"}) says: "$trimmed"',
            temperature: 0.7,
          )
          .timeout(const Duration(seconds: 15));

      final jsonStr = _extractJsonPayload(raw, isArray: false);
      final map = jsonDecode(jsonStr) as Map<String, dynamic>;
      final replyEn = (map['replyEn'] as String?)?.trim();
      final replyVi = (map['replyVi'] as String?)?.trim() ?? '';

      if (replyEn != null && replyEn.isNotEmpty) {
        _friendChats[contact.id] = List<FriendChatMessage>.from(list)
          ..add(
            FriendChatMessage(
              senderName: contact.name,
              isMe: false,
              textEn: replyEn,
              textVi: replyVi,
              timeLabel: timeStr,
            ),
          );
      } else {
        throw Exception('Empty reply');
      }
    } catch (_) {
      _friendChats[contact.id] = List<FriendChatMessage>.from(list)
        ..add(
          FriendChatMessage(
            senderName: contact.name,
            isMe: false,
            textEn:
                'Nice to hear from you, $meName! That sounds great—keep practicing English every day!',
            textVi:
                'Rất vui được nghe từ $meName! Nghe tuyệt lắm — hãy tiếp tục luyện tiếng Anh mỗi ngày nhé!',
            timeLabel: timeStr,
          ),
        );
    } finally {
      _isFriendChatSending = false;
      await recordActivityCompletion(
        questId: 'q_speak',
        skill: SkillType.speaking,
        baseXp: 10,
        skillBoost: 1,
      );
      notifyListeners();
    }
  }

  /// Speaking Roleplay conversation turns for a given scenario.
  List<RoleplayTurn> turnsForScenario(RoleplayScenario scenario) {
    return _roleplayHistories.putIfAbsent(
      scenario.id,
      () => <RoleplayTurn>[
        RoleplayTurn(isUser: false, text: scenario.openingLineEn),
      ],
    );
  }

  void resetRoleplayScenario(RoleplayScenario scenario) {
    _roleplayHistories[scenario.id] = <RoleplayTurn>[
      RoleplayTurn(isUser: false, text: scenario.openingLineEn),
    ];
    notifyListeners();
  }

  Future<void> sendRoleplayMessage({
    required RoleplayScenario scenario,
    required String userText,
    bool autoSpeakReply = true,
  }) async {
    final trimmed = userText.trim();
    if (trimmed.isEmpty || _isRoleplayStreaming) return;

    final turns = List<RoleplayTurn>.from(turnsForScenario(scenario))
      ..add(RoleplayTurn(isUser: true, text: trimmed))
      ..add(const RoleplayTurn(isUser: false, text: ''));
    _roleplayHistories[scenario.id] = turns;
    _isRoleplayStreaming = true;
    notifyListeners();

    final historyPayload = <Map<String, String>>[];
    for (var i = 0; i < turns.length - 1; i++) {
      final t = turns[i];
      historyPayload.add(<String, String>{
        'role': t.isUser ? 'user' : 'assistant',
        'content': t.text,
      });
    }

    final buffer = StringBuffer();
    try {
      await for (final chunk in _aiTutor.streamMessages(
        systemPrompt: scenario.systemInstruction,
        messages: historyPayload,
        temperature: 0.7,
      )) {
        buffer.write(chunk);
        final currentTurns = List<RoleplayTurn>.from(turns);
        currentTurns[currentTurns.length - 1] = RoleplayTurn(
          isUser: false,
          text: buffer.toString(),
        );
        _roleplayHistories[scenario.id] = currentTurns;
        notifyListeners();
      }

      await recordActivityCompletion(
        questId: 'q_speak',
        skill: SkillType.speaking,
        baseXp: 15,
        skillBoost: 1,
      );

      if (autoSpeakReply && buffer.isNotEmpty) {
        final fullReply = buffer.toString();
        final englishOnly = fullReply.split(RegExp(r'💡|🎯|🎓')).first.trim();
        if (englishOnly.isNotEmpty) {
          unawaited(
            tts.speak(
              englishOnly,
              id: 'rp_${scenario.id}_${turns.length}',
            ),
          );
        }
      }
    } catch (_) {
      final currentTurns = List<RoleplayTurn>.from(turns);
      currentTurns[currentTurns.length - 1] = const RoleplayTurn(
        isUser: false,
        text:
            'That is an insightful perspective! Could you elaborate further with a concrete academic example from your university coursework?\n\n💡 **Gợi ý nâng cấp câu nói (Better Phrasing):** Bạn có thể mở rộng câu trả lời bằng cấu trúc *"To illustrate this with a concrete example from my university project..."*',
      );
      _roleplayHistories[scenario.id] = currentTurns;
    } finally {
      _isRoleplayStreaming = false;
      notifyListeners();
    }
  }

  /// Evaluates a student's writing submission using AI IELTS & Academic Rubric.
  Future<WritingEvaluation> evaluateWritingSubmission({
    required WritingPrompt prompt,
    required String essayText,
  }) async {
    _isGradingWriting = true;
    notifyListeners();

    try {
      final raw = await _aiTutor.completeText(
        systemPrompt:
            'Bạn là gia sư tiếng Anh AI thân thiện. Hãy chấm bài viết thật dễ hiểu, ngắn gọn, chỉ rõ lỗi sai và viết lại 1 bản tự nhiên hơn. Trả về DUY NHẤT 1 JSON object hợp lệ:\n'
            '{\n'
            '  "overallBand": 6.0,\n'
            '  "taskResponseBand": 6.0,\n'
            '  "coherenceBand": 6.0,\n'
            '  "lexicalBand": 5.5,\n'
            '  "grammarBand": 6.0,\n'
            '  "feedbackMarkdown": "Nhận xét ngắn gọn 3-5 gạch đầu dòng bằng tiếng Việt dễ hiểu (lỗi sai -> cách sửa)",\n'
            '  "upgradedEssay": "Bản viết lại tự nhiên, chuẩn hơn bằng tiếng Anh dễ học theo"\n'
            '}',
        userPrompt:
            'Đề bài (${prompt.title}):\n${prompt.promptEn}\n\n'
            'Bài viết của người học:\n$essayText',
        temperature: 0.5,
      );

      WritingEvaluation evaluation;
      try {
        final jsonStr = _extractJsonPayload(raw, isArray: false);
        final map = jsonDecode(jsonStr) as Map<String, dynamic>;
        evaluation = WritingEvaluation(
          promptTitle: prompt.title,
          userEssay: essayText,
          overallBand: (map['overallBand'] as num?)?.toDouble() ?? 6.5,
          taskResponseBand:
              (map['taskResponseBand'] as num?)?.toDouble() ?? 6.5,
          coherenceBand: (map['coherenceBand'] as num?)?.toDouble() ?? 6.5,
          lexicalBand: (map['lexicalBand'] as num?)?.toDouble() ?? 6.5,
          grammarBand: (map['grammarBand'] as num?)?.toDouble() ?? 6.5,
          feedbackMarkdown: map['feedbackMarkdown'] as String? ?? raw,
          upgradedEssay: map['upgradedEssay'] as String? ?? '',
          submittedAt: DateTime.now(),
        );
      } catch (_) {
        evaluation = WritingEvaluation(
          promptTitle: prompt.title,
          userEssay: essayText,
          overallBand: 6.5,
          taskResponseBand: 6.5,
          coherenceBand: 6.5,
          lexicalBand: 6.5,
          grammarBand: 6.5,
          feedbackMarkdown: raw.isNotEmpty
              ? raw
              : 'Bài viết có bố cục rõ ràng, bám sát yêu cầu đề bài. Cần bổ sung thêm các liên từ học thuật (Consequently, Furthermore, Nevertheless) và mệnh đề phân từ để nâng lên Band 7.5+.',
          upgradedEssay:
              'In contemporary higher education, integrating advanced methodologies and critical analysis is paramount to achieving sustainable academic excellence.',
          submittedAt: DateTime.now(),
        );
      }

      if (_state != null) {
        final updatedHistory = <WritingEvaluation>[
          evaluation,
          ..._state!.writingHistory,
        ];
        _state = _state!.copyWith(writingHistory: updatedHistory);
        await recordActivityCompletion(
          questId: 'q_write',
          skill: SkillType.writing,
          baseXp: 50,
          lessonId: prompt.id,
          skillBoost: 3,
        );
      }
      return evaluation;
    } finally {
      _isGradingWriting = false;
      notifyListeners();
    }
  }

  /// Cloud sync export/import helpers
  String exportCloudSyncCode() {
    if (_state == null) return '';
    return _storage.exportSyncCode(_state!);
  }

  Future<bool> importCloudSyncCode(String code) async {
    final restored = _storage.importSyncCode(code);
    if (restored == null) return false;
    _state = _refreshStreakAndDailyQuests(restored);
    await _storage.saveProgress(_state!);
    _knownAccounts = await _storage.loadKnownGoogleAccounts();
    notifyListeners();
    return true;
  }

  String _extractJsonPayload(String raw, {required bool isArray}) {
    final startChar = isArray ? '[' : '{';
    final endChar = isArray ? ']' : '}';
    final startIdx = raw.indexOf(startChar);
    final endIdx = raw.lastIndexOf(endChar);
    if (startIdx >= 0 && endIdx > startIdx) {
      return raw.substring(startIdx, endIdx + 1);
    }
    return raw;
  }
}
