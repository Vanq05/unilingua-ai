import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:http/http.dart' as http;

import '../../domain/models/learning_models.dart';
import 'secret_vault.dart';

/// Response model for Auth & Profile REST endpoints (Supabase PostgreSQL + GAS MailApp).
class GasAuthApiResponse {
  const GasAuthApiResponse({
    required this.ok,
    required this.message,
    this.email = '',
    this.username = '',
    this.role = 'user',
    this.fullName = '',
    this.createdAt = '',
    this.isUnsupportedLegacyAction = false,
  });

  final bool ok;
  final String message;
  final String email;
  final String username;
  final String role;
  final String fullName;
  final String createdAt;
  final bool isUnsupportedLegacyAction;
}

/// User summary returned by `searchUsers` and `getFriends`.
class SocialUserItem {
  const SocialUserItem({
    required this.username,
    required this.fullName,
    this.email = '',
    this.friendshipStatus = 'none',
  });

  final String username;
  final String fullName;
  final String email;

  /// 'none' | 'pending_sent' | 'pending_received' | 'accepted'
  final String friendshipStatus;

  String get initials {
    final parts = fullName.trim().split(RegExp(r'\s+'));
    if (parts.isEmpty || parts.first.isEmpty) {
      return username.isNotEmpty ? username[0].toUpperCase() : 'U';
    }
    if (parts.length == 1) return parts.first[0].toUpperCase();
    return '${parts.first[0]}${parts.last[0]}'.toUpperCase();
  }

  factory SocialUserItem.fromJson(Map<String, dynamic> json) {
    return SocialUserItem(
      username: (json['username'] ?? '').toString().trim().toLowerCase(),
      fullName:
          (json['full_name'] ?? json['fullname'] ?? json['fullName'] ?? '')
              .toString()
              .trim(),
      email: (json['email'] ?? '').toString().trim().toLowerCase(),
      friendshipStatus:
          (json['friendshipStatus'] ?? 'none').toString().trim().toLowerCase(),
    );
  }
}

/// Direct peer message returned by `sendMessage` / `getMessages` / Realtime push.
class DirectChatMessage {
  const DirectChatMessage({
    required this.sender,
    required this.receiver,
    required this.content,
    required this.timestamp,
  });

  final String sender;
  final String receiver;
  final String content;
  final int timestamp;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'sender': sender,
        'receiver': receiver,
        'content': content,
        'timestamp': timestamp,
      };

  factory DirectChatMessage.fromJson(Map<String, dynamic> json) {
    final rawTs = json['timestamp_ms'] ?? json['timestamp'];
    int ts;
    if (rawTs is int) {
      ts = rawTs;
    } else if (rawTs is num) {
      ts = rawTs.toInt();
    } else {
      ts = int.tryParse((rawTs ?? '0').toString()) ??
          DateTime.tryParse((rawTs ?? '').toString())?.millisecondsSinceEpoch ??
          0;
    }
    return DirectChatMessage(
      sender: (json['sender'] ?? '').toString().trim().toLowerCase(),
      receiver: (json['receiver'] ?? '').toString().trim().toLowerCase(),
      content: (json['content'] ?? '').toString(),
      timestamp: ts,
    );
  }
}

/// High-Speed Cloud Backend Service powered by **Supabase PostgreSQL + Realtime WebSocket**
/// (~60–120ms REST, <200ms Realtime Chat) with Google Apps Script `MailApp` for Gmail OTP.
class CentralDriveServerService {
  const CentralDriveServerService();

  static const String _sharedSecret = 'UL_DB_2026_SECURE_KEY_9981';
  static const String _passwordSalt = 'UL_SHA256_SECRET_SALT_2026';

  bool get isSupabaseConfigured =>
      SecretVault.supabaseUrl.startsWith('https://') &&
      SecretVault.supabaseAnonKey.isNotEmpty;

  bool get isGasConfigured =>
      SecretVault.driveServerUrl.startsWith('https://');

  bool get isConfigured => isSupabaseConfigured || isGasConfigured;

  Map<String, String> _sbHeaders({String? prefer}) => <String, String>{
        'apikey': SecretVault.supabaseAnonKey,
        'Authorization': 'Bearer ${SecretVault.supabaseAnonKey}',
        'Content-Type': 'application/json; charset=UTF-8',
        if (prefer != null) 'Prefer': prefer,
      };

  Uri _sbUri(String table, [Map<String, String>? query]) {
    final base = Uri.parse('${SecretVault.supabaseUrl}/rest/v1/$table');
    return query == null ? base : base.replace(queryParameters: query);
  }

  /// Standard FIPS 180-4 SHA-256 hash matching GAS `Utilities.computeDigest(SHA_256, raw + SECRET_SALT)`.
  static String hashPasswordSha256(String rawPassword) {
    final trimmed = rawPassword.trim();
    if (trimmed.isEmpty) return '';
    return sha256Hex('$trimmed$_passwordSalt');
  }

  /// Pure-Dart SHA-256 Hex digest (no extra dependencies required).
  static String sha256Hex(String input) {
    final msg = utf8.encode(input);
    final bitLen = msg.length * 8;

    final padLen = ((56 - (msg.length + 1) % 64) + 64) % 64;
    final totalLen = msg.length + 1 + padLen + 8;
    final buf = Uint8List(totalLen);
    buf.setAll(0, msg);
    buf[msg.length] = 0x80;

    final bd = ByteData.sublistView(buf);
    bd.setUint32(totalLen - 8, (bitLen ~/ 0x100000000) & 0xffffffff, Endian.big);
    bd.setUint32(totalLen - 4, bitLen & 0xffffffff, Endian.big);

    const k = <int>[
      0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1,
      0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
      0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786,
      0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
      0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
      0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
      0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b,
      0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
      0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a,
      0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
      0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
    ];

    var h0 = 0x6a09e667;
    var h1 = 0xbb67ae85;
    var h2 = 0x3c6ef372;
    var h3 = 0xa54ff53a;
    var h4 = 0x510e527f;
    var h5 = 0x9b05688c;
    var h6 = 0x1f83d9ab;
    var h7 = 0x5be0cd19;

    final w = Uint32List(64);
    for (var offset = 0; offset < totalLen; offset += 64) {
      for (var i = 0; i < 16; i++) {
        w[i] = bd.getUint32(offset + i * 4, Endian.big);
      }
      for (var i = 16; i < 64; i++) {
        final s0 = _rotr(w[i - 15], 7) ^
            _rotr(w[i - 15], 18) ^
            ((w[i - 15] & 0xffffffff) >> 3);
        final s1 = _rotr(w[i - 2], 17) ^
            _rotr(w[i - 2], 19) ^
            ((w[i - 2] & 0xffffffff) >> 10);
        w[i] = (w[i - 16] + s0 + w[i - 7] + s1) & 0xffffffff;
      }

      var a = h0;
      var b = h1;
      var c = h2;
      var d = h3;
      var e = h4;
      var f = h5;
      var g = h6;
      var h = h7;

      for (var i = 0; i < 64; i++) {
        final S1 = _rotr(e, 6) ^ _rotr(e, 11) ^ _rotr(e, 25);
        final ch = (e & f) ^ ((~e & 0xffffffff) & g);
        final temp1 = (h + S1 + ch + k[i] + w[i]) & 0xffffffff;
        final S0 = _rotr(a, 2) ^ _rotr(a, 13) ^ _rotr(a, 22);
        final maj = (a & b) ^ (a & c) ^ (b & c);
        final temp2 = (S0 + maj) & 0xffffffff;

        h = g;
        g = f;
        f = e;
        e = (d + temp1) & 0xffffffff;
        d = c;
        c = b;
        b = a;
        a = (temp1 + temp2) & 0xffffffff;
      }

      h0 = (h0 + a) & 0xffffffff;
      h1 = (h1 + b) & 0xffffffff;
      h2 = (h2 + c) & 0xffffffff;
      h3 = (h3 + d) & 0xffffffff;
      h4 = (h4 + e) & 0xffffffff;
      h5 = (h5 + f) & 0xffffffff;
      h6 = (h6 + g) & 0xffffffff;
      h7 = (h7 + h) & 0xffffffff;
    }

    final sb = StringBuffer();
    for (final v in <int>[h0, h1, h2, h3, h4, h5, h6, h7]) {
      sb.write(v.toRadixString(16).padLeft(8, '0'));
    }
    return sb.toString();
  }

  static int _rotr(int x, int n) {
    final u = x & 0xffffffff;
    return ((u >> n) | (u << (32 - n))) & 0xffffffff;
  }

  // ==================== AUTH & PROFILE (SUPABASE PRIMARY) ====================

  Future<GasAuthApiResponse> registerAccount({
    required String email,
    required String password,
    required String fullName,
    String username = '',
  }) async {
    final cleanEmail = email.trim().toLowerCase();
    final cleanName = fullName.trim();
    final cleanHandle = (username.trim().isNotEmpty
            ? username.trim().toLowerCase()
            : cleanEmail.split('@').first)
        .replaceAll(RegExp(r'^@+'), '')
        .replaceAll(RegExp(r'[^a-z0-9._]'), '');

    if (isSupabaseConfigured) {
      try {
        final checkResp = await http
            .get(
              _sbUri('users', <String, String>{
                'or': '(email.eq.$cleanEmail,username.eq.$cleanHandle)',
                'select': 'email,username',
              }),
              headers: _sbHeaders(),
            )
            .timeout(const Duration(seconds: 10));

        if (checkResp.statusCode == 200) {
          final rows = jsonDecode(checkResp.body) as List<dynamic>;
          for (final row in rows.whereType<Map<String, dynamic>>()) {
            if ((row['email'] ?? '').toString().toLowerCase() == cleanEmail) {
              return const GasAuthApiResponse(
                ok: false,
                message: 'Email này đã được đăng ký.',
              );
            }
            if ((row['username'] ?? '').toString().toLowerCase() ==
                cleanHandle) {
              return GasAuthApiResponse(
                ok: false,
                message:
                    'Username @$cleanHandle đã có người sử dụng. Hãy chọn tên khác!',
              );
            }
          }
        }

        final nowIso = DateTime.now().toUtc().toIso8601String();
        final insertResp = await http
            .post(
              _sbUri('users'),
              headers: _sbHeaders(prefer: 'return=representation'),
              body: jsonEncode(<String, dynamic>{
                'email': cleanEmail,
                'password_hash': hashPasswordSha256(password),
                'full_name': cleanName,
                'username': cleanHandle,
                'role': 'user',
                'created_at': nowIso,
              }),
            )
            .timeout(const Duration(seconds: 10));

        if (insertResp.statusCode >= 200 && insertResp.statusCode < 300) {
          // Best-effort background mirror to GAS Users sheet for Gmail OTP lookup
          if (isGasConfigured) {
            unawaited(
              _callGasAuthEndpoint(<String, dynamic>{
                'action': 'register',
                'email': cleanEmail,
                'password': password,
                'fullname': cleanName,
                'username': cleanHandle,
              }),
            );
          }
          return GasAuthApiResponse(
            ok: true,
            message: 'Đăng ký thành công (Supabase)!',
            email: cleanEmail,
            username: cleanHandle,
            fullName: cleanName,
            role: 'user',
            createdAt: nowIso,
          );
        }
      } catch (_) {
        // Fallback to GAS below if Supabase unreachable
      }
    }

    return _callGasAuthEndpoint(<String, dynamic>{
      'action': 'register',
      'email': cleanEmail,
      'password': password,
      'fullname': cleanName,
      if (cleanHandle.isNotEmpty) 'username': cleanHandle,
    });
  }

  Future<GasAuthApiResponse> loginAccount({
    required String email,
    required String password,
  }) async {
    final id = email.trim().toLowerCase().replaceFirst(RegExp(r'^@+'), '');
    final handleId = id.replaceAll(RegExp(r'[^a-z0-9._]'), '');
    final passHash = hashPasswordSha256(password);

    if (isSupabaseConfigured) {
      try {
        final resp = await http
            .get(
              _sbUri('users', <String, String>{
                'or': '(email.eq.$id,username.eq.$handleId)',
                'select': 'email,password_hash,full_name,username,role,created_at',
                'limit': '1',
              }),
              headers: _sbHeaders(),
            )
            .timeout(const Duration(seconds: 10));

        if (resp.statusCode == 200) {
          final rows = jsonDecode(resp.body) as List<dynamic>;
          if (rows.isNotEmpty && rows.first is Map<String, dynamic>) {
            final row = rows.first as Map<String, dynamic>;
            if ((row['password_hash'] ?? '').toString().trim() == passHash) {
              return GasAuthApiResponse(
                ok: true,
                message: 'Đăng nhập thành công!',
                email: (row['email'] ?? '').toString(),
                username: (row['username'] ?? '').toString(),
                fullName: (row['full_name'] ?? '').toString(),
                role: (row['role'] ?? 'user').toString(),
                createdAt: (row['created_at'] ?? '').toString(),
              );
            }
            return const GasAuthApiResponse(
              ok: false,
              message: 'Mật khẩu không chính xác.',
            );
          }

          // Account not in Supabase yet: try seamless migration from legacy GAS
          if (isGasConfigured) {
            final gasRes = await _callGasAuthEndpoint(<String, dynamic>{
              'action': 'login',
              'identifier': id,
              'email': id,
              'username': handleId,
              'password': password,
            });
            if (gasRes.ok && gasRes.email.isNotEmpty) {
              final migratedHandle = gasRes.username.isNotEmpty
                  ? gasRes.username
                  : gasRes.email.split('@').first;
              unawaited(
                http.post(
                  _sbUri('users'),
                  headers: _sbHeaders(prefer: 'resolution=merge-duplicates'),
                  body: jsonEncode(<String, dynamic>{
                    'email': gasRes.email,
                    'password_hash': passHash,
                    'full_name': gasRes.fullName.isNotEmpty
                        ? gasRes.fullName
                        : migratedHandle,
                    'username': migratedHandle,
                    'role': gasRes.role,
                  }),
                ),
              );
              return gasRes;
            }
          }

          return const GasAuthApiResponse(
            ok: false,
            message: 'Tài khoản hoặc mật khẩu không chính xác.',
          );
        }
      } catch (_) {
        // Fall through to GAS
      }
    }

    return _callGasAuthEndpoint(<String, dynamic>{
      'action': 'login',
      'identifier': id,
      'email': id,
      'username': handleId,
      'password': password,
    });
  }

  Future<GasAuthApiResponse> changePassword({
    required String email,
    required String oldPassword,
    required String newPassword,
  }) async {
    final cleanEmail = email.trim().toLowerCase();
    final oldHash = hashPasswordSha256(oldPassword);
    final newHash = hashPasswordSha256(newPassword);

    if (isSupabaseConfigured) {
      try {
        final check = await http
            .get(
              _sbUri('users', <String, String>{
                'email': 'eq.$cleanEmail',
                'select': 'password_hash',
                'limit': '1',
              }),
              headers: _sbHeaders(),
            )
            .timeout(const Duration(seconds: 10));
        if (check.statusCode == 200) {
          final rows = jsonDecode(check.body) as List<dynamic>;
          if (rows.isNotEmpty && rows.first is Map<String, dynamic>) {
            final stored =
                ((rows.first as Map<String, dynamic>)['password_hash'] ?? '')
                    .toString();
            if (stored.isNotEmpty && stored != oldHash) {
              return const GasAuthApiResponse(
                ok: false,
                message: 'Mật khẩu hiện tại không đúng.',
              );
            }
          }
          final patch = await http
              .patch(
                _sbUri('users', <String, String>{'email': 'eq.$cleanEmail'}),
                headers: _sbHeaders(),
                body: jsonEncode(<String, dynamic>{'password_hash': newHash}),
              )
              .timeout(const Duration(seconds: 10));
          if (patch.statusCode >= 200 && patch.statusCode < 300) {
            if (isGasConfigured) {
              unawaited(
                _callGasAuthEndpoint(<String, dynamic>{
                  'action': 'change_password',
                  'email': cleanEmail,
                  'old_password': oldPassword,
                  'new_password': newPassword,
                }),
              );
            }
            return const GasAuthApiResponse(
              ok: true,
              message: 'Đổi mật khẩu thành công!',
            );
          }
        }
      } catch (_) {}
    }

    return _callGasAuthEndpoint(<String, dynamic>{
      'action': 'change_password',
      'email': cleanEmail,
      'old_password': oldPassword,
      'new_password': newPassword,
    });
  }

  /// Forgot Password uses Google Apps Script `MailApp` to send real 6-digit OTP to Gmail.
  Future<GasAuthApiResponse> forgotPassword({required String email}) =>
      _callGasAuthEndpoint(<String, dynamic>{
        'action': 'forgot_password',
        'email': email.trim().toLowerCase(),
      });

  Future<GasAuthApiResponse> resetPassword({
    required String email,
    required String otp,
    required String newPassword,
  }) async {
    final cleanEmail = email.trim().toLowerCase();
    final res = await _callGasAuthEndpoint(<String, dynamic>{
      'action': 'reset_password',
      'email': cleanEmail,
      'otp': otp.trim(),
      'new_password': newPassword,
    });
    if (res.ok && isSupabaseConfigured) {
      try {
        await http
            .patch(
              _sbUri('users', <String, String>{'email': 'eq.$cleanEmail'}),
              headers: _sbHeaders(),
              body: jsonEncode(<String, dynamic>{
                'password_hash': hashPasswordSha256(newPassword),
              }),
            )
            .timeout(const Duration(seconds: 8));
      } catch (_) {}
    }
    return res;
  }

  Future<GasAuthApiResponse> updateProfile({
    required String email,
    required String fullName,
    required String username,
  }) async {
    final cleanEmail = email.trim().toLowerCase();
    final cleanName = fullName.trim();
    final cleanHandle = username.trim().toLowerCase();

    if (isSupabaseConfigured) {
      try {
        // Verify username uniqueness
        final dup = await http
            .get(
              _sbUri('users', <String, String>{
                'username': 'eq.$cleanHandle',
                'email': 'neq.$cleanEmail',
                'select': 'email',
                'limit': '1',
              }),
              headers: _sbHeaders(),
            )
            .timeout(const Duration(seconds: 10));
        if (dup.statusCode == 200) {
          final rows = jsonDecode(dup.body) as List<dynamic>;
          if (rows.isNotEmpty) {
            return GasAuthApiResponse(
              ok: false,
              message: 'Username @$cleanHandle đã thuộc về người khác.',
            );
          }
        }

        // Fetch old username to migrate friends/messages if changed
        String oldHandle = '';
        final cur = await http
            .get(
              _sbUri('users', <String, String>{
                'email': 'eq.$cleanEmail',
                'select': 'username',
                'limit': '1',
              }),
              headers: _sbHeaders(),
            )
            .timeout(const Duration(seconds: 8));
        if (cur.statusCode == 200) {
          final rows = jsonDecode(cur.body) as List<dynamic>;
          if (rows.isNotEmpty && rows.first is Map<String, dynamic>) {
            oldHandle =
                ((rows.first as Map<String, dynamic>)['username'] ?? '')
                    .toString();
          }
        }

        final patch = await http
            .patch(
              _sbUri('users', <String, String>{'email': 'eq.$cleanEmail'}),
              headers: _sbHeaders(),
              body: jsonEncode(<String, dynamic>{
                'full_name': cleanName,
                'username': cleanHandle,
              }),
            )
            .timeout(const Duration(seconds: 10));

        if (patch.statusCode >= 200 && patch.statusCode < 300) {
          if (oldHandle.isNotEmpty && oldHandle != cleanHandle) {
            unawaited(_migrateHandleInSocialTables(oldHandle, cleanHandle));
          }
          return GasAuthApiResponse(
            ok: true,
            message: 'Cập nhật hồ sơ thành công!',
            email: cleanEmail,
            fullName: cleanName,
            username: cleanHandle,
          );
        }
      } catch (_) {}
    }

    return _callGasAuthEndpoint(<String, dynamic>{
      'action': 'update_profile',
      'email': cleanEmail,
      'fullname': cleanName,
      'username': cleanHandle,
    });
  }

  Future<void> _migrateHandleInSocialTables(
      String oldHandle, String newHandle) async {
    try {
      await Future.wait(<Future<dynamic>>[
        http.patch(
          _sbUri('friends', <String, String>{'user_a': 'eq.$oldHandle'}),
          headers: _sbHeaders(),
          body: jsonEncode(<String, dynamic>{'user_a': newHandle}),
        ),
        http.patch(
          _sbUri('friends', <String, String>{'user_b': 'eq.$oldHandle'}),
          headers: _sbHeaders(),
          body: jsonEncode(<String, dynamic>{'user_b': newHandle}),
        ),
        http.patch(
          _sbUri('messages', <String, String>{'sender': 'eq.$oldHandle'}),
          headers: _sbHeaders(),
          body: jsonEncode(<String, dynamic>{'sender': newHandle}),
        ),
        http.patch(
          _sbUri('messages', <String, String>{'receiver': 'eq.$oldHandle'}),
          headers: _sbHeaders(),
          body: jsonEncode(<String, dynamic>{'receiver': newHandle}),
        ),
      ]);
    } catch (_) {}
  }

  // ==================== FRIENDS & REALTIME CHAT (SUPABASE) ====================

  Future<({bool ok, List<SocialUserItem> users, String message})> searchUsers({
    required String query,
    required String currentUser,
  }) async {
    final q = query.trim().replaceFirst(RegExp(r'^@+'), '');
    final me = currentUser.trim().toLowerCase();
    if (q.isEmpty) {
      return (ok: true, users: const <SocialUserItem>[], message: '');
    }

    if (isSupabaseConfigured) {
      try {
        final usersResp = await http
            .get(
              _sbUri('users', <String, String>{
                'or': '(username.ilike.*$q*,full_name.ilike.*$q*)',
                if (me.isNotEmpty) 'username': 'neq.$me',
                'select': 'email,full_name,username',
                'limit': '25',
              }),
              headers: _sbHeaders(),
            )
            .timeout(const Duration(seconds: 10));

        if (usersResp.statusCode == 200) {
          final statusMap = await _fetchFriendshipStatusMap(me);
          final rows = jsonDecode(usersResp.body) as List<dynamic>;
          final list = <SocialUserItem>[
            for (final r in rows.whereType<Map<String, dynamic>>())
              SocialUserItem(
                username: (r['username'] ?? '').toString().toLowerCase(),
                fullName: (r['full_name'] ?? '').toString(),
                email: (r['email'] ?? '').toString().toLowerCase(),
                friendshipStatus:
                    statusMap[(r['username'] ?? '').toString().toLowerCase()] ??
                        'none',
              ),
          ];
          return (ok: true, users: list, message: '');
        }
      } catch (_) {}
    }

    if (!isGasConfigured) {
      return (
        ok: false,
        users: const <SocialUserItem>[],
        message: 'Chưa kết nối máy chủ.',
      );
    }
    try {
      final resp = await _postFollowingRedirects(
        Uri.parse(SecretVault.driveServerUrl),
        <String, dynamic>{
          'action': 'search_user',
          'query': q,
          'current_user': me,
        },
      );
      if (resp == null || resp.statusCode != 200) {
        return (
          ok: false,
          users: const <SocialUserItem>[],
          message: 'Lỗi tìm kiếm người dùng.',
        );
      }
      final decoded = jsonDecode(resp.body) as Map<String, dynamic>;
      final raw = decoded['users'];
      final list = <SocialUserItem>[
        if (raw is List)
          for (final item in raw)
            if (item is Map<String, dynamic>)
              SocialUserItem.fromJson(item)
            else if (item is Map)
              SocialUserItem.fromJson(Map<String, dynamic>.from(item)),
      ];
      return (ok: true, users: list, message: '');
    } catch (_) {
      return (
        ok: false,
        users: const <SocialUserItem>[],
        message: 'Không thể tìm kiếm người dùng.',
      );
    }
  }

  Future<Map<String, String>> _fetchFriendshipStatusMap(String me) async {
    final map = <String, String>{};
    if (me.isEmpty || !isSupabaseConfigured) return map;
    try {
      final resp = await http
          .get(
            _sbUri('friends', <String, String>{
              'or': '(user_a.eq.$me,user_b.eq.$me)',
              'select': 'user_a,user_b,status',
            }),
            headers: _sbHeaders(),
          )
          .timeout(const Duration(seconds: 8));
      if (resp.statusCode == 200) {
        final rows = jsonDecode(resp.body) as List<dynamic>;
        for (final r in rows.whereType<Map<String, dynamic>>()) {
          final a = (r['user_a'] ?? '').toString().toLowerCase();
          final b = (r['user_b'] ?? '').toString().toLowerCase();
          final st = (r['status'] ?? '').toString().toLowerCase();
          if (a == me) {
            map[b] = st == 'accepted' ? 'accepted' : 'pending_sent';
          } else if (b == me) {
            map[a] = st == 'accepted' ? 'accepted' : 'pending_received';
          }
        }
      }
    } catch (_) {}
    return map;
  }

  Future<({bool ok, String message})> sendFriendRequest({
    required String fromUser,
    required String toUser,
  }) async {
    final f = fromUser.trim().toLowerCase();
    final t = toUser.trim().toLowerCase();
    if (f.isEmpty || t.isEmpty || f == t) {
      return (ok: false, message: 'Thông tin kết bạn không hợp lệ.');
    }

    if (isSupabaseConfigured) {
      try {
        final existing = await http
            .get(
              _sbUri('friends', <String, String>{
                'or': '(and(user_a.eq.$f,user_b.eq.$t),and(user_a.eq.$t,user_b.eq.$f))',
                'select': 'id,user_a,user_b,status',
                'limit': '1',
              }),
              headers: _sbHeaders(),
            )
            .timeout(const Duration(seconds: 8));
        if (existing.statusCode == 200) {
          final rows = jsonDecode(existing.body) as List<dynamic>;
          if (rows.isNotEmpty && rows.first is Map<String, dynamic>) {
            final row = rows.first as Map<String, dynamic>;
            final st = (row['status'] ?? '').toString();
            if (st == 'accepted') {
              return (ok: true, message: 'Hai bạn đã là bạn bè.');
            }
            if ((row['user_a'] ?? '').toString() == t) {
              await http.patch(
                _sbUri('friends', <String, String>{'id': 'eq.${row['id']}'}),
                headers: _sbHeaders(),
                body: jsonEncode(<String, dynamic>{'status': 'accepted'}),
              );
              return (ok: true, message: 'Hai bạn đã trở thành bạn bè!');
            }
            return (ok: true, message: 'Đã gửi lời mời kết bạn cho @$t.');
          }
        }

        final ins = await http
            .post(
              _sbUri('friends'),
              headers: _sbHeaders(),
              body: jsonEncode(<String, dynamic>{
                'user_a': f,
                'user_b': t,
                'status': 'pending',
              }),
            )
            .timeout(const Duration(seconds: 8));
        if (ins.statusCode >= 200 && ins.statusCode < 300) {
          return (ok: true, message: 'Đã gửi lời mời kết bạn tới @$t!');
        }
      } catch (_) {}
    }

    return (ok: false, message: 'Không thể gửi lời mời kết bạn.');
  }

  Future<({bool ok, String message})> acceptFriendRequest({
    required String fromUser,
    required String toUser,
  }) async {
    final f = fromUser.trim().toLowerCase();
    final t = toUser.trim().toLowerCase();

    if (isSupabaseConfigured) {
      try {
        final patch = await http
            .patch(
              _sbUri('friends', <String, String>{
                'or': '(and(user_a.eq.$f,user_b.eq.$t),and(user_a.eq.$t,user_b.eq.$f))',
              }),
              headers: _sbHeaders(),
              body: jsonEncode(<String, dynamic>{'status': 'accepted'}),
            )
            .timeout(const Duration(seconds: 8));
        if (patch.statusCode >= 200 && patch.statusCode < 300) {
          return (ok: true, message: 'Đã chấp nhận kết bạn với @$f!');
        }
      } catch (_) {}
    }
    return (ok: false, message: 'Không thể xác nhận kết bạn.');
  }

  Future<
      ({
        bool ok,
        List<SocialUserItem> friends,
        List<SocialUserItem> pendingReceived,
        List<SocialUserItem> pendingSent,
      })> getFriends({required String username}) async {
    final me = username.trim().toLowerCase();
    if (me.isEmpty) {
      return (
        ok: false,
        friends: const <SocialUserItem>[],
        pendingReceived: const <SocialUserItem>[],
        pendingSent: const <SocialUserItem>[],
      );
    }

    if (isSupabaseConfigured) {
      try {
        final fResp = await http
            .get(
              _sbUri('friends', <String, String>{
                'or': '(user_a.eq.$me,user_b.eq.$me)',
                'select': 'user_a,user_b,status',
              }),
              headers: _sbHeaders(),
            )
            .timeout(const Duration(seconds: 8));
        if (fResp.statusCode == 200) {
          final fRows = (jsonDecode(fResp.body) as List<dynamic>)
              .whereType<Map<String, dynamic>>()
              .toList();
          final peerSet = <String>{};
          for (final r in fRows) {
            final a = (r['user_a'] ?? '').toString().toLowerCase();
            final b = (r['user_b'] ?? '').toString().toLowerCase();
            if (a != me && a.isNotEmpty) peerSet.add(a);
            if (b != me && b.isNotEmpty) peerSet.add(b);
          }

          final profileByHandle = <String, Map<String, dynamic>>{};
          if (peerSet.isNotEmpty) {
            final inClause = '(${peerSet.join(',')})';
            final uResp = await http
                .get(
                  _sbUri('users', <String, String>{
                    'username': 'in.$inClause',
                    'select': 'username,full_name,email',
                  }),
                  headers: _sbHeaders(),
                )
                .timeout(const Duration(seconds: 8));
            if (uResp.statusCode == 200) {
              for (final u in (jsonDecode(uResp.body) as List<dynamic>)
                  .whereType<Map<String, dynamic>>()) {
                final h = (u['username'] ?? '').toString().toLowerCase();
                if (h.isNotEmpty) profileByHandle[h] = u;
              }
            }
          }

          final friends = <SocialUserItem>[];
          final pendingReceived = <SocialUserItem>[];
          final pendingSent = <SocialUserItem>[];

          for (final r in fRows) {
            final a = (r['user_a'] ?? '').toString().toLowerCase();
            final b = (r['user_b'] ?? '').toString().toLowerCase();
            final st = (r['status'] ?? '').toString().toLowerCase();
            final peer = a == me ? b : a;
            final info = profileByHandle[peer];
            final fullName = (info?['full_name'] ?? peer).toString();
            final email = (info?['email'] ?? '').toString();

            if (st == 'accepted') {
              friends.add(
                SocialUserItem(
                  username: peer,
                  fullName: fullName,
                  email: email,
                  friendshipStatus: 'accepted',
                ),
              );
            } else if (b == me) {
              pendingReceived.add(
                SocialUserItem(
                  username: peer,
                  fullName: fullName,
                  email: email,
                  friendshipStatus: 'pending_received',
                ),
              );
            } else {
              pendingSent.add(
                SocialUserItem(
                  username: peer,
                  fullName: fullName,
                  email: email,
                  friendshipStatus: 'pending_sent',
                ),
              );
            }
          }

          return (
            ok: true,
            friends: friends,
            pendingReceived: pendingReceived,
            pendingSent: pendingSent,
          );
        }
      } catch (_) {}
    }

    return (
      ok: false,
      friends: const <SocialUserItem>[],
      pendingReceived: const <SocialUserItem>[],
      pendingSent: const <SocialUserItem>[],
    );
  }

  Future<({bool ok, DirectChatMessage? message, String error})> sendMessage({
    required String sender,
    required String receiver,
    required String content,
  }) async {
    final s = sender.trim().toLowerCase();
    final r = receiver.trim().toLowerCase();
    final c = content.trim();
    if (s.isEmpty || r.isEmpty || c.isEmpty) {
      return (ok: false, message: null, error: 'Tin nhắn không hợp lệ.');
    }

    if (isSupabaseConfigured) {
      try {
        final nowMs = DateTime.now().millisecondsSinceEpoch;
        final resp = await http
            .post(
              _sbUri('messages'),
              headers: _sbHeaders(prefer: 'return=representation'),
              body: jsonEncode(<String, dynamic>{
                'sender': s,
                'receiver': r,
                'content': c,
                'timestamp_ms': nowMs,
              }),
            )
            .timeout(const Duration(seconds: 8));

        if (resp.statusCode >= 200 && resp.statusCode < 300) {
          return (
            ok: true,
            message: DirectChatMessage(
              sender: s,
              receiver: r,
              content: c,
              timestamp: nowMs,
            ),
            error: '',
          );
        }
      } catch (_) {}
    }

    return (ok: false, message: null, error: 'Không thể gửi tin nhắn.');
  }

  Future<({bool ok, List<DirectChatMessage> messages})> getMessages({
    required String currentUser,
    required String friendUser,
    required int lastTimestamp,
  }) async {
    final u1 = currentUser.trim().toLowerCase();
    final u2 = friendUser.trim().toLowerCase();

    if (isSupabaseConfigured) {
      try {
        final resp = await http
            .get(
              _sbUri('messages', <String, String>{
                'or': '(and(sender.eq.$u1,receiver.eq.$u2),and(sender.eq.$u2,receiver.eq.$u1))',
                'timestamp_ms': 'gt.$lastTimestamp',
                'order': 'timestamp_ms.desc',
                'limit': '100',
              }),
              headers: _sbHeaders(),
            )
            .timeout(const Duration(seconds: 8));
        if (resp.statusCode == 200) {
          final rows = (jsonDecode(resp.body) as List<dynamic>)
              .whereType<Map<String, dynamic>>()
              .map(DirectChatMessage.fromJson)
              .toList()
              .reversed
              .toList();
          return (ok: true, messages: rows);
        }
      } catch (_) {}
    }

    return (ok: false, messages: const <DirectChatMessage>[]);
  }

  /// Connects to **Supabase Realtime WebSocket** (`public.messages` INSERT stream)
  /// so new chat messages arrive in <200ms without waiting for polling.
  Stream<DirectChatMessage> subscribeDirectMessages({
    required String currentUser,
    required String friendUser,
  }) {
    if (!isSupabaseConfigured) {
      return const Stream<DirectChatMessage>.empty();
    }

    final u1 = currentUser.trim().toLowerCase();
    final u2 = friendUser.trim().toLowerCase();
    final controller = StreamController<DirectChatMessage>();
    WebSocket? socket;
    Timer? heartbeat;
    var closed = false;

    Future<void> connect() async {
      try {
        final host = Uri.parse(SecretVault.supabaseUrl).host;
        final wsUrl =
            'wss://$host/realtime/v1/websocket?apikey=${SecretVault.supabaseAnonKey}&vsn=1.0.0';
        socket = await WebSocket.connect(wsUrl)
            .timeout(const Duration(seconds: 10));
        if (closed) {
          await socket?.close();
          return;
        }

        // Join Phoenix realtime channel for `public.messages` INSERTs
        socket!.add(
          jsonEncode(<String, dynamic>{
            'topic': 'realtime:public:messages',
            'event': 'phx_join',
            'payload': <String, dynamic>{
              'config': <String, dynamic>{
                'postgres_changes': <Map<String, dynamic>>[
                  <String, dynamic>{
                    'event': 'INSERT',
                    'schema': 'public',
                    'table': 'messages',
                  },
                ],
              },
            },
            'ref': '1',
          }),
        );

        var refCounter = 2;
        heartbeat = Timer.periodic(const Duration(seconds: 25), (_) {
          if (!closed && socket != null) {
            try {
              socket!.add(
                jsonEncode(<String, dynamic>{
                  'topic': 'phoenix',
                  'event': 'heartbeat',
                  'payload': <String, dynamic>{},
                  'ref': '${refCounter++}',
                }),
              );
            } catch (_) {}
          }
        });

        socket!.listen(
          (dynamic raw) {
            if (closed || raw is! String) return;
            try {
              final frame = jsonDecode(raw) as Map<String, dynamic>;
              if (frame['event'] != 'postgres_changes') return;
              final payload = frame['payload'] as Map<String, dynamic>?;
              final data = payload?['data'] as Map<String, dynamic>?;
              final record = data?['record'] as Map<String, dynamic>?;
              if (record == null) return;
              final msg = DirectChatMessage.fromJson(record);
              if ((msg.sender == u1 && msg.receiver == u2) ||
                  (msg.sender == u2 && msg.receiver == u1)) {
                controller.add(msg);
              }
            } catch (_) {}
          },
          onError: (_) {},
          onDone: () {},
        );
      } catch (_) {
        // Silent fallback: ChatRoomScreen Smart Polling continues working
      }
    }

    controller.onListen = () {
      unawaited(connect());
    };
    controller.onCancel = () async {
      closed = true;
      heartbeat?.cancel();
      heartbeat = null;
      try {
        await socket?.close();
      } catch (_) {}
    };

    return controller.stream;
  }

  // ==================== STUDENT PROGRESS SYNC (SUPABASE PRIMARY) ====================

  Future<StudentProgressState?> loadUserState(String email) async {
    final cleanEmail = email.trim().toLowerCase();
    if (!isConfigured || cleanEmail.isEmpty) return null;

    if (isSupabaseConfigured) {
      try {
        final resp = await http
            .get(
              _sbUri('user_progress', <String, String>{
                'email': 'eq.$cleanEmail',
                'select': 'state_json',
                'limit': '1',
              }),
              headers: _sbHeaders(),
            )
            .timeout(const Duration(seconds: 10));
        if (resp.statusCode == 200) {
          final rows = jsonDecode(resp.body) as List<dynamic>;
          if (rows.isNotEmpty && rows.first is Map<String, dynamic>) {
            final stateJson =
                (rows.first as Map<String, dynamic>)['state_json'];
            if (stateJson is Map<String, dynamic>) {
              return StudentProgressState.fromJson(stateJson);
            }
          }
        }
      } catch (_) {}
    }

    // Legacy fallback from Google Drive Server if user hasn't synced to Supabase yet
    if (isGasConfigured) {
      try {
        final resp = await _postFollowingRedirects(
          Uri.parse(SecretVault.driveServerUrl),
          <String, dynamic>{
            'secret': _sharedSecret,
            'action': 'load',
            'email': cleanEmail,
          },
        );
        if (resp != null && resp.statusCode == 200) {
          final decoded = jsonDecode(resp.body) as Map<String, dynamic>;
          if (decoded['ok'] == true && decoded['found'] == true) {
            final data = decoded['data'] as Map<String, dynamic>?;
            if (data != null) return StudentProgressState.fromJson(data);
          }
        }
      } catch (_) {}
    }
    return null;
  }

  Future<bool> saveUserState(StudentProgressState state) async {
    if (!isConfigured) return false;
    final cleanEmail = state.user.email.trim().toLowerCase();

    if (isSupabaseConfigured) {
      try {
        final resp = await http
            .post(
              _sbUri('user_progress'),
              headers: _sbHeaders(prefer: 'resolution=merge-duplicates'),
              body: jsonEncode(<String, dynamic>{
                'email': cleanEmail,
                'state_json': state.toJson(),
                'updated_at': DateTime.now().toUtc().toIso8601String(),
              }),
            )
            .timeout(const Duration(seconds: 10));
        if (resp.statusCode >= 200 && resp.statusCode < 300) {
          return true;
        }
      } catch (_) {}
    }

    if (isGasConfigured) {
      try {
        final resp = await _postFollowingRedirects(
          Uri.parse(SecretVault.driveServerUrl),
          <String, dynamic>{
            'secret': _sharedSecret,
            'action': 'save',
            'email': cleanEmail,
            'data': state.toJson(),
          },
        );
        if (resp != null && resp.statusCode == 200) {
          final decoded = jsonDecode(resp.body) as Map<String, dynamic>;
          return decoded['ok'] == true && decoded['saved'] == true;
        }
      } catch (_) {}
    }
    return false;
  }

  // ==================== GAS HELPER (GMAIL OTP & LEGACY) ====================

  Future<GasAuthApiResponse> _callGasAuthEndpoint(
      Map<String, dynamic> payload) async {
    if (!isGasConfigured) {
      return const GasAuthApiResponse(
        ok: false,
        message: 'Offline mode',
        isUnsupportedLegacyAction: true,
      );
    }
    try {
      final resp = await _postFollowingRedirects(
        Uri.parse(SecretVault.driveServerUrl),
        payload,
      );
      if (resp == null || resp.statusCode != 200) {
        return const GasAuthApiResponse(
          ok: false,
          message: 'Lỗi kết nối máy chủ Email OTP.',
          isUnsupportedLegacyAction: true,
        );
      }
      final decoded = jsonDecode(resp.body) as Map<String, dynamic>;
      final errStr = (decoded['error'] ?? '').toString().toLowerCase();
      if (errStr.contains('unknown action') || errStr.contains('unauthorized')) {
        return GasAuthApiResponse(
          ok: false,
          message: errStr,
          isUnsupportedLegacyAction: true,
        );
      }
      final isOk = decoded['ok'] == true || decoded['status'] == 'success';
      final userMap = decoded['user'] as Map<String, dynamic>?;
      return GasAuthApiResponse(
        ok: isOk,
        message: (decoded['message'] ?? decoded['error'] ?? '').toString(),
        email: (userMap?['email'] ?? '').toString(),
        username: (userMap?['username'] ?? '').toString(),
        role: (userMap?['role'] ?? 'user').toString(),
        fullName: (userMap?['fullname'] ?? '').toString(),
        createdAt: (userMap?['createdAt'] ?? '').toString(),
      );
    } catch (_) {
      return const GasAuthApiResponse(
        ok: false,
        message: 'Không thể kết nối máy chủ.',
        isUnsupportedLegacyAction: true,
      );
    }
  }

  Future<http.Response?> _postFollowingRedirects(
    Uri url,
    Map<String, dynamic> payload,
  ) async {
    final client = http.Client();
    try {
      final req = http.Request('POST', url)
        ..followRedirects = false
        ..headers['Content-Type'] = 'application/json; charset=UTF-8'
        ..body = jsonEncode(payload);

      final streamed =
          await client.send(req).timeout(const Duration(seconds: 18));
      if (<int>{301, 302, 303, 307, 308}.contains(streamed.statusCode)) {
        final location = streamed.headers['location'];
        if (location == null || location.isEmpty) return null;
        return await client
            .get(Uri.parse(location))
            .timeout(const Duration(seconds: 18));
      }
      return await http.Response.fromStream(streamed);
    } finally {
      client.close();
    }
  }
}
