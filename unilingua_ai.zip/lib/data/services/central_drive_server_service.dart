import 'dart:convert';
import 'dart:typed_data';

import 'package:http/http.dart' as http;

import '../../domain/models/learning_models.dart';
import 'secret_vault.dart';

/// Response model for Google Apps Script Auth & Profile REST endpoints.
class GasAuthApiResponse {
  const GasAuthApiResponse({
    required this.ok,
    required this.message,
    this.email = '',
    this.username = '',
    this.role = 'user',
    this.fullName = '',
    this.createdAt = '',
    this.isUnsupportedLegacyAction = false,
  });

  final bool ok;
  final String message;
  final String email;
  final String username;
  final String role;
  final String fullName;
  final String createdAt;
  final bool isUnsupportedLegacyAction;
}

/// User summary returned by `search_user` and `get_friends`.
class SocialUserItem {
  const SocialUserItem({
    required this.username,
    required this.fullName,
    this.email = '',
    this.friendshipStatus = 'none',
  });

  final String username;
  final String fullName;
  final String email;

  /// 'none' | 'pending_sent' | 'pending_received' | 'accepted'
  final String friendshipStatus;

  String get initials {
    final parts = fullName.trim().split(RegExp(r'\s+'));
    if (parts.isEmpty || parts.first.isEmpty) {
      return username.isNotEmpty ? username[0].toUpperCase() : 'U';
    }
    if (parts.length == 1) return parts.first[0].toUpperCase();
    return '${parts.first[0]}${parts.last[0]}'.toUpperCase();
  }

  factory SocialUserItem.fromJson(Map<String, dynamic> json) {
    return SocialUserItem(
      username: (json['username'] ?? '').toString().trim().toLowerCase(),
      fullName: (json['fullname'] ?? json['fullName'] ?? '').toString().trim(),
      email: (json['email'] ?? '').toString().trim().toLowerCase(),
      friendshipStatus:
          (json['friendshipStatus'] ?? 'none').toString().trim().toLowerCase(),
    );
  }
}

/// Direct peer message returned by `send_message` / `get_messages`.
class DirectChatMessage {
  const DirectChatMessage({
    required this.sender,
    required this.receiver,
    required this.content,
    required this.timestamp,
  });

  final String sender;
  final String receiver;
  final String content;
  final int timestamp;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'sender': sender,
        'receiver': receiver,
        'content': content,
        'timestamp': timestamp,
      };

  factory DirectChatMessage.fromJson(Map<String, dynamic> json) {
    final rawTs = json['timestamp'];
    int ts;
    if (rawTs is int) {
      ts = rawTs;
    } else if (rawTs is num) {
      ts = rawTs.toInt();
    } else {
      ts = int.tryParse((rawTs ?? '0').toString()) ??
          DateTime.tryParse((rawTs ?? '').toString())?.millisecondsSinceEpoch ??
          0;
    }
    return DirectChatMessage(
      sender: (json['sender'] ?? '').toString().trim().toLowerCase(),
      receiver: (json['receiver'] ?? '').toString().trim().toLowerCase(),
      content: (json['content'] ?? '').toString(),
      timestamp: ts,
    );
  }
}

/// Connects UniLingua AI to the fixed Central Google Drive + Sheets Server
/// (Google Apps Script Web App) for:
/// - SHA-256 salted password hashing (matching server `Code.gs`)
/// - 5 Auth REST actions (`register`, `login`, `change_password`, `forgot_password`, `reset_password`)
/// - Complete student progress persistence (`load` / `save`)
class CentralDriveServerService {
  const CentralDriveServerService();

  static const String _sharedSecret = 'UL_DB_2026_SECURE_KEY_9981';
  static const String _passwordSalt = 'UL_SHA256_SECRET_SALT_2026';

  bool get isConfigured => SecretVault.driveServerUrl.startsWith('https://');

  /// Standard FIPS 180-4 SHA-256 hash matching GAS `Utilities.computeDigest(SHA_256, raw + SECRET_SALT)`.
  static String hashPasswordSha256(String rawPassword) {
    final trimmed = rawPassword.trim();
    if (trimmed.isEmpty) return '';
    return sha256Hex('$trimmed$_passwordSalt');
  }

  /// Pure-Dart SHA-256 Hex digest (no extra dependencies required).
  static String sha256Hex(String input) {
    final msg = utf8.encode(input);
    final bitLen = msg.length * 8;

    final padLen = ((56 - (msg.length + 1) % 64) + 64) % 64;
    final totalLen = msg.length + 1 + padLen + 8;
    final buf = Uint8List(totalLen);
    buf.setAll(0, msg);
    buf[msg.length] = 0x80;

    final bd = ByteData.sublistView(buf);
    bd.setUint32(totalLen - 8, (bitLen ~/ 0x100000000) & 0xffffffff, Endian.big);
    bd.setUint32(totalLen - 4, bitLen & 0xffffffff, Endian.big);

    const k = <int>[
      0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1,
      0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
      0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786,
      0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
      0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
      0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
      0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b,
      0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
      0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a,
      0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
      0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
    ];

    var h0 = 0x6a09e667;
    var h1 = 0xbb67ae85;
    var h2 = 0x3c6ef372;
    var h3 = 0xa54ff53a;
    var h4 = 0x510e527f;
    var h5 = 0x9b05688c;
    var h6 = 0x1f83d9ab;
    var h7 = 0x5be0cd19;

    final w = Uint32List(64);
    for (var offset = 0; offset < totalLen; offset += 64) {
      for (var i = 0; i < 16; i++) {
        w[i] = bd.getUint32(offset + i * 4, Endian.big);
      }
      for (var i = 16; i < 64; i++) {
        final s0 = _rotr(w[i - 15], 7) ^
            _rotr(w[i - 15], 18) ^
            ((w[i - 15] & 0xffffffff) >> 3);
        final s1 = _rotr(w[i - 2], 17) ^
            _rotr(w[i - 2], 19) ^
            ((w[i - 2] & 0xffffffff) >> 10);
        w[i] = (w[i - 16] + s0 + w[i - 7] + s1) & 0xffffffff;
      }

      var a = h0;
      var b = h1;
      var c = h2;
      var d = h3;
      var e = h4;
      var f = h5;
      var g = h6;
      var h = h7;

      for (var i = 0; i < 64; i++) {
        final S1 = _rotr(e, 6) ^ _rotr(e, 11) ^ _rotr(e, 25);
        final ch = (e & f) ^ ((~e & 0xffffffff) & g);
        final temp1 = (h + S1 + ch + k[i] + w[i]) & 0xffffffff;
        final S0 = _rotr(a, 2) ^ _rotr(a, 13) ^ _rotr(a, 22);
        final maj = (a & b) ^ (a & c) ^ (b & c);
        final temp2 = (S0 + maj) & 0xffffffff;

        h = g;
        g = f;
        f = e;
        e = (d + temp1) & 0xffffffff;
        d = c;
        c = b;
        b = a;
        a = (temp1 + temp2) & 0xffffffff;
      }

      h0 = (h0 + a) & 0xffffffff;
      h1 = (h1 + b) & 0xffffffff;
      h2 = (h2 + c) & 0xffffffff;
      h3 = (h3 + d) & 0xffffffff;
      h4 = (h4 + e) & 0xffffffff;
      h5 = (h5 + f) & 0xffffffff;
      h6 = (h6 + g) & 0xffffffff;
      h7 = (h7 + h) & 0xffffffff;
    }

    final sb = StringBuffer();
    for (final v in <int>[h0, h1, h2, h3, h4, h5, h6, h7]) {
      sb.write(v.toRadixString(16).padLeft(8, '0'));
    }
    return sb.toString();
  }

  static int _rotr(int x, int n) {
    final u = x & 0xffffffff;
    return ((u >> n) | (u << (32 - n))) & 0xffffffff;
  }

  // ==================== AUTH & PROFILE REST ENDPOINTS ====================

  Future<GasAuthApiResponse> registerAccount({
    required String email,
    required String password,
    required String fullName,
    String username = '',
  }) =>
      _callAuthEndpoint(<String, dynamic>{
        'action': 'register',
        'email': email.trim().toLowerCase(),
        'password': password,
        'fullname': fullName.trim(),
        if (username.trim().isNotEmpty)
          'username': username.trim().toLowerCase(),
      });

  Future<GasAuthApiResponse> loginAccount({
    required String email,
    required String password,
  }) =>
      _callAuthEndpoint(<String, dynamic>{
        'action': 'login',
        'identifier': email.trim().toLowerCase(),
        'email': email.trim().toLowerCase(),
        'username': email.trim().toLowerCase(),
        'password': password,
      });

  Future<GasAuthApiResponse> changePassword({
    required String email,
    required String oldPassword,
    required String newPassword,
  }) =>
      _callAuthEndpoint(<String, dynamic>{
        'action': 'change_password',
        'email': email.trim().toLowerCase(),
        'old_password': oldPassword,
        'new_password': newPassword,
      });

  Future<GasAuthApiResponse> forgotPassword({required String email}) =>
      _callAuthEndpoint(<String, dynamic>{
        'action': 'forgot_password',
        'email': email.trim().toLowerCase(),
      });

  Future<GasAuthApiResponse> resetPassword({
    required String email,
    required String otp,
    required String newPassword,
  }) =>
      _callAuthEndpoint(<String, dynamic>{
        'action': 'reset_password',
        'email': email.trim().toLowerCase(),
        'otp': otp.trim(),
        'new_password': newPassword,
      });

  Future<GasAuthApiResponse> updateProfile({
    required String email,
    required String fullName,
    required String username,
  }) =>
      _callAuthEndpoint(<String, dynamic>{
        'action': 'update_profile',
        'email': email.trim().toLowerCase(),
        'fullname': fullName.trim(),
        'username': username.trim().toLowerCase(),
      });

  Future<GasAuthApiResponse> _callAuthEndpoint(
      Map<String, dynamic> payload) async {
    if (!isConfigured) {
      return const GasAuthApiResponse(
        ok: false,
        message: 'Offline mode',
        isUnsupportedLegacyAction: true,
      );
    }
    try {
      final resp = await _postFollowingRedirects(
        Uri.parse(SecretVault.driveServerUrl),
        payload,
      );
      if (resp == null || resp.statusCode != 200) {
        return const GasAuthApiResponse(
          ok: false,
          message: 'Lỗi kết nối Google Apps Script.',
          isUnsupportedLegacyAction: true,
        );
      }
      final decoded = jsonDecode(resp.body) as Map<String, dynamic>;
      final errStr = (decoded['error'] ?? '').toString().toLowerCase();
      if (errStr.contains('unknown action') || errStr.contains('unauthorized')) {
        return GasAuthApiResponse(
          ok: false,
          message: errStr,
          isUnsupportedLegacyAction: true,
        );
      }
      final isOk = decoded['ok'] == true || decoded['status'] == 'success';
      final userMap = decoded['user'] as Map<String, dynamic>?;
      return GasAuthApiResponse(
        ok: isOk,
        message: (decoded['message'] ?? decoded['error'] ?? '').toString(),
        email: (userMap?['email'] ?? '').toString(),
        username: (userMap?['username'] ?? '').toString(),
        role: (userMap?['role'] ?? 'user').toString(),
        fullName: (userMap?['fullname'] ?? '').toString(),
        createdAt: (userMap?['createdAt'] ?? '').toString(),
      );
    } catch (_) {
      return const GasAuthApiResponse(
        ok: false,
        message: 'Không thể kết nối máy chủ.',
        isUnsupportedLegacyAction: true,
      );
    }
  }

  // ==================== STUDENT PROGRESS SYNC (DRIVE JSON DB) ====================

  /// Loads a user's progress state from the central Google Drive Database.
  Future<StudentProgressState?> loadUserState(String email) async {
    if (!isConfigured || email.trim().isEmpty) return null;
    try {
      final resp = await _postFollowingRedirects(
        Uri.parse(SecretVault.driveServerUrl),
        <String, dynamic>{
          'secret': _sharedSecret,
          'action': 'load',
          'email': email.trim().toLowerCase(),
        },
      );
      if (resp == null || resp.statusCode != 200) return null;

      final decoded = jsonDecode(resp.body) as Map<String, dynamic>;
      if (decoded['ok'] != true || decoded['found'] != true) return null;
      final data = decoded['data'] as Map<String, dynamic>?;
      if (data == null) return null;
      return StudentProgressState.fromJson(data);
    } catch (_) {
      return null;
    }
  }

  /// Saves/updates a user's progress state into the central Google Drive Database.
  Future<bool> saveUserState(StudentProgressState state) async {
    if (!isConfigured) return false;
    try {
      final resp = await _postFollowingRedirects(
        Uri.parse(SecretVault.driveServerUrl),
        <String, dynamic>{
          'secret': _sharedSecret,
          'action': 'save',
          'email': state.user.email.trim().toLowerCase(),
          'data': state.toJson(),
        },
      );
      if (resp == null || resp.statusCode != 200) return false;
      final decoded = jsonDecode(resp.body) as Map<String, dynamic>;
      return decoded['ok'] == true && decoded['saved'] == true;
    } catch (_) {
      return false;
    }
  }

  // ==================== FRIENDS & HIGH-SPEED CHAT API ====================

  Future<({bool ok, List<SocialUserItem> users, String message})> searchUsers({
    required String query,
    required String currentUser,
  }) async {
    if (!isConfigured) {
      return (
        ok: false,
        users: const <SocialUserItem>[],
        message: 'Chưa kết nối máy chủ.',
      );
    }
    try {
      final resp = await _postFollowingRedirects(
        Uri.parse(SecretVault.driveServerUrl),
        <String, dynamic>{
          'action': 'search_user',
          'query': query.trim(),
          'current_user': currentUser.trim().toLowerCase(),
        },
      );
      if (resp == null || resp.statusCode != 200) {
        return (
          ok: false,
          users: const <SocialUserItem>[],
          message: 'Lỗi tìm kiếm người dùng.',
        );
      }
      final decoded = jsonDecode(resp.body) as Map<String, dynamic>;
      final isOk = decoded['ok'] == true || decoded['status'] == 'success';
      final raw = decoded['users'];
      final list = <SocialUserItem>[
        if (raw is List)
          for (final item in raw)
            if (item is Map<String, dynamic>)
              SocialUserItem.fromJson(item)
            else if (item is Map)
              SocialUserItem.fromJson(Map<String, dynamic>.from(item)),
      ];
      return (
        ok: isOk,
        users: list,
        message: (decoded['message'] ?? '').toString(),
      );
    } catch (_) {
      return (
        ok: false,
        users: const <SocialUserItem>[],
        message: 'Không thể tìm kiếm người dùng.',
      );
    }
  }

  Future<({bool ok, String message})> sendFriendRequest({
    required String fromUser,
    required String toUser,
  }) async {
    if (!isConfigured) {
      return (ok: false, message: 'Chưa kết nối máy chủ.');
    }
    try {
      final resp = await _postFollowingRedirects(
        Uri.parse(SecretVault.driveServerUrl),
        <String, dynamic>{
          'action': 'send_friend_request',
          'from_user': fromUser.trim().toLowerCase(),
          'to_user': toUser.trim().toLowerCase(),
        },
      );
      if (resp == null || resp.statusCode != 200) {
        return (ok: false, message: 'Lỗi gửi lời mời kết bạn.');
      }
      final decoded = jsonDecode(resp.body) as Map<String, dynamic>;
      final isOk = decoded['ok'] == true || decoded['status'] == 'success';
      return (
        ok: isOk,
        message: (decoded['message'] ?? decoded['error'] ?? '').toString(),
      );
    } catch (_) {
      return (ok: false, message: 'Không thể gửi lời mời kết bạn.');
    }
  }

  Future<({bool ok, String message})> acceptFriendRequest({
    required String fromUser,
    required String toUser,
  }) async {
    if (!isConfigured) {
      return (ok: false, message: 'Chưa kết nối máy chủ.');
    }
    try {
      final resp = await _postFollowingRedirects(
        Uri.parse(SecretVault.driveServerUrl),
        <String, dynamic>{
          'action': 'accept_friend_request',
          'from_user': fromUser.trim().toLowerCase(),
          'to_user': toUser.trim().toLowerCase(),
        },
      );
      if (resp == null || resp.statusCode != 200) {
        return (ok: false, message: 'Lỗi chấp nhận lời mời.');
      }
      final decoded = jsonDecode(resp.body) as Map<String, dynamic>;
      final isOk = decoded['ok'] == true || decoded['status'] == 'success';
      return (
        ok: isOk,
        message: (decoded['message'] ?? decoded['error'] ?? '').toString(),
      );
    } catch (_) {
      return (ok: false, message: 'Không thể xác nhận kết bạn.');
    }
  }

  Future<
      ({
        bool ok,
        List<SocialUserItem> friends,
        List<SocialUserItem> pendingReceived,
        List<SocialUserItem> pendingSent,
      })> getFriends({required String username}) async {
    if (!isConfigured || username.trim().isEmpty) {
      return (
        ok: false,
        friends: const <SocialUserItem>[],
        pendingReceived: const <SocialUserItem>[],
        pendingSent: const <SocialUserItem>[],
      );
    }
    try {
      final resp = await _postFollowingRedirects(
        Uri.parse(SecretVault.driveServerUrl),
        <String, dynamic>{
          'action': 'get_friends',
          'username': username.trim().toLowerCase(),
        },
      );
      if (resp == null || resp.statusCode != 200) {
        return (
          ok: false,
          friends: const <SocialUserItem>[],
          pendingReceived: const <SocialUserItem>[],
          pendingSent: const <SocialUserItem>[],
        );
      }
      final decoded = jsonDecode(resp.body) as Map<String, dynamic>;
      final isOk = decoded['ok'] == true || decoded['status'] == 'success';

      List<SocialUserItem> parseList(dynamic raw) => <SocialUserItem>[
            if (raw is List)
              for (final item in raw)
                if (item is Map<String, dynamic>)
                  SocialUserItem.fromJson(item)
                else if (item is Map)
                  SocialUserItem.fromJson(Map<String, dynamic>.from(item)),
          ];

      return (
        ok: isOk,
        friends: parseList(decoded['friends']),
        pendingReceived: parseList(decoded['pending_received']),
        pendingSent: parseList(decoded['pending_sent']),
      );
    } catch (_) {
      return (
        ok: false,
        friends: const <SocialUserItem>[],
        pendingReceived: const <SocialUserItem>[],
        pendingSent: const <SocialUserItem>[],
      );
    }
  }

  Future<({bool ok, DirectChatMessage? message, String error})> sendMessage({
    required String sender,
    required String receiver,
    required String content,
  }) async {
    if (!isConfigured) {
      return (ok: false, message: null, error: 'Chưa kết nối máy chủ.');
    }
    try {
      final resp = await _postFollowingRedirects(
        Uri.parse(SecretVault.driveServerUrl),
        <String, dynamic>{
          'action': 'send_message',
          'sender': sender.trim().toLowerCase(),
          'receiver': receiver.trim().toLowerCase(),
          'content': content.trim(),
        },
      );
      if (resp == null || resp.statusCode != 200) {
        return (ok: false, message: null, error: 'Lỗi gửi tin nhắn.');
      }
      final decoded = jsonDecode(resp.body) as Map<String, dynamic>;
      final isOk = decoded['ok'] == true || decoded['status'] == 'success';
      final rawMsg = decoded['message_item'] ?? decoded['data'];
      DirectChatMessage? msgObj;
      if (rawMsg is Map<String, dynamic>) {
        msgObj = DirectChatMessage.fromJson(rawMsg);
      } else if (rawMsg is Map) {
        msgObj = DirectChatMessage.fromJson(Map<String, dynamic>.from(rawMsg));
      }
      return (
        ok: isOk,
        message: msgObj,
        error: (decoded['message'] ?? decoded['error'] ?? '').toString(),
      );
    } catch (_) {
      return (ok: false, message: null, error: 'Không thể gửi tin nhắn.');
    }
  }

  Future<({bool ok, List<DirectChatMessage> messages})> getMessages({
    required String currentUser,
    required String friendUser,
    required int lastTimestamp,
  }) async {
    if (!isConfigured) {
      return (ok: false, messages: const <DirectChatMessage>[]);
    }
    try {
      final resp = await _postFollowingRedirects(
        Uri.parse(SecretVault.driveServerUrl),
        <String, dynamic>{
          'action': 'get_messages',
          'user1': currentUser.trim().toLowerCase(),
          'user2': friendUser.trim().toLowerCase(),
          'last_timestamp': lastTimestamp,
        },
      );
      if (resp == null || resp.statusCode != 200) {
        return (ok: false, messages: const <DirectChatMessage>[]);
      }
      final decoded = jsonDecode(resp.body) as Map<String, dynamic>;
      final isOk = decoded['ok'] == true || decoded['status'] == 'success';
      final raw = decoded['messages'];
      final list = <DirectChatMessage>[
        if (raw is List)
          for (final item in raw)
            if (item is Map<String, dynamic>)
              DirectChatMessage.fromJson(item)
            else if (item is Map)
              DirectChatMessage.fromJson(Map<String, dynamic>.from(item)),
      ];
      return (ok: isOk, messages: list);
    } catch (_) {
      return (ok: false, messages: const <DirectChatMessage>[]);
    }
  }

  /// Google Apps Script Web Apps respond to POST with a 302 redirect to a
  /// googleusercontent.com URL that must be followed with GET to read the JSON result.
  Future<http.Response?> _postFollowingRedirects(
    Uri url,
    Map<String, dynamic> payload,
  ) async {
    final client = http.Client();
    try {
      final req = http.Request('POST', url)
        ..followRedirects = false
        ..headers['Content-Type'] = 'application/json; charset=UTF-8'
        ..body = jsonEncode(payload);

      final streamed =
          await client.send(req).timeout(const Duration(seconds: 18));
      if (<int>{301, 302, 303, 307, 308}.contains(streamed.statusCode)) {
        final location = streamed.headers['location'];
        if (location == null || location.isEmpty) return null;
        return await client
            .get(Uri.parse(location))
            .timeout(const Duration(seconds: 18));
      }
      return await http.Response.fromStream(streamed);
    } finally {
      client.close();
    }
  }
}
