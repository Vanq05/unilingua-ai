import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import 'secret_vault.dart';

/// Service communicating with the hidden OpenAI-compatible AI endpoint.
/// Token usage is intentionally never exposed or displayed in the UI.
class AiTutorService {
  AiTutorService();

  static const List<String> _fallbackModels = <String>[
    'gpt-6-luna',
    'gpt-6.2-sol',
    'gpt-6.2-astra',
  ];

  String _activeModel = _fallbackModels.first;
  bool _modelsInitialized = false;

  String get activeModel => _activeModel;

  Future<void> ensureModelInitialized() async {
    if (_modelsInitialized) return;
    _modelsInitialized = true;
    try {
      final uri = Uri.parse('${SecretVault.baseUrl}/models');
      final response = await http.get(
        uri,
        headers: <String, String>{
          'Authorization': 'Bearer ${SecretVault.apiKey}',
        },
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final decoded = jsonDecode(response.body) as Map<String, dynamic>;
        final data = decoded['data'] as List<dynamic>? ?? const <dynamic>[];
        final ids = data
            .whereType<Map<String, dynamic>>()
            .map((m) => m['id'] as String? ?? '')
            .where((id) => id.isNotEmpty)
            .toList();
        if (ids.isNotEmpty) {
          if (ids.contains('gpt-6-luna')) {
            _activeModel = 'gpt-6-luna';
          } else {
            _activeModel = ids.first;
          }
        }
      }
    } catch (_) {
      _activeModel = _fallbackModels.first;
    }
  }

  /// Sends a single prompt and returns the complete response text.
  Future<String> completeText({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.65,
  }) async {
    await ensureModelInitialized();
    final buffer = StringBuffer();
    final client = http.Client();
    try {
      await for (final chunk in streamMessages(
        systemPrompt: systemPrompt,
        messages: <Map<String, String>>[
          <String, String>{'role': 'user', 'content': userPrompt},
        ],
        temperature: temperature,
        client: client,
      )) {
        buffer.write(chunk);
      }
    } finally {
      client.close();
    }
    return buffer.toString().trim();
  }

  /// Streams assistant text chunks via SSE without exposing token usage.
  Stream<String> streamMessages({
    required String systemPrompt,
    required List<Map<String, String>> messages,
    double temperature = 0.7,
    http.Client? client,
  }) async* {
    await ensureModelInitialized();
    final ownClient = client == null;
    final activeClient = client ?? http.Client();

    try {
      final payloadMessages = <Map<String, dynamic>>[
        if (systemPrompt.trim().isNotEmpty)
          <String, dynamic>{
            'role': 'system',
            'content': systemPrompt.trim(),
          },
        ...messages.map(
          (m) => <String, dynamic>{
            'role': m['role'] ?? 'user',
            'content': m['content'] ?? '',
          },
        ),
      ];

      final uri = Uri.parse('${SecretVault.baseUrl}/chat/completions');
      final request = http.Request('POST', uri)
        ..headers['Content-Type'] = 'application/json'
        ..headers['Authorization'] = 'Bearer ${SecretVault.apiKey}'
        ..headers['Accept'] = 'text/event-stream'
        ..body = jsonEncode(<String, dynamic>{
          'model': _activeModel,
          'messages': payloadMessages,
          'temperature': temperature,
          'stream': true,
        });

      final streamed = await activeClient
          .send(request)
          .timeout(const Duration(seconds: 60));

      if (streamed.statusCode != 200) {
        final errBody = await streamed.stream.bytesToString();
        // If non-streaming JSON was returned or an error occurred
        var friendly = 'Không thể kết nối AI Tutor (${streamed.statusCode}).';
        try {
          final errJson = jsonDecode(errBody) as Map<String, dynamic>;
          final msg = (errJson['error'] as Map<String, dynamic>?)?['message']
              as String?;
          if (msg != null && msg.trim().isNotEmpty) {
            friendly = msg.trim();
          }
        } catch (_) {}
        throw Exception(friendly);
      }

      final lines = streamed.stream
          .transform(utf8.decoder)
          .transform(const LineSplitter());

      await for (final rawLine in lines) {
        final line = rawLine.trim();
        if (!line.startsWith('data:')) continue;
        final payload = line.substring(5).trim();
        if (payload.isEmpty) continue;
        if (payload == '[DONE]') break;

        try {
          final decoded = jsonDecode(payload) as Map<String, dynamic>;
          final choices = decoded['choices'] as List<dynamic>?;
          if (choices == null || choices.isEmpty) continue;
          final firstChoice = choices.first as Map<String, dynamic>;
          final delta = firstChoice['delta'] as Map<String, dynamic>?;
          final content = delta?['content'] as String? ??
              (firstChoice['message'] as Map<String, dynamic>?)?['content']
                  as String?;
          if (content != null && content.isNotEmpty) {
            yield content;
          }
        } catch (_) {
          // Ignore keep-alive or partial lines
        }
      }
    } finally {
      if (ownClient) {
        activeClient.close();
      }
    }
  }
}
