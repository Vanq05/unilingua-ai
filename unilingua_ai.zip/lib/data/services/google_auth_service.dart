import 'package:flutter/foundation.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../../domain/models/learning_models.dart';

class GoogleAuthResult {
  const GoogleAuthResult({
    this.profile,
    this.accessToken,
    this.errorReason = '',
    this.isSha1ConfigError = false,
  });

  final GoogleUserProfile? profile;
  final String? accessToken;
  final String errorReason;
  final bool isSha1ConfigError;

  bool get isSuccess => profile != null;
}

/// Real Google Sign-In OAuth service requesting profile, email, and Google Drive
/// (`drive.file` + `drive.appdata`) so the student's Google Drive acts as their live cloud database.
class GoogleAuthService {
  GoogleAuthService();

  static const String androidPackageName = 'com.unilingua.ai.unilingua_ai';
  static const String releaseKeystoreSha1 =
      'CA:59:94:6D:5A:3B:EB:96:63:C8:58:E1:2D:C4:F3:DB:75:A5:FC:7E';

  final GoogleSignIn _googleSignIn = GoogleSignIn(
    scopes: <String>[
      'email',
      'profile',
      'https://www.googleapis.com/auth/drive.file',
      'https://www.googleapis.com/auth/drive.appdata',
    ],
  );

  /// Silently refreshes an already-authorized Google session on startup
  /// so Google Drive database sync continues automatically.
  Future<GoogleAuthResult?> signInSilently() async {
    if (kIsWeb || defaultTargetPlatform == TargetPlatform.iOS) {
      return null;
    }
    try {
      final account = await _googleSignIn
          .signInSilently()
          .timeout(const Duration(seconds: 8));
      if (account == null) return null;
      final auth = await account.authentication;
      return GoogleAuthResult(
        profile: GoogleUserProfile(
          id: 'google_${account.id}',
          email: account.email,
          displayName: (account.displayName?.trim().isNotEmpty ?? false)
              ? account.displayName!.trim()
              : account.email.split('@').first,
          photoUrl: account.photoUrl ?? '',
        ),
        accessToken: auth.accessToken,
      );
    } catch (_) {
      return null;
    }
  }

  /// Launches the native Google Account Sign-In flow (real Google redirect/account sheet),
  /// fetches the real Google Display Name, Email, Avatar, and OAuth Drive Access Token.
  Future<GoogleAuthResult> signInWithGoogle() async {
    if (kIsWeb || defaultTargetPlatform == TargetPlatform.iOS) {
      return const GoogleAuthResult(
        isSha1ConfigError: true,
        errorReason:
            'Bản iOS cài ngoài (unsigned IPA) chưa gắn GoogleService-Info.plist.',
      );
    }
    try {
      final account = await _googleSignIn
          .signIn()
          .timeout(const Duration(seconds: 25));
      if (account == null) {
        return const GoogleAuthResult(
          errorReason: 'Bạn đã hủy đăng nhập Google.',
        );
      }
      final auth = await account.authentication;
      return GoogleAuthResult(
        profile: GoogleUserProfile(
          id: 'google_${account.id}',
          email: account.email,
          displayName: (account.displayName?.trim().isNotEmpty ?? false)
              ? account.displayName!.trim()
              : account.email.split('@').first,
          photoUrl: account.photoUrl ?? '',
        ),
        accessToken: auth.accessToken,
      );
    } catch (e) {
      final msg = e.toString();
      final isConfigError = msg.contains('ApiException: 10') ||
          msg.contains('sign_in_failed') ||
          msg.contains('DEVELOPER_ERROR');
      return GoogleAuthResult(
        isSha1ConfigError: isConfigError,
        errorReason: isConfigError
            ? 'Cần thêm mã SHA-1 của app vào Google Cloud Console để bật đăng nhập Google & lưu Database lên Drive.'
            : 'Không thể kết nối Google Sign-In ($msg).',
      );
    }
  }

  /// Refreshes the OAuth access token for Drive API calls if expired.
  Future<String?> refreshAccessToken() async {
    if (kIsWeb || defaultTargetPlatform == TargetPlatform.iOS) return null;
    try {
      final current =
          _googleSignIn.currentUser ?? await _googleSignIn.signInSilently();
      if (current == null) return null;
      final auth = await current.authentication;
      return auth.accessToken;
    } catch (_) {
      return null;
    }
  }

  Future<void> signOut() async {
    if (kIsWeb || defaultTargetPlatform == TargetPlatform.iOS) return;
    try {
      await _googleSignIn.signOut();
    } catch (_) {}
  }
}
