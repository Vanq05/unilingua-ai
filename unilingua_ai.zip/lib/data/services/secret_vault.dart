import 'dart:convert';

/// Internal credential vault keeping API endpoint, API key, and central
/// Google Drive Server Database URL hidden & obfuscated from plain-text inspection.
class SecretVault {
  const SecretVault._();

  static const List<int> _u = <int>[
    51, 22, 29, 0, 4, 68, 170, 163, 240, 245, 197, 205, 215, 152, 219, 171,
    184, 166, 184, 206, 134, 158, 133, 211, 117, 59,
  ];

  static const List<int> _k = <int>[
    250, 251, 186, 174, 149, 201, 210, 216, 241, 252, 249, 181, 235, 214,
    141, 150, 204, 98, 53, 35, 96, 118, 75, 79, 7, 79, 11, 51, 34, 57, 61,
    80, 11, 67, 78, 7, 168, 186, 165, 172, 151, 206, 159, 135, 139,
  ];

  static const List<int> _d = <int>[
    197, 192, 207, 178, 186, 234, 248, 241, 150, 143, 129, 147, 113, 124,
    33, 113, 114, 75, 76, 94, 92, 110, 36, 33, 56, 115, 14, 11, 18, 10, 16,
    245, 162, 231, 180, 227, 226, 214, 206, 221, 167, 181, 254, 247, 147,
    177, 129, 131, 191, 98, 125, 88, 90, 106, 66, 103, 77, 127, 9, 38, 6,
    55, 44, 12, 21, 66, 9, 208, 177, 219, 216, 238, 225, 212, 221, 219, 132,
    191, 226, 181, 147, 138, 177, 133, 176, 70, 107, 126, 113, 120, 27, 88,
    122, 1, 82, 2, 25, 4, 108, 18, 62, 10, 40, 73, 205, 203, 226, 181, 196,
    208, 202, 213,
  ];

  static String _decode(List<int> bytes, int seed) {
    if (bytes.isEmpty) return '';
    final out = List<int>.generate(
      bytes.length,
      (i) => bytes[i] ^ ((seed + i * 7) & 0xFF),
    );
    return utf8.decode(out);
  }

  static String get baseUrl => _decode(_u, 91);
  static String get apiKey => _decode(_k, 137);
  static String get driveServerUrl => _decode(_d, 173);
}
