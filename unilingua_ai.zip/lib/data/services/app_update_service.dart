import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

@immutable
class AppUpdateInfo {
  const AppUpdateInfo({
    required this.latestVersion,
    required this.releaseNotes,
    required this.downloadUrl,
  });

  final String latestVersion;
  final String releaseNotes;
  final String downloadUrl;
}

/// Checks GitHub Releases for newer signed builds so Android users can
/// download and install directly over the existing app without uninstalling.
class AppUpdateService {
  const AppUpdateService();

  static const String currentVersion = String.fromEnvironment(
    'APP_VERSION',
    defaultValue: '1.2.0',
  );
  static const String _latestReleaseApi =
      'https://api.github.com/repos/Vanq05/unilingua-ai/releases/latest';

  Future<AppUpdateInfo?> checkForUpdate() async {
    try {
      final resp = await http
          .get(
            Uri.parse(_latestReleaseApi),
            headers: const <String, String>{
              'Accept': 'application/vnd.github+json',
            },
          )
          .timeout(const Duration(seconds: 8));
      if (resp.statusCode != 200) return null;

      final data = jsonDecode(resp.body) as Map<String, dynamic>;
      final rawTag = (data['tag_name'] as String? ?? '').trim();
      final cleanLatest = rawTag.replaceFirst(RegExp(r'^[vV]'), '');
      if (cleanLatest.isEmpty || !_isNewer(cleanLatest, currentVersion)) {
        return null;
      }

      final assets = data['assets'] as List<dynamic>? ?? const <dynamic>[];
      String downloadUrl = data['html_url'] as String? ?? '';
      final targetExt =
          defaultTargetPlatform == TargetPlatform.iOS ? '.ipa' : '.apk';

      for (final asset in assets.whereType<Map<String, dynamic>>()) {
        final name = (asset['name'] as String? ?? '').toLowerCase();
        final url = asset['browser_download_url'] as String? ?? '';
        if (name.endsWith(targetExt) && url.isNotEmpty) {
          downloadUrl = url;
          break;
        }
      }

      if (downloadUrl.isEmpty) return null;
      return AppUpdateInfo(
        latestVersion: cleanLatest,
        releaseNotes: (data['body'] as String? ?? '').trim(),
        downloadUrl: downloadUrl,
      );
    } catch (_) {
      return null;
    }
  }

  Future<bool> launchUpdateDownload(String url) async {
    try {
      final uri = Uri.parse(url);
      return await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      return false;
    }
  }

  bool _isNewer(String latest, String current) {
    final lParts = latest
        .split(RegExp(r'[.+\-]'))
        .map((e) => int.tryParse(e) ?? 0)
        .toList();
    final cParts = current
        .split(RegExp(r'[.+\-]'))
        .map((e) => int.tryParse(e) ?? 0)
        .toList();
    final maxLen =
        lParts.length > cParts.length ? lParts.length : cParts.length;
    for (var i = 0; i < maxLen; i++) {
      final lv = i < lParts.length ? lParts[i] : 0;
      final cv = i < cParts.length ? cParts[i] : 0;
      if (lv > cv) return true;
      if (lv < cv) return false;
    }
    return false;
  }
}
