import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../../domain/models/learning_models.dart';
import 'central_drive_server_service.dart';

/// Persists each Google account's learning progress, placement test results,
/// personalized 12-week roadmap, daily streak, XP, and vocabulary flashcards.
class ProgressStorageService {
  const ProgressStorageService();

  static const String _activeEmailKey = 'unilingua_active_google_email_v1';
  static const String _knownAccountsKey = 'unilingua_known_google_accounts_v1';
  static const String _themeModeKey = 'unilingua_theme_mode_v1';
  static const String _notificationsKey = 'unilingua_notifications_enabled_v1';

  Future<bool> loadNotificationsEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_notificationsKey) ?? true;
  }

  Future<void> saveNotificationsEnabled(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_notificationsKey, enabled);
  }

  static String _chatCacheKey(String userA, String userB) {
    final pair = <String>[
      userA.trim().toLowerCase(),
      userB.trim().toLowerCase(),
    ]..sort();
    return 'unilingua_direct_chat_${pair[0]}__${pair[1]}_v1';
  }

  Future<List<DirectChatMessage>> loadCachedChatMessages(
    String userA,
    String userB,
  ) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_chatCacheKey(userA, userB));
    if (raw == null || raw.isEmpty) return const <DirectChatMessage>[];
    try {
      final decoded = jsonDecode(raw) as List<dynamic>;
      return decoded
          .whereType<Map<String, dynamic>>()
          .map(DirectChatMessage.fromJson)
          .toList()
        ..sort((a, b) => a.timestamp.compareTo(b.timestamp));
    } catch (_) {
      return const <DirectChatMessage>[];
    }
  }

  Future<void> saveCachedChatMessages(
    String userA,
    String userB,
    List<DirectChatMessage> messages,
  ) async {
    final prefs = await SharedPreferences.getInstance();
    final trimmed = messages.length > 300
        ? messages.sublist(messages.length - 300)
        : messages;
    await prefs.setString(
      _chatCacheKey(userA, userB),
      jsonEncode(trimmed.map((m) => m.toJson()).toList()),
    );
  }

  Future<bool> loadIsDarkMode() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_themeModeKey) ?? false; // Default: Light Sky-Blue mode!
  }

  Future<void> saveIsDarkMode(bool isDark) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_themeModeKey, isDark);
  }

  static String _progressKeyForEmail(String email) =>
      'unilingua_progress_${email.trim().toLowerCase()}_v1';

  Future<String?> loadActiveEmail() async {
    final prefs = await SharedPreferences.getInstance();
    final email = prefs.getString(_activeEmailKey);
    return (email != null && email.trim().isNotEmpty) ? email.trim() : null;
  }

  Future<void> saveActiveEmail(String? email) async {
    final prefs = await SharedPreferences.getInstance();
    if (email == null || email.trim().isEmpty) {
      await prefs.remove(_activeEmailKey);
    } else {
      await prefs.setString(_activeEmailKey, email.trim().toLowerCase());
    }
  }

  Future<List<GoogleUserProfile>> loadKnownGoogleAccounts() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_knownAccountsKey);
    if (raw == null || raw.isEmpty) return const <GoogleUserProfile>[];
    try {
      final list = jsonDecode(raw) as List<dynamic>;
      return list
          .whereType<Map<String, dynamic>>()
          .map(GoogleUserProfile.fromJson)
          .toList();
    } catch (_) {
      return const <GoogleUserProfile>[];
    }
  }

  Future<void> upsertKnownGoogleAccount(GoogleUserProfile profile) async {
    final prefs = await SharedPreferences.getInstance();
    final current = await loadKnownGoogleAccounts();
    final updated = <GoogleUserProfile>[
      profile,
      ...current.where(
        (a) => a.email.toLowerCase() != profile.email.toLowerCase(),
      ),
    ];
    await prefs.setString(
      _knownAccountsKey,
      jsonEncode(updated.map((a) => a.toJson()).toList()),
    );
  }

  Future<StudentProgressState?> loadProgressForEmail(String email) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_progressKeyForEmail(email));
    if (raw == null || raw.isEmpty) return null;
    try {
      final decoded = jsonDecode(raw) as Map<String, dynamic>;
      return StudentProgressState.fromJson(decoded);
    } catch (_) {
      return null;
    }
  }

  Future<void> saveProgress(StudentProgressState state) async {
    final prefs = await SharedPreferences.getInstance();
    final email = state.user.email.trim().toLowerCase();
    await prefs.setString(
      _progressKeyForEmail(email),
      jsonEncode(state.toJson()),
    );
    await saveActiveEmail(email);
    await upsertKnownGoogleAccount(state.user);
  }

  /// Exports the student's entire progress state as a base64 cloud sync code
  /// so they can back up or transfer their Google account progress across devices.
  String exportSyncCode(StudentProgressState state) {
    final jsonStr = jsonEncode(state.toJson());
    return base64UrlEncode(utf8.encode(jsonStr));
  }

  /// Restores progress state from a base64 cloud sync code.
  StudentProgressState? importSyncCode(String code) {
    try {
      final cleaned = code.trim();
      final decodedBytes = base64Url.decode(cleaned);
      final jsonMap =
          jsonDecode(utf8.decode(decodedBytes)) as Map<String, dynamic>;
      return StudentProgressState.fromJson(jsonMap);
    } catch (_) {
      return null;
    }
  }
}
