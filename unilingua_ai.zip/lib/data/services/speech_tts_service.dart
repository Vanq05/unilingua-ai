import 'package:flutter/foundation.dart';
import 'package:flutter_tts/flutter_tts.dart';

/// Text-to-Speech service for Listening Passages, Speaking Shadowing,
/// AI Roleplay conversations, and Vocabulary Flashcards.
class SpeechTtsService extends ChangeNotifier {
  SpeechTtsService() {
    _init();
  }

  final FlutterTts _tts = FlutterTts();
  bool _isSpeaking = false;
  double _speechRate = 0.48; // Natural clear English speed on mobile TTS
  String _currentSpeakingId = '';

  bool get isSpeaking => _isSpeaking;
  double get speechRate => _speechRate;
  String get currentSpeakingId => _currentSpeakingId;

  String get speedLabel {
    if (_speechRate <= 0.38) return '0.75x (Chậm)';
    if (_speechRate >= 0.58) return '1.25x (Nhanh)';
    return '1.0x (Chuẩn)';
  }

  Future<void> _init() async {
    try {
      await _tts.setLanguage('en-US');
      await _tts.setPitch(1.0);
      await _tts.setSpeechRate(_speechRate);
      await _tts.setVolume(1.0);

      _tts.setStartHandler(() {
        _isSpeaking = true;
        notifyListeners();
      });

      _tts.setCompletionHandler(() {
        _isSpeaking = false;
        _currentSpeakingId = '';
        notifyListeners();
      });

      _tts.setCancelHandler(() {
        _isSpeaking = false;
        _currentSpeakingId = '';
        notifyListeners();
      });

      _tts.setErrorHandler((_) {
        _isSpeaking = false;
        _currentSpeakingId = '';
        notifyListeners();
      });
    } catch (_) {
      // Safe fallback in headless tests
    }
  }

  Future<void> cycleSpeed() async {
    if (_speechRate <= 0.38) {
      _speechRate = 0.48;
    } else if (_speechRate <= 0.50) {
      _speechRate = 0.60;
    } else {
      _speechRate = 0.36;
    }
    try {
      await _tts.setSpeechRate(_speechRate);
    } catch (_) {}
    notifyListeners();
  }

  Future<void> speak(String text, {String id = 'default'}) async {
    if (text.trim().isEmpty) return;
    try {
      if (_isSpeaking && _currentSpeakingId == id) {
        await stop();
        return;
      }
      await _tts.stop();
      _currentSpeakingId = id;
      _isSpeaking = true;
      notifyListeners();
      await _tts.setLanguage('en-US');
      await _tts.setSpeechRate(_speechRate);
      await _tts.speak(text.trim());
    } catch (_) {
      _isSpeaking = false;
      _currentSpeakingId = '';
      notifyListeners();
    }
  }

  Future<void> stop() async {
    try {
      await _tts.stop();
    } catch (_) {}
    _isSpeaking = false;
    _currentSpeakingId = '';
    notifyListeners();
  }
}
