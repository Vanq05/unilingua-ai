import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

/// Contextual character voices covering female/male, child/teen/adult
/// so every exercise, listening passage, and roleplay sounds natural and lively.
enum VoicePersona {
  bea(
    name: 'Bea',
    roleLabelVi: 'Nữ trẻ • Bạn bè',
    emoji: '👩🏽',
    isMale: false,
    locale: 'en-US',
    pitch: 1.12,
    defaultRate: 0.48,
    accentHex: 0xFF1CB0F6,
  ),
  junior(
    name: 'Junior',
    roleLabelVi: 'Bé trai • Gia đình',
    emoji: '👦🏻',
    isMale: true,
    locale: 'en-US',
    pitch: 1.42,
    defaultRate: 0.50,
    accentHex: 0xFFFFC800,
  ),
  zari(
    name: 'Zari',
    roleLabelVi: 'Bé gái • Năng động',
    emoji: '👧🏽',
    isMale: false,
    locale: 'en-US',
    pitch: 1.30,
    defaultRate: 0.52,
    accentHex: 0xFFFF66B2,
  ),
  lily(
    name: 'Lily',
    roleLabelVi: 'Nữ trầm • Teen',
    emoji: '👩🏻‍🎤',
    isMale: false,
    locale: 'en-US',
    pitch: 0.92,
    defaultRate: 0.44,
    accentHex: 0xFFCE82FF,
  ),
  oscar(
    name: 'Oscar',
    roleLabelVi: 'Nam trưởng thành • Du lịch',
    emoji: '👨🏻',
    isMale: true,
    locale: 'en-GB',
    pitch: 0.86,
    defaultRate: 0.46,
    accentHex: 0xFF6366F1,
  ),
  falstaff(
    name: 'Falstaff',
    roleLabelVi: 'Nam trung niên • Công sở',
    emoji: '🧔🏾',
    isMale: true,
    locale: 'en-GB',
    pitch: 0.76,
    defaultRate: 0.44,
    accentHex: 0xFF58CC02,
  );

  const VoicePersona({
    required this.name,
    required this.roleLabelVi,
    required this.emoji,
    required this.isMale,
    required this.locale,
    required this.pitch,
    required this.defaultRate,
    required this.accentHex,
  });

  final String name;
  final String roleLabelVi;
  final String emoji;
  final bool isMale;
  final String locale;
  final double pitch;
  final double defaultRate;
  final int accentHex;

  Color get accentColor => Color(accentHex);

  /// Picks an appropriate character voice automatically from lesson context/topic.
  static VoicePersona forContext(String contextHint) {
    final lower = contextHint.toLowerCase();
    if (lower.contains('kid') ||
        lower.contains('child') ||
        lower.contains('family') ||
        lower.contains('mom') ||
        lower.contains('school') ||
        lower.contains('junior')) {
      return VoicePersona.junior;
    }
    if (lower.contains('girl') ||
        lower.contains('zari') ||
        lower.contains('fun') ||
        lower.contains('hobby')) {
      return VoicePersona.zari;
    }
    if (lower.contains('business') ||
        lower.contains('interview') ||
        lower.contains('office') ||
        lower.contains('work') ||
        lower.contains('falstaff') ||
        lower.contains('news')) {
      return VoicePersona.falstaff;
    }
    if (lower.contains('restaurant') ||
        lower.contains('travel') ||
        lower.contains('hotel') ||
        lower.contains('coffee') ||
        lower.contains('tea') ||
        lower.contains('oscar')) {
      return VoicePersona.oscar;
    }
    if (lower.contains('movie') ||
        lower.contains('music') ||
        lower.contains('lily') ||
        lower.contains('teen')) {
      return VoicePersona.lily;
    }
    return VoicePersona.bea;
  }
}

/// Text-to-Speech service supporting 6 contextual character voices
/// (male/female, child/teen/adult) with real OS voice selection + slow turtle mode.
class SpeechTtsService extends ChangeNotifier {
  SpeechTtsService() {
    _init();
  }

  final FlutterTts _tts = FlutterTts();
  bool _isSpeaking = false;
  double _speechRate = 0.48;
  String _currentSpeakingId = '';
  VoicePersona _activePersona = VoicePersona.bea;

  final List<Map<String, String>> _maleVoices = <Map<String, String>>[];
  final List<Map<String, String>> _femaleVoices = <Map<String, String>>[];

  bool get isSpeaking => _isSpeaking;
  double get speechRate => _speechRate;
  String get currentSpeakingId => _currentSpeakingId;
  VoicePersona get activePersona => _activePersona;

  String get speedLabel {
    if (_speechRate <= 0.38) return '0.75x (Chậm)';
    if (_speechRate >= 0.58) return '1.25x (Nhanh)';
    return '1.0x (Chuẩn)';
  }

  static const Set<String> _knownMaleHints = <String>{
    'male',
    'daniel',
    'aaron',
    'alex',
    'arthur',
    'fred',
    'gordon',
    'lee',
    'oliver',
    'rishi',
    'tom',
    'iom',
    'iob',
    'tpd',
    'sfb',
    'gba',
    'rjs',
  };

  static const Set<String> _knownFemaleHints = <String>{
    'female',
    'samantha',
    'karen',
    'moira',
    'tessa',
    'nicky',
    'allison',
    'ava',
    'susan',
    'victoria',
    'serena',
    'martha',
    'tpf',
    'sfg',
    'iol',
    'tpc',
    'gbb',
  };

  Future<void> _init() async {
    try {
      await _tts.setLanguage('en-US');
      await _tts.setPitch(1.0);
      await _tts.setSpeechRate(_speechRate);
      await _tts.setVolume(1.0);
      await _loadDeviceVoices();

      _tts.setStartHandler(() {
        _isSpeaking = true;
        notifyListeners();
      });

      _tts.setCompletionHandler(() {
        _isSpeaking = false;
        _currentSpeakingId = '';
        notifyListeners();
      });

      _tts.setCancelHandler(() {
        _isSpeaking = false;
        _currentSpeakingId = '';
        notifyListeners();
      });

      _tts.setErrorHandler((_) {
        _isSpeaking = false;
        _currentSpeakingId = '';
        notifyListeners();
      });
    } catch (_) {
      // Safe fallback in headless tests
    }
  }

  Future<void> _loadDeviceVoices() async {
    try {
      final rawVoices = await _tts.getVoices;
      if (rawVoices is! List) return;
      for (final item in rawVoices) {
        if (item is! Map) continue;
        final name = (item['name'] ?? '').toString();
        final locale = (item['locale'] ?? '').toString();
        if (!locale.toLowerCase().startsWith('en')) continue;
        final lowerName = name.toLowerCase();
        final gender = (item['gender'] ?? '').toString().toLowerCase();
        final voiceMap = <String, String>{'name': name, 'locale': locale};

        final isMale = gender == 'male' ||
            _knownMaleHints.any((h) => lowerName.contains(h));
        final isFemale = gender == 'female' ||
            _knownFemaleHints.any((h) => lowerName.contains(h));

        if (isMale && !isFemale) {
          _maleVoices.add(voiceMap);
        } else if (isFemale) {
          _femaleVoices.add(voiceMap);
        }
      }
    } catch (_) {}
  }

  void setPersona(VoicePersona persona) {
    if (_activePersona == persona) return;
    _activePersona = persona;
    notifyListeners();
  }

  Future<void> cycleSpeed() async {
    if (_speechRate <= 0.38) {
      _speechRate = 0.48;
    } else if (_speechRate <= 0.50) {
      _speechRate = 0.60;
    } else {
      _speechRate = 0.36;
    }
    try {
      await _tts.setSpeechRate(_speechRate);
    } catch (_) {}
    notifyListeners();
  }

  Future<void> _applyPersonaVoice(
    VoicePersona persona, {
    required bool slow,
  }) async {
    final pool = persona.isMale ? _maleVoices : _femaleVoices;
    Map<String, String>? chosen;
    if (pool.isNotEmpty) {
      final preferredLocale = persona.locale.toLowerCase();
      chosen = pool.firstWhere(
        (v) => (v['locale'] ?? '').toLowerCase().startsWith(preferredLocale),
        orElse: () => pool[persona.index % pool.length],
      );
    }

    try {
      if (chosen != null) {
        await _tts.setVoice(chosen);
      } else {
        await _tts.setLanguage(persona.locale);
      }
      await _tts.setPitch(persona.pitch);
      final targetRate = slow ? 0.33 : persona.defaultRate;
      await _tts.setSpeechRate(targetRate);
    } catch (_) {}
  }

  Future<void> speak(
    String text, {
    String id = 'default',
    VoicePersona? persona,
    bool slow = false,
  }) async {
    if (text.trim().isEmpty) return;
    final effectivePersona = persona ?? _activePersona;
    try {
      if (_isSpeaking && _currentSpeakingId == id) {
        await stop();
        return;
      }
      await _tts.stop();
      _currentSpeakingId = id;
      _isSpeaking = true;
      notifyListeners();
      await _applyPersonaVoice(effectivePersona, slow: slow);
      await _tts.speak(text.trim());
    } catch (_) {
      _isSpeaking = false;
      _currentSpeakingId = '';
      notifyListeners();
    }
  }

  Future<void> speakSlow(
    String text, {
    String id = 'slow',
    VoicePersona? persona,
  }) =>
      speak(text, id: id, persona: persona, slow: true);

  Future<void> stop() async {
    try {
      await _tts.stop();
    } catch (_) {}
    _isSpeaking = false;
    _currentSpeakingId = '';
    notifyListeners();
  }
}
