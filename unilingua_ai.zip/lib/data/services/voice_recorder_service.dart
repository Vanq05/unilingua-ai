import 'package:flutter/foundation.dart';
import 'package:speech_to_text/speech_to_text.dart';

/// High-sensitivity native microphone Speech-to-Text service (English en_US)
/// with per-button mic isolation (`micId`) and bilingual Vietnamese-English
/// proper noun & place name phonetic normalization.
class VoiceRecorderService extends ChangeNotifier {
  VoiceRecorderService();

  final SpeechToText _speech = SpeechToText();
  bool _initialized = false;
  bool _isAvailable = false;
  bool _isListening = false;
  String _activeMicId = '';
  String _liveTranscript = '';
  double _soundLevel = 0.0;
  String _statusMessage = '';
  String? _activeUserDisplayName;

  bool get isAvailable => _isAvailable;
  bool get isListening => _isListening;
  String get activeMicId => _activeMicId;
  String get liveTranscript => _liveTranscript;
  double get soundLevel => _soundLevel;
  String get statusMessage => _statusMessage;

  /// Returns true ONLY for the specific mic button that initiated listening,
  /// preventing UI conflicts when multiple mic buttons appear on one screen.
  bool isMicListening(String micId) => _isListening && _activeMicId == micId;

  Future<bool> ensureInitialized() async {
    if (_initialized) return _isAvailable;
    _initialized = true;
    try {
      _isAvailable = await _speech.initialize(
        finalTimeout: const Duration(milliseconds: 1200),
        onStatus: (status) {
          if (status == 'done' || status == 'notListening') {
            _isListening = false;
            _activeMicId = '';
            _soundLevel = 0.0;
            notifyListeners();
          }
        },
        onError: (err) {
          _isListening = false;
          _activeMicId = '';
          _soundLevel = 0.0;
          if (_liveTranscript.isEmpty) {
            _statusMessage =
                'Chưa bắt được tiếng — thử đưa Mic gần hơn và nói rõ nhé.';
          }
          notifyListeners();
        },
      );
    } catch (_) {
      _isAvailable = false;
      _statusMessage = 'Thiết bị chưa cấp quyền Micro.';
    }
    notifyListeners();
    return _isAvailable;
  }

  /// Starts high-sensitivity listening isolated to [micId] and applies
  /// bilingual Vietnamese-English proper noun correction (e.g. "tên Vang", "Thái Nguyên").
  Future<bool> startListening({
    String micId = 'default',
    String? userDisplayName,
    void Function(String words, bool isFinal)? onTranscript,
  }) async {
    if (_isListening && _activeMicId != micId) {
      await stopListening();
    }

    final ok = await ensureInitialized();
    if (!ok) {
      _statusMessage =
          'Vui lòng cấp quyền Micro trong cài đặt để nói trực tiếp.';
      notifyListeners();
      return false;
    }

    _activeMicId = micId;
    _activeUserDisplayName = userDisplayName;
    _liveTranscript = '';
    _statusMessage = 'Đang nghe... hãy nói tự nhiên nhé!';
    _isListening = true;
    notifyListeners();

    try {
      await _speech.listen(
        localeId: 'en_US',
        listenFor: const Duration(seconds: 45),
        pauseFor: const Duration(seconds: 7),
        listenOptions: SpeechListenOptions(
          partialResults: true,
          cancelOnError: false,
          onDevice: false, // Cloud recognition for higher sensitivity
          autoPunctuation: false,
          listenMode: ListenMode.dictation,
        ),
        onSoundLevelChange: (level) {
          _soundLevel = level.clamp(0.0, 14.0);
          notifyListeners();
        },
        onResult: (result) {
          final rawWords = result.recognizedWords.trim();
          if (rawWords.isNotEmpty) {
            final normalized = normalizeVietnameseProperNouns(
              rawWords,
              userDisplayName: _activeUserDisplayName,
            );
            _liveTranscript = normalized;
            onTranscript?.call(_liveTranscript, result.finalResult);
            notifyListeners();
          }
        },
      );
      return true;
    } catch (_) {
      _isListening = false;
      _activeMicId = '';
      _statusMessage = 'Không thể bật Micro lúc này.';
      notifyListeners();
      return false;
    }
  }

  /// Stops listening and returns the normalized recognized transcript.
  Future<String> stopListening() async {
    try {
      await _speech.stop();
    } catch (_) {}
    _isListening = false;
    _activeMicId = '';
    _soundLevel = 0.0;
    _statusMessage = '';
    notifyListeners();
    return _liveTranscript.trim();
  }

  void clearTranscript() {
    _liveTranscript = '';
    _statusMessage = '';
    notifyListeners();
  }

  /// Post-processes en_US speech recognition output to accurately recover
  /// Vietnamese proper names and places that English STT commonly garbles
  /// (e.g., "tên Vang" -> "ten van" / "van", "Thái Nguyên" -> "tynguah").
  static String normalizeVietnameseProperNouns(
    String rawTranscript, {
    String? userDisplayName,
  }) {
    var text = rawTranscript.trim();
    if (text.isEmpty) return text;

    // 1. Direct Vietnamese places phonetic normalization dictionary
    final placeReplacements = <RegExp, String>{
      RegExp(
        r'\b(?:ty\s*nguah|tynguah|tai\s*nguah|thai\s*nguah|tie\s*nguyen|thigh\s*nguyen|tai\s*nguyen|thai\s*win|tiny\s*win|tying\s*win|thai\s*nguyen)\b',
        caseSensitive: false,
      ): 'Thai Nguyen',
      RegExp(r'\b(?:ha\s*noi|hanoi|ha\s*noy|hanoy)\b', caseSensitive: false):
          'Hanoi',
      RegExp(
        r'\b(?:ho\s*chi\s*minh(?:\s*city)?|saigon|sai\s*gon)\b',
        caseSensitive: false,
      ): 'Ho Chi Minh City',
      RegExp(r'\b(?:da\s*nang|danang|da\s*nung)\b', caseSensitive: false):
          'Da Nang',
      RegExp(r'\b(?:hai\s*phong|hi\s*phong|haiphong)\b', caseSensitive: false):
          'Hai Phong',
      RegExp(r'\b(?:can\s*tho|can\s*toe|cantho)\b', caseSensitive: false):
          'Can Tho',
      RegExp(r'\b(?:nha\s*trang|na\s*trang|nhatrang)\b', caseSensitive: false):
          'Nha Trang',
      RegExp(r'\b(?:da\s*lat|dalat)\b', caseSensitive: false): 'Da Lat',
      RegExp(r'\b(?:quang\s*ninh|ha\s*long)\b', caseSensitive: false):
          'Quang Ninh',
      RegExp(r'\b(?:bac\s*ninh|back\s*ninh)\b', caseSensitive: false):
          'Bac Ninh',
      RegExp(r'\b(?:bac\s*giang|back\s*giang)\b', caseSensitive: false):
          'Bac Giang',
      RegExp(r'\b(?:vinh\s*phuc|ving\s*fuk)\b', caseSensitive: false):
          'Vinh Phuc',
      RegExp(r'\b(?:phu\s*tho|foo\s*toe)\b', caseSensitive: false): 'Phu Tho',
      RegExp(r'\b(?:tuyen\s*quang|twin\s*kwang)\b', caseSensitive: false):
          'Tuyen Quang',
      RegExp(r'\b(?:cao\s*bang|cow\s*bang)\b', caseSensitive: false):
          'Cao Bang',
      RegExp(r'\b(?:lang\s*son|long\s*son)\b', caseSensitive: false):
          'Lang Son',
      RegExp(r'\b(?:lao\s*cai|lao\s*kai)\b', caseSensitive: false): 'Lao Cai',
      RegExp(r'\b(?:yen\s*bai|yen\s*bye)\b', caseSensitive: false): 'Yen Bai',
      RegExp(r'\b(?:thanh\s*hoa|tang\s*wah)\b', caseSensitive: false):
          'Thanh Hoa',
      RegExp(r'\b(?:nghe\s*an|gay\s*an)\b', caseSensitive: false): 'Nghe An',
      RegExp(r'\b(?:hai\s*duong|hi\s*zung)\b', caseSensitive: false):
          'Hai Duong',
      RegExp(r'\b(?:hung\s*yen|hoong\s*yen)\b', caseSensitive: false):
          'Hung Yen',
      RegExp(r'\b(?:nam\s*dinh|nam\s*ding)\b', caseSensitive: false):
          'Nam Dinh',
      RegExp(r'\b(?:thai\s*binh|tie\s*bing)\b', caseSensitive: false):
          'Thai Binh',
      RegExp(r'\b(?:ninh\s*binh|ning\s*bing)\b', caseSensitive: false):
          'Ninh Binh',
      RegExp(r'\b(?:viet\s*nam|vietnam)\b', caseSensitive: false): 'Vietnam',
    };

    placeReplacements.forEach((pattern, normalizedPlace) {
      text = text.replaceAll(pattern, normalizedPlace);
    });

    // 2. Bilingual Vietnamese intro phrase + Vang phonetic misrecognitions
    // e.g., "tên Vang" -> "ten van", "tan van", "my name is van", "i'm bang"
    text = text.replaceAllMapped(
      RegExp(
        r'\b(?:t[eê]n|ten|tan)\s+(?:v[aă]ng?|van|bang|fan|von|vine)\b',
        caseSensitive: false,
      ),
      (_) => 'my name is Vang',
    );

    text = text.replaceAllMapped(
      RegExp(
        r"\b(my\s+name\s+is|my\s+name's|i\s+am|i'm|call\s+me)\s+(?:van|vang|bang|fan|von|vine|vung|vang\s*)\b",
        caseSensitive: false,
      ),
      (m) => '${m.group(1)} Vang',
    );

    // Common Vietnamese personal names misheard after intro cues
    final commonNameCues = <String, String>{
      'minh': 'Minh',
      'ming': 'Minh',
      'linh': 'Linh',
      'ling': 'Linh',
      'lean': 'Linh',
      'tuan': 'Tuan',
      'wan': 'Quan',
      'quan': 'Quan',
      'kwang': 'Quang',
      'quang': 'Quang',
      'nam': 'Nam',
      'numb': 'Nam',
      'huy': 'Huy',
      'wee': 'Huy',
      'hoa': 'Hoa',
      'wah': 'Hoa',
      'lan': 'Lan',
      'long': 'Long',
      'trang': 'Trang',
      'chong': 'Trong',
      'duc': 'Duc',
      'duck': 'Duc',
      'dung': 'Dung',
      'zoong': 'Dung',
      'hung': 'Hung',
      'hoong': 'Hung',
      'son': 'Son',
      'thao': 'Thao',
      'tow': 'Thao',
      'mai': 'Mai',
      'my': 'Mai',
      'khanh': 'Khanh',
      'kang': 'Khang',
      'phuc': 'Phuc',
      'fook': 'Phuc',
      'viet': 'Viet',
      'hai': 'Hai',
      'hi': 'Hai',
    };

    // Apply user's own profile displayName with highest priority after intro cues
    final trimmedName = (userDisplayName ?? '').trim();
    if (trimmedName.isNotEmpty) {
      final cleanTarget = _stripVietnameseDiacritics(trimmedName).toLowerCase();
      text = text.replaceAllMapped(
        RegExp(
          r"\b(my\s+name\s+is|my\s+name's|i\s+am|i'm|call\s+me|this\s+is)\s+([a-zA-Z]+)\b",
          caseSensitive: false,
        ),
        (match) {
          final cue = match.group(1)!;
          final candidate = match.group(2)!;
          final candLower = candidate.toLowerCase();
          // Keep standard English adjectives/articles when not resembling the user's name
          const excludedWords = <String>{
            'a',
            'an',
            'the',
            'from',
            'twenty',
            'nineteen',
            'eighteen',
            'good',
            'fine',
            'great',
            'happy',
            'tired',
            'busy',
            'ready',
            'sure',
            'student',
            'teacher',
            'studying',
            'living',
            'working',
            'learning',
            'very',
            'so',
            'doing',
          };
          if (excludedWords.contains(candLower)) {
            return match.group(0)!;
          }
          if (_isPhoneticMatch(candLower, cleanTarget)) {
            return '$cue $trimmedName';
          }
          final mapped = commonNameCues[candLower];
          if (mapped != null) {
            return '$cue $mapped';
          }
          return match.group(0)!;
        },
      );

      // Also check trailing phrase "I'm called X" or standalone mishearing of user's name
      if (cleanTarget == 'vang') {
        text = text.replaceAll(
          RegExp(r'\bvan\b(?=\s*$|,|\.|!)', caseSensitive: false),
          trimmedName,
        );
      }
    }

    return text.replaceAll(RegExp(r'\s{2,}'), ' ').trim();
  }

  static String _stripVietnameseDiacritics(String input) {
    const withDia =
        'àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ'
        'ÀÁẠẢÃÂẦẤẬẨẪĂẰẮẶẲẴÈÉẸẺẼÊỀẾỆỂỄÌÍỊỈĨÒÓỌỎÕÔỒỐỘỔỖƠỜỚỢỞỠÙÚỤỦŨƯỪỨỰỬỮỲÝỴỶỸĐ';
    const withoutDia =
        'aaaaaaaaaaaaaaaaaeeeeeeeeeeeiiiiiooooooooooooooooouuuuuuuuuuuyyyyyd'
        'AAAAAAAAAAAAAAAAAEEEEEEEEEEEIIIIIOOOOOOOOOOOOOOOOOUUUUUUUUUUUYYYYYD';
    var out = input;
    for (var i = 0; i < withDia.length; i++) {
      out = out.replaceAll(withDia[i], withoutDia[i]);
    }
    return out;
  }

  static bool _isPhoneticMatch(String spoken, String targetAscii) {
    if (spoken == targetAscii) return true;
    if (targetAscii.length < 2 || spoken.length < 2) return false;
    if (targetAscii == 'vang' &&
        <String>{'van', 'vang', 'bang', 'fan', 'von', 'vine', 'vung', 'wang'}
            .contains(spoken)) {
      return true;
    }
    // Check prefix/consonant skeleton similarity
    final sSkel = spoken.replaceAll(RegExp(r'[aeiouy]'), '');
    final tSkel = targetAscii.replaceAll(RegExp(r'[aeiouy]'), '');
    if (spoken[0] == targetAscii[0] &&
        (sSkel == tSkel ||
            spoken.startsWith(targetAscii.substring(0, 2)) ||
            targetAscii.startsWith(spoken))) {
      return true;
    }
    return false;
  }
}
