import 'dart:convert';

import 'package:http/http.dart' as http;

import '../../domain/models/learning_models.dart';

/// Uses the student's own Google Drive (`UniLingua AI Data/unilingua_database.json`)
/// as a personal cloud database via Google Drive REST API v3.
class GoogleDriveDatabaseService {
  const GoogleDriveDatabaseService();

  static const String _folderName = 'UniLingua AI Data';
  static const String _dbFileName = 'unilingua_database.json';

  Future<String?> _findFileId({
    required String accessToken,
    required String query,
  }) async {
    final uri = Uri.https('www.googleapis.com', '/drive/v3/files', <String, String>{
      'q': query,
      'fields': 'files(id,name)',
      'spaces': 'drive',
      'pageSize': '1',
    });
    final resp = await http
        .get(
          uri,
          headers: <String, String>{
            'Authorization': 'Bearer $accessToken',
          },
        )
        .timeout(const Duration(seconds: 12));
    if (resp.statusCode != 200) return null;
    final data = jsonDecode(resp.body) as Map<String, dynamic>;
    final files = data['files'] as List<dynamic>? ?? const <dynamic>[];
    if (files.isEmpty) return null;
    return (files.first as Map<String, dynamic>)['id'] as String?;
  }

  Future<String?> _ensureFolderId(String accessToken) async {
    final existing = await _findFileId(
      accessToken: accessToken,
      query:
          "name='$_folderName' and mimeType='application/vnd.google-apps.folder' and trashed=false",
    );
    if (existing != null) return existing;

    final resp = await http
        .post(
          Uri.parse('https://www.googleapis.com/drive/v3/files'),
          headers: <String, String>{
            'Authorization': 'Bearer $accessToken',
            'Content-Type': 'application/json; charset=UTF-8',
          },
          body: jsonEncode(<String, dynamic>{
            'name': _folderName,
            'mimeType': 'application/vnd.google-apps.folder',
          }),
        )
        .timeout(const Duration(seconds: 12));
    if (resp.statusCode == 200 || resp.statusCode == 201) {
      final data = jsonDecode(resp.body) as Map<String, dynamic>;
      return data['id'] as String?;
    }
    return null;
  }

  /// Loads `unilingua_database.json` from the user's Google Drive if present.
  Future<StudentProgressState?> loadFromGoogleDrive(String accessToken) async {
    try {
      final fileId = await _findFileId(
        accessToken: accessToken,
        query: "name='$_dbFileName' and trashed=false",
      );
      if (fileId == null) return null;

      final uri = Uri.parse(
        'https://www.googleapis.com/drive/v3/files/$fileId?alt=media',
      );
      final resp = await http
          .get(
            uri,
            headers: <String, String>{
              'Authorization': 'Bearer $accessToken',
            },
          )
          .timeout(const Duration(seconds: 15));
      if (resp.statusCode != 200) return null;

      final decoded = jsonDecode(utf8.decode(resp.bodyBytes))
          as Map<String, dynamic>;
      return StudentProgressState.fromJson(decoded);
    } catch (_) {
      return null;
    }
  }

  /// Saves/updates `unilingua_database.json` directly inside `UniLingua AI Data`
  /// on the user's Google Drive. Returns true if synced successfully.
  Future<bool> saveToGoogleDrive({
    required String accessToken,
    required StudentProgressState state,
  }) async {
    try {
      final payloadJson = jsonEncode(state.toJson());
      final existingFileId = await _findFileId(
        accessToken: accessToken,
        query: "name='$_dbFileName' and trashed=false",
      );

      if (existingFileId != null) {
        final patchUri = Uri.parse(
          'https://www.googleapis.com/upload/drive/v3/files/$existingFileId?uploadType=media',
        );
        final resp = await http
            .patch(
              patchUri,
              headers: <String, String>{
                'Authorization': 'Bearer $accessToken',
                'Content-Type': 'application/json; charset=UTF-8',
              },
              body: utf8.encode(payloadJson),
            )
            .timeout(const Duration(seconds: 15));
        return resp.statusCode == 200;
      }

      // Create new JSON database file inside "UniLingua AI Data" folder
      final folderId = await _ensureFolderId(accessToken);
      const boundary = 'unilingua_drive_db_boundary';
      final metadata = <String, dynamic>{
        'name': _dbFileName,
        'mimeType': 'application/json',
        if (folderId != null) 'parents': <String>[folderId],
      };

      final multipartBody = StringBuffer()
        ..write('--$boundary\r\n')
        ..write('Content-Type: application/json; charset=UTF-8\r\n\r\n')
        ..write('${jsonEncode(metadata)}\r\n')
        ..write('--$boundary\r\n')
        ..write('Content-Type: application/json; charset=UTF-8\r\n\r\n')
        ..write('$payloadJson\r\n')
        ..write('--$boundary--\r\n');

      final createUri = Uri.parse(
        'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart',
      );
      final resp = await http
          .post(
            createUri,
            headers: <String, String>{
              'Authorization': 'Bearer $accessToken',
              'Content-Type': 'multipart/related; boundary=$boundary',
            },
            body: utf8.encode(multipartBody.toString()),
          )
          .timeout(const Duration(seconds: 15));
      return resp.statusCode == 200 || resp.statusCode == 201;
    } catch (_) {
      return false;
    }
  }
}
