import 'dart:math';

import '../../domain/models/learning_models.dart';

/// A uniquely generated Placement Exam instance tailored to user's age & self-assessed level.
class PlacementExamSet {
  const PlacementExamSet({
    required this.examCode,
    required this.tailoredLevelLabel,
    required this.questions,
    required this.dictationAudio,
    required this.speakingPrompt1,
    required this.speakingPrompt1Vi,
    required this.speakingPrompt2,
    required this.speakingPrompt2Vi,
    required this.writingPrompt,
    required this.writingPromptVi,
  });

  final String examCode;
  final String tailoredLevelLabel;
  final List<PlacementQuestion> questions;
  final String dictationAudio;
  final String speakingPrompt1;
  final String speakingPrompt1Vi;
  final String speakingPrompt2;
  final String speakingPrompt2Vi;
  final String writingPrompt;
  final String writingPromptVi;
}

/// Curriculum with:
/// - 100% English prompts & questions + accurate Vietnamese translation (`promptVi`/`questionVi`)
/// - 48+ diversified Placement Test questions calibrated across A1, A2, B1, and B2
/// - Tailored generation by user's Age & Self-Assessed Level (Mất gốc / Có biết cơ bản / Đã giỏi)
class CurriculumRepository {
  const CurriculumRepository._();

  static const List<int> dailyMinuteOptions = <int>[15, 30, 45];
  static const List<int> targetWeekOptions = <int>[4, 8, 12, 16];

  static const String placementDictationAudio =
      'I want to speak English every day.';

  // ==================== DIVERSIFIED LISTENING POOLS (16 QUESTIONS) ====================

  static const List<PlacementQuestion> _listeningA1Pool = <PlacementQuestion>[
    PlacementQuestion(
      id: 'l_a1_1',
      skill: SkillType.listening,
      cefrDifficulty: 'A1',
      topicTag: 'Daily Routine (A1)',
      audioScript:
          'Hi, my name is Anna. I am a student. I wake up at seven o clock every morning.',
      prompt: 'What time does Anna wake up every morning?',
      promptVi: 'Anna thức dậy lúc mấy giờ mỗi sáng?',
      options: <String>['At 6:00 AM', 'At 7:00 AM', 'At 8:00 AM', 'At 9:00 AM'],
      correctIndex: 1,
      explanationVi: 'Anna nói: "I wake up at seven o\'clock" (7 giờ sáng).',
      weight: 20,
    ),
    PlacementQuestion(
      id: 'l_a1_2',
      skill: SkillType.listening,
      cefrDifficulty: 'A1',
      topicTag: 'Breakfast Habits (A1)',
      audioScript:
          'Hello, I am Tom. For breakfast, I usually eat bread and drink a cup of warm milk.',
      prompt: 'What does Tom usually drink for breakfast?',
      promptVi: 'Tom thường uống gì vào bữa sáng?',
      options: <String>[
        'Orange juice',
        'Iced coffee',
        'Warm milk',
        'Green tea',
      ],
      correctIndex: 2,
      explanationVi: 'Tom nói: "drink a cup of warm milk" (một ly sữa ấm).',
      weight: 20,
    ),
    PlacementQuestion(
      id: 'l_a1_3',
      skill: SkillType.listening,
      cefrDifficulty: 'A1',
      topicTag: 'Family & Numbers (A1)',
      audioScript:
          'My name is Lan. I have two younger brothers and one small dog at home.',
      prompt: 'How many younger brothers does Lan have?',
      promptVi: 'Lan có bao nhiêu người em trai?',
      options: <String>['One', 'Two', 'Three', 'None'],
      correctIndex: 1,
      explanationVi: 'Lan nói: "I have two younger brothers" (2 người em trai).',
      weight: 20,
    ),
    PlacementQuestion(
      id: 'l_a1_4',
      skill: SkillType.listening,
      cefrDifficulty: 'A1',
      topicTag: 'Transportation (A1)',
      audioScript:
          'Good morning! I live near my school, so I always ride my bicycle there with my neighbor.',
      prompt: 'How does the speaker go to school every day?',
      promptVi: 'Người nói đi đến trường hằng ngày bằng phương tiện gì?',
      options: <String>['By bus', 'By bicycle', 'By train', 'By taxi'],
      correctIndex: 1,
      explanationVi: 'Người nói nói: "I always ride my bicycle there."',
      weight: 20,
    ),
  ];

  static const List<PlacementQuestion> _listeningA2Pool = <PlacementQuestion>[
    PlacementQuestion(
      id: 'l_a2_1',
      skill: SkillType.listening,
      cefrDifficulty: 'A2',
      topicTag: 'Ordering at Cafe (A2)',
      audioScript:
          'Customer: Excuse me, how much is this iced coffee? Staff: It is three dollars.',
      prompt: 'How much does the iced coffee cost?',
      promptVi: 'Ly cà phê đá trong đoạn hội thoại giá bao nhiêu tiền?',
      options: <String>[
        'Two dollars',
        'Three dollars',
        'Four dollars',
        'Five dollars',
      ],
      correctIndex: 1,
      explanationVi: 'Nhân viên trả lời: "It is three dollars" (3 đô la).',
      weight: 30,
    ),
    PlacementQuestion(
      id: 'l_a2_2',
      skill: SkillType.listening,
      cefrDifficulty: 'A2',
      topicTag: 'Asking Directions (A2)',
      audioScript:
          'Excuse me, where is the city library? Go straight for two blocks, then turn left. It is right next to the bank.',
      prompt: 'Where is the city library located?',
      promptVi: 'Thư viện thành phố nằm ở đâu?',
      options: <String>[
        'Next to the bank',
        'Inside the park',
        'Opposite the airport',
        'Behind the hospital',
      ],
      correctIndex: 0,
      explanationVi: 'Người chỉ đường nói: "It is right next to the bank."',
      weight: 30,
    ),
    PlacementQuestion(
      id: 'l_a2_3',
      skill: SkillType.listening,
      cefrDifficulty: 'A2',
      topicTag: 'Weekend Plans (A2)',
      audioScript:
          'Hey Minh, are you free on Saturday afternoon? Let us watch a new movie at the shopping mall at three p.m.',
      prompt: 'When do the two friends plan to watch a movie?',
      promptVi: 'Hai người bạn hẹn đi xem phim vào lúc nào?',
      options: <String>[
        'Friday at 8:00 AM',
        'Saturday at 3:00 PM',
        'Sunday at 7:00 PM',
        'Monday at 2:00 PM',
      ],
      correctIndex: 1,
      explanationVi: '"on Saturday afternoon... at three p.m."',
      weight: 30,
    ),
    PlacementQuestion(
      id: 'l_a2_4',
      skill: SkillType.listening,
      cefrDifficulty: 'A2',
      topicTag: 'Weather Report (A2)',
      audioScript:
          'This afternoon will be sunny and warm, but remember to bring an umbrella tonight because light rain is expected after eight.',
      prompt: 'Why should listeners bring an umbrella tonight?',
      promptVi: 'Tại sao mọi người nên mang theo ô vào tối nay?',
      options: <String>[
        'Because snow is expected',
        'Because light rain is expected after eight',
        'Because it is very windy all day',
        'Because the weather will be freezing',
      ],
      correctIndex: 1,
      explanationVi: '"because light rain is expected after eight."',
      weight: 30,
    ),
  ];

  static const List<PlacementQuestion> _listeningB1Pool = <PlacementQuestion>[
    PlacementQuestion(
      id: 'l_b1_1',
      skill: SkillType.listening,
      cefrDifficulty: 'B1',
      topicTag: 'Class Schedule Change (B1)',
      audioScript:
          'Attention students: Tomorrow our English workshop will start at nine thirty instead of eight o clock because our instructor has a morning meeting.',
      prompt: 'Why will tomorrow\'s English workshop start at 9:30 AM?',
      promptVi: 'Tại sao buổi học tiếng Anh ngày mai bắt đầu lúc 9:30 sáng?',
      options: <String>[
        'The classroom is closed until noon',
        'The instructor has a morning meeting',
        'The exam was postponed to next week',
        'Most students are traveling',
      ],
      correctIndex: 1,
      explanationVi: '"because our instructor has a morning meeting."',
      weight: 40,
    ),
    PlacementQuestion(
      id: 'l_b1_2',
      skill: SkillType.listening,
      cefrDifficulty: 'B1',
      topicTag: 'Job Interview (B1)',
      audioScript:
          'I would like to apply for the weekend cashier position because I have full-time classes from Monday to Friday.',
      prompt: 'Why does the applicant prefer working only on weekends?',
      promptVi: 'Tại sao ứng viên muốn làm việc vào cuối tuần?',
      options: <String>[
        'Weekend pay is lower',
        'They attend classes from Monday to Friday',
        'The shop closes on weekdays',
        'They live far away on weekends',
      ],
      correctIndex: 1,
      explanationVi: '"because I have full-time classes from Monday to Friday."',
      weight: 40,
    ),
    PlacementQuestion(
      id: 'l_b1_3',
      skill: SkillType.listening,
      cefrDifficulty: 'B1',
      topicTag: 'Vocabulary Study Tip (B1)',
      audioScript:
          'Instead of memorizing long lists of words silently, try using each new word in a short spoken sentence every day.',
      prompt: 'What vocabulary method does the speaker recommend?',
      promptVi: 'Người nói khuyên cách học từ vựng nào hiệu quả hơn?',
      options: <String>[
        'Copy lists of 100 words every night',
        'Use each new word in a short spoken sentence daily',
        'Never speak words out loud',
        'Only read dictionary definitions',
      ],
      correctIndex: 1,
      explanationVi: '"try using each new word in a short spoken sentence every day."',
      weight: 40,
    ),
    PlacementQuestion(
      id: 'l_b1_4',
      skill: SkillType.listening,
      cefrDifficulty: 'B1',
      topicTag: 'Hotel Booking (B1)',
      audioScript:
          'We are sorry to inform you that rooms with a sea view are fully booked this Friday, so we can offer you a quiet garden room with complimentary breakfast.',
      prompt: 'What can the hotel offer the guest this Friday?',
      promptVi: 'Khách sạn có thể sắp xếp cho khách phòng nào vào thứ Sáu này?',
      options: <String>[
        'A sea-view suite at half price',
        'A garden room with free breakfast',
        'A room on Sunday morning',
        'An upgrade to a penthouse',
      ],
      correctIndex: 1,
      explanationVi: '"a quiet garden room with complimentary breakfast."',
      weight: 40,
    ),
  ];

  static const List<PlacementQuestion> _listeningB2Pool = <PlacementQuestion>[
    PlacementQuestion(
      id: 'l_b2_1',
      skill: SkillType.listening,
      cefrDifficulty: 'B2',
      topicTag: 'Remote Work Research (B2)',
      audioScript:
          'While flexible working hours boost individual productivity, researchers emphasize that teams still need regular face-to-face catchups to maintain long-term trust and creative collaboration.',
      prompt: 'What do researchers warn about completely remote teams?',
      promptVi: 'Các nhà nghiên cứu lưu ý điều gì đối với nhóm làm việc từ xa?',
      options: <String>[
        'Flexible hours always lower individual focus',
        'Regular in-person catchups remain vital for trust and collaboration',
        'Remote teams never need communication tools',
        'Employees dislike flexible schedules',
      ],
      correctIndex: 1,
      explanationVi: '"teams still need regular face-to-face catchups to maintain long-term trust and creative collaboration."',
      weight: 45,
    ),
    PlacementQuestion(
      id: 'l_b2_2',
      skill: SkillType.listening,
      cefrDifficulty: 'B2',
      topicTag: 'Tech Conference Talk (B2)',
      audioScript:
          'Although artificial intelligence can automate repetitive analysis, critical decision-making still relies heavily on human empathy and ethical judgment.',
      prompt: 'According to the speaker, what cannot be replaced solely by AI?',
      promptVi: 'Theo diễn giả, yếu tố nào vẫn phụ thuộc vào con người chứ không thể thay thế hoàn toàn bằng AI?',
      options: <String>[
        'Sorting large data tables',
        'Critical decisions requiring empathy and ethical judgment',
        'Drafting simple meeting summaries',
        'Translating standard manuals',
      ],
      correctIndex: 1,
      explanationVi: '"critical decision-making still relies heavily on human empathy and ethical judgment."',
      weight: 45,
    ),
    PlacementQuestion(
      id: 'l_b2_3',
      skill: SkillType.listening,
      cefrDifficulty: 'B2',
      topicTag: 'Urban Planning Podcast (B2)',
      audioScript:
          'Expanding bike lanes alone rarely convinces commuters to abandon cars unless those routes are physically protected and seamlessly connected to public transit stations.',
      prompt: 'What makes commuters more likely to use urban bike lanes?',
      promptVi: 'Điều gì khiến người đi làm thực sự muốn sử dụng làn đường xe đạp?',
      options: <String>[
        'Higher bicycle taxes in downtown areas',
        'Protected lanes connected seamlessly to public transit',
        'Closing all public bus stops',
        'Painting lanes only on weekend roads',
      ],
      correctIndex: 1,
      explanationVi: '"physically protected and seamlessly connected to public transit stations."',
      weight: 45,
    ),
  ];

  // ==================== DIVERSIFIED READING POOLS (15 QUESTIONS) ====================

  static const List<PlacementQuestion> _readingA1Pool = <PlacementQuestion>[
    PlacementQuestion(
      id: 'r_a1_1',
      skill: SkillType.reading,
      cefrDifficulty: 'A1',
      topicTag: 'Short Message (A1)',
      readingContext:
          'Hi Nam, I am at the coffee shop near our school. Let\'s study English together after class!',
      prompt: 'Where is the person who sent this message?',
      promptVi: 'Người gửi tin nhắn này hiện đang ở đâu?',
      options: <String>[
        'At home',
        'At a coffee shop near school',
        'At the movie theater',
        'At the bus station',
      ],
      correctIndex: 1,
      explanationVi: '"I am at the coffee shop near our school."',
      weight: 20,
    ),
    PlacementQuestion(
      id: 'r_a1_2',
      skill: SkillType.reading,
      cefrDifficulty: 'A1',
      topicTag: 'Store Sign (A1)',
      readingContext:
          'Bookstore Opening Hours: Open Monday to Saturday, 8:00 AM to 8:00 PM. Closed on Sunday.',
      prompt: 'Which day is the bookstore closed?',
      promptVi: 'Hiệu sách đóng cửa vào ngày nào trong tuần?',
      options: <String>['Monday', 'Wednesday', 'Saturday', 'Sunday'],
      correctIndex: 3,
      explanationVi: '"Closed on Sunday" (Đóng cửa vào Chủ nhật).',
      weight: 20,
    ),
    PlacementQuestion(
      id: 'r_a1_3',
      skill: SkillType.reading,
      cefrDifficulty: 'A1',
      topicTag: 'Hobbies Note (A1)',
      readingContext:
          'My best friend is Hoa. She loves cooking Vietnamese food and listening to pop music in the evening.',
      prompt: 'What does Hoa enjoy doing in the evening?',
      promptVi: 'Hoa thích làm gì vào buổi tối?',
      options: <String>[
        'Playing basketball',
        'Listening to pop music',
        'Swimming at the beach',
        'Repairing bicycles',
      ],
      correctIndex: 1,
      explanationVi: '"listening to pop music in the evening."',
      weight: 20,
    ),
    PlacementQuestion(
      id: 'r_a1_4',
      skill: SkillType.reading,
      cefrDifficulty: 'A1',
      topicTag: 'Lunch Invitation (A1)',
      readingContext:
          'Hello Mai! Would you like to have lunch at the campus canteen at 12:15 PM today? I bought two extra apples for us.',
      prompt: 'What time does the sender suggest having lunch?',
      promptVi: 'Người nhắn mời đi ăn trưa vào lúc mấy giờ?',
      options: <String>['11:15 AM', '12:15 PM', '1:30 PM', '6:15 PM'],
      correctIndex: 1,
      explanationVi: '"at 12:15 PM today."',
      weight: 20,
    ),
  ];

  static const List<PlacementQuestion> _readingA2Pool = <PlacementQuestion>[
    PlacementQuestion(
      id: 'r_a2_1',
      skill: SkillType.reading,
      cefrDifficulty: 'A2',
      topicTag: 'Study Routine (A2)',
      readingContext:
          'Minh studies English for 20 minutes every evening. First, he learns 5 new words. Then, he listens to a short dialogue and repeats it out loud.',
      prompt: 'How many minutes does Minh practice English each evening?',
      promptVi: 'Mỗi tối Minh dành bao nhiêu phút để luyện tiếng Anh?',
      options: <String>['10 minutes', '20 minutes', '45 minutes', '2 hours'],
      correctIndex: 1,
      explanationVi: '"Minh studies English for 20 minutes every evening."',
      weight: 30,
    ),
    PlacementQuestion(
      id: 'r_a2_2',
      skill: SkillType.reading,
      cefrDifficulty: 'A2',
      topicTag: 'Club Notice (A2)',
      readingContext:
          'Join our English Speaking Club every Wednesday at 5:30 PM in Room 204! Entry is free for all students, and beginners are always welcome.',
      prompt: 'Who is invited to join the English Speaking Club?',
      promptVi: 'Những ai có thể tham gia Câu lạc bộ Nói Tiếng Anh?',
      options: <String>[
        'Only IELTS 8.0 students',
        'All students, including beginners, for free',
        'Only foreign teachers',
        'Students who pay a monthly fee',
      ],
      correctIndex: 1,
      explanationVi: '"Entry is free for all students, and beginners are always welcome."',
      weight: 30,
    ),
    PlacementQuestion(
      id: 'r_a2_3',
      skill: SkillType.reading,
      cefrDifficulty: 'A2',
      topicTag: 'Travel Story (A2)',
      readingContext:
          'Last summer, Linh traveled to Da Nang by train. Although the trip took 14 hours, she enjoyed watching the ocean view through the window.',
      prompt: 'How did Linh travel to Da Nang last summer?',
      promptVi: 'Mùa hè năm ngoái Linh đã đi Đà Nẵng bằng phương tiện nào?',
      options: <String>['By airplane', 'By train', 'By motorbike', 'By boat'],
      correctIndex: 1,
      explanationVi: '"traveled to Da Nang by train" (đi bằng tàu hỏa).',
      weight: 30,
    ),
    PlacementQuestion(
      id: 'r_a2_4',
      skill: SkillType.reading,
      cefrDifficulty: 'A2',
      topicTag: 'Package Delivery (A2)',
      readingContext:
          'Dear Customer, your new headphones arrived at our local post office today. Please bring your ID card to pick them up before 6:00 PM on Friday.',
      prompt: 'What must the customer bring to collect the package?',
      promptVi: 'Khách hàng cần mang theo gì khi đến nhận bưu phẩm?',
      options: <String>[
        'A friend\'s phone',
        'An ID card',
        'An old keyboard',
        'Extra cash for shipping',
      ],
      correctIndex: 1,
      explanationVi: '"Please bring your ID card to pick them up."',
      weight: 30,
    ),
  ];

  static const List<PlacementQuestion> _readingB1Pool = <PlacementQuestion>[
    PlacementQuestion(
      id: 'r_b1_1',
      skill: SkillType.reading,
      cefrDifficulty: 'B1',
      topicTag: 'Part-time Work Balance (B1)',
      readingContext:
          'Having a part-time job during university helps students earn extra income and build communication skills. However, students should manage their schedule carefully so work does not hurt exam results.',
      prompt: 'What advice does the passage give to working university students?',
      promptVi: 'Đoạn văn khuyên sinh viên đi làm thêm nên chú ý điều gì?',
      options: <String>[
        'Skip morning lectures regularly',
        'Manage their schedule carefully to protect exam results',
        'Avoid talking to coworkers',
        'Work only midnight shifts',
      ],
      correctIndex: 1,
      explanationVi: '"manage their schedule carefully so work does not hurt exam results."',
      weight: 40,
    ),
    PlacementQuestion(
      id: 'r_b1_2',
      skill: SkillType.reading,
      cefrDifficulty: 'B1',
      topicTag: 'Sleep & Memory (B1)',
      readingContext:
          'Staying up all night before an exam might feel productive, yet studies show that getting seven to eight hours of sleep helps your brain organize and remember what you studied much more effectively.',
      prompt: 'Why is getting 7–8 hours of sleep helpful before an exam?',
      promptVi: 'Tại sao ngủ đủ 7–8 tiếng trước kỳ thi lại có ích?',
      options: <String>[
        'It makes you forget hard lessons',
        'It helps the brain organize and retain studied material better',
        'It guarantees no study is needed',
        'It replaces reading textbooks',
      ],
      correctIndex: 1,
      explanationVi: '"helps your brain organize and remember what you studied much more effectively."',
      weight: 40,
    ),
    PlacementQuestion(
      id: 'r_b1_3',
      skill: SkillType.reading,
      cefrDifficulty: 'B1',
      topicTag: 'Speaking Fluency (B1)',
      readingContext:
          'Most English learners wait until their grammar is perfect before speaking. In reality, fluency develops faster when you communicate regularly and learn from small mistakes along the way.',
      prompt: 'What is the main point about building speaking fluency?',
      promptVi: 'Ý chính của đoạn văn về cách rèn sự trôi chảy khi nói là gì?',
      options: <String>[
        'Wait until grammar is 100% perfect before speaking',
        'Communicate regularly and learn from small mistakes',
        'Memorize an entire dictionary first',
        'Focus solely on silent reading',
      ],
      correctIndex: 1,
      explanationVi: '"fluency develops faster when you communicate regularly and learn from small mistakes."',
      weight: 40,
    ),
  ];

  static const List<PlacementQuestion> _readingB2Pool = <PlacementQuestion>[
    PlacementQuestion(
      id: 'r_b2_1',
      skill: SkillType.reading,
      cefrDifficulty: 'B2',
      topicTag: 'Digital Habits (B2)',
      readingContext:
          'Constant notifications fracture deep attention, forcing the brain to spend valuable cognitive energy switching back and forth between unrelated tasks. Setting dedicated offline focus blocks significantly improves problem-solving speed.',
      prompt: 'According to the passage, what happens when notifications interrupt work?',
      promptVi: 'Theo đoạn văn, điều gì xảy ra khi thông báo điện thoại liên tục ngắt quãng công việc?',
      options: <String>[
        'The brain relaxes faster',
        'Mental energy is wasted switching between tasks',
        'Creative problem-solving speeds up',
        'Memory recall becomes automatic',
      ],
      correctIndex: 1,
      explanationVi: '"forcing the brain to spend valuable cognitive energy switching back and forth."',
      weight: 45,
    ),
    PlacementQuestion(
      id: 'r_b2_2',
      skill: SkillType.reading,
      cefrDifficulty: 'B2',
      topicTag: 'Sustainable Cities (B2)',
      readingContext:
          'Urban green roofs do far more than add visual appeal; by absorbing rainwater and shading rooftops, they substantially reduce summer cooling costs while easing pressure on city drainage systems.',
      prompt: 'Which practical benefit of urban green roofs is highlighted?',
      promptVi: 'Lợi ích thực tế nào của mái nhà phủ cây xanh đô thị được nhấn mạnh?',
      options: <String>[
        'They completely eliminate winter heating bills',
        'They lower cooling costs and ease drainage pressure',
        'They require zero maintenance throughout the year',
        'They increase street traffic capacity',
      ],
      correctIndex: 1,
      explanationVi: '"substantially reduce summer cooling costs while easing pressure on city drainage systems."',
      weight: 45,
    ),
  ];

  // ==================== DIVERSIFIED GRAMMAR & VOCAB POOLS (16 QUESTIONS) ====================

  static const List<PlacementQuestion> _grammarA1Pool = <PlacementQuestion>[
    PlacementQuestion(
      id: 'g_a1_1',
      skill: SkillType.writing,
      cefrDifficulty: 'A1',
      topicTag: 'Verb To Be (A1)',
      prompt: 'Choose the correct word to complete the sentence:\n"She _____ a university student."',
      promptVi: 'Chọn từ đúng để hoàn thành câu: "Cô ấy là sinh viên đại học."',
      options: <String>['am', 'is', 'are', 'be'],
      correctIndex: 1,
      explanationVi: 'Chủ ngữ số ít "She" đi với động từ "is".',
      weight: 20,
    ),
    PlacementQuestion(
      id: 'g_a1_2',
      skill: SkillType.writing,
      cefrDifficulty: 'A1',
      topicTag: 'Present Simple (A1)',
      prompt: 'Choose the best option:\n"We _____ English together every evening."',
      promptVi: 'Chọn đáp án đúng: "Chúng tôi học tiếng Anh cùng nhau mỗi tối."',
      options: <String>['study', 'studies', 'studying', 'studied'],
      correctIndex: 0,
      explanationVi: 'Chủ ngữ "We" với thói quen "every evening" dùng "study".',
      weight: 20,
    ),
    PlacementQuestion(
      id: 'g_a1_3',
      skill: SkillType.writing,
      cefrDifficulty: 'A1',
      topicTag: 'Articles a / an (A1)',
      prompt: 'Choose the correct article:\n"I usually eat _____ apple after lunch."',
      promptVi: 'Chọn mạo từ đúng: "Tôi thường ăn một quả táo sau bữa trưa."',
      options: <String>['a', 'an', 'two', 'are'],
      correctIndex: 1,
      explanationVi: 'Trước danh từ số ít bắt đầu bằng nguyên âm ("apple") dùng "an".',
      weight: 20,
    ),
    PlacementQuestion(
      id: 'g_a1_4',
      skill: SkillType.writing,
      cefrDifficulty: 'A1',
      topicTag: 'Pronouns & Origin (A1)',
      prompt: 'Complete the introduction:\n"Hello! My name is Vang, and I _____ from Thai Nguyen."',
      promptVi: 'Hoàn thành câu giới thiệu: "Xin chào! Tên tôi là Vang, và tôi đến từ Thái Nguyên."',
      options: <String>['am', 'is', 'have', 'go'],
      correctIndex: 0,
      explanationVi: 'Giới thiệu quê quán dùng "I am from ...".',
      weight: 20,
    ),
  ];

  static const List<PlacementQuestion> _grammarA2Pool = <PlacementQuestion>[
    PlacementQuestion(
      id: 'g_a2_1',
      skill: SkillType.writing,
      cefrDifficulty: 'A2',
      topicTag: 'Past Simple (A2)',
      prompt: 'Choose the right verb form:\n"Yesterday, I _____ to the bookstore with my friends."',
      promptVi: 'Chọn dạng động từ đúng: "Hôm qua tôi đã đi đến hiệu sách cùng bạn bè."',
      options: <String>['go', 'goes', 'went', 'going'],
      correctIndex: 2,
      explanationVi: '"Yesterday" dùng quá khứ đơn → quá khứ của "go" là "went".',
      weight: 30,
    ),
    PlacementQuestion(
      id: 'g_a2_2',
      skill: SkillType.writing,
      cefrDifficulty: 'A2',
      topicTag: 'Prepositions of Time (A2)',
      prompt: 'Fill in the blank with the right preposition:\n"Our meeting starts _____ 9:00 AM tomorrow."',
      promptVi: 'Điền giới từ thích hợp: "Cuộc họp của chúng ta bắt đầu lúc 9:00 sáng mai."',
      options: <String>['in', 'on', 'at', 'by'],
      correctIndex: 2,
      explanationVi: 'Trước giờ cụ thể (9:00 AM) luôn dùng giới từ "at".',
      weight: 30,
    ),
    PlacementQuestion(
      id: 'g_a2_3',
      skill: SkillType.writing,
      cefrDifficulty: 'A2',
      topicTag: 'Comparatives (A2)',
      prompt: 'Choose the correct word:\n"Practicing every day makes my English _____ than before."',
      promptVi: 'Chọn từ đúng: "Luyện tập mỗi ngày giúp tiếng Anh của tôi tốt hơn trước."',
      options: <String>['good', 'better', 'best', 'well'],
      correctIndex: 1,
      explanationVi: 'Có "than" dùng so sánh hơn → so sánh hơn của "good" là "better".',
      weight: 30,
    ),
    PlacementQuestion(
      id: 'g_a2_4',
      skill: SkillType.writing,
      cefrDifficulty: 'A2',
      topicTag: 'Modal Verbs (A2)',
      prompt: 'Complete the sentence:\n"Students _____ turn off their phones during the exam."',
      promptVi: 'Hoàn thành câu: "Học sinh phải tắt điện thoại trong lúc làm bài thi."',
      options: <String>['must', 'can to', 'having', 'are'],
      correctIndex: 0,
      explanationVi: '"must" diễn tả quy định bắt buộc ("phải tắt điện thoại").',
      weight: 30,
    ),
  ];

  static const List<PlacementQuestion> _grammarB1Pool = <PlacementQuestion>[
    PlacementQuestion(
      id: 'g_b1_1',
      skill: SkillType.writing,
      cefrDifficulty: 'B1',
      topicTag: 'First Conditional (B1)',
      prompt: 'Complete the sentence:\n"If I practice speaking every day, my English _____ much better."',
      promptVi: 'Hoàn thành câu điều kiện: "Nếu tôi luyện nói mỗi ngày, tiếng Anh của tôi sẽ khá hơn nhiều."',
      options: <String>['will become', 'became', 'becoming', 'was'],
      correctIndex: 0,
      explanationVi: 'Câu điều kiện loại 1: If + hiện tại đơn, S + will + V.',
      weight: 40,
    ),
    PlacementQuestion(
      id: 'g_b1_2',
      skill: SkillType.writing,
      cefrDifficulty: 'B1',
      topicTag: 'Present Perfect (B1)',
      prompt: 'Choose the accurate verb tense:\n"I _____ in this city since 2023."',
      promptVi: 'Chọn thì đúng: "Tôi đã sống ở thành phố này từ năm 2023."',
      options: <String>['live', 'lived', 'have lived', 'living'],
      correctIndex: 2,
      explanationVi: 'Có "since 2023" dùng thì hiện tại hoàn thành "have lived".',
      weight: 40,
    ),
    PlacementQuestion(
      id: 'g_b1_3',
      skill: SkillType.writing,
      cefrDifficulty: 'B1',
      topicTag: 'Contrast Connectors (B1)',
      prompt: 'Select the best connector:\n"_____ it was raining heavily, we still arrived on time."',
      promptVi: 'Chọn liên từ đúng: "Mặc dù trời mưa rất to, chúng tôi vẫn đến đúng giờ."',
      options: <String>['Although', 'Because', 'So', 'Despite'],
      correctIndex: 0,
      explanationVi: '"Although + mệnh đề (S + V)" diễn tả sự nhượng bộ ("Mặc dù...").',
      weight: 40,
    ),
    PlacementQuestion(
      id: 'g_b1_4',
      skill: SkillType.writing,
      cefrDifficulty: 'B1',
      topicTag: 'Gerunds (B1)',
      prompt: 'Pick the correct form:\n"She really enjoys _____ English podcasts while walking."',
      promptVi: 'Chọn dạng từ đúng: "Cô ấy rất thích nghe podcast tiếng Anh khi đi dạo."',
      options: <String>['listen', 'to listen', 'listening to', 'listened'],
      correctIndex: 2,
      explanationVi: 'Động từ sau "enjoy" dùng dạng V-ing ("listening to").',
      weight: 40,
    ),
  ];

  static const List<PlacementQuestion> _grammarB2Pool = <PlacementQuestion>[
    PlacementQuestion(
      id: 'g_b2_1',
      skill: SkillType.writing,
      cefrDifficulty: 'B2',
      topicTag: 'Inversion & Emphasis (B2)',
      prompt: 'Complete the formal sentence:\n"Not only _____ fluent in English, but she also speaks Japanese."',
      promptVi: 'Hoàn thành câu nâng cao: "Cô ấy không chỉ nói trôi chảy tiếng Anh mà còn nói được tiếng Nhật."',
      options: <String>['she is', 'is she', 'she was', 'has she'],
      correctIndex: 1,
      explanationVi: 'Cấu trúc đảo ngữ đứng đầu câu với "Not only": trợ động từ đứng trước chủ ngữ ("is she").',
      weight: 45,
    ),
    PlacementQuestion(
      id: 'g_b2_2',
      skill: SkillType.writing,
      cefrDifficulty: 'B2',
      topicTag: 'Past Wish / Regret (B2)',
      prompt: 'Choose the best option:\n"I wish I _____ earlier for last week\'s presentation."',
      promptVi: 'Chọn đáp án đúng: "Ước gì tuần trước tôi đã chuẩn bị sớm hơn cho bài thuyết trình."',
      options: <String>[
        'prepare',
        'had prepared',
        'am preparing',
        'will prepare',
      ],
      correctIndex: 1,
      explanationVi: 'Câu ước về quá khứ ("last week") dùng quá khứ hoàn thành ("had prepared").',
      weight: 45,
    ),
    PlacementQuestion(
      id: 'g_b2_3',
      skill: SkillType.writing,
      cefrDifficulty: 'B2',
      topicTag: 'Academic Collocation (B2)',
      prompt: 'Select the natural academic collocation:\n"Regular feedback can _____ a significant impact on learner motivation."',
      promptVi: 'Chọn cụm từ học thuật tự nhiên: "Phản hồi thường xuyên có thể tạo ra tác động lớn đến động lực học tập."',
      options: <String>['do', 'have', 'take', 'say'],
      correctIndex: 1,
      explanationVi: 'Cụm từ chuẩn là "have an impact on ...".',
      weight: 45,
    ),
  ];

  // ==================== DIVERSIFIED SPEAKING COMM POOLS (6 QUESTIONS) ====================

  static const List<PlacementQuestion> _speakingCommPool = <PlacementQuestion>[
    PlacementQuestion(
      id: 's_a1_1',
      skill: SkillType.speaking,
      cefrDifficulty: 'A1',
      topicTag: 'Friendly Greeting (A1)',
      audioScript: 'Hi! How are you doing today?',
      prompt: 'How do you reply naturally when someone asks "How are you doing today?"',
      promptVi: 'Bạn sẽ đáp lại tự nhiên như thế nào khi ai đó hỏi "Hôm nay bạn thế nào?"',
      options: <String>[
        'I am twenty years old.',
        'I\'m doing great, thanks! How about you?',
        'Yes, I like coffee.',
        'Goodbye, see you tomorrow.',
      ],
      correctIndex: 1,
      explanationVi: '"I\'m doing great, thanks! How about you?" là cách đáp tự nhiên nhất.',
      weight: 25,
    ),
    PlacementQuestion(
      id: 's_a2_2',
      skill: SkillType.speaking,
      cefrDifficulty: 'A2',
      topicTag: 'Clarification (A2)',
      audioScript: 'Sorry, I did not catch what you just said.',
      prompt: 'Someone speaks too fast. What is the most polite way to ask them to slow down?',
      promptVi: 'Nếu người khác nói quá nhanh, câu lịch sự nhất để nhờ họ nói chậm lại là gì?',
      options: <String>[
        'Stop talking right now.',
        'Could you speak a little slower, please?',
        'I do not like English.',
        'You are too loud.',
      ],
      correctIndex: 1,
      explanationVi: '"Could you speak a little slower, please?" lịch sự và tự nhiên.',
      weight: 30,
    ),
    PlacementQuestion(
      id: 's_a2_3',
      skill: SkillType.speaking,
      cefrDifficulty: 'A2',
      topicTag: 'Replying Thanks (A2)',
      audioScript: 'Thank you so much for helping me with my project!',
      prompt: 'Your classmate says "Thank you so much!". What is a warm response?',
      promptVi: 'Bạn cùng lớp nói "Cảm ơn bạn rất nhiều!". Câu đáp thân thiện là gì?',
      options: <String>[
        'You\'re welcome! Anytime.',
        'Good morning!',
        'I am a student.',
        'How much does it cost?',
      ],
      correctIndex: 0,
      explanationVi: '"You\'re welcome! Anytime." nghĩa là "Không có gì! Lúc nào cũng sẵn lòng."',
      weight: 30,
    ),
    PlacementQuestion(
      id: 's_b1_4',
      skill: SkillType.speaking,
      cefrDifficulty: 'B1',
      topicTag: 'Polite Disagreement (B1)',
      audioScript: 'In my opinion, studying alone is always better than teamwork.',
      prompt: 'How can you politely express a different opinion during a discussion?',
      promptVi: 'Trong buổi thảo luận, bạn nên mở đầu câu như thế nào để phản biện lịch sự?',
      options: <String>[
        'Your idea makes zero sense.',
        'I see your point, though I think teamwork also brings great ideas.',
        'Be quiet and listen to me.',
        'Nobody cares about your opinion.',
      ],
      correctIndex: 1,
      explanationVi: '"I see your point, though..." là cách phản biện lịch sự và chuyên nghiệp.',
      weight: 40,
    ),
    PlacementQuestion(
      id: 's_b2_5',
      skill: SkillType.speaking,
      cefrDifficulty: 'B2',
      topicTag: 'Interview Follow-up (B2)',
      audioScript: 'Why should our team select you for this leadership role?',
      prompt: 'Which answer sounds most convincing in an English job interview?',
      promptVi: 'Câu trả lời nào thuyết phục và chuyên nghiệp nhất trong phỏng vấn?',
      options: <String>[
        'Because I just want a higher salary soon.',
        'I have led three campus projects and enjoy helping teammates solve tough problems together.',
        'Because I have nothing else to do this summer.',
        'My friends forced me to apply.',
      ],
      correctIndex: 1,
      explanationVi: 'Nêu bằng chứng thực tế ("led three campus projects") và tinh thần đồng đội.',
      weight: 45,
    ),
  ];

  static const List<String> _dictationPoolBeginner = <String>[
    'I want to speak English every day.',
    'Nice to meet you. Where are you from?',
    'Good morning! How are you doing today?',
    'I live in Vietnam and love music.',
  ];

  static const List<String> _dictationPoolIntermediate = <String>[
    'Can I have an iced coffee with less sugar, please?',
    'She practices speaking English for twenty minutes every night.',
    'Let us review the new vocabulary together after class.',
    'Thank you very much for helping me yesterday.',
  ];

  static const List<String> _dictationPoolAdvanced = <String>[
    'Regular daily conversation helps learners build natural confidence rapidly.',
    'Although the project deadline was tight, our team delivered impressive results.',
    'Clear communication makes international teamwork smoother and far more effective.',
  ];

  static const List<Map<String, String>> _openPromptsYoungBeginner =
      <Map<String, String>>[
    <String, String>{
      's1': 'Introduce yourself in 1–3 simple English sentences (name, age, hometown).',
      's1Vi': 'Giới thiệu ngắn về bản thân bằng 1–3 câu tiếng Anh đơn giản (tên, tuổi, quê quán).',
      's2': 'What do you like doing in your free time? Say 1–2 short English sentences.',
      's2Vi': 'Bạn thích làm gì vào thời gian rảnh? Hãy nói 1–2 câu tiếng Anh ngắn.',
      'w': 'Write 2–4 simple English sentences about yourself and why you are learning English.',
      'wVi': 'Viết 2–4 câu tiếng Anh đơn giản về bản thân và lý do bạn học tiếng Anh.',
    },
    <String, String>{
      's1': 'Tell us about your favorite food or drink in 1–3 easy English sentences.',
      's1Vi': 'Kể về món ăn hoặc đồ uống bạn yêu thích bằng 1–3 câu tiếng Anh dễ.',
      's2': 'How do you go to school or work? Answer in 1–2 short English sentences.',
      's2Vi': 'Bạn đi học hoặc đi làm bằng phương tiện gì? Trả lời bằng 1–2 câu ngắn.',
      'w': 'Write 2–4 easy English sentences describing your morning routine.',
      'wVi': 'Viết 2–4 câu tiếng Anh ngắn mô tả thói quen buổi sáng của bạn.',
    },
  ];

  static const List<Map<String, String>> _openPromptsBasic =
      <Map<String, String>>[
    <String, String>{
      's1': 'Introduce yourself in English: mention your name, city, and current study or work.',
      's1Vi': 'Giới thiệu bản thân bằng tiếng Anh: nói tên, thành phố và việc học/làm hiện tại.',
      's2': 'Describe what you usually do on weekends in 2–3 English sentences.',
      's2Vi': 'Mô tả việc bạn thường làm vào cuối tuần bằng 2–3 câu tiếng Anh.',
      'w': 'Write 3–5 English sentences about your English goals for the next 3 months.',
      'wVi': 'Viết 3–5 câu tiếng Anh về mục tiêu tiếng Anh của bạn trong 3 tháng tới.',
    },
    <String, String>{
      's1': 'Talk briefly about your hometown and what makes it special (2–3 sentences).',
      's1Vi': 'Nói ngắn gọn về quê hương của bạn và điểm đặc biệt ở đó (2–3 câu).',
      's2': 'Do you prefer studying English in the morning or evening? Explain briefly.',
      's2Vi': 'Bạn thích học tiếng Anh vào buổi sáng hay buổi tối hơn? Giải thích ngắn gọn.',
      'w': 'Write 3–5 English sentences about a memorable trip or hobby you enjoy.',
      'wVi': 'Viết 3–5 câu tiếng Anh về một chuyến đi đáng nhớ hoặc sở thích của bạn.',
    },
  ];

  static const List<Map<String, String>> _openPromptsAdvanced =
      <Map<String, String>>[
    <String, String>{
      's1': 'Introduce your background, city, and career or academic ambitions in 3–4 fluent sentences.',
      's1Vi': 'Giới thiệu bản thân, quê hương và định hướng học tập/nghề nghiệp của bạn bằng 3–4 câu trôi chảy.',
      's2': 'How has technology changed the way people learn foreign languages? Give 2 reasons.',
      's2Vi': 'Công nghệ đã thay đổi cách mọi người học ngoại ngữ như thế nào? Nêu 2 lý do.',
      'w': 'Write 4–6 sentences explaining why strong English communication helps career growth.',
      'wVi': 'Viết 4–6 câu giải thích vì sao giao tiếp tiếng Anh tốt giúp phát triển sự nghiệp.',
    },
    <String, String>{
      's1': 'Introduce yourself and share a skill or project you are proud of (3–4 sentences).',
      's1Vi': 'Giới thiệu bản thân và chia sẻ một kỹ năng hoặc dự án khiến bạn tự hào (3–4 câu).',
      's2': 'Compare working independently versus working in a team.',
      's2Vi': 'So sánh ưu điểm của việc làm việc độc lập so với làm việc nhóm.',
      'w': 'Write a short opinion paragraph (4–6 sentences) about balancing study/work with rest.',
      'wVi': 'Viết đoạn văn ngắn (4–6 câu) nêu quan điểm về việc cân bằng giữa học/làm và nghỉ ngơi.',
    },
  ];

  /// Default static list for backwards compatibility in tests.
  static List<PlacementQuestion> get placementQuestions => <PlacementQuestion>[
        _listeningA1Pool.first,
        _listeningA2Pool.first,
        _listeningB1Pool.first,
        _readingA1Pool.first,
        _readingA2Pool.first,
        _readingB1Pool.first,
        _grammarA1Pool.first,
        _grammarA2Pool.first,
        _grammarB1Pool.first,
        _speakingCommPool.first,
      ];

  /// Generates a brand-new randomized Placement Exam tailored to [selfAssessedLevel]
  /// (`Mất gốc`, `Có biết cơ bản`, `Đã giỏi`) and [age], picking non-repeating
  /// questions from a 48+ item pool.
  static PlacementExamSet generateUniquePlacementExam({
    int? seed,
    String selfAssessedLevel = GoogleUserProfile.levelBeginner,
    int age = 20,
  }) {
    final rng = seed != null
        ? Random(seed)
        : Random(DateTime.now().microsecondsSinceEpoch);

    List<PlacementQuestion> pickUnique(
      List<PlacementQuestion> pool,
      int count, {
      Set<String>? excludeIds,
    }) {
      final copy = pool
          .where((q) => excludeIds == null || !excludeIds.contains(q.id))
          .toList()
        ..shuffle(rng);
      final takeCount = count.clamp(0, copy.length);
      final chosen = copy.take(takeCount).toList();
      if (excludeIds != null) {
        for (final q in chosen) {
          excludeIds.add(q.id);
        }
      }
      return chosen;
    }

    final usedIds = <String>{};
    late List<PlacementQuestion> selectedQuestions;
    late String dictation;
    late Map<String, String> openSet;
    late String tailoredLabel;

    if (selfAssessedLevel == GoogleUserProfile.levelAdvanced) {
      tailoredLabel = 'Nâng cao ($selfAssessedLevel • $age tuổi)';
      selectedQuestions = <PlacementQuestion>[
        ...pickUnique(_listeningB1Pool, 2, excludeIds: usedIds),
        ...pickUnique(_listeningB2Pool, 1, excludeIds: usedIds),
        ...pickUnique(_readingB1Pool, 1, excludeIds: usedIds),
        ...pickUnique(_readingB2Pool, 2, excludeIds: usedIds),
        ...pickUnique(_grammarB1Pool, 1, excludeIds: usedIds),
        ...pickUnique(_grammarB2Pool, 2, excludeIds: usedIds),
        ...pickUnique(
          _speakingCommPool.where((q) => q.cefrDifficulty == 'B1' || q.cefrDifficulty == 'B2').toList(),
          1,
          excludeIds: usedIds,
        ),
      ];
      dictation =
          _dictationPoolAdvanced[rng.nextInt(_dictationPoolAdvanced.length)];
      openSet = _openPromptsAdvanced[rng.nextInt(_openPromptsAdvanced.length)];
    } else if (selfAssessedLevel == GoogleUserProfile.levelBasic) {
      tailoredLabel = 'Trung cấp nhẹ ($selfAssessedLevel • $age tuổi)';
      selectedQuestions = <PlacementQuestion>[
        ...pickUnique(_listeningA2Pool, 2, excludeIds: usedIds),
        ...pickUnique(_listeningB1Pool, 1, excludeIds: usedIds),
        ...pickUnique(_readingA2Pool, 2, excludeIds: usedIds),
        ...pickUnique(_readingB1Pool, 1, excludeIds: usedIds),
        ...pickUnique(_grammarA2Pool, 2, excludeIds: usedIds),
        ...pickUnique(_grammarB1Pool, 1, excludeIds: usedIds),
        ...pickUnique(_speakingCommPool, 1, excludeIds: usedIds),
      ];
      dictation = _dictationPoolIntermediate[
          rng.nextInt(_dictationPoolIntermediate.length)];
      openSet = _openPromptsBasic[rng.nextInt(_openPromptsBasic.length)];
    } else {
      tailoredLabel = 'Nền tảng cơ bản ($selfAssessedLevel • $age tuổi)';
      selectedQuestions = <PlacementQuestion>[
        ...pickUnique(_listeningA1Pool, 2, excludeIds: usedIds),
        ...pickUnique(_listeningA2Pool, 1, excludeIds: usedIds),
        ...pickUnique(_readingA1Pool, 2, excludeIds: usedIds),
        ...pickUnique(_readingA2Pool, 1, excludeIds: usedIds),
        ...pickUnique(_grammarA1Pool, 2, excludeIds: usedIds),
        ...pickUnique(_grammarA2Pool, 1, excludeIds: usedIds),
        ...pickUnique(
          _speakingCommPool.where((q) => q.cefrDifficulty == 'A1' || q.cefrDifficulty == 'A2').toList(),
          1,
          excludeIds: usedIds,
        ),
      ];
      dictation =
          _dictationPoolBeginner[rng.nextInt(_dictationPoolBeginner.length)];
      openSet = age <= 22
          ? _openPromptsYoungBeginner[
              rng.nextInt(_openPromptsYoungBeginner.length)]
          : _openPromptsBasic[rng.nextInt(_openPromptsBasic.length)];
    }

    // Also randomize option order? Keep exact options unless shuffled safely;
    // selecting distinct pools guarantees no duplicate questions!
    final code = 'DE-${1000 + rng.nextInt(9000)}';

    return PlacementExamSet(
      examCode: code,
      tailoredLevelLabel: tailoredLabel,
      questions: selectedQuestions,
      dictationAudio: dictation,
      speakingPrompt1: openSet['s1']!,
      speakingPrompt1Vi: openSet['s1Vi']!,
      speakingPrompt2: openSet['s2']!,
      speakingPrompt2Vi: openSet['s2Vi']!,
      writingPrompt: openSet['w']!,
      writingPromptVi: openSet['wVi']!,
    );
  }

  /// Evaluates a Placement Exam submission against the exact PlacementExamSet taken.
  static PlacementTestResult evaluatePlacementSubmission({
    required PlacementSubmissionPayload submission,
    required GoogleUserProfile user,
    PlacementExamSet? examSet,
  }) {
    final activeQuestions = examSet?.questions ?? placementQuestions;
    final activeDictation = examSet?.dictationAudio ?? placementDictationAudio;
    final mistakes = <PlacementMistakeReview>[];
    var totalCorrect = 0;

    int calcObjectivePercent(SkillType skill) {
      final qs = activeQuestions.where((q) => q.skill == skill).toList();
      if (qs.isEmpty) return 50;
      var earned = 0;
      var totalWeight = 0;
      for (final q in qs) {
        totalWeight += q.weight;
        final chosen = submission.selectedAnswers[q.id];
        if (chosen == q.correctIndex) {
          earned += q.weight;
          totalCorrect++;
        } else {
          final userTxt = (chosen != null &&
                  chosen >= 0 &&
                  chosen < q.options.length)
              ? q.options[chosen]
              : '(Chưa chọn)';
          mistakes.add(
            PlacementMistakeReview(
              questionId: q.id,
              skill: q.skill,
              cefrDifficulty: q.cefrDifficulty,
              topicTag: q.topicTag,
              questionSummary: q.prompt,
              userAnswerText: userTxt,
              correctAnswerText: q.options[q.correctIndex],
              explanationVi: q.explanationVi,
            ),
          );
        }
      }
      return totalWeight > 0 ? ((earned / totalWeight) * 100).round() : 50;
    }

    final lisMcqPercent = calcObjectivePercent(SkillType.listening);
    final readMcqPercent = calcObjectivePercent(SkillType.reading);
    final gramMcqPercent = calcObjectivePercent(SkillType.writing);
    final spkMcqPercent = calcObjectivePercent(SkillType.speaking);

    final dictAcc = _computeDictationPercent(
      submission.listeningDictationInput,
      activeDictation,
    );

    final spkProdScore = _evaluateOpenTextQuality(
      '${submission.speakingIntroAnswer} ${submission.speakingOpinionAnswer}',
      idealMinWords: 15,
    );

    final wrtProdScore = _evaluateOpenTextQuality(
      submission.writingEssayAnswer,
      idealMinWords: 20,
    );

    final lScore =
        ((lisMcqPercent * 0.75) + (dictAcc * 0.25)).round().clamp(20, 95);
    final rScore = (15 + readMcqPercent * 0.80).round().clamp(20, 95);
    final sScore =
        ((spkMcqPercent * 0.45) + (spkProdScore * 0.55)).round().clamp(20, 95);
    final wScore =
        ((gramMcqPercent * 0.50) + (wrtProdScore * 0.50)).round().clamp(20, 95);

    final avg = ((lScore + sScore + rScore + wScore) / 4).round();
    final bands = mapScoreToCefrIeltsToeic(avg);

    final gapTopics = mistakes.map((m) => m.topicTag).toSet().take(3).toList();
    if (dictAcc < 70) {
      gapTopics.add('Listening dictation accuracy ($dictAcc%)');
    }

    final strengths = <String>[];
    if (lScore >= 65) strengths.add('Nghe hiểu hội thoại cơ bản tốt ($lScore%)');
    if (rScore >= 65) strengths.add('Đọc hiểu đoạn ngắn nhanh ($rScore%)');
    if (sScore >= 65) strengths.add('Phản xạ nói tự tin ($sScore%)');
    if (wScore >= 65) strengths.add('Nắm chắc ngữ pháp cơ bản ($wScore%)');
    if (strengths.isEmpty) {
      strengths.add('Bắt đầu lại từ gốc A1 bài bản — tiến bộ rất nhanh!');
    }

    final dailySchedule = buildAdaptiveDailySchedule(
      totalMinutes: user.dailyTargetMinutes,
      lScore: lScore,
      sScore: sScore,
      rScore: rScore,
      wScore: wScore,
    );

    final roadmap = buildAdaptiveRoadmap(
      cefr: bands.cefr,
      dailyMinutes: user.dailyTargetMinutes,
      targetWeeks: user.targetWeeks,
      lScore: lScore,
      sScore: sScore,
      rScore: rScore,
      wScore: wScore,
    );

    final weakest = _findWeakestSkill(lScore, sScore, rScore, wScore);
    final levelNote = (bands.cefr == 'A1' || bands.cefr == 'A2')
        ? 'Lộ trình được tối ưu cho mức **${user.selfAssessedLevel} (${user.age} tuổi)**: bắt đầu từ **giao tiếp thiết yếu & ngữ âm rõ ràng**.'
        : 'Bạn đã có nền tảng tốt ở mức **${user.selfAssessedLevel}**! Lộ trình tập trung **bật phản xạ giao tiếp thực tế & nâng điểm**.';

    final summary =
        'Bạn đúng **$totalCorrect/${activeQuestions.length} câu** (Nghe chép: **$dictAcc%**), trình độ đánh giá: **${bands.cefr}** (IELTS ~${bands.ielts} | TOEIC ~${bands.toeic}).\n\n'
        '• $levelNote\n'
        '• Kỹ năng cần ưu tiên nhất: **${weakest.shortVi}** — lộ trình ${user.targetWeeks} tuần (${user.dailyTargetMinutes} phút/ngày) đã sẵn sàng cho ${user.displayName}.';

    return PlacementTestResult(
      completedAt: DateTime.now(),
      listeningScore: lScore,
      speakingScore: sScore,
      readingScore: rScore,
      writingScore: wScore,
      dictationAccuracyPercent: dictAcc,
      objectiveCorrectCount: totalCorrect,
      objectiveTotalCount: activeQuestions.length,
      cefrLevel: bands.cefr,
      estimatedIelts: bands.ielts,
      estimatedToeic: bands.toeic,
      aiDiagnosticSummary: summary,
      speakingFeedbackVi: submission.speakingIntroAnswer.trim().isEmpty &&
              submission.speakingOpinionAnswer.trim().isEmpty
          ? 'Bạn bỏ qua phần nói — hãy bắt đầu với câu chào hỏi cơ bản trong Bài tập Nói nhé.'
          : 'Rất tốt vì bạn đã tự trả lời! Câu nhận diện: "${submission.speakingIntroAnswer.trim()}".',
      writingFeedbackVi: submission.writingEssayAnswer.trim().isEmpty
          ? 'Bạn chưa viết câu nào — hãy thử bài viết 3 câu giới thiệu trong Bài tập Viết nhé.'
          : 'Bạn đã diễn đạt được ý chính. Vào Bài tập Viết để AI sửa chi tiết từng câu.',
      keyStrengths: strengths,
      criticalGaps: gapTopics.isEmpty
          ? const <String>['Luyện phản xạ nói hàng ngày & mở rộng từ vựng']
          : gapTopics,
      dailySchedule: dailySchedule,
      mistakes: mistakes,
      roadmapPhases: roadmap,
      generatedByAi: false,
    );
  }

  static ({String cefr, String ielts, int toeic}) mapScoreToCefrIeltsToeic(
      int avgScore) {
    if (avgScore >= 82) {
      return (cefr: 'B2', ielts: '6.0 - 6.5', toeic: 720);
    } else if (avgScore >= 65) {
      return (cefr: 'B1', ielts: '5.0 - 5.5', toeic: 560);
    } else if (avgScore >= 45) {
      return (cefr: 'A2', ielts: '4.0 - 4.5', toeic: 430);
    } else {
      return (cefr: 'A1', ielts: '3.0 - 3.5', toeic: 300);
    }
  }

  static int _computeDictationPercent(String input, String target) {
    final cleanedInput = input
        .toLowerCase()
        .replaceAll(RegExp(r'[^\w\s]'), '')
        .trim();
    if (cleanedInput.isEmpty) return 20;
    final userWords =
        cleanedInput.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    final targetWords = target
        .toLowerCase()
        .replaceAll(RegExp(r'[^\w\s]'), '')
        .split(RegExp(r'\s+'))
        .where((w) => w.isNotEmpty)
        .toList();
    if (targetWords.isEmpty) return 50;
    var hit = 0;
    for (final tw in targetWords) {
      if (userWords.contains(tw)) hit++;
    }
    return ((hit / targetWords.length) * 100).round().clamp(15, 100);
  }

  static int _evaluateOpenTextQuality(
    String rawText, {
    required int idealMinWords,
  }) {
    final trimmed = rawText.trim();
    if (trimmed.isEmpty) return 25;
    final words =
        trimmed.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    final wordCount = words.length;
    final lengthScore =
        ((wordCount / idealMinWords).clamp(0.0, 1.0) * 55).round();
    return (25 + lengthScore).clamp(25, 88);
  }

  static SkillType _findWeakestSkill(int l, int s, int r, int w) {
    final map = <SkillType, int>{
      SkillType.listening: l,
      SkillType.speaking: s,
      SkillType.reading: r,
      SkillType.writing: w,
    };
    return map.entries.reduce((a, b) => a.value <= b.value ? a : b).key;
  }

  static List<DailyScheduleSlot> buildAdaptiveDailySchedule({
    required int totalMinutes,
    required int lScore,
    required int sScore,
    required int rScore,
    required int wScore,
  }) {
    final ranked = <MapEntry<SkillType, int>>[
      MapEntry(SkillType.listening, lScore),
      MapEntry(SkillType.speaking, sScore),
      MapEntry(SkillType.reading, rScore),
      MapEntry(SkillType.writing, wScore),
    ]..sort((a, b) => a.value.compareTo(b.value));

    final m1 = (totalMinutes * 0.40).round().clamp(5, totalMinutes);
    final m2 = (totalMinutes * 0.25).round().clamp(3, totalMinutes);
    final m3 = (totalMinutes * 0.20).round().clamp(3, totalMinutes);
    final m4 = (totalMinutes - m1 - m2 - m3).clamp(2, totalMinutes);
    final allocations = <int>[m1, m2, m3, m4];

    String titleFor(SkillType skill, bool isTop) {
      final tag = isTop ? '⭐ Ưu tiên: ' : '';
      switch (skill) {
        case SkillType.listening:
          return '${tag}Nghe hội thoại ngắn';
        case SkillType.speaking:
          return '${tag}Nói & Gọi AI';
        case SkillType.reading:
          return '${tag}Đọc đoạn ngắn song ngữ';
        case SkillType.writing:
          return '${tag}Viết 3–5 câu để AI sửa';
      }
    }

    String detailFor(SkillType skill) {
      switch (skill) {
        case SkillType.listening:
          return 'Nghe tốc độ 0.75x rồi tăng lên 1.0x và làm câu hỏi.';
        case SkillType.speaking:
          return 'Đọc vượt 70% hoặc trò chuyện tiếng Anh cùng AI & bạn bè.';
        case SkillType.reading:
          return 'Đọc 1 bài ngắn Anh–Việt và lưu 3 từ mới.';
        case SkillType.writing:
          return 'Viết vài câu đơn giản để AI chỉ lỗi sửa ngay.';
      }
    }

    return List<DailyScheduleSlot>.generate(4, (i) {
      final skill = ranked[i].key;
      return DailyScheduleSlot(
        skill: skill,
        minutes: allocations[i],
        activityTitle: titleFor(skill, i == 0),
        detail: detailFor(skill),
      );
    });
  }

  static List<String> weekLabelsForTotal(int totalWeeks) {
    final safeTotal = totalWeeks < 4 ? 4 : totalWeeks;
    final perPhase = (safeTotal / 4).floor();
    final r1End = perPhase;
    final r2End = perPhase * 2;
    final r3End = perPhase * 3;
    String range(int a, int b) => a == b ? 'Tuần $a' : 'Tuần $a - $b';
    return <String>[
      range(1, r1End),
      range(r1End + 1, r2End),
      range(r2End + 1, r3End),
      range(r3End + 1, safeTotal),
    ];
  }

  static List<RoadmapPhase> buildAdaptiveRoadmap({
    required String cefr,
    required int dailyMinutes,
    int targetWeeks = 8,
    required int lScore,
    required int sScore,
    required int rScore,
    required int wScore,
  }) {
    final weakest = _findWeakestSkill(lScore, sScore, rScore, wScore);
    final labels = weekLabelsForTotal(targetWeeks);
    return <RoadmapPhase>[
      RoadmapPhase(
        weekRange: '${labels[0]} • Nền tảng ($cefr)',
        title: 'Lấy gốc Giao tiếp Cơ bản & Vá kỹ năng ${weakest.shortVi}',
        focusGoal:
            'Học $dailyMinutes phút/ngày: nắm từ vựng đời sống, câu đơn giản và nghe quen tai.',
        listeningTask: 'Nghe hội thoại chào hỏi, mua sắm tốc độ chậm 0.75x.',
        speakingTask: 'Đọc theo 3 câu giao tiếp mỗi ngày đạt trên 70%.',
        readingTask: 'Đọc đoạn ngắn song ngữ và lưu 5 từ mới mỗi ngày.',
        writingTask: 'Tập viết câu đơn đúng thì hiện tại & quá khứ.',
        milestone: 'Tự giới thiệu bản thân trôi chảy & hiểu câu cơ bản.',
      ),
      RoadmapPhase(
        weekRange: '${labels[1]} • Giao tiếp Hàng ngày (A2)',
        title: 'Phản xạ Hội thoại Đời sống & Kết bạn',
        focusGoal: 'Tự tin nghe nói ở quán cà phê, hỏi đường, trò chuyện bạn bè.',
        listeningTask: 'Nghe tốc độ chuẩn 1.0x không cần phụ đề lần đầu.',
        speakingTask: 'Gọi thoại AI & Trò chuyện bạn bè bằng tiếng Anh.',
        readingTask: 'Đọc bài ngắn về thói quen hàng ngày & du lịch.',
        writingTask: 'Viết tin nhắn, email ngắn để AI sửa lỗi trực tiếp.',
        milestone: 'Giao tiếp thoải mái các tình huống quen thuộc.',
      ),
      RoadmapPhase(
        weekRange: '${labels[2]} • Trung cấp (B1)',
        title: 'Giao tiếp Tự nhiên & Mở rộng Ý tưởng',
        focusGoal: 'Biết giải thích lý do, nêu quan điểm rõ ràng.',
        listeningTask: 'Nghe thông báo, hội thoại dài hơn và chép chính tả.',
        speakingTask: 'Gọi thoại AI về học tập và công việc.',
        readingTask: 'Đọc bài 2–3 đoạn ít phụ thuộc bản dịch.',
        writingTask: 'Viết đoạn 60–100 từ có câu nối mạch lạc.',
        milestone: 'Đạt mức giao tiếp tự tin B1.',
      ),
      RoadmapPhase(
        weekRange: '${labels[3]} • Bứt phá (B1+ / B2)',
        title: 'Phỏng vấn Thực tập & Chuẩn Đầu Ra',
        focusGoal: 'Hoàn thiện đều cả 4 kỹ năng Nghe – Nói – Đọc – Viết.',
        listeningTask: 'Nghe tốc độ 1.0x–1.25x và luyện câu hỏi hiểu ý.',
        speakingTask: 'Gọi thoại phỏng vấn xin việc / thực tập cùng AI.',
        readingTask: 'Đọc hiểu bài ngắn và tóm tắt ý chính.',
        writingTask: 'Viết email xin việc / đoạn văn để AI chấm điểm.',
        milestone: 'Tự tin giao tiếp thực tế & thi đạt chuẩn đầu ra.',
      ),
    ];
  }

  /// Diversified Daily Workout Quiz (English questions + Vietnamese toggle translation)
  static const List<DailyQuizQuestion> defaultDailyQuiz = <DailyQuizQuestion>[
    DailyQuizQuestion(
      question: 'Choose the correct verb:\n"They _____ students at this university."',
      questionVi: 'Chọn động từ đúng: "Họ là sinh viên tại trường đại học này."',
      options: <String>['am', 'is', 'are', 'be'],
      correctIndex: 2,
      explanationVi: 'Chủ ngữ số nhiều "They" luôn đi với "are".',
      skillTag: 'A1 • Grammar',
    ),
    DailyQuizQuestion(
      question: 'What do you say when you want to thank someone politely?',
      questionVi: 'Bạn sẽ nói câu gì khi muốn cảm ơn ai đó một cách lịch sự?',
      options: <String>[
        'Thank you so much!',
        'No, I am busy.',
        'Where is the bus?',
        'Good night!',
      ],
      correctIndex: 0,
      explanationVi: '"Thank you so much!" nghĩa là "Cảm ơn bạn rất nhiều!".',
      skillTag: 'A1 • Speaking',
    ),
    DailyQuizQuestion(
      question: 'Select the right verb form:\n"I _____ coffee every morning."',
      questionVi: 'Chọn dạng động từ đúng: "Tôi uống cà phê mỗi buổi sáng."',
      options: <String>['drink', 'drinks', 'drinking', 'drank'],
      correctIndex: 0,
      explanationVi: 'Thói quen hàng ngày ("every morning") với "I" dùng "drink".',
      skillTag: 'A2 • Present Tense',
    ),
    DailyQuizQuestion(
      question: 'Choose the correct preposition:\n"My English class starts _____ 8:00 AM."',
      questionVi: 'Chọn giới từ đúng: "Lớp tiếng Anh của tôi bắt đầu lúc 8:00 sáng."',
      options: <String>['in', 'on', 'at', 'to'],
      correctIndex: 2,
      explanationVi: 'Trước giờ giấc cụ thể (8:00 AM) luôn dùng giới từ "at".',
      skillTag: 'A2 • Preposition',
    ),
    DailyQuizQuestion(
      question: 'Choose the best connector:\n"I was tired, _____ I still finished my homework."',
      questionVi: 'Chọn từ nối phù hợp: "Tôi đã mệt, nhưng tôi vẫn làm xong bài tập về nhà."',
      options: <String>['but', 'because', 'or', 'if'],
      correctIndex: 0,
      explanationVi: '"but" (nhưng) nối hai vế đối lập: mệt nhưng vẫn làm xong bài.',
      skillTag: 'B1 • Connector',
    ),
  ];

  static const List<List<DailyQuizQuestion>> extraDailyQuizSets =
      <List<DailyQuizQuestion>>[
    <DailyQuizQuestion>[
      DailyQuizQuestion(
        question: 'Complete the greeting:\n"Nice to _____ you! Where are you from?"',
        questionVi: 'Hoàn thành câu chào: "Rất vui được gặp bạn! Bạn đến từ đâu?"',
        options: <String>['meet', 'see to', 'look', 'watch'],
        correctIndex: 0,
        explanationVi: 'Cụm chào chuẩn: "Nice to meet you!".',
        skillTag: 'A1 • Greeting',
      ),
      DailyQuizQuestion(
        question: 'Pick the correct past tense:\n"Yesterday, we _____ a great English movie."',
        questionVi: 'Chọn thì quá khứ đúng: "Hôm qua chúng tôi đã xem một bộ phim tiếng Anh rất hay."',
        options: <String>['watch', 'watched', 'watching', 'watches'],
        correctIndex: 1,
        explanationVi: '"Yesterday" chia động từ quá khứ "watched".',
        skillTag: 'A2 • Past Simple',
      ),
      DailyQuizQuestion(
        question: 'Choose the natural response to "How much is this tea?"',
        questionVi: 'Chọn câu trả lời tự nhiên cho câu hỏi "Cốc trà này bao nhiêu tiền?"',
        options: <String>[
          'It is two dollars.',
          'Yes, I drink milk.',
          'At 8:00 AM.',
          'Next to the library.',
        ],
        correctIndex: 0,
        explanationVi: '"It is two dollars." trả lời đúng về giá tiền.',
        skillTag: 'A2 • Shopping',
      ),
      DailyQuizQuestion(
        question: 'Choose the right word:\n"Could you speak a little _____, please?"',
        questionVi: 'Chọn từ đúng: "Bạn có thể nói chậm hơn một chút được không?"',
        options: <String>['slower', 'slowing', 'slowly of', 'slowest'],
        correctIndex: 0,
        explanationVi: 'Nhờ ai nói chậm hơn: "speak a little slower".',
        skillTag: 'A2 • Conversation',
      ),
      DailyQuizQuestion(
        question: 'Complete the conditional sentence:\n"If you practice daily, you _____ feel much more confident."',
        questionVi: 'Hoàn thành câu điều kiện: "Nếu bạn luyện tập mỗi ngày, bạn sẽ thấy tự tin hơn nhiều."',
        options: <String>['will', 'did', 'were', 'was'],
        correctIndex: 0,
        explanationVi: 'Câu điều kiện loại 1 dùng "will + V".',
        skillTag: 'B1 • Conditional',
      ),
    ],
  ];

  /// Listening lessons ordered from A1 -> A2 -> B1 with English questions + Vietnamese translations
  static const List<ListeningLesson> listeningLessons = <ListeningLesson>[
    ListeningLesson(
      id: 'lis_a1_1',
      title: 'Lesson 1 (A1): Greetings & Making Friends',
      category: 'Everyday Basics • A1',
      cefrLevel: 'A1',
      durationLabel: '1 min',
      audioTranscript:
          'Hi! Nice to meet you. My name is Linh. I am twenty years old and I am a student. I live in Hanoi. In my free time, I like listening to music and drinking milk tea with my friends.',
      vietnameseTranslation:
          'Chào bạn! Rất vui được gặp bạn. Tên mình là Linh. Mình 20 tuổi và là sinh viên. Mình sống ở Hà Nội. Lúc rảnh rỗi, mình thích nghe nhạc và uống trà sữa cùng bạn bè.',
      dictationSentence: 'Nice to meet you. My name is Linh.',
      keyVocab: <VocabFlashcard>[
        VocabFlashcard(
          word: 'nice to meet you',
          ipa: '/naɪs tuː miːt juː/',
          partOfSpeech: 'phrase',
          meaningVi: 'rất vui được gặp bạn',
          exampleEn: 'Hi Tom, nice to meet you!',
          topic: 'Giao tiếp A1',
        ),
        VocabFlashcard(
          word: 'free time',
          ipa: '/friː taɪm/',
          partOfSpeech: 'n.',
          meaningVi: 'thời gian rảnh rỗi',
          exampleEn: 'What do you do in your free time?',
          topic: 'Giao tiếp A1',
        ),
      ],
      questions: <ComprehensionMcq>[
        ComprehensionMcq(
          question: 'How old is Linh?',
          questionVi: 'Linh bao nhiêu tuổi?',
          options: <String>[
            '18 years old',
            '19 years old',
            '20 years old',
            '22 years old',
          ],
          correctIndex: 2,
          explanationVi: 'Linh nói: "I am twenty years old" (20 tuổi).',
        ),
        ComprehensionMcq(
          question: 'What does Linh enjoy doing in her free time?',
          questionVi: 'Lúc rảnh rỗi Linh thích làm gì?',
          options: <String>[
            'Listening to music and drinking milk tea with friends',
            'Swimming alone at the pool',
            'Cooking dinner at home',
            'Playing football',
          ],
          correctIndex: 0,
          explanationVi: '"listening to music and drinking milk tea with my friends."',
        ),
      ],
    ),
    ListeningLesson(
      id: 'lis_a2_2',
      title: 'Lesson 2 (A2): Ordering at a Coffee Shop',
      category: 'Daily Communication • A2',
      cefrLevel: 'A2',
      durationLabel: '1 min',
      audioTranscript:
          'Staff: Good morning! What can I get for you today? Customer: Hi, can I have a large iced latte with less sugar, please? Staff: Sure! Anything else? Customer: No, that is all. How much is it? Staff: It is four dollars. You can pay by card or cash.',
      vietnameseTranslation:
          'Nhân viên: Chào buổi sáng! Bạn muốn gọi gì hôm nay? Khách: Chào bạn, cho mình một ly latte đá cỡ lớn ít đường nhé? Nhân viên: Được ạ! Bạn gọi thêm gì không? Khách: Không, vậy thôi ạ. Bao nhiêu tiền thế? Nhân viên: 4 đô la ạ. Bạn có thể trả bằng thẻ hoặc tiền mặt.',
      dictationSentence: 'Can I have a large iced latte, please?',
      keyVocab: <VocabFlashcard>[
        VocabFlashcard(
          word: 'less sugar',
          ipa: '/les ˈʃʊɡər/',
          partOfSpeech: 'n. phr.',
          meaningVi: 'ít đường',
          exampleEn: 'I would like milk tea with less sugar.',
          topic: 'Giao tiếp A2',
        ),
        VocabFlashcard(
          word: 'pay by card',
          ipa: '/peɪ baɪ kɑːrd/',
          partOfSpeech: 'v. phr.',
          meaningVi: 'thanh toán bằng thẻ',
          exampleEn: 'Can I pay by card here?',
          topic: 'Giao tiếp A2',
        ),
      ],
      questions: <ComprehensionMcq>[
        ComprehensionMcq(
          question: 'What kind of drink does the customer order?',
          questionVi: 'Khách hàng gọi đồ uống như thế nào?',
          options: <String>[
            'Small hot latte with extra sugar',
            'Large iced latte with less sugar',
            'Black hot tea without ice',
            'Orange juice with cream',
          ],
          correctIndex: 1,
          explanationVi: 'Khách nói: "a large iced latte with less sugar".',
        ),
      ],
    ),
    ListeningLesson(
      id: 'lis_b1_3',
      title: 'Lesson 3 (B1): Part-Time Job Interview',
      category: 'Work & Study • B1',
      cefrLevel: 'B1',
      durationLabel: '2 min',
      audioTranscript:
          'Interviewer: Why do you want to work part-time at our bookstore? Student: First, I love reading books and helping customers. Second, I want to practice my English speaking skills and become more independent. I can work three evenings a week after my classes.',
      vietnameseTranslation:
          'Người phỏng vấn: Tại sao bạn muốn làm thêm tại hiệu sách của chúng tôi? Sinh viên: Thứ nhất, mình rất thích đọc sách và hỗ trợ khách hàng. Thứ hai, mình muốn luyện kỹ năng nói tiếng Anh và tự lập hơn. Mình có thể làm 3 buổi tối mỗi tuần sau giờ học.',
      dictationSentence: 'I want to practice my English speaking skills.',
      keyVocab: <VocabFlashcard>[
        VocabFlashcard(
          word: 'part-time',
          ipa: '/ˌpɑːrt ˈtaɪm/',
          partOfSpeech: 'adj./adv.',
          meaningVi: 'bán thời gian (làm thêm)',
          exampleEn: 'Many students have a part-time job.',
          topic: 'Sinh viên B1',
        ),
        VocabFlashcard(
          word: 'independent',
          ipa: '/ˌɪndɪˈpendənt/',
          partOfSpeech: 'adj.',
          meaningVi: 'tự lập, độc lập',
          exampleEn: 'Working helps me become more independent.',
          topic: 'Sinh viên B1',
        ),
      ],
      questions: <ComprehensionMcq>[
        ComprehensionMcq(
          question: 'How many evenings per week can the student work?',
          questionVi: 'Sinh viên có thể làm việc mấy buổi tối mỗi tuần?',
          options: <String>[
            'One evening',
            'Two evenings',
            'Three evenings',
            'Seven evenings',
          ],
          correctIndex: 2,
          explanationVi: '"I can work three evenings a week after my classes."',
        ),
      ],
    ),
  ];

  /// Speaking pronunciation drills
  static const List<SpeakingDrill> speakingDrills = <SpeakingDrill>[
    SpeakingDrill(
      id: 'spk_a1_1',
      category: 'A1 • Self Introduction',
      cefrLevel: 'A1',
      sentenceEn: 'Hi, my name is Vang and I am from Thai Nguyen.',
      ipa: '/haɪ maɪ neɪm ɪz væŋ ænd aɪ æm frʌm ˈtaɪ ˈŋwɪən/',
      meaningVi: 'Xin chào, tên mình là Vang và mình đến từ Thái Nguyên.',
      tipVi: 'Nói chậm rãi tên riêng và địa danh để máy bắt âm chính xác.',
    ),
    SpeakingDrill(
      id: 'spk_a1_2',
      category: 'A1 • Polite Request',
      cefrLevel: 'A1',
      sentenceEn: 'Excuse me, could you speak a little slower, please?',
      ipa: '/ɪkˈskjuːz miː kʊd juː spiːk ə ˈlɪtl ˈsləʊər pliːz/',
      meaningVi: 'Xin lỗi, bạn có thể nói chậm lại một chút được không?',
      tipVi: 'Câu cực hữu ích khi mới tập giao tiếp với người nước ngoài!',
    ),
    SpeakingDrill(
      id: 'spk_a2_3',
      category: 'A2 • Cafe Ordering',
      cefrLevel: 'A2',
      sentenceEn: 'Can I have an iced coffee with less sugar, please?',
      ipa: '/kæn aɪ hæv ən aɪst ˈkɒfi wɪð les ˈʃʊɡər pliːz/',
      meaningVi: 'Cho mình một ly cà phê đá ít đường nhé?',
      tipVi: 'Nhớ bật nhẹ âm /s/ ở cuối "less" và âm /z/ ở cuối "please".',
    ),
    SpeakingDrill(
      id: 'spk_b1_4',
      category: 'B1 • Teamwork & Confidence',
      cefrLevel: 'B1',
      sentenceEn: 'I am a fast learner and I enjoy working in a team.',
      ipa: '/aɪ æm ə fɑːst ˈlɜːrnər ænd aɪ ɪnˈdʒɔɪ ˈwɜːrkɪŋ ɪn ə tiːm/',
      meaningVi: 'Mình là người học hỏi nhanh và thích làm việc nhóm.',
      tipVi: 'Nhấn rõ vào 2 từ khóa chính: "FAST learner" và "WORKING in a TEAM".',
    ),
  ];

  /// AI 1-1 Roleplay Scenarios
  static const List<RoleplayScenario> roleplayScenarios = <RoleplayScenario>[
    RoleplayScenario(
      id: 'rp_a1_friend',
      title: 'A1 • Making Friends',
      subtitle: 'Hội thoại ngắn dễ hiểu + Hỗ trợ tên riêng & địa danh Việt Nam',
      cefrLevel: 'A1',
      aiRoleName: 'Emma (Study Buddy)',
      systemInstruction:
          'You are Emma, a warm, patient English friend chatting with a Vietnamese learner. Keep English sentences short and natural (1-2 sentences). Always understand and respect Vietnamese proper names (like Vang, Minh, Linh) and Vietnamese cities (like Thai Nguyen, Hanoi, Da Nang). After your English reply, add a short line "💡 Tip:" in Vietnamese when helpful.',
      openingLineEn:
          'Hi! I am Emma. Nice to meet you! What is your name and where are you from?\n\n🇻🇳 Dịch: Chào bạn! Mình là Emma. Rất vui được gặp bạn! Bạn tên gì và đến từ đâu?',
      openingLineVi: 'Chào bạn! Mình là Emma. Bạn tên gì và đến từ đâu?',
      suggestedReplies: <String>[
        'Hi Emma! My name is Vang. I am from Thai Nguyen.',
        'Hello! I am a student from Vietnam.',
      ],
    ),
    RoleplayScenario(
      id: 'rp_a2_coffee',
      title: 'A2 • At the Cafe',
      subtitle: 'Gọi đồ uống & thanh toán thực tế',
      cefrLevel: 'A2',
      aiRoleName: 'Alex (Barista)',
      systemInstruction:
          'You are Alex, a friendly cafe barista talking to a Vietnamese student at A2 level. Keep replies short (1-2 simple English sentences). Add 1 short Vietnamese tip line ("💡 Gợi ý:").',
      openingLineEn:
          'Welcome to Sunny Cafe! What would you like to drink today?\n\n🇻🇳 Dịch: Chào mừng đến Sunny Cafe! Hôm nay bạn muốn uống gì?',
      openingLineVi: 'Hôm nay bạn muốn uống gì?',
      suggestedReplies: <String>[
        'Can I have an iced coffee with milk, please?',
        'How much is a large iced latte?',
      ],
    ),
    RoleplayScenario(
      id: 'rp_b1_interview',
      title: 'B1 • Job Interview',
      subtitle: 'Tập trả lời phỏng vấn tự nhiên',
      cefrLevel: 'B1',
      aiRoleName: 'Ms. Clara (Interviewer)',
      systemInstruction:
          'You are Ms. Clara, a friendly interviewer talking to a student at B1 level. Ask practical interview questions (1-2 sentences). Respect Vietnamese proper nouns and hometown names cleanly.',
      openingLineEn:
          'Hello! Thanks for coming today. Can you tell me a little bit about yourself?',
      openingLineVi: 'Chào bạn! Bạn có thể giới thiệu ngắn gọn về bản thân không?',
      suggestedReplies: <String>[
        'Hi! My name is Vang and I am hardworking and eager to learn.',
      ],
    ),
  ];

  /// Reading Passages with English questions + Vietnamese translations
  static const List<ReadingPassage> readingPassages = <ReadingPassage>[
    ReadingPassage(
      id: 'read_a1_1',
      title: 'Lesson 1 (A1): My Daily Routine',
      majorTag: 'Everyday Life • A1',
      cefrLevel: 'A1',
      readingTimeLabel: '1 min read',
      paragraphsEn: <String>[
        'My name is Tuan. Every day, I wake up at 6:30 AM. I brush my teeth, wash my face, and eat bread for breakfast.',
        'In the morning, I go to school by motorbike. At noon, I have lunch with my friends at the canteen. In the evening, I practice English for 15 minutes before going to bed.',
      ],
      paragraphsVi: <String>[
        'Tên mình là Tuấn. Mỗi ngày, mình thức dậy lúc 6 giờ 30 sáng. Mình đánh răng, rửa mặt và ăn bánh mì cho bữa sáng.',
        'Buổi sáng, mình đi học bằng xe máy. Buổi trưa, mình ăn cơm cùng bạn bè ở căng tin. Buổi tối, mình luyện tiếng Anh 15 phút trước khi đi ngủ.',
      ],
      highlights: <VocabFlashcard>[
        VocabFlashcard(
          word: 'wake up',
          ipa: '/weɪk ʌp/',
          partOfSpeech: 'v.',
          meaningVi: 'thức dậy',
          exampleEn: 'I usually wake up at 7 AM.',
          topic: 'Cơ bản A1',
        ),
        VocabFlashcard(
          word: 'breakfast',
          ipa: '/ˈbrekfəst/',
          partOfSpeech: 'n.',
          meaningVi: 'bữa ăn sáng',
          exampleEn: 'I eat pho for breakfast.',
          topic: 'Cơ bản A1',
        ),
        VocabFlashcard(
          word: 'practice',
          ipa: '/ˈpræktɪs/',
          partOfSpeech: 'v.',
          meaningVi: 'luyện tập, thực hành',
          exampleEn: 'I practice speaking English every night.',
          topic: 'Cơ bản A1',
        ),
      ],
      questions: <ComprehensionMcq>[
        ComprehensionMcq(
          question: 'How does Tuan go to school in the morning?',
          questionVi: 'Buổi sáng Tuấn đi học bằng phương tiện gì?',
          options: <String>['By bus', 'By motorbike', 'By bicycle', 'On foot'],
          correctIndex: 1,
          explanationVi: 'Bài đọc ghi: "I go to school by motorbike".',
        ),
        ComprehensionMcq(
          question: 'How long does Tuan practice English in the evening?',
          questionVi: 'Buổi tối Tuấn luyện tiếng Anh trong bao lâu?',
          options: <String>['5 minutes', '15 minutes', '1 hour', 'Never'],
          correctIndex: 1,
          explanationVi: '"I practice English for 15 minutes before going to bed."',
        ),
      ],
    ),
    ReadingPassage(
      id: 'read_a2_2',
      title: 'Lesson 2 (A2): 3 Tips to Speak Confidently',
      majorTag: 'Study Tips • A2',
      cefrLevel: 'A2',
      readingTimeLabel: '2 min read',
      paragraphsEn: <String>[
        'Many students are afraid of making mistakes when speaking English. However, making mistakes is a normal part of learning any new language.',
        'To improve quickly, try speaking out loud for 5 minutes every day. You can talk about your day, describe things around your room, or chat with an AI tutor without feeling shy.',
      ],
      paragraphsVi: <String>[
        'Nhiều sinh viên sợ mắc lỗi khi nói tiếng Anh. Tuy nhiên, mắc lỗi là chuyện hoàn toàn bình thường khi học bất kỳ ngôn ngữ mới nào.',
        'Để tiến bộ nhanh, hãy thử nói thành tiếng 5 phút mỗi ngày. Bạn có thể kể về ngày hôm nay của mình, mô tả đồ vật quanh phòng hoặc trò chuyện với gia sư AI mà không cần ngại.',
      ],
      highlights: <VocabFlashcard>[
        VocabFlashcard(
          word: 'make mistakes',
          ipa: '/meɪk mɪˈsteɪks/',
          partOfSpeech: 'v. phr.',
          meaningVi: 'mắc lỗi sai',
          exampleEn: 'Don\'t be afraid to make mistakes!',
          topic: 'Giao tiếp A2',
        ),
        VocabFlashcard(
          word: 'confident',
          ipa: '/ˈkɒnfɪdənt/',
          partOfSpeech: 'adj.',
          meaningVi: 'tự tin',
          exampleEn: 'Practice helps you feel more confident.',
          topic: 'Giao tiếp A2',
        ),
      ],
      questions: <ComprehensionMcq>[
        ComprehensionMcq(
          question: 'How many minutes a day does the article suggest speaking out loud?',
          questionVi: 'Bài đọc khuyên nên nói thành tiếng ít nhất mấy phút mỗi ngày?',
          options: <String>[
            '5 minutes',
            '30 minutes',
            '2 hours',
            'Weekends only',
          ],
          correctIndex: 0,
          explanationVi: '"try speaking out loud for 5 minutes every day."',
        ),
      ],
    ),
    ReadingPassage(
      id: 'read_b1_3',
      title: 'Lesson 3 (B1): How English Opens New Opportunities',
      majorTag: 'Future Career • B1',
      cefrLevel: 'B1',
      readingTimeLabel: '2 min read',
      paragraphsEn: <String>[
        'Learning English is one of the best investments a university student can make. With good English skills, you can access free online courses from top universities around the world and read updated information easily.',
        'Moreover, companies today prefer candidates who can communicate comfortably with international clients. Starting with just 15 to 30 minutes a day will create a big difference after one year.',
      ],
      paragraphsVi: <String>[
        'Học tiếng Anh là một trong những khoản đầu tư tốt nhất của sinh viên đại học. Với kỹ năng tiếng Anh tốt, bạn có thể tiếp cận các khóa học trực tuyến miễn phí từ các trường hàng đầu thế giới và đọc thông tin mới dễ dàng.',
        'Hơn nữa, các công ty hiện nay ưu tiên ứng viên có thể giao tiếp thoải mái với khách hàng quốc tế. Chỉ cần bắt đầu 15 đến 30 phút mỗi ngày sẽ tạo ra sự khác biệt lớn sau một năm.',
      ],
      highlights: <VocabFlashcard>[
        VocabFlashcard(
          word: 'opportunity',
          ipa: '/ˌɒpərˈtjuːnəti/',
          partOfSpeech: 'n.',
          meaningVi: 'cơ hội',
          exampleEn: 'English gives you better job opportunities.',
          topic: 'Sinh viên B1',
        ),
        VocabFlashcard(
          word: 'communicate',
          ipa: '/kəˈmjuːnɪkeɪt/',
          partOfSpeech: 'v.',
          meaningVi: 'giao tiếp',
          exampleEn: 'I want to communicate clearly in English.',
          topic: 'Sinh viên B1',
        ),
      ],
      questions: <ComprehensionMcq>[
        ComprehensionMcq(
          question: 'What ability do modern companies value in job candidates?',
          questionVi: 'Theo bài đọc, các công ty hiện nay ưu tiên ứng viên có khả năng gì?',
          options: <String>[
            'Communicating comfortably with international clients',
            'Reading only printed paper books',
            'Avoiding the internet completely',
            'Memorizing a dictionary word by word',
          ],
          correctIndex: 0,
          explanationVi: '"companies today prefer candidates who can communicate comfortably with international clients."',
        ),
      ],
    ),
  ];

  /// Writing Prompts
  static const List<WritingPrompt> writingPrompts = <WritingPrompt>[
    WritingPrompt(
      id: 'wrt_a1_1',
      title: 'Task 1 (A1): Self Introduction (3–5 sentences)',
      category: 'Beginner Core • A1',
      cefrLevel: 'A1',
      minWords: 20,
      promptEn:
          'Write 3 to 5 simple sentences about yourself (your name, hometown, age, and hobbies).',
      guideVi: 'Viết 3–5 câu tiếng Anh ngắn về bản thân (tên, quê hương, tuổi, sở thích). Chạm mẫu câu bên dưới để ghép nhanh.',
      keyStructures: <String>[
        'Hi, my name is ... and I am from ...',
        'In my free time, I like ...',
        'I want to learn English because ...',
      ],
    ),
    WritingPrompt(
      id: 'wrt_a2_2',
      title: 'Task 2 (A2): My Typical Day',
      category: 'Daily Communication • A2',
      cefrLevel: 'A2',
      minWords: 35,
      promptEn:
          'Describe your typical day (morning, afternoon, and evening activities).',
      guideVi: 'Dùng thì hiện tại đơn kể 4–6 câu theo thứ tự Sáng → Chiều → Tối.',
      keyStructures: <String>[
        'Every morning, I wake up at ...',
        'In the afternoon, I usually ...',
        'Before going to bed, I ...',
      ],
    ),
    WritingPrompt(
      id: 'wrt_b1_3',
      title: 'Task 3 (B1): Polite Absence Email',
      category: 'Practical Email • B1',
      cefrLevel: 'B1',
      minWords: 45,
      promptEn:
          'Write a short polite email to your teacher to say you cannot attend tomorrow\'s class because you have a fever, and ask about the homework.',
      guideVi: 'Lời chào → Lý do nghỉ & hỏi bài tập → Cảm ơn.',
      keyStructures: <String>[
        'I am writing to let you know that I cannot attend class tomorrow.',
        'Could you please tell me if there is any homework?',
        'Thank you for your understanding.',
      ],
    ),
  ];

  /// Study buddies / Peer contacts for the "Trò chuyện bạn bè" tab
  static const List<FriendChatContact> friendContacts = <FriendChatContact>[
    FriendChatContact(
      id: 'friend_minh',
      name: 'Minh Nguyen',
      city: 'Thái Nguyên',
      levelBadge: 'B1 • Streak 14 ngày',
      xp: 1480,
      streakDays: 14,
      isOnline: true,
      bio: 'Luyện giao tiếp tiếng Anh CNTT & du lịch mỗi tối 20 phút.',
      personaPrompt:
          'You are Minh Nguyen, a friendly Vietnamese university student from Thai Nguyen practicing English on UniLingua AI. Reply naturally in short English sentences (1-2 sentences) to chat with a fellow Vietnamese learner about daily life, hobbies, Thai Nguyen, or studying English.',
      initialMessages: <FriendChatMessage>[
        FriendChatMessage(
          senderName: 'Minh Nguyen',
          isMe: false,
          textEn: 'Hey! Have you finished today\'s 5-question English workout yet?',
          textVi: 'Này bạn! Hôm nay bạn làm xong bài tập 5 câu tiếng Anh chưa?',
          timeLabel: '20:15',
        ),
        FriendChatMessage(
          senderName: 'Minh Nguyen',
          isMe: false,
          textEn: 'Let\'s practice introducing ourselves in English together!',
          textVi: 'Cùng luyện giới thiệu bản thân bằng tiếng Anh nhé!',
          timeLabel: '20:16',
        ),
      ],
    ),
    FriendChatContact(
      id: 'friend_lan',
      name: 'Lan Anh',
      city: 'Hà Nội',
      levelBadge: 'A2 • Streak 9 ngày',
      xp: 960,
      streakDays: 9,
      isOnline: true,
      bio: 'Học tiếng Anh từ mất gốc được 2 tháng • Thích nghe nhạc & cà phê.',
      personaPrompt:
          'You are Lan Anh from Hanoi, practicing English at A2 level on UniLingua AI. Speak in friendly, easy English sentences (1-2 sentences) and encourage your study buddy.',
      initialMessages: <FriendChatMessage>[
        FriendChatMessage(
          senderName: 'Lan Anh',
          isMe: false,
          textEn: 'Hi friend! How is your English speaking practice going today?',
          textVi: 'Chào bạn! Hôm nay việc luyện nói tiếng Anh của bạn thế nào rồi?',
          timeLabel: '19:40',
        ),
      ],
    ),
    FriendChatContact(
      id: 'friend_emma',
      name: 'Emma Wilson',
      city: 'Melbourne (AI Partner)',
      levelBadge: 'Native Tutor • 24/7',
      xp: 3250,
      streakDays: 45,
      isOnline: true,
      bio: 'Bạn đồng hành bản ngữ giúp sửa câu tự nhiên & chuẩn bị giao tiếp.',
      personaPrompt:
          'You are Emma Wilson, a kind native English study buddy chatting with a Vietnamese learner. Keep sentences clear and engaging (1-2 sentences), and gently appreciate their Vietnamese hometowns or names.',
      initialMessages: <FriendChatMessage>[
        FriendChatMessage(
          senderName: 'Emma Wilson',
          isMe: false,
          textEn: 'Hello! Tell me a little bit about your hometown or what you did today!',
          textVi: 'Xin chào! Hãy kể cho mình nghe một chút về quê hương bạn hoặc hôm nay bạn làm gì nhé!',
          timeLabel: 'Online',
        ),
      ],
    ),
  ];
}
