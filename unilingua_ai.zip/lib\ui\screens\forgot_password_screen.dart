import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../view_models/learning_view_model.dart';

/// 2-Step Forgot Password Screen:
/// - Step 1: Enter account Email & request a 6-digit OTP (`forgot_password`).
/// - Step 2: Enter the 6-digit OTP + new SHA-256 password (`reset_password`) and return to Login.
class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({
    super.key,
    required this.viewModel,
    this.initialEmail = '',
  });

  final LearningViewModel viewModel;
  final String initialEmail;

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  late final TextEditingController _emailCtrl;
  final TextEditingController _otpCtrl = TextEditingController();
  final TextEditingController _newPasswordCtrl = TextEditingController();
  final TextEditingController _confirmPasswordCtrl = TextEditingController();

  bool _otpSent = false;
  bool _obscurePassword = true;
  String? _statusMessage;
  bool _isError = false;
  String? _fallbackOtpHint;

  @override
  void initState() {
    super.initState();
    _emailCtrl = TextEditingController(text: widget.initialEmail);
  }

  @override
  void dispose() {
    _emailCtrl.dispose();
    _otpCtrl.dispose();
    _newPasswordCtrl.dispose();
    _confirmPasswordCtrl.dispose();
    super.dispose();
  }

  Future<void> _sendOtp() async {
    FocusScope.of(context).unfocus();
    setState(() {
      _statusMessage = null;
      _isError = false;
      _fallbackOtpHint = null;
    });

    final res = await widget.viewModel.requestPasswordResetOtp(
      email: _emailCtrl.text,
    );
    if (!mounted) return;
    setState(() {
      _statusMessage = res.message;
      _isError = !res.ok;
      _fallbackOtpHint = res.fallbackOtp;
      if (res.ok) {
        _otpSent = true;
      }
    });
  }

  Future<void> _confirmReset() async {
    FocusScope.of(context).unfocus();
    setState(() {
      _statusMessage = null;
      _isError = false;
    });

    final newPass = _newPasswordCtrl.text;
    final confirmPass = _confirmPasswordCtrl.text;
    if (newPass != confirmPass) {
      setState(() {
        _statusMessage = 'Mật khẩu xác nhận không khớp.';
        _isError = true;
      });
      return;
    }

    final res = await widget.viewModel.resetPasswordWithOtp(
      email: _emailCtrl.text,
      otp: _otpCtrl.text,
      newPassword: newPass,
    );
    if (!mounted) return;
    if (res.ok) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(res.message)),
      );
      Navigator.of(context).pop();
    } else {
      setState(() {
        _statusMessage = res.message;
        _isError = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.viewModel,
      builder: (context, _) {
        final p = AppPalette.of(context);
        final busy = widget.viewModel.isBusy;

        return Scaffold(
          appBar: AppBar(
            title: const Text(
              'Quên mật khẩu (OTP)',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18),
            ),
          ),
          body: SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  // Step indicator row
                  Row(
                    children: <Widget>[
                      _OtpStepChip(
                        number: '1',
                        label: 'Nhập Email',
                        isActive: !_otpSent,
                        isDone: _otpSent,
                      ),
                      const Expanded(child: Divider(indent: 8, endIndent: 8)),
                      _OtpStepChip(
                        number: '2',
                        label: 'OTP & Mật khẩu mới',
                        isActive: _otpSent,
                        isDone: false,
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: p.card,
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: p.border),
                    ),
                    child: !_otpSent
                        ? Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: <Widget>[
                              Text(
                                'Bước 1: Nhập Email tài khoản để nhận mã xác thực OTP gồm 6 chữ số (hiệu lực 10 phút).',
                                style: TextStyle(
                                  fontSize: 13.5,
                                  height: 1.45,
                                  color: p.textSecondary,
                                ),
                              ),
                              const SizedBox(height: 16),
                              TextField(
                                key: const Key('forgot_email_field'),
                                controller: _emailCtrl,
                                keyboardType: TextInputType.emailAddress,
                                autocorrect: false,
                                decoration: const InputDecoration(
                                  prefixIcon: Icon(Icons.email_outlined),
                                  hintText: 'Nhập Email hoặc tên tài khoản',
                                ),
                              ),
                              const SizedBox(height: 18),
                              SizedBox(
                                height: 52,
                                child: ElevatedButton.icon(
                                  key: const Key('forgot_send_otp_btn'),
                                  onPressed: busy ? null : _sendOtp,
                                  icon: busy
                                      ? const SizedBox(
                                          width: 18,
                                          height: 18,
                                          child: CircularProgressIndicator(
                                            strokeWidth: 2,
                                            color: Colors.white,
                                          ),
                                        )
                                      : const Icon(
                                          Icons.mark_email_read_outlined,
                                        ),
                                  label: const Text('Gửi mã OTP'),
                                ),
                              ),
                            ],
                          )
                        : Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: <Widget>[
                              Text(
                                'Bước 2: Nhập mã OTP 6 chữ số đã tạo cho ${_emailCtrl.text.trim()} và đặt mật khẩu mới.',
                                style: TextStyle(
                                  fontSize: 13.5,
                                  height: 1.45,
                                  color: p.textSecondary,
                                ),
                              ),
                              if (_fallbackOtpHint != null) ...<Widget>[
                                const SizedBox(height: 12),
                                Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: p.primary.withValues(alpha: 0.12),
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(color: p.primary),
                                  ),
                                  child: Text(
                                    '🔐 Mã OTP của bạn: $_fallbackOtpHint (hiệu lực 10 phút)',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontSize: 14.5,
                                      fontWeight: FontWeight.w900,
                                      color: p.primary,
                                    ),
                                  ),
                                ),
                              ],
                              const SizedBox(height: 14),
                              TextField(
                                key: const Key('forgot_otp_field'),
                                controller: _otpCtrl,
                                keyboardType: TextInputType.number,
                                maxLength: 6,
                                decoration: const InputDecoration(
                                  prefixIcon: Icon(Icons.pin_outlined),
                                  hintText: 'Nhập mã OTP 6 chữ số',
                                ),
                              ),
                              const SizedBox(height: 10),
                              TextField(
                                key: const Key('forgot_new_password_field'),
                                controller: _newPasswordCtrl,
                                obscureText: _obscurePassword,
                                decoration: InputDecoration(
                                  prefixIcon:
                                      const Icon(Icons.lock_outline_rounded),
                                  hintText: 'Mật khẩu mới (tối thiểu 6 ký tự)',
                                  suffixIcon: IconButton(
                                    onPressed: () => setState(
                                      () => _obscurePassword = !_obscurePassword,
                                    ),
                                    icon: Icon(
                                      _obscurePassword
                                          ? Icons.visibility_outlined
                                          : Icons.visibility_off_outlined,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 12),
                              TextField(
                                key: const Key('forgot_confirm_password_field'),
                                controller: _confirmPasswordCtrl,
                                obscureText: _obscurePassword,
                                decoration: const InputDecoration(
                                  prefixIcon: Icon(Icons.lock_reset_rounded),
                                  hintText: 'Xác nhận mật khẩu mới',
                                ),
                              ),
                              const SizedBox(height: 18),
                              SizedBox(
                                height: 52,
                                child: ElevatedButton(
                                  key: const Key('forgot_reset_submit_btn'),
                                  onPressed: busy ? null : _confirmReset,
                                  child: busy
                                      ? const SizedBox(
                                          width: 20,
                                          height: 20,
                                          child: CircularProgressIndicator(
                                            strokeWidth: 2.2,
                                            color: Colors.white,
                                          ),
                                        )
                                      : const Text(
                                          'Xác nhận & Đặt mật khẩu mới',
                                        ),
                                ),
                              ),
                              const SizedBox(height: 8),
                              TextButton(
                                onPressed: busy
                                    ? null
                                    : () => setState(() {
                                          _otpSent = false;
                                          _statusMessage = null;
                                          _fallbackOtpHint = null;
                                        }),
                                child: const Text('Đổi Email hoặc gửi lại OTP'),
                              ),
                            ],
                          ),
                  ),

                  if (_statusMessage != null) ...<Widget>[
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: (_isError ? p.danger : p.success)
                            .withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(12),
                        border:
                            Border.all(color: _isError ? p.danger : p.success),
                      ),
                      child: Text(
                        _statusMessage!,
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                          color: _isError ? p.danger : p.success,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _OtpStepChip extends StatelessWidget {
  const _OtpStepChip({
    required this.number,
    required this.label,
    required this.isActive,
    required this.isDone,
  });

  final String number;
  final String label;
  final bool isActive;
  final bool isDone;

  @override
  Widget build(BuildContext context) {
    final p = AppPalette.of(context);
    final bg = isDone ? p.success : (isActive ? p.primary : p.cardElevated);
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        CircleAvatar(
          radius: 13,
          backgroundColor: bg,
          child: isDone
              ? const Icon(Icons.check, size: 15, color: Colors.white)
              : Text(
                  number,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    color: (isActive || isDone) ? Colors.white : p.textSecondary,
                  ),
                ),
        ),
        const SizedBox(width: 6),
        Text(
          label,
          style: TextStyle(
            fontSize: 12.5,
            fontWeight: isActive ? FontWeight.w800 : FontWeight.w600,
            color: isActive ? p.primary : p.textSecondary,
          ),
        ),
      ],
    );
  }
}
