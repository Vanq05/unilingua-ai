/**
 * UniLingua AI — Central Google Drive + Sheets Auth, Social & High-Speed Messaging Server (Google Apps Script)
 *
 * 4 Google Sheets trong file `UniLingua_Users_Dashboard`:
 *   1. `Users`     : Email | Password (SHA-256) | FullName | Username | CreatedAt
 *   2. `OTP_Codes` : Email | OTP | ExpiresAt
 *   3. `Friends`   : UserA | UserB | Status (pending | accepted) | CreatedAt
 *   4. `Messages`  : Sender | Receiver | Content | Timestamp (epoch ms)
 *
 * Hỗ trợ actions trong doPost(e):
 *   - Auth & Profile : register, login, change_password, forgot_password, reset_password, update_profile
 *   - Friends        : search_user, send_friend_request, accept_friend_request, get_friends
 *   - High-speed Chat: send_message (CacheService), get_messages (CacheService + 100-row Reverse Delta Sync)
 *   - Progress Sync  : load, save (JSON trên Google Drive `UniLingua_Server_DB/users/`)
 */

const DB_FOLDER_NAME = 'UniLingua_Server_DB';
const USERS_FOLDER_NAME = 'users';
const DASHBOARD_SHEET_NAME = 'UniLingua_Users_Dashboard';

const USERS_SHEET_NAME = 'Users';
const OTP_SHEET_NAME = 'OTP_Codes';
const FRIENDS_SHEET_NAME = 'Friends';
const MESSAGES_SHEET_NAME = 'Messages';

const APP_SHARED_SECRET = 'UL_DB_2026_SECURE_KEY_9981';
const SECRET_SALT = 'UL_SHA256_SECRET_SALT_2026';
const OTP_EXPIRY_MINUTES = 10;
const MSG_CACHE_TTL_SECONDS = 21600; // 6 giờ

const USERS_HEADERS = ['Email', 'Password', 'FullName', 'Username', 'CreatedAt'];
const OTP_HEADERS = ['Email', 'OTP', 'ExpiresAt'];
const FRIENDS_HEADERS = ['UserA', 'UserB', 'Status', 'CreatedAt'];
const MESSAGES_HEADERS = ['Sender', 'Receiver', 'Content', 'Timestamp'];

// ==================== HELPERS ====================

function normalizeEmail_(email) {
  return String(email || '').trim().toLowerCase();
}

function isValidEmail_(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function stripVietnamese_(text) {
  return String(text || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D');
}

function normalizeUsername_(raw) {
  return stripVietnamese_(String(raw || ''))
    .trim()
    .toLowerCase()
    .replace(/^@+/, '')
    .replace(/[^a-z0-9._]/g, '');
}

function isValidUsername_(username) {
  return /^[a-z0-9._]{3,30}$/.test(username);
}

function parseTimestampMs_(raw) {
  if (typeof raw === 'number' && !isNaN(raw)) return raw;
  const num = Number(raw);
  if (!isNaN(num) && num > 1000000000) return num;
  if (raw instanceof Date) return raw.getTime();
  const parsed = new Date(String(raw || '')).getTime();
  return isNaN(parsed) ? 0 : parsed;
}

/**
 * Băm mật khẩu bằng SHA-256 + SECRET_SALT phía server (khớp 100% với sha256Hex trong Dart)
 */
function hashPassword_(rawPassword) {
  const input = String(rawPassword || '') + SECRET_SALT;
  const rawHash = Utilities.computeDigest(
    Utilities.DigestAlgorithm.SHA_256,
    input,
    Utilities.Charset.UTF_8
  );
  let hex = '';
  for (let i = 0; i < rawHash.length; i++) {
    let byteVal = rawHash[i];
    if (byteVal < 0) byteVal += 256;
    const hexPart = byteVal.toString(16);
    hex += hexPart.length === 1 ? '0' + hexPart : hexPart;
  }
  return hex;
}

function getOrCreateRootFolder_() {
  const it = DriveApp.getFoldersByName(DB_FOLDER_NAME);
  if (it.hasNext()) return it.next();
  return DriveApp.createFolder(DB_FOLDER_NAME);
}

function getOrCreateUsersFolder_(rootFolder) {
  const it = rootFolder.getFoldersByName(USERS_FOLDER_NAME);
  if (it.hasNext()) return it.next();
  return rootFolder.createFolder(USERS_FOLDER_NAME);
}

function getOrCreateDatabaseSpreadsheet_(rootFolder) {
  const files = rootFolder.getFilesByName(DASHBOARD_SHEET_NAME);
  if (files.hasNext()) {
    return SpreadsheetApp.open(files.next());
  }
  const ss = SpreadsheetApp.create(DASHBOARD_SHEET_NAME);
  const createdFile = DriveApp.getFileById(ss.getId());
  rootFolder.addFile(createdFile);
  try {
    DriveApp.getRootFolder().removeFile(createdFile);
  } catch (e) {}
  return ss;
}

function getOrCreateSheetWithHeaders_(ss, sheetName, headers) {
  let sheet = ss.getSheetByName(sheetName);
  if (!sheet) {
    sheet = ss.insertSheet(sheetName);
  }
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(headers);
    sheet.getRange(1, 1, 1, headers.length).setFontWeight('bold');
    sheet.setFrozenRows(1);
    return sheet;
  }

  // Tự động nâng cấp cột 4 từ bảng cũ ('Role' -> 'Username') nếu có
  const headerRange = sheet.getRange(1, 1, 1, headers.length);
  const currentHeaders = headerRange.getValues()[0];
  if (
    sheetName === USERS_SHEET_NAME &&
    String(currentHeaders[3] || '').trim() === 'Role'
  ) {
    const values = sheet.getDataRange().getValues();
    const usedHandles = {};
    for (let i = 1; i < values.length; i++) {
      const col3 = normalizeUsername_(values[i][3]);
      if (col3 && col3 !== 'user' && col3 !== 'admin') {
        usedHandles[col3] = true;
      }
    }
    for (let i = 1; i < values.length; i++) {
      const rowEmail = normalizeEmail_(values[i][0]);
      if (!rowEmail) continue;
      const curHandle = normalizeUsername_(values[i][3]);
      if (!curHandle || curHandle === 'user' || curHandle === 'admin') {
        let base = normalizeUsername_(rowEmail.split('@')[0]) || 'user';
        if (base.length < 3) base = base + '123';
        let candidate = base;
        let suffix = 1;
        while (usedHandles[candidate]) {
          candidate = base + suffix;
          suffix++;
        }
        usedHandles[candidate] = true;
        sheet.getRange(i + 1, 4).setNumberFormat('@').setValue(candidate);
      }
    }
  }

  let mismatch = false;
  for (let c = 0; c < headers.length; c++) {
    if (String(currentHeaders[c] || '').trim() !== headers[c]) {
      mismatch = true;
      break;
    }
  }
  if (mismatch) {
    headerRange.setValues([headers]).setFontWeight('bold');
    sheet.setFrozenRows(1);
  }
  return sheet;
}

function safeFileName_(email) {
  return (
    String(email || 'guest')
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9@._-]/g, '_') + '.json'
  );
}

function jsonOut_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(
    ContentService.MimeType.JSON
  );
}

function escapeHtml_(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function buildUniqueDerivedUsername_(usersSheet, email) {
  const values = usersSheet.getDataRange().getValues();
  const used = {};
  for (let i = 1; i < values.length; i++) {
    const u = normalizeUsername_(values[i][3]);
    if (u) used[u] = true;
  }
  let base = normalizeUsername_(String(email || '').split('@')[0]) || 'user';
  if (base.length < 3) base = base + '01';
  let candidate = base;
  let counter = 1;
  while (used[candidate]) {
    candidate = base + counter;
    counter++;
  }
  return candidate;
}

// ==================== ENTRYPOINTS ====================

function doGet(e) {
  return jsonOut_({
    ok: true,
    status: 'success',
    service: 'UniLingua Google Sheets Auth, Friends & High-Speed Chat Server',
    timestamp: new Date().toISOString(),
  });
}

function doPost(e) {
  let body = {};
  try {
    body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
  } catch (parseErr) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Payload JSON không hợp lệ.',
    });
  }

  const action = String(body.action || '').trim().toLowerCase();

  // 🚀 TỐI ƯU CACHESERVICE CHO get_messages:
  // Kiểm tra tín hiệu trong ScriptCache TRƯỚC khi xin Lock hoặc mở Google Sheet!
  if (action === 'get_messages') {
    const user1 = normalizeUsername_(body.user1 || body.current_user || body.username);
    const user2 = normalizeUsername_(body.user2 || body.friend_user || body.friend);
    const lastTs = Number(body.last_timestamp || 0);

    if (!user1 || !user2) {
      return jsonOut_({
        ok: false,
        status: 'error',
        message: 'Thiếu thông tin người gửi/nhận.',
        messages: [],
      });
    }

    const cache = CacheService.getScriptCache();
    const cachedSignal = cache.get('new_msg_for_' + user1);
    if (lastTs > 0 && cachedSignal !== null && Number(cachedSignal) <= lastTs) {
      return jsonOut_({
        ok: true,
        status: 'success',
        messages: [],
        from_cache: true,
      });
    }
  }

  const lock = LockService.getScriptLock();
  lock.waitLock(15000);

  try {
    const rootFolder = getOrCreateRootFolder_();
    const ss = getOrCreateDatabaseSpreadsheet_(rootFolder);

    // 1. AUTH & PROFILE
    if (
      action === 'register' ||
      action === 'login' ||
      action === 'change_password' ||
      action === 'forgot_password' ||
      action === 'reset_password' ||
      action === 'update_profile'
    ) {
      const usersSheet = getOrCreateSheetWithHeaders_(
        ss,
        USERS_SHEET_NAME,
        USERS_HEADERS
      );
      const otpSheet = getOrCreateSheetWithHeaders_(
        ss,
        OTP_SHEET_NAME,
        OTP_HEADERS
      );

      switch (action) {
        case 'register':
          return handleRegister_(usersSheet, body);
        case 'login':
          return handleLogin_(usersSheet, body);
        case 'change_password':
          return handleChangePassword_(usersSheet, body);
        case 'forgot_password':
          return handleForgotPassword_(usersSheet, otpSheet, body);
        case 'reset_password':
          return handleResetPassword_(
            usersSheet,
            otpSheet,
            getOrCreateUsersFolder_(rootFolder),
            body
          );
        case 'update_profile':
          return handleUpdateProfile_(ss, usersSheet, getOrCreateUsersFolder_(rootFolder), body);
      }
    }

    // 2. FRIENDS SYSTEM
    if (
      action === 'search_user' ||
      action === 'send_friend_request' ||
      action === 'accept_friend_request' ||
      action === 'get_friends'
    ) {
      const usersSheet = getOrCreateSheetWithHeaders_(
        ss,
        USERS_SHEET_NAME,
        USERS_HEADERS
      );
      const friendsSheet = getOrCreateSheetWithHeaders_(
        ss,
        FRIENDS_SHEET_NAME,
        FRIENDS_HEADERS
      );

      switch (action) {
        case 'search_user':
          return handleSearchUser_(usersSheet, friendsSheet, body);
        case 'send_friend_request':
          return handleSendFriendRequest_(usersSheet, friendsSheet, body);
        case 'accept_friend_request':
          return handleAcceptFriendRequest_(friendsSheet, body);
        case 'get_friends':
          return handleGetFriends_(usersSheet, friendsSheet, body);
      }
    }

    // 3. HIGH-SPEED MESSAGING (CacheService + 100-row Reverse Delta Sync)
    if (action === 'send_message' || action === 'get_messages') {
      const msgSheet = getOrCreateSheetWithHeaders_(
        ss,
        MESSAGES_SHEET_NAME,
        MESSAGES_HEADERS
      );
      if (action === 'send_message') {
        return handleSendMessage_(msgSheet, body);
      }
      return handleGetMessages_(msgSheet, body);
    }

    // 4. PROGRESS SYNC (Drive JSON Backup)
    if (body.secret !== APP_SHARED_SECRET) {
      return jsonOut_({ ok: false, status: 'error', error: 'Unauthorized' });
    }

    const email = normalizeEmail_(body.email);
    if (!email) {
      return jsonOut_({ ok: false, status: 'error', error: 'Missing email' });
    }

    const usersFolder = getOrCreateUsersFolder_(rootFolder);
    const fileName = safeFileName_(email);

    if (action === 'load') {
      const files = usersFolder.getFilesByName(fileName);
      if (!files.hasNext()) {
        return jsonOut_({ ok: true, found: false, data: null });
      }
      const content = files.next().getBlob().getDataAsString('UTF-8');
      return jsonOut_({
        ok: true,
        found: true,
        data: JSON.parse(content),
      });
    }

    if (action === 'save') {
      const stateObj = body.data;
      if (!stateObj) {
        return jsonOut_({ ok: false, error: 'Missing data payload' });
      }
      const serialized = JSON.stringify(stateObj);
      const files = usersFolder.getFilesByName(fileName);
      if (files.hasNext()) {
        files.next().setContent(serialized);
      } else {
        usersFolder.createFile(fileName, serialized, MimeType.PLAIN_TEXT);
      }
      syncStateToUsersSheet_(ss, stateObj);
      return jsonOut_({ ok: true, saved: true });
    }

    return jsonOut_({ ok: false, status: 'error', error: 'Unknown action' });
  } catch (err) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: String(err),
      error: String(err),
    });
  } finally {
    lock.releaseLock();
  }
}

// ==================== 1. AUTH & PROFILE HANDLERS ====================

function handleRegister_(usersSheet, body) {
  const email = normalizeEmail_(body.email);
  const password = String(body.password || '');
  const fullName = String(body.fullname || body.fullName || '').trim();
  let username = normalizeUsername_(body.username || '');

  if (!isValidEmail_(email)) {
    return jsonOut_({ ok: false, status: 'error', message: 'Email không hợp lệ.' });
  }
  if (password.length < 6) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Mật khẩu phải có ít nhất 6 ký tự.',
    });
  }
  if (!fullName) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Vui lòng nhập họ và tên.',
    });
  }

  if (!username) {
    username = buildUniqueDerivedUsername_(usersSheet, email);
  } else if (!isValidUsername_(username)) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Username phải từ 3–30 ký tự không dấu (chỉ gồm a-z, 0-9, dấu chấm hoặc gạch dưới).',
    });
  }

  const values = usersSheet.getDataRange().getValues();
  for (let i = 1; i < values.length; i++) {
    if (normalizeEmail_(values[i][0]) === email) {
      return jsonOut_({
        ok: false,
        status: 'error',
        message: 'Email này đã được đăng ký.',
      });
    }
    if (normalizeUsername_(values[i][3]) === username) {
      return jsonOut_({
        ok: false,
        status: 'error',
        message: 'Username @' + username + ' đã có người sử dụng. Hãy chọn tên khác!',
      });
    }
  }

  const passwordHash = hashPassword_(password);
  const createdAt = new Date().toISOString();

  usersSheet.appendRow([email, passwordHash, fullName, username, createdAt]);
  const lastRow = usersSheet.getLastRow();
  usersSheet.getRange(lastRow, 1, 1, USERS_HEADERS.length).setNumberFormat('@');

  return jsonOut_({
    ok: true,
    status: 'success',
    message: 'Đăng ký thành công!',
    user: {
      email: email,
      fullname: fullName,
      username: username,
      createdAt: createdAt,
    },
  });
}

function handleLogin_(usersSheet, body) {
  const rawIdentifier = String(
    body.identifier || body.email || body.username || ''
  ).trim().toLowerCase();
  const cleanHandle = normalizeUsername_(rawIdentifier);
  const password = String(body.password || '');

  if (!rawIdentifier || !password) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Vui lòng nhập Email/@username và mật khẩu.',
    });
  }

  const passHash = hashPassword_(password);
  const values = usersSheet.getDataRange().getValues();

  for (let i = 1; i < values.length; i++) {
    const rowEmail = normalizeEmail_(values[i][0]);
    const rowUsername = normalizeUsername_(values[i][3]);
    const matchesEmail = rowEmail === rawIdentifier;
    const matchesUsername = cleanHandle && rowUsername === cleanHandle;

    if (matchesEmail || matchesUsername) {
      if (String(values[i][1] || '').trim() === passHash) {
        return jsonOut_({
          ok: true,
          status: 'success',
          message: 'Đăng nhập thành công!',
          user: {
            email: rowEmail,
            fullname: String(values[i][2] || ''),
            username: rowUsername,
            createdAt: String(values[i][4] || ''),
          },
        });
      }
      return jsonOut_({
        ok: false,
        status: 'error',
        message: 'Mật khẩu không chính xác.',
      });
    }
  }

  return jsonOut_({
    ok: false,
    status: 'error',
    message: 'Tài khoản hoặc mật khẩu không chính xác.',
  });
}

function handleChangePassword_(usersSheet, body) {
  const email = normalizeEmail_(body.email);
  const usernameInput = normalizeUsername_(body.username || '');
  const oldPassword = String(body.old_password || '');
  const newPassword = String(body.new_password || '');

  if ((!isValidEmail_(email) && !usernameInput) || !oldPassword || newPassword.length < 6) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Mật khẩu mới cần tối thiểu 6 ký tự.',
    });
  }

  const oldHash = hashPassword_(oldPassword);
  const newHash = hashPassword_(newPassword);
  const values = usersSheet.getDataRange().getValues();

  for (let i = 1; i < values.length; i++) {
    const rowEmail = normalizeEmail_(values[i][0]);
    const rowHandle = normalizeUsername_(values[i][3]);
    if ((email && rowEmail === email) || (usernameInput && rowHandle === usernameInput)) {
      if (String(values[i][1] || '').trim() !== oldHash) {
        return jsonOut_({
          ok: false,
          status: 'error',
          message: 'Mật khẩu hiện tại không đúng.',
        });
      }
      usersSheet.getRange(i + 1, 2).setNumberFormat('@').setValue(newHash);
      return jsonOut_({
        ok: true,
        status: 'success',
        message: 'Đổi mật khẩu thành công.',
      });
    }
  }

  return jsonOut_({
    ok: false,
    status: 'error',
    message: 'Không tìm thấy tài khoản.',
  });
}

function handleForgotPassword_(usersSheet, otpSheet, body) {
  const email = normalizeEmail_(body.email);
  if (!isValidEmail_(email)) {
    return jsonOut_({ ok: false, status: 'error', message: 'Email không hợp lệ.' });
  }

  const userValues = usersSheet.getDataRange().getValues();
  let foundName = 'bạn';
  let exists = false;
  for (let i = 1; i < userValues.length; i++) {
    if (normalizeEmail_(userValues[i][0]) === email) {
      exists = true;
      foundName = String(userValues[i][2] || 'bạn');
      break;
    }
  }

  if (!exists) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Email này chưa được đăng ký trong hệ thống.',
    });
  }

  const otpValues = otpSheet.getDataRange().getValues();
  for (let i = otpValues.length - 1; i >= 1; i--) {
    if (normalizeEmail_(otpValues[i][0]) === email) {
      otpSheet.deleteRow(i + 1);
    }
  }

  const otp = String(Math.floor(100000 + Math.random() * 900000));
  const expiresAt = new Date(
    Date.now() + OTP_EXPIRY_MINUTES * 60 * 1000
  ).toISOString();

  otpSheet.appendRow([email, otp, expiresAt]);
  const insertedRow = otpSheet.getLastRow();
  otpSheet.getRange(insertedRow, 1, 1, 3).setNumberFormat('@');

  MailApp.sendEmail({
    to: email,
    subject: '[UniLingua AI] Mã OTP đặt lại mật khẩu',
    htmlBody:
      '<div style="font-family:Arial,sans-serif;max-width:480px;margin:auto;padding:24px;border:1px solid #bae6fd;border-radius:14px;">' +
      '<h2 style="color:#0284c7;margin-top:0;">Xin chào ' +
      escapeHtml_(foundName) +
      ',</h2>' +
      '<p>Mã OTP khôi phục mật khẩu UniLingua AI của bạn (có hiệu lực <b>10 phút</b>):</p>' +
      '<div style="background:#eff8ff;border:1px dashed #0284c7;border-radius:10px;padding:16px;text-align:center;margin:18px 0;">' +
      '<span style="font-size:28px;font-weight:bold;letter-spacing:6px;color:#0284c7;">' +
      otp +
      '</span></div>' +
      '<p style="color:#64748b;font-size:12px;">Nếu bạn không thực hiện yêu cầu này, hãy bỏ qua email này.</p></div>',
  });

  return jsonOut_({
    ok: true,
    status: 'success',
    message: 'Mã OTP 6 số đã được gửi tới email ' + email + '.',
  });
}

function handleResetPassword_(usersSheet, otpSheet, usersFolder, body) {
  const email = normalizeEmail_(body.email);
  const otpInput = String(body.otp || '').trim();
  const newPassword = String(body.new_password || '');

  if (!isValidEmail_(email)) {
    return jsonOut_({ ok: false, status: 'error', message: 'Email không hợp lệ.' });
  }
  if (!/^\d{6}$/.test(otpInput)) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Mã OTP phải gồm 6 chữ số.',
    });
  }
  if (newPassword.length < 6) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Mật khẩu mới phải có ít nhất 6 ký tự.',
    });
  }

  const otpValues = otpSheet.getDataRange().getValues();
  let matchedRowIndex = -1;
  let expiresAtRaw = '';

  for (let i = otpValues.length - 1; i >= 1; i--) {
    const rowEmail = normalizeEmail_(otpValues[i][0]);
    const rowOtp = String(otpValues[i][1] || '').trim();
    if (rowEmail === email && rowOtp === otpInput) {
      matchedRowIndex = i + 1;
      expiresAtRaw = String(otpValues[i][2] || '').trim();
      break;
    }
  }

  if (matchedRowIndex === -1) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Mã OTP không chính xác.',
    });
  }

  const expiresMs = new Date(expiresAtRaw).getTime();
  if (isNaN(expiresMs) || expiresMs <= Date.now()) {
    otpSheet.deleteRow(matchedRowIndex);
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Mã OTP đã hết hạn (quá 10 phút).',
    });
  }

  const newHash = hashPassword_(newPassword);
  const userValues = usersSheet.getDataRange().getValues();
  for (let i = 1; i < userValues.length; i++) {
    if (normalizeEmail_(userValues[i][0]) === email) {
      usersSheet.getRange(i + 1, 2).setNumberFormat('@').setValue(newHash);
      break;
    }
  }

  otpSheet.deleteRow(matchedRowIndex);

  if (usersFolder) {
    try {
      const files = usersFolder.getFilesByName(safeFileName_(email));
      if (files.hasNext()) {
        const file = files.next();
        const content = file.getBlob().getDataAsString('UTF-8');
        const stateObj = JSON.parse(content);
        if (stateObj && typeof stateObj === 'object' && stateObj.user) {
          stateObj.user.passwordHash = newHash;
          stateObj.user.pendingOtpCode = '';
          stateObj.user.pendingOtpExpiresAt = '';
          file.setContent(JSON.stringify(stateObj));
        }
      }
    } catch (e) {}
  }

  return jsonOut_({
    ok: true,
    status: 'success',
    message: 'Đặt lại mật khẩu thành công!',
  });
}

function handleUpdateProfile_(ss, usersSheet, usersFolder, body) {
  const email = normalizeEmail_(body.email);
  const newFullName = String(body.fullname || body.fullName || '').trim();
  const newUsername = normalizeUsername_(body.username || '');

  if (!isValidEmail_(email)) {
    return jsonOut_({ ok: false, status: 'error', message: 'Email không hợp lệ.' });
  }
  if (!newFullName) {
    return jsonOut_({ ok: false, status: 'error', message: 'Tên hiển thị không được để trống.' });
  }
  if (!isValidUsername_(newUsername)) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Username phải gồm 3–30 ký tự không dấu (a-z, 0-9, ., _).',
    });
  }

  const values = usersSheet.getDataRange().getValues();
  let targetRow = -1;
  let oldUsername = '';
  let createdAt = '';

  for (let i = 1; i < values.length; i++) {
    const rowEmail = normalizeEmail_(values[i][0]);
    const rowUsername = normalizeUsername_(values[i][3]);
    if (rowEmail === email) {
      targetRow = i + 1;
      oldUsername = rowUsername;
      createdAt = String(values[i][4] || '');
    } else if (rowUsername === newUsername) {
      return jsonOut_({
        ok: false,
        status: 'error',
        message: 'Username @' + newUsername + ' đã thuộc về người khác.',
      });
    }
  }

  if (targetRow === -1) {
    return jsonOut_({ ok: false, status: 'error', message: 'Không tìm thấy tài khoản.' });
  }

  usersSheet
    .getRange(targetRow, 3, 1, 2)
    .setNumberFormat('@')
    .setValues([[newFullName, newUsername]]);

  // Nếu đổi Username, cập nhật luôn lịch sử Friends & Messages để giữ toàn vẹn kết bạn/tin nhắn
  if (oldUsername && oldUsername !== newUsername) {
    const friendsSheet = getOrCreateSheetWithHeaders_(ss, FRIENDS_SHEET_NAME, FRIENDS_HEADERS);
    const fValues = friendsSheet.getDataRange().getValues();
    for (let i = 1; i < fValues.length; i++) {
      let dirty = false;
      const a = normalizeUsername_(fValues[i][0]);
      const b = normalizeUsername_(fValues[i][1]);
      if (a === oldUsername) {
        fValues[i][0] = newUsername;
        dirty = true;
      }
      if (b === oldUsername) {
        fValues[i][1] = newUsername;
        dirty = true;
      }
      if (dirty) {
        friendsSheet.getRange(i + 1, 1, 1, 2).setNumberFormat('@').setValues([[fValues[i][0], fValues[i][1]]]);
      }
    }

    const msgSheet = getOrCreateSheetWithHeaders_(ss, MESSAGES_SHEET_NAME, MESSAGES_HEADERS);
    const mLast = msgSheet.getLastRow();
    if (mLast > 1) {
      const mRange = msgSheet.getRange(2, 1, mLast - 1, 2);
      const mVals = mRange.getValues();
      let msgChanged = false;
      for (let i = 0; i < mVals.length; i++) {
        if (normalizeUsername_(mVals[i][0]) === oldUsername) {
          mVals[i][0] = newUsername;
          msgChanged = true;
        }
        if (normalizeUsername_(mVals[i][1]) === oldUsername) {
          mVals[i][1] = newUsername;
          msgChanged = true;
        }
      }
      if (msgChanged) {
        mRange.setNumberFormat('@').setValues(mVals);
      }
    }
  }

  if (usersFolder) {
    try {
      const files = usersFolder.getFilesByName(safeFileName_(email));
      if (files.hasNext()) {
        const file = files.next();
        const content = file.getBlob().getDataAsString('UTF-8');
        const stateObj = JSON.parse(content);
        if (stateObj && typeof stateObj === 'object' && stateObj.user) {
          stateObj.user.displayName = newFullName;
          stateObj.user.username = newUsername;
          file.setContent(JSON.stringify(stateObj));
        }
      }
    } catch (e) {}
  }

  return jsonOut_({
    ok: true,
    status: 'success',
    message: 'Cập nhật hồ sơ thành công!',
    user: {
      email: email,
      fullname: newFullName,
      username: newUsername,
      createdAt: createdAt,
    },
  });
}

// ==================== 2. FRIENDS HANDLERS ====================

function buildFriendshipMap_(friendsSheet, me) {
  const fValues = friendsSheet.getDataRange().getValues();
  const statusByPeer = {};
  for (let i = 1; i < fValues.length; i++) {
    const a = normalizeUsername_(fValues[i][0]);
    const b = normalizeUsername_(fValues[i][1]);
    const status = String(fValues[i][2] || '').trim().toLowerCase();
    if (!a || !b || !status) continue;
    if (a === me) {
      statusByPeer[b] = status === 'accepted' ? 'accepted' : 'pending_sent';
    } else if (b === me) {
      statusByPeer[a] = status === 'accepted' ? 'accepted' : 'pending_received';
    }
  }
  return statusByPeer;
}

function handleSearchUser_(usersSheet, friendsSheet, body) {
  const rawQuery = stripVietnamese_(String(body.query || '')).trim().toLowerCase().replace(/^@+/, '');
  const currentUser = normalizeUsername_(body.current_user || body.username || '');

  if (!rawQuery) {
    return jsonOut_({ ok: true, status: 'success', users: [] });
  }

  const statusByPeer = currentUser ? buildFriendshipMap_(friendsSheet, currentUser) : {};
  const uValues = usersSheet.getDataRange().getValues();
  const matches = [];

  for (let i = 1; i < uValues.length; i++) {
    const rowEmail = normalizeEmail_(uValues[i][0]);
    const rowName = String(uValues[i][2] || '').trim();
    const rowHandle = normalizeUsername_(uValues[i][3]);
    if (!rowHandle || rowHandle === currentUser) continue;

    const cleanName = stripVietnamese_(rowName).toLowerCase();
    if (rowHandle.indexOf(rawQuery) !== -1 || cleanName.indexOf(rawQuery) !== -1) {
      matches.push({
        email: rowEmail,
        fullname: rowName,
        username: rowHandle,
        friendshipStatus: statusByPeer[rowHandle] || 'none',
      });
    }
    if (matches.length >= 25) break;
  }

  return jsonOut_({
    ok: true,
    status: 'success',
    users: matches,
  });
}

function handleSendFriendRequest_(usersSheet, friendsSheet, body) {
  const fromUser = normalizeUsername_(body.from_user || body.sender || '');
  const toUser = normalizeUsername_(body.to_user || body.receiver || '');

  if (!fromUser || !toUser || fromUser === toUser) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Thông tin kết bạn không hợp lệ.',
    });
  }

  // Kiểm tra tồn tại cả 2 username
  const uValues = usersSheet.getDataRange().getValues();
  let foundFrom = false;
  let foundTo = false;
  for (let i = 1; i < uValues.length; i++) {
    const h = normalizeUsername_(uValues[i][3]);
    if (h === fromUser) foundFrom = true;
    if (h === toUser) foundTo = true;
  }
  if (!foundFrom || !foundTo) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Không tìm thấy người dùng @' + toUser + '.',
    });
  }

  const fValues = friendsSheet.getDataRange().getValues();
  for (let i = 1; i < fValues.length; i++) {
    const a = normalizeUsername_(fValues[i][0]);
    const b = normalizeUsername_(fValues[i][1]);
    const status = String(fValues[i][2] || '').trim().toLowerCase();

    if ((a === fromUser && b === toUser) || (a === toUser && b === fromUser)) {
      if (status === 'accepted') {
        return jsonOut_({ ok: true, status: 'success', message: 'Hai bạn đã là bạn bè.' });
      }
      if (a === fromUser && b === toUser) {
        return jsonOut_({
          ok: true,
          status: 'success',
          message: 'Đã gửi lời mời kết bạn cho @' + toUser + '.',
        });
      }
      // Nếu người kia đã gửi lời mời trước đó -> tự động chấp nhận
      friendsSheet.getRange(i + 1, 3).setNumberFormat('@').setValue('accepted');
      return jsonOut_({
        ok: true,
        status: 'success',
        message: 'Hai bạn đã trở thành bạn bè!',
      });
    }
  }

  friendsSheet.appendRow([fromUser, toUser, 'pending', new Date().toISOString()]);
  friendsSheet
    .getRange(friendsSheet.getLastRow(), 1, 1, FRIENDS_HEADERS.length)
    .setNumberFormat('@');

  return jsonOut_({
    ok: true,
    status: 'success',
    message: 'Đã gửi lời mời kết bạn tới @' + toUser + '!',
  });
}

function handleAcceptFriendRequest_(friendsSheet, body) {
  const fromUser = normalizeUsername_(body.from_user || '');
  const toUser = normalizeUsername_(body.to_user || body.current_user || '');

  if (!fromUser || !toUser) {
    return jsonOut_({ ok: false, status: 'error', message: 'Thiếu username xác nhận.' });
  }

  const fValues = friendsSheet.getDataRange().getValues();
  for (let i = 1; i < fValues.length; i++) {
    const a = normalizeUsername_(fValues[i][0]);
    const b = normalizeUsername_(fValues[i][1]);
    if ((a === fromUser && b === toUser) || (a === toUser && b === fromUser)) {
      friendsSheet.getRange(i + 1, 3).setNumberFormat('@').setValue('accepted');
      return jsonOut_({
        ok: true,
        status: 'success',
        message: 'Đã chấp nhận kết bạn với @' + fromUser + '!',
      });
    }
  }

  return jsonOut_({
    ok: false,
    status: 'error',
    message: 'Không tìm thấy lời mời kết bạn.',
  });
}

function handleGetFriends_(usersSheet, friendsSheet, body) {
  const me = normalizeUsername_(body.username || body.current_user || '');
  if (!me) {
    return jsonOut_({
      ok: false,
      status: 'error',
      friends: [],
      pending_received: [],
      pending_sent: [],
    });
  }

  const uValues = usersSheet.getDataRange().getValues();
  const userLookup = {};
  for (let i = 1; i < uValues.length; i++) {
    const handle = normalizeUsername_(uValues[i][3]);
    if (!handle) continue;
    userLookup[handle] = {
      email: normalizeEmail_(uValues[i][0]),
      fullname: String(uValues[i][2] || handle),
      username: handle,
    };
  }

  const fValues = friendsSheet.getDataRange().getValues();
  const friends = [];
  const pendingReceived = [];
  const pendingSent = [];

  for (let i = 1; i < fValues.length; i++) {
    const a = normalizeUsername_(fValues[i][0]);
    const b = normalizeUsername_(fValues[i][1]);
    const status = String(fValues[i][2] || '').trim().toLowerCase();
    if (!a || !b) continue;

    if (a === me || b === me) {
      const peer = a === me ? b : a;
      const peerInfo = userLookup[peer] || {
        email: '',
        fullname: peer,
        username: peer,
      };
      if (status === 'accepted') {
        friends.push({
          email: peerInfo.email,
          fullname: peerInfo.fullname,
          username: peerInfo.username,
          friendshipStatus: 'accepted',
        });
      } else if (status === 'pending') {
        if (b === me) {
          pendingReceived.push({
            email: peerInfo.email,
            fullname: peerInfo.fullname,
            username: peerInfo.username,
            friendshipStatus: 'pending_received',
          });
        } else {
          pendingSent.push({
            email: peerInfo.email,
            fullname: peerInfo.fullname,
            username: peerInfo.username,
            friendshipStatus: 'pending_sent',
          });
        }
      }
    }
  }

  return jsonOut_({
    ok: true,
    status: 'success',
    friends: friends,
    pending_received: pendingReceived,
    pending_sent: pendingSent,
  });
}

// ==================== 3. HIGH-SPEED MESSAGING (CacheService + 100-Row Delta Sync) ====================

function handleSendMessage_(msgSheet, body) {
  const sender = normalizeUsername_(body.sender || '');
  const receiver = normalizeUsername_(body.receiver || '');
  const content = String(body.content || '').trim();

  if (!sender || !receiver || !content) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Người gửi, người nhận hoặc nội dung không hợp lệ.',
    });
  }

  const nowMs = Date.now();
  msgSheet.appendRow([sender, receiver, content, nowMs]);
  const insertedRow = msgSheet.getLastRow();
  msgSheet.getRange(insertedRow, 1, 1, 3).setNumberFormat('@');

  // Ghi tín hiệu CacheService ngay lập tức để người nhận kiểm tra không cần mở Sheet nếu không có tin mới
  const cache = CacheService.getScriptCache();
  cache.put('new_msg_for_' + receiver, String(nowMs), MSG_CACHE_TTL_SECONDS);
  cache.put('new_msg_for_' + sender, String(nowMs), MSG_CACHE_TTL_SECONDS);

  return jsonOut_({
    ok: true,
    status: 'success',
    message_item: {
      sender: sender,
      receiver: receiver,
      content: content,
      timestamp: nowMs,
    },
  });
}

function handleGetMessages_(msgSheet, body) {
  const user1 = normalizeUsername_(body.user1 || body.current_user || body.username);
  const user2 = normalizeUsername_(body.user2 || body.friend_user || body.friend);
  const lastTs = Number(body.last_timestamp || 0);

  if (!user1 || !user2) {
    return jsonOut_({
      ok: false,
      status: 'error',
      messages: [],
    });
  }

  const cache = CacheService.getScriptCache();
  const lastRow = msgSheet.getLastRow();
  if (lastRow <= 1) {
    cache.put(
      'new_msg_for_' + user1,
      String(lastTs > 0 ? lastTs : Date.now()),
      MSG_CACHE_TTL_SECONDS
    );
    return jsonOut_({
      ok: true,
      status: 'success',
      messages: [],
      from_cache: false,
    });
  }

  // Delta Sync: chỉ đọc tối đa 100 dòng cuối cùng
  const startRow = Math.max(2, lastRow - 99);
  const numRows = lastRow - startRow + 1;
  const rows = msgSheet.getRange(startRow, 1, numRows, 4).getValues();

  const reversed = [];
  let maxSeenTs = lastTs;

  for (let i = rows.length - 1; i >= 0; i--) {
    const ts = parseTimestampMs_(rows[i][3]);
    if (ts > maxSeenTs) maxSeenTs = ts;

    // Gặp tin nhắn cũ hơn hoặc bằng last_timestamp thì dừng vòng lặp ngay lập tức
    if (lastTs > 0 && ts <= lastTs) {
      break;
    }

    const s = normalizeUsername_(rows[i][0]);
    const r = normalizeUsername_(rows[i][1]);
    if ((s === user1 && r === user2) || (s === user2 && r === user1)) {
      reversed.push({
        sender: s,
        receiver: r,
        content: String(rows[i][2] || ''),
        timestamp: ts,
      });
    }
  }

  reversed.reverse();
  cache.put(
    'new_msg_for_' + user1,
    String(maxSeenTs > 0 ? maxSeenTs : Date.now()),
    MSG_CACHE_TTL_SECONDS
  );

  return jsonOut_({
    ok: true,
    status: 'success',
    messages: reversed,
    from_cache: false,
  });
}

// ==================== 4. PROGRESS SYNC -> USERS SHEET ====================

function syncStateToUsersSheet_(ss, stateObj) {
  try {
    const user = stateObj.user || {};
    const email = normalizeEmail_(user.email);
    if (!email) return;

    const usersSheet = getOrCreateSheetWithHeaders_(
      ss,
      USERS_SHEET_NAME,
      USERS_HEADERS
    );

    const values = usersSheet.getDataRange().getValues();
    for (let i = 1; i < values.length; i++) {
      if (normalizeEmail_(values[i][0]) === email) {
        const existingHash = String(values[i][1] || '').trim();
        const existingName = String(values[i][2] || '').trim();
        const existingUsername = normalizeUsername_(values[i][3]);
        const existingCreated = String(values[i][4] || '').trim();
        const updatedRow = [
          email,
          existingHash || user.passwordHash || '',
          user.displayName || existingName || '',
          existingUsername ||
            normalizeUsername_(user.username) ||
            buildUniqueDerivedUsername_(usersSheet, email),
          existingCreated || user.createdAt || new Date().toISOString(),
        ];
        usersSheet
          .getRange(i + 1, 1, 1, updatedRow.length)
          .setNumberFormat('@')
          .setValues([updatedRow]);
        return;
      }
    }

    const derivedUsername =
      normalizeUsername_(user.username) ||
      buildUniqueDerivedUsername_(usersSheet, email);
    const rowData = [
      email,
      user.passwordHash || '',
      user.displayName || '',
      derivedUsername,
      user.createdAt || new Date().toISOString(),
    ];
    usersSheet.appendRow(rowData);
    usersSheet
      .getRange(usersSheet.getLastRow(), 1, 1, rowData.length)
      .setNumberFormat('@');
  } catch (e) {}
}

function testSetupPermissions() {
  const rootFolder = getOrCreateRootFolder_();
  const ss = getOrCreateDatabaseSpreadsheet_(rootFolder);
  getOrCreateSheetWithHeaders_(ss, USERS_SHEET_NAME, USERS_HEADERS);
  getOrCreateSheetWithHeaders_(ss, OTP_SHEET_NAME, OTP_HEADERS);
  getOrCreateSheetWithHeaders_(ss, FRIENDS_SHEET_NAME, FRIENDS_HEADERS);
  getOrCreateSheetWithHeaders_(ss, MESSAGES_SHEET_NAME, MESSAGES_HEADERS);
  getOrCreateUsersFolder_(rootFolder);
  const quota = MailApp.getRemainingDailyQuota();
  return 'OK | Sheet=' + ss.getUrl() + ' | MailQuota=' + quota;
}
