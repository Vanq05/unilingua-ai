/**
 * UniLingua AI — Central Google Drive + Sheets Auth & Progress Server (Google Apps Script)
 *
 * Hỗ trợ đồng thời:
 *   1. Xác thực Mobile App qua Google Sheets (`Users`, `OTP_Codes`) với SHA-256 + SECRET_SALT & MailApp OTP:
 *      - action: "register" | "login" | "change_password" | "forgot_password" | "reset_password"
 *   2. Lưu & Đồng bộ toàn bộ dữ liệu học tập JSON trên Google Drive (`UniLingua_Server_DB/users/`):
 *      - action: "load" | "save"
 */

const DB_FOLDER_NAME = 'UniLingua_Server_DB';
const USERS_FOLDER_NAME = 'users';
const DASHBOARD_SHEET_NAME = 'UniLingua_Users_Dashboard';
const USERS_SHEET_NAME = 'Users';
const OTP_SHEET_NAME = 'OTP_Codes';

const APP_SHARED_SECRET = 'UL_DB_2026_SECURE_KEY_9981';
const SECRET_SALT = 'UL_SHA256_SECRET_SALT_2026';
const ADMIN_SECRET_PIN = '2026';
const OTP_EXPIRY_MINUTES = 10;

const USERS_HEADERS = ['Email', 'Password', 'FullName', 'Role', 'CreatedAt'];
const OTP_HEADERS = ['Email', 'OTP', 'ExpiresAt'];

function normalizeEmail_(email) {
  return String(email || '').trim().toLowerCase();
}

function isValidEmail_(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

/**
 * Băm mật khẩu bằng SHA-256 + SECRET_SALT phía server (khớp 100% với hàm sha256Hex trong Dart)
 */
function hashPassword_(rawPassword) {
  const input = String(rawPassword || '') + SECRET_SALT;
  const rawHash = Utilities.computeDigest(
    Utilities.DigestAlgorithm.SHA_256,
    input,
    Utilities.Charset.UTF_8
  );
  let hex = '';
  for (let i = 0; i < rawHash.length; i++) {
    let byteVal = rawHash[i];
    if (byteVal < 0) byteVal += 256;
    const hexPart = byteVal.toString(16);
    hex += hexPart.length === 1 ? '0' + hexPart : hexPart;
  }
  return hex;
}

function getOrCreateRootFolder_() {
  const it = DriveApp.getFoldersByName(DB_FOLDER_NAME);
  if (it.hasNext()) return it.next();
  return DriveApp.createFolder(DB_FOLDER_NAME);
}

function getOrCreateUsersFolder_(rootFolder) {
  const it = rootFolder.getFoldersByName(USERS_FOLDER_NAME);
  if (it.hasNext()) return it.next();
  return rootFolder.createFolder(USERS_FOLDER_NAME);
}

function getOrCreateDatabaseSpreadsheet_(rootFolder) {
  const files = rootFolder.getFilesByName(DASHBOARD_SHEET_NAME);
  if (files.hasNext()) {
    return SpreadsheetApp.open(files.next());
  }
  const ss = SpreadsheetApp.create(DASHBOARD_SHEET_NAME);
  const createdFile = DriveApp.getFileById(ss.getId());
  rootFolder.addFile(createdFile);
  try {
    DriveApp.getRootFolder().removeFile(createdFile);
  } catch (e) {}
  return ss;
}

function getOrCreateSheetWithHeaders_(ss, sheetName, headers) {
  let sheet = ss.getSheetByName(sheetName);
  if (!sheet) {
    sheet = ss.insertSheet(sheetName);
  }
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(headers);
    sheet.getRange(1, 1, 1, headers.length).setFontWeight('bold');
    sheet.setFrozenRows(1);
  }
  return sheet;
}

function safeFileName_(email) {
  return (
    String(email || 'guest')
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9@._-]/g, '_') + '.json'
  );
}

function jsonOut_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(
    ContentService.MimeType.JSON
  );
}

function doGet(e) {
  return jsonOut_({
    ok: true,
    status: 'success',
    service: 'UniLingua Central Google Drive + Sheets Auth Server',
    timestamp: new Date().toISOString(),
  });
}

function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(15000);

  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    const action = String(body.action || '').trim().toLowerCase();
    const rootFolder = getOrCreateRootFolder_();

    // ==================== 5 AUTH ACTIONS (Google Sheets + MailApp) ====================
    if (
      action === 'register' ||
      action === 'login' ||
      action === 'change_password' ||
      action === 'forgot_password' ||
      action === 'reset_password'
    ) {
      const ss = getOrCreateDatabaseSpreadsheet_(rootFolder);
      const usersSheet = getOrCreateSheetWithHeaders_(
        ss,
        USERS_SHEET_NAME,
        USERS_HEADERS
      );
      const otpSheet = getOrCreateSheetWithHeaders_(
        ss,
        OTP_SHEET_NAME,
        OTP_HEADERS
      );

      switch (action) {
        case 'register':
          return handleRegister_(usersSheet, body);
        case 'login':
          return handleLogin_(usersSheet, body);
        case 'change_password':
          return handleChangePassword_(usersSheet, body);
        case 'forgot_password':
          return handleForgotPassword_(usersSheet, otpSheet, body);
        case 'reset_password':
          return handleResetPassword_(
            usersSheet,
            otpSheet,
            getOrCreateUsersFolder_(rootFolder),
            body
          );
      }
    }

    // ==================== 3 ADMIN ACTIONS (Account Management) ====================
    if (
      action === 'admin_list_users' ||
      action === 'admin_update_user' ||
      action === 'admin_delete_user'
    ) {
      const providedPin = String(body.adminPin || body.pin || '').trim();
      const providedSecret = String(body.secret || '').trim();
      const callerEmail = normalizeEmail_(body.callerEmail || '');

      const ss = getOrCreateDatabaseSpreadsheet_(rootFolder);
      const usersSheet = getOrCreateSheetWithHeaders_(
        ss,
        USERS_SHEET_NAME,
        USERS_HEADERS
      );
      const otpSheet = getOrCreateSheetWithHeaders_(
        ss,
        OTP_SHEET_NAME,
        OTP_HEADERS
      );
      const usersFolder = getOrCreateUsersFolder_(rootFolder);

      const isPinValid = providedPin === ADMIN_SECRET_PIN;
      const isRoleAdmin =
        providedSecret === APP_SHARED_SECRET &&
        isCallerAdminInSheet_(usersSheet, callerEmail);

      if (!isPinValid && !isRoleAdmin) {
        return jsonOut_({
          ok: false,
          status: 'error',
          message: 'Mã PIN quản trị viên không đúng hoặc tài khoản không có quyền Admin.',
        });
      }

      switch (action) {
        case 'admin_list_users':
          return handleAdminListUsers_(ss, usersSheet);
        case 'admin_update_user':
          return handleAdminUpdateUser_(usersSheet, usersFolder, body);
        case 'admin_delete_user':
          return handleAdminDeleteUser_(usersSheet, otpSheet, usersFolder, body);
      }
    }

    // ==================== PROGRESS SYNC ACTIONS (load / save) ====================
    if (body.secret !== APP_SHARED_SECRET) {
      return jsonOut_({ ok: false, status: 'error', error: 'Unauthorized' });
    }

    const email = normalizeEmail_(body.email);
    if (!email) {
      return jsonOut_({ ok: false, status: 'error', error: 'Missing email' });
    }

    const usersFolder = getOrCreateUsersFolder_(rootFolder);
    const fileName = safeFileName_(email);

    if (action === 'load') {
      const files = usersFolder.getFilesByName(fileName);
      if (!files.hasNext()) {
        return jsonOut_({ ok: true, found: false, data: null });
      }
      const content = files.next().getBlob().getDataAsString('UTF-8');
      return jsonOut_({
        ok: true,
        found: true,
        data: JSON.parse(content),
      });
    }

    if (action === 'save') {
      const stateObj = body.data;
      if (!stateObj) {
        return jsonOut_({ ok: false, error: 'Missing data payload' });
      }
      const serialized = JSON.stringify(stateObj);
      const files = usersFolder.getFilesByName(fileName);
      if (files.hasNext()) {
        files.next().setContent(serialized);
      } else {
        usersFolder.createFile(fileName, serialized, MimeType.PLAIN_TEXT);
      }
      syncStateToUsersSheet_(rootFolder, stateObj);
      return jsonOut_({ ok: true, saved: true });
    }

    return jsonOut_({ ok: false, status: 'error', error: 'Unknown action' });
  } catch (err) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: String(err),
      error: String(err),
    });
  } finally {
    lock.releaseLock();
  }
}

function handleRegister_(usersSheet, body) {
  const email = normalizeEmail_(body.email);
  const password = String(body.password || '');
  const fullName = String(body.fullname || body.fullName || '').trim();

  if (!isValidEmail_(email)) {
    return jsonOut_({ ok: false, status: 'error', message: 'Email không hợp lệ.' });
  }
  if (password.length < 6) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Mật khẩu phải có ít nhất 6 ký tự.',
    });
  }
  if (!fullName) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Vui lòng nhập họ và tên.',
    });
  }

  const values = usersSheet.getDataRange().getValues();
  for (let i = 1; i < values.length; i++) {
    if (normalizeEmail_(values[i][0]) === email) {
      return jsonOut_({
        ok: false,
        status: 'error',
        message: 'Email này đã được đăng ký.',
      });
    }
  }

  const hashed = hashPassword_(password);
  const role = 'user';
  const createdAt = new Date().toISOString();

  usersSheet.appendRow([email, hashed, fullName, role, createdAt]);
  const insertedRow = usersSheet.getLastRow();
  usersSheet.getRange(insertedRow, 1, 1, 5).setNumberFormat('@');

  return jsonOut_({
    ok: true,
    status: 'success',
    message: 'Đăng ký tài khoản thành công.',
    user: {
      email: email,
      fullname: fullName,
      role: role,
      createdAt: createdAt,
    },
  });
}

function handleLogin_(usersSheet, body) {
  const email = normalizeEmail_(body.email);
  const password = String(body.password || '');
  if (!isValidEmail_(email) || !password) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Vui lòng nhập đầy đủ Email và Mật khẩu.',
    });
  }

  const hashed = hashPassword_(password);
  const values = usersSheet.getDataRange().getValues();
  for (let i = 1; i < values.length; i++) {
    const rowEmail = normalizeEmail_(values[i][0]);
    const rowHash = String(values[i][1] || '').trim();
    if (rowEmail === email && rowHash === hashed) {
      return jsonOut_({
        ok: true,
        status: 'success',
        message: 'Đăng nhập thành công.',
        user: {
          email: rowEmail,
          fullname: String(values[i][2] || ''),
          role: String(values[i][3] || 'user'),
          createdAt: String(values[i][4] || ''),
        },
      });
    }
  }

  return jsonOut_({
    ok: false,
    status: 'error',
    message: 'Email hoặc mật khẩu không chính xác.',
  });
}

function handleChangePassword_(usersSheet, body) {
  const email = normalizeEmail_(body.email);
  const oldPassword = String(body.old_password || '');
  const newPassword = String(body.new_password || '');

  if (!isValidEmail_(email) || !oldPassword || newPassword.length < 6) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Mật khẩu mới cần tối thiểu 6 ký tự.',
    });
  }

  const oldHash = hashPassword_(oldPassword);
  const newHash = hashPassword_(newPassword);
  const values = usersSheet.getDataRange().getValues();

  for (let i = 1; i < values.length; i++) {
    if (normalizeEmail_(values[i][0]) === email) {
      if (String(values[i][1] || '').trim() !== oldHash) {
        return jsonOut_({
          ok: false,
          status: 'error',
          message: 'Mật khẩu hiện tại không đúng.',
        });
      }
      usersSheet.getRange(i + 1, 2).setNumberFormat('@').setValue(newHash);
      return jsonOut_({
        ok: true,
        status: 'success',
        message: 'Đổi mật khẩu thành công.',
      });
    }
  }

  return jsonOut_({
    ok: false,
    status: 'error',
    message: 'Không tìm thấy tài khoản.',
  });
}

function handleForgotPassword_(usersSheet, otpSheet, body) {
  const email = normalizeEmail_(body.email);
  if (!isValidEmail_(email)) {
    return jsonOut_({ ok: false, status: 'error', message: 'Email không hợp lệ.' });
  }

  const userValues = usersSheet.getDataRange().getValues();
  let foundName = 'bạn';
  let exists = false;
  for (let i = 1; i < userValues.length; i++) {
    if (normalizeEmail_(userValues[i][0]) === email) {
      exists = true;
      foundName = String(userValues[i][2] || 'bạn');
      break;
    }
  }

  if (!exists) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Email này chưa được đăng ký trong hệ thống.',
    });
  }

  const otpValues = otpSheet.getDataRange().getValues();
  for (let i = otpValues.length - 1; i >= 1; i--) {
    if (normalizeEmail_(otpValues[i][0]) === email) {
      otpSheet.deleteRow(i + 1);
    }
  }

  const otp = String(Math.floor(100000 + Math.random() * 900000));
  const expiresAt = new Date(
    Date.now() + OTP_EXPIRY_MINUTES * 60 * 1000
  ).toISOString();

  otpSheet.appendRow([email, otp, expiresAt]);
  const insertedRow = otpSheet.getLastRow();
  otpSheet.getRange(insertedRow, 1, 1, 3).setNumberFormat('@');

  MailApp.sendEmail({
    to: email,
    subject: '[UniLingua AI] Mã OTP đặt lại mật khẩu',
    htmlBody:
      '<div style="font-family:Arial,sans-serif;max-width:480px;margin:auto;padding:24px;border:1px solid #bae6fd;border-radius:14px;">' +
      '<h2 style="color:#0284c7;margin-top:0;">Xin chào ' +
      foundName +
      ',</h2>' +
      '<p>Mã OTP khôi phục mật khẩu UniLingua AI của bạn (có hiệu lực <b>10 phút</b>):</p>' +
      '<div style="background:#eff8ff;border:1px dashed #0284c7;border-radius:10px;padding:16px;text-align:center;margin:18px 0;">' +
      '<span style="font-size:28px;font-weight:bold;letter-spacing:6px;color:#0284c7;">' +
      otp +
      '</span></div>' +
      '<p style="color:#64748b;font-size:12px;">Nếu bạn không thực hiện yêu cầu này, hãy bỏ qua email này.</p></div>',
  });

  return jsonOut_({
    ok: true,
    status: 'success',
    message: 'Mã OTP 6 số đã được gửi tới email ' + email + '.',
  });
}

function handleResetPassword_(usersSheet, otpSheet, usersFolder, body) {
  const email = normalizeEmail_(body.email);
  const otpInput = String(body.otp || '').trim();
  const newPassword = String(body.new_password || '');

  if (!isValidEmail_(email)) {
    return jsonOut_({ ok: false, status: 'error', message: 'Email không hợp lệ.' });
  }
  if (!/^\d{6}$/.test(otpInput)) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Mã OTP phải gồm 6 chữ số.',
    });
  }
  if (newPassword.length < 6) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Mật khẩu mới phải có ít nhất 6 ký tự.',
    });
  }

  const otpValues = otpSheet.getDataRange().getValues();
  let matchedRowIndex = -1;
  let expiresAtRaw = '';

  for (let i = otpValues.length - 1; i >= 1; i--) {
    const rowEmail = normalizeEmail_(otpValues[i][0]);
    const rowOtp = String(otpValues[i][1] || '').trim();
    if (rowEmail === email && rowOtp === otpInput) {
      matchedRowIndex = i + 1;
      expiresAtRaw = String(otpValues[i][2] || '').trim();
      break;
    }
  }

  if (matchedRowIndex === -1) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Mã OTP không chính xác.',
    });
  }

  const expiresMs = new Date(expiresAtRaw).getTime();
  if (isNaN(expiresMs) || expiresMs <= Date.now()) {
    otpSheet.deleteRow(matchedRowIndex);
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Mã OTP đã hết hạn (quá 10 phút).',
    });
  }

  const newHash = hashPassword_(newPassword);
  const userValues = usersSheet.getDataRange().getValues();
  for (let i = 1; i < userValues.length; i++) {
    if (normalizeEmail_(userValues[i][0]) === email) {
      usersSheet.getRange(i + 1, 2).setNumberFormat('@').setValue(newHash);
      break;
    }
  }

  otpSheet.deleteRow(matchedRowIndex);

  if (usersFolder) {
    try {
      const files = usersFolder.getFilesByName(safeFileName_(email));
      if (files.hasNext()) {
        const file = files.next();
        const content = file.getBlob().getDataAsString('UTF-8');
        const stateObj = JSON.parse(content);
        if (stateObj && typeof stateObj === 'object' && stateObj.user) {
          stateObj.user.passwordHash = newHash;
          stateObj.user.pendingOtpCode = '';
          stateObj.user.pendingOtpExpiresAt = '';
          file.setContent(JSON.stringify(stateObj));
        }
      }
    } catch (e) {}
  }

  return jsonOut_({
    ok: true,
    status: 'success',
    message: 'Đặt lại mật khẩu thành công!',
  });
}

function syncStateToUsersSheet_(rootFolder, stateObj) {
  try {
    const user = stateObj.user || {};
    const email = normalizeEmail_(user.email);
    if (!email) return;

    const ss = getOrCreateDatabaseSpreadsheet_(rootFolder);
    const usersSheet = getOrCreateSheetWithHeaders_(
      ss,
      USERS_SHEET_NAME,
      USERS_HEADERS
    );

    const values = usersSheet.getDataRange().getValues();
    for (let i = 1; i < values.length; i++) {
      if (normalizeEmail_(values[i][0]) === email) {
        const existingHash = String(values[i][1] || '').trim();
        const existingName = String(values[i][2] || '').trim();
        const existingRole = String(values[i][3] || '').trim();
        const existingCreated = String(values[i][4] || '').trim();
        const updatedRow = [
          email,
          existingHash || user.passwordHash || '',
          user.displayName || existingName || '',
          existingRole || user.role || 'user',
          existingCreated || user.createdAt || new Date().toISOString(),
        ];
        usersSheet
          .getRange(i + 1, 1, 1, updatedRow.length)
          .setNumberFormat('@')
          .setValues([updatedRow]);
        return;
      }
    }

    const rowData = [
      email,
      user.passwordHash || '',
      user.displayName || '',
      user.role || 'user',
      user.createdAt || new Date().toISOString(),
    ];
    usersSheet.appendRow(rowData);
    usersSheet.getRange(usersSheet.getLastRow(), 1, 1, rowData.length).setNumberFormat('@');
  } catch (e) {}
}

function isCallerAdminInSheet_(usersSheet, callerEmail) {
  if (!callerEmail) return false;
  const values = usersSheet.getDataRange().getValues();
  for (let i = 1; i < values.length; i++) {
    if (normalizeEmail_(values[i][0]) === callerEmail) {
      return String(values[i][3] || '').trim().toLowerCase() === 'admin';
    }
  }
  return false;
}

function handleAdminListUsers_(ss, usersSheet) {
  const values = usersSheet.getDataRange().getValues();
  const users = [];
  for (let i = 1; i < values.length; i++) {
    const rowEmail = normalizeEmail_(values[i][0]);
    if (!rowEmail) continue;
    users.push({
      email: rowEmail,
      fullname: String(values[i][2] || ''),
      role: String(values[i][3] || 'user').trim().toLowerCase() || 'user',
      createdAt: String(values[i][4] || ''),
    });
  }
  return jsonOut_({
    ok: true,
    status: 'success',
    dashboardUrl: ss.getUrl(),
    users: users,
  });
}

function handleAdminUpdateUser_(usersSheet, usersFolder, body) {
  const targetEmail = normalizeEmail_(body.targetEmail || body.email || '');
  if (!isValidEmail_(targetEmail)) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Email tài khoản cần cập nhật không hợp lệ.',
    });
  }

  const hasNewPassword =
    body.newPassword !== undefined &&
    body.newPassword !== null &&
    String(body.newPassword).length > 0;
  const newPassword = String(body.newPassword || '');
  if (hasNewPassword && newPassword.length < 6) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Mật khẩu mới cần tối thiểu 6 ký tự.',
    });
  }

  const values = usersSheet.getDataRange().getValues();
  let matchedRow = -1;
  let currentHash = '';
  let currentName = '';
  let currentRole = 'user';
  let currentCreated = '';

  for (let i = 1; i < values.length; i++) {
    if (normalizeEmail_(values[i][0]) === targetEmail) {
      matchedRow = i + 1;
      currentHash = String(values[i][1] || '').trim();
      currentName = String(values[i][2] || '');
      currentRole = String(values[i][3] || 'user').trim().toLowerCase() || 'user';
      currentCreated = String(values[i][4] || '');
      break;
    }
  }

  if (matchedRow === -1) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Không tìm thấy tài khoản trong Google Sheets.',
    });
  }

  let updatedRole = currentRole;
  if (body.newRole !== undefined && body.newRole !== null) {
    const candidate = String(body.newRole).trim().toLowerCase();
    if (candidate === 'admin' || candidate === 'user') {
      updatedRole = candidate;
    }
  }

  let updatedName = currentName;
  if (
    body.newFullName !== undefined &&
    body.newFullName !== null &&
    String(body.newFullName).trim().length > 0
  ) {
    updatedName = String(body.newFullName).trim();
  }

  const updatedHash = hasNewPassword ? hashPassword_(newPassword) : currentHash;

  usersSheet
    .getRange(matchedRow, 2, 1, 3)
    .setNumberFormat('@')
    .setValues([[updatedHash, updatedName, updatedRole]]);

  const fileName = safeFileName_(targetEmail);
  const files = usersFolder.getFilesByName(fileName);
  if (files.hasNext()) {
    try {
      const file = files.next();
      const content = file.getBlob().getDataAsString('UTF-8');
      const stateObj = JSON.parse(content);
      if (stateObj && typeof stateObj === 'object' && stateObj.user) {
        stateObj.user.role = updatedRole;
        stateObj.user.displayName = updatedName;
        if (hasNewPassword) {
          stateObj.user.passwordHash = updatedHash;
        }
        file.setContent(JSON.stringify(stateObj));
      }
    } catch (e) {}
  }

  return jsonOut_({
    ok: true,
    status: 'success',
    message: 'Đã cập nhật tài khoản ' + targetEmail + '.',
    user: {
      email: targetEmail,
      fullname: updatedName,
      role: updatedRole,
      createdAt: currentCreated,
    },
  });
}

function handleAdminDeleteUser_(usersSheet, otpSheet, usersFolder, body) {
  const targetEmail = normalizeEmail_(body.targetEmail || body.email || '');
  if (!isValidEmail_(targetEmail)) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Email tài khoản cần xóa không hợp lệ.',
    });
  }

  let removedAny = false;
  const userValues = usersSheet.getDataRange().getValues();
  for (let i = userValues.length - 1; i >= 1; i--) {
    if (normalizeEmail_(userValues[i][0]) === targetEmail) {
      usersSheet.deleteRow(i + 1);
      removedAny = true;
    }
  }

  const otpValues = otpSheet.getDataRange().getValues();
  for (let i = otpValues.length - 1; i >= 1; i--) {
    if (normalizeEmail_(otpValues[i][0]) === targetEmail) {
      otpSheet.deleteRow(i + 1);
    }
  }

  const fileName = safeFileName_(targetEmail);
  const files = usersFolder.getFilesByName(fileName);
  while (files.hasNext()) {
    files.next().setTrashed(true);
    removedAny = true;
  }

  if (!removedAny) {
    return jsonOut_({
      ok: false,
      status: 'error',
      message: 'Không tìm thấy tài khoản cần xóa.',
    });
  }

  return jsonOut_({
    ok: true,
    status: 'success',
    message: 'Đã xóa tài khoản ' + targetEmail + ' khỏi hệ thống.',
  });
}


function testSetupPermissions() {
  const rootFolder = getOrCreateRootFolder_();
  const ss = getOrCreateDatabaseSpreadsheet_(rootFolder);
  getOrCreateSheetWithHeaders_(ss, USERS_SHEET_NAME, USERS_HEADERS);
  getOrCreateSheetWithHeaders_(ss, OTP_SHEET_NAME, OTP_HEADERS);
  getOrCreateUsersFolder_(rootFolder);
  const quota = MailApp.getRemainingDailyQuota();
  return 'OK | Sheet=' + ss.getUrl() + ' | MailQuota=' + quota;
}
