import 'package:flutter/material.dart';

import '../../../data/repositories/curriculum_repository.dart';
import '../../../domain/models/learning_models.dart';
import '../../theme/app_theme.dart';
import '../../view_models/learning_view_model.dart';

class WritingScreen extends StatefulWidget {
  const WritingScreen({
    super.key,
    required this.viewModel,
  });

  final LearningViewModel viewModel;

  @override
  State<WritingScreen> createState() => _WritingScreenState();
}

class _WritingScreenState extends State<WritingScreen> {
  int _selectedPromptIndex = 0;
  final TextEditingController _essayCtrl = TextEditingController();
  WritingEvaluation? _latestEvaluation;

  @override
  void initState() {
    super.initState();
    _essayCtrl.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _essayCtrl.dispose();
    super.dispose();
  }

  int get _wordCount {
    final trimmed = _essayCtrl.text.trim();
    if (trimmed.isEmpty) return 0;
    return trimmed.split(RegExp(r'\s+')).length;
  }

  void _fillSampleDraft(WritingPrompt prompt) {
    if (prompt.id == 'wrt_1') {
      _essayCtrl.text =
          'In the contemporary era of rapid digital transformation, the integration of Artificial Intelligence into university education has sparked intense debate. While some critics contend that AI tools might undermine independent critical thinking, I firmly believe that teaching undergraduates to harness AI responsibly is indispensable for their future careers.\n\nOn the one hand, unrestricted reliance on generative models can tempt students to bypass rigorous research processes. On the other hand, employers across global industries increasingly expect graduates to utilize AI for data synthesis, software debugging, and strategic modeling. Therefore, universities should establish clear ethical guidelines rather than imposing blanket bans.';
    } else if (prompt.id == 'wrt_2') {
      _essayCtrl.text =
          'Subject: Inquiry Regarding Undergraduate Research Assistant Opportunity\n\nDear Professor Nguyen,\n\nI am a third-year undergraduate student majoring in Computer Science at the National University. Having recently read your peer-reviewed publication on Explainable Artificial Intelligence in healthcare diagnostics, I was deeply intrigued by your methodology for reducing algorithmic bias.\n\nI am writing to inquire whether you might have an opening for an undergraduate research assistant in your laboratory next semester. I have completed advanced coursework in Machine Learning and Python data analysis, and I have attached my curriculum vitae and transcript for your review.\n\nThank you very much for your time and consideration.\n\nSincerely,\nMinh Anh';
    } else {
      _essayCtrl.text =
          'Dear Hiring Committee,\n\nI am thrilled to submit my application for the Summer Internship position at your organization. As a university student with a strong academic foundation in analytical problem-solving, I recently spearheaded a four-member capstone team to design an automated supply-chain dashboard that improved forecasting accuracy by 22%.\n\nI would welcome the opportunity to discuss how my technical skills and collaborative mindset align with your team’s objectives.\n\nBest regards,\nMinh Anh';
    }
  }

  Future<void> _submitForAiGrading(WritingPrompt prompt) async {
    final text = _essayCtrl.text.trim();
    if (text.length < 20) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Vui lòng viết ít nhất 1-2 câu tiếng Anh để AI chấm bài.'),
        ),
      );
      return;
    }
    final evaluation = await widget.viewModel.evaluateWritingSubmission(
      prompt: prompt,
      essayText: text,
    );
    if (!mounted) return;
    setState(() {
      _latestEvaluation = evaluation;
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.viewModel,
      builder: (context, _) {
        final prompts = CurriculumRepository.writingPrompts;
        final prompt = prompts[_selectedPromptIndex];

        return Scaffold(
          appBar: AppBar(
            title: const Text(
              '✍️ Phòng Luyện Viết & AI Chấm Luận',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17),
            ),
          ),
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                // Prompt Selector
                SizedBox(
                  height: 82,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: prompts.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 10),
                    itemBuilder: (context, index) {
                      final item = prompts[index];
                      final selected = index == _selectedPromptIndex;
                      return InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: () => setState(() {
                          _selectedPromptIndex = index;
                          _latestEvaluation = null;
                        }),
                        child: Container(
                          width: 245,
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: selected
                                ? AppTheme.violetAccent.withValues(alpha: 0.2)
                                : AppTheme.bgCard,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: selected
                                  ? AppTheme.violetAccent
                                  : AppTheme.borderSubtle,
                              width: selected ? 1.6 : 1,
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                item.title,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontSize: 13.5,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '${item.cefrLevel} • ${item.category}',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontSize: 11.5,
                                  color: AppTheme.textSecondary,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 16),

                // Writing Prompt & Structure Guide Card
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: AppTheme.bgCard,
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: AppTheme.borderSubtle),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color:
                                  AppTheme.violetAccent.withValues(alpha: 0.2),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              '${prompt.category} • ${prompt.cefrLevel}',
                              style: const TextStyle(
                                color: AppTheme.cyanPrimary,
                                fontWeight: FontWeight.w800,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(
                        prompt.promptEn,
                        style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w800,
                          height: 1.45,
                        ),
                      ),
                      const Divider(height: 20),
                      Text(
                        prompt.guideVi,
                        style: const TextStyle(
                          fontSize: 13,
                          height: 1.45,
                          color: AppTheme.textSecondary,
                        ),
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'Cấu trúc ăn điểm Band 7.5+ (Bấm để chèn vào bài viết):',
                        style: TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.goldAccent,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: prompt.keyStructures.map((s) {
                          return ActionChip(
                            backgroundColor: AppTheme.bgSurface,
                            label: Text(
                              s,
                              style: const TextStyle(fontSize: 12),
                            ),
                            onPressed: () {
                              final current = _essayCtrl.text;
                              _essayCtrl.text = current.isEmpty
                                  ? s
                                  : '$current $s';
                            },
                          );
                        }).toList(),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // Essay Editor
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Text(
                      'Bài viết của bạn ($_wordCount từ / Gợi ý ≥${prompt.minWords} từ)',
                      style: const TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 14,
                      ),
                    ),
                    TextButton.icon(
                      onPressed: () => _fillSampleDraft(prompt),
                      icon: const Icon(Icons.auto_fix_high_rounded, size: 16),
                      label: const Text('Điền bài mẫu thử nghiệm'),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                TextField(
                  controller: _essayCtrl,
                  minLines: 7,
                  maxLines: 14,
                  decoration: const InputDecoration(
                    hintText:
                        'Viết bài luận hoặc email học thuật bằng tiếng Anh tại đây để AI chấm điểm theo 4 tiêu chí IELTS và sửa từng lỗi...',
                  ),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: ElevatedButton.icon(
                    onPressed: widget.viewModel.isGradingWriting
                        ? null
                        : () => _submitForAiGrading(prompt),
                    icon: widget.viewModel.isGradingWriting
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Color(0xFF04101E),
                            ),
                          )
                        : const Icon(Icons.grade_rounded),
                    label: Text(
                      widget.viewModel.isGradingWriting
                          ? 'Giám khảo AI đang chấm điểm & sửa bài...'
                          : 'Chấm Điểm Band IELTS & Nâng Cấp Bài Viết (+50 XP)',
                    ),
                  ),
                ),

                // AI Evaluation Result Card
                if (_latestEvaluation != null) ...<Widget>[
                  const SizedBox(height: 22),
                  _buildEvaluationCard(_latestEvaluation!),
                ],
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildEvaluationCard(WritingEvaluation eval) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: <Color>[Color(0xFF1E1B4B), Color(0xFF0F172A)],
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: AppTheme.goldAccent.withValues(alpha: 0.5),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: AppTheme.goldAccent,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Text(
                  'Overall Band ${eval.overallBand.toStringAsFixed(1)}',
                  style: const TextStyle(
                    color: Color(0xFF04101E),
                    fontWeight: FontWeight.w900,
                    fontSize: 16,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Text(
                  'Kết quả Chấm thi AI IELTS & Academic Rubric',
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 15,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: <Widget>[
              Expanded(
                child: _CriteriaChip(
                  label: 'Task Response',
                  band: eval.taskResponseBand,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _CriteriaChip(
                  label: 'Coherence',
                  band: eval.coherenceBand,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: <Widget>[
              Expanded(
                child: _CriteriaChip(
                  label: 'Lexical Resource',
                  band: eval.lexicalBand,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _CriteriaChip(
                  label: 'Grammar Range',
                  band: eval.grammarBand,
                ),
              ),
            ],
          ),
          const Divider(height: 24),
          const Text(
            '📋 Nhận xét & Sửa lỗi Chi tiết:',
            style: TextStyle(
              fontWeight: FontWeight.w800,
              fontSize: 14.5,
              color: AppTheme.cyanPrimary,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            eval.feedbackMarkdown,
            style: const TextStyle(
              fontSize: 13.5,
              height: 1.5,
              color: AppTheme.textPrimary,
            ),
          ),
          if (eval.upgradedEssay.isNotEmpty) ...<Widget>[
            const Divider(height: 24),
            Row(
              children: <Widget>[
                const Expanded(
                  child: Text(
                    '✨ Bản viết nâng cấp chuẩn Band 8.0+ (Academic Upgrade):',
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 14.5,
                      color: AppTheme.goldAccent,
                    ),
                  ),
                ),
                IconButton(
                  onPressed: () => widget.viewModel.tts.speak(
                    eval.upgradedEssay,
                    id: 'upgraded_essay',
                  ),
                  icon: const Icon(
                    Icons.volume_up_rounded,
                    color: AppTheme.cyanPrimary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppTheme.bgSurface,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Text(
                eval.upgradedEssay,
                style: const TextStyle(
                  fontSize: 14,
                  height: 1.55,
                  color: AppTheme.textPrimary,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _CriteriaChip extends StatelessWidget {
  const _CriteriaChip({
    required this.label,
    required this.band,
  });

  final String label;
  final double band;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.borderSubtle),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Flexible(
            child: Text(
              label,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 12.5,
                color: AppTheme.textSecondary,
              ),
            ),
          ),
          Text(
            band.toStringAsFixed(1),
            style: const TextStyle(
              fontWeight: FontWeight.w900,
              fontSize: 14,
              color: AppTheme.cyanPrimary,
            ),
          ),
        ],
      ),
    );
  }
}
