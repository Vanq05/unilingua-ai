import 'package:flutter/material.dart';

import '../../../data/repositories/curriculum_repository.dart';
import '../../../domain/models/learning_models.dart';
import '../../theme/app_theme.dart';
import '../../view_models/learning_view_model.dart';

class WritingScreen extends StatefulWidget {
  const WritingScreen({
    super.key,
    required this.viewModel,
  });

  final LearningViewModel viewModel;

  @override
  State<WritingScreen> createState() => _WritingScreenState();
}

class _WritingScreenState extends State<WritingScreen> {
  int _selectedPromptIndex = 0;
  final TextEditingController _essayCtrl = TextEditingController();
  WritingEvaluation? _latestEvaluation;

  @override
  void initState() {
    super.initState();
    _essayCtrl.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _essayCtrl.dispose();
    super.dispose();
  }

  int get _wordCount {
    final trimmed = _essayCtrl.text.trim();
    if (trimmed.isEmpty) return 0;
    return trimmed.split(RegExp(r'\s+')).length;
  }

  void _fillSampleDraft(WritingPrompt prompt) {
    if (prompt.id == 'wrt_a1_1') {
      _essayCtrl.text =
          'Hi, my name is Minh and I am a university student. I am twenty years old. In my free time, I like listening to music and drinking coffee with my friends. I want to learn English because it helps me communicate better and find a good job.';
    } else if (prompt.id == 'wrt_a2_2') {
      _essayCtrl.text =
          'Every morning, I wake up at 7 AM and eat breakfast before going to school. In the afternoon, I study at the library or play sports with my classmates. In the evening, I practice English for 20 minutes and listen to music before sleeping.';
    } else {
      _essayCtrl.text =
          'Dear Teacher,\n\nI am writing to let you know that I cannot attend tomorrow\'s English class because I have a fever. Could you please tell me if there is any homework for this week?\n\nThank you for your understanding.\nBest regards,\nMinh';
    }
  }

  Future<void> _submitForAiGrading(WritingPrompt prompt) async {
    final text = _essayCtrl.text.trim();
    if (text.length < 20) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Vui lòng viết ít nhất 1-2 câu tiếng Anh để AI chấm bài.'),
        ),
      );
      return;
    }
    final evaluation = await widget.viewModel.evaluateWritingSubmission(
      prompt: prompt,
      essayText: text,
    );
    if (!mounted) return;
    setState(() {
      _latestEvaluation = evaluation;
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.viewModel,
      builder: (context, _) {
        final prompts = CurriculumRepository.writingPrompts;
        final prompt = prompts[_selectedPromptIndex];

        return Scaffold(
          appBar: AppBar(
            title: Text(
              '✍️ Phòng Luyện Viết & AI Chấm Luận',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17),
            ),
          ),
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                // Prompt Selector
                SizedBox(
                  height: 82,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: prompts.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 10),
                    itemBuilder: (context, index) {
                      final item = prompts[index];
                      final selected = index == _selectedPromptIndex;
                      return InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: () => setState(() {
                          _selectedPromptIndex = index;
                          _latestEvaluation = null;
                        }),
                        child: Container(
                          width: 245,
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: selected
                                ? AppTheme.violetAccent.withValues(alpha: 0.2)
                                : AppPalette.of(context).card,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: selected
                                  ? AppTheme.violetAccent
                                  : AppPalette.of(context).border,
                              width: selected ? 1.6 : 1,
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                item.title,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontSize: 13.5,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '${item.cefrLevel} • ${item.category}',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 16),

                // Writing Prompt & Structure Guide Card
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: AppPalette.of(context).card,
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: AppPalette.of(context).border),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color:
                                  AppTheme.violetAccent.withValues(alpha: 0.2),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              '${prompt.category} • ${prompt.cefrLevel}',
                              style: TextStyle(),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(
                        prompt.promptEn,
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w800,
                          height: 1.45,
                        ),
                      ),
                      const Divider(height: 20),
                      Text(
                        prompt.guideVi,
                        style: TextStyle(),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        'Cấu trúc ăn điểm Band 7.5+ (Bấm để chèn vào bài viết):',
                        style: TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.goldAccent,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: prompt.keyStructures.map((s) {
                          return ActionChip(
                            backgroundColor: AppPalette.of(context).bg,
                            label: Text(
                              s,
                              style: TextStyle(fontSize: 12),
                            ),
                            onPressed: () {
                              final current = _essayCtrl.text;
                              _essayCtrl.text = current.isEmpty
                                  ? s
                                  : '$current $s';
                            },
                          );
                        }).toList(),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // Essay Editor
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Text(
                      'Bài viết của bạn ($_wordCount từ / Gợi ý ≥${prompt.minWords} từ)',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 14,
                      ),
                    ),
                    TextButton.icon(
                      onPressed: () => _fillSampleDraft(prompt),
                      icon: Icon(Icons.auto_fix_high_rounded, size: 16),
                      label: Text('Điền bài mẫu thử nghiệm'),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                TextField(
                  controller: _essayCtrl,
                  minLines: 7,
                  maxLines: 14,
                  decoration: InputDecoration(
                    hintText:
                        'Viết bài luận hoặc email học thuật bằng tiếng Anh tại đây để AI chấm điểm theo 4 tiêu chí IELTS và sửa từng lỗi...',
                  ),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: ElevatedButton.icon(
                    onPressed: widget.viewModel.isGradingWriting
                        ? null
                        : () => _submitForAiGrading(prompt),
                    icon: widget.viewModel.isGradingWriting
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Color(0xFF04101E),
                            ),
                          )
                        : Icon(Icons.grade_rounded),
                    label: Text(
                      widget.viewModel.isGradingWriting
                          ? 'Giám khảo AI đang chấm điểm & sửa bài...'
                          : 'Chấm Điểm Band IELTS & Nâng Cấp Bài Viết (+50 XP)',
                    ),
                  ),
                ),

                // AI Evaluation Result Card
                if (_latestEvaluation != null) ...<Widget>[
                  const SizedBox(height: 22),
                  _buildEvaluationCard(_latestEvaluation!),
                ],
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildEvaluationCard(WritingEvaluation eval) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: <Color>[AppPalette.of(context).cardElevated, AppPalette.of(context).card]),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: AppTheme.goldAccent.withValues(alpha: 0.5),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: AppTheme.goldAccent,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Text(
                  'Overall Band ${eval.overallBand.toStringAsFixed(1)}',
                  style: TextStyle(
                    color: Color(0xFF04101E),
                    fontWeight: FontWeight.w900,
                    fontSize: 16,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Kết quả Chấm thi AI IELTS & Academic Rubric',
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 15,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: <Widget>[
              Expanded(
                child: _CriteriaChip(
                  label: 'Task Response',
                  band: eval.taskResponseBand,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _CriteriaChip(
                  label: 'Coherence',
                  band: eval.coherenceBand,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: <Widget>[
              Expanded(
                child: _CriteriaChip(
                  label: 'Lexical Resource',
                  band: eval.lexicalBand,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _CriteriaChip(
                  label: 'Grammar Range',
                  band: eval.grammarBand,
                ),
              ),
            ],
          ),
          const Divider(height: 24),
          Text(
            '📋 Nhận xét & Sửa lỗi:',
            style: TextStyle(
              fontWeight: FontWeight.w800,
              fontSize: 14.5,
              color: AppPalette.of(context).primary,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            eval.feedbackMarkdown,
            style: TextStyle(),
          ),
          if (eval.upgradedEssay.isNotEmpty) ...<Widget>[
            const Divider(height: 24),
            Row(
              children: <Widget>[
                Expanded(
                  child: Text(
                    '✨ Bản viết nâng cấp chuẩn Band 8.0+ (Academic Upgrade):',
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 14.5,
                      color: AppTheme.goldAccent,
                    ),
                  ),
                ),
                IconButton(
                  onPressed: () => widget.viewModel.tts.speak(
                    eval.upgradedEssay,
                    id: 'upgraded_essay',
                  ),
                  icon: Icon(
                    Icons.volume_up_rounded,
                    color: AppPalette.of(context).primary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppPalette.of(context).bg,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Text(
                eval.upgradedEssay,
                style: TextStyle(),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _CriteriaChip extends StatelessWidget {
  const _CriteriaChip({
    required this.label,
    required this.band,
  });

  final String label;
  final double band;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: AppPalette.of(context).card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppPalette.of(context).border),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Flexible(
            child: Text(
              label,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(),
            ),
          ),
          Text(
            band.toStringAsFixed(1),
            style: TextStyle(),
          ),
        ],
      ),
    );
  }
}
