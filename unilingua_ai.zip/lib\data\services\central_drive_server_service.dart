import 'dart:convert';

import 'package:http/http.dart' as http;

import '../../domain/models/learning_models.dart';
import 'secret_vault.dart';

/// Connects the mobile app to ONE fixed central Google Drive Server Database
/// (deployed via Google Apps Script Web App) so ALL users' learning progress
/// is stored centrally in the owner's fixed Google Drive.
class CentralDriveServerService {
  const CentralDriveServerService();

  static const String _sharedSecret = 'UL_DB_2026_SECURE_KEY_9981';

  bool get isConfigured => SecretVault.driveServerUrl.startsWith('https://');

  /// Loads a user's progress state from the central Google Drive Database.
  Future<StudentProgressState?> loadUserState(String email) async {
    if (!isConfigured || email.trim().isEmpty) return null;
    try {
      final resp = await _postFollowingRedirects(
        Uri.parse(SecretVault.driveServerUrl),
        <String, dynamic>{
          'secret': _sharedSecret,
          'action': 'load',
          'email': email.trim().toLowerCase(),
        },
      );
      if (resp == null || resp.statusCode != 200) return null;

      final decoded = jsonDecode(resp.body) as Map<String, dynamic>;
      if (decoded['ok'] != true || decoded['found'] != true) return null;
      final data = decoded['data'] as Map<String, dynamic>?;
      if (data == null) return null;
      return StudentProgressState.fromJson(data);
    } catch (_) {
      return null;
    }
  }

  /// Saves/updates a user's progress state into the central Google Drive Database.
  Future<bool> saveUserState(StudentProgressState state) async {
    if (!isConfigured) return false;
    try {
      final resp = await _postFollowingRedirects(
        Uri.parse(SecretVault.driveServerUrl),
        <String, dynamic>{
          'secret': _sharedSecret,
          'action': 'save',
          'email': state.user.email.trim().toLowerCase(),
          'data': state.toJson(),
        },
      );
      if (resp == null || resp.statusCode != 200) return false;
      final decoded = jsonDecode(resp.body) as Map<String, dynamic>;
      return decoded['ok'] == true && decoded['saved'] == true;
    } catch (_) {
      return false;
    }
  }

  /// Google Apps Script Web Apps respond to POST with a 302 redirect to a
  /// googleusercontent.com URL that must be followed with GET to read the JSON result.
  Future<http.Response?> _postFollowingRedirects(
    Uri url,
    Map<String, dynamic> payload,
  ) async {
    final client = http.Client();
    try {
      final req = http.Request('POST', url)
        ..followRedirects = false
        ..headers['Content-Type'] = 'application/json; charset=UTF-8'
        ..body = jsonEncode(payload);

      final streamed =
          await client.send(req).timeout(const Duration(seconds: 15));
      if (streamed.statusCode == 302 ||
          streamed.statusCode == 301 ||
          streamed.statusCode == 303) {
        final location = streamed.headers['location'];
        if (location == null || location.isEmpty) return null;
        return await client
            .get(Uri.parse(location))
            .timeout(const Duration(seconds: 15));
      }
      return await http.Response.fromStream(streamed);
    } finally {
      client.close();
    }
  }
}
