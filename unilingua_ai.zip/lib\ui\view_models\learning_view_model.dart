import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';

import '../../data/repositories/curriculum_repository.dart';
import '../../data/services/ai_tutor_service.dart';
import '../../data/services/google_auth_service.dart';
import '../../data/services/progress_storage_service.dart';
import '../../data/services/speech_tts_service.dart';
import '../../domain/models/learning_models.dart';

class RoleplayTurn {
  const RoleplayTurn({
    required this.isUser,
    required this.text,
  });

  final bool isUser;
  final String text;
}

class LearningViewModel extends ChangeNotifier {
  LearningViewModel({
    ProgressStorageService? storage,
    GoogleAuthService? googleAuth,
    AiTutorService? aiTutor,
    SpeechTtsService? tts,
  })  : _storage = storage ?? const ProgressStorageService(),
        _googleAuth = googleAuth ?? GoogleAuthService(),
        _aiTutor = aiTutor ?? AiTutorService(),
        tts = tts ?? SpeechTtsService();

  final ProgressStorageService _storage;
  final GoogleAuthService _googleAuth;
  final AiTutorService _aiTutor;
  final SpeechTtsService tts;

  bool _isInitializing = true;
  bool _isBusy = false;
  StudentProgressState? _state;
  List<GoogleUserProfile> _knownAccounts = const <GoogleUserProfile>[];

  // Keeps the newly registered student on the Placement Result & Roadmap screen
  // until they finish reviewing their diagnostic report and tap "Start Learning".
  bool _isReviewingPlacementResult = false;
  bool _isGradingPlacementExam = false;

  // Dynamic lessons & quizzes (built-in + AI generated during session)
  final List<ListeningLesson> _customListeningLessons = <ListeningLesson>[];
  final List<ReadingPassage> _customReadingPassages = <ReadingPassage>[];
  List<DailyQuizQuestion> _dailyQuizQuestions =
      CurriculumRepository.defaultDailyQuiz;
  bool _isGeneratingAiContent = false;

  // Speaking Roleplay state
  final Map<String, List<RoleplayTurn>> _roleplayHistories =
      <String, List<RoleplayTurn>>{};
  bool _isRoleplayStreaming = false;

  // Writing grader state
  bool _isGradingWriting = false;

  bool get isInitializing => _isInitializing;
  bool get isBusy => _isBusy;
  bool get isSignedIn => _state != null;
  StudentProgressState? get state => _state;
  List<GoogleUserProfile> get knownAccounts => _knownAccounts;
  bool get isReviewingPlacementResult => _isReviewingPlacementResult;
  bool get isGradingPlacementExam => _isGradingPlacementExam;
  bool get isGeneratingAiContent => _isGeneratingAiContent;
  bool get isRoleplayStreaming => _isRoleplayStreaming;
  bool get isGradingWriting => _isGradingWriting;

  List<ListeningLesson> get listeningLessons => <ListeningLesson>[
        ..._customListeningLessons,
        ...CurriculumRepository.listeningLessons,
      ];

  List<ReadingPassage> get readingPassages => <ReadingPassage>[
        ..._customReadingPassages,
        ...CurriculumRepository.readingPassages,
      ];

  List<DailyQuizQuestion> get dailyQuizQuestions => _dailyQuizQuestions;

  Future<void> initialize() async {
    _isInitializing = true;
    notifyListeners();

    try {
      _knownAccounts = await _storage.loadKnownGoogleAccounts();
      final activeEmail = await _storage.loadActiveEmail();
      if (activeEmail != null) {
        final loaded = await _storage.loadProgressForEmail(activeEmail);
        if (loaded != null) {
          _state = _refreshStreakAndDailyQuests(loaded);
          await _storage.saveProgress(_state!);
        }
      }
      unawaited(_aiTutor.ensureModelInitialized());
    } finally {
      _isInitializing = false;
      notifyListeners();
    }
  }

  StudentProgressState _refreshStreakAndDailyQuests(
      StudentProgressState current) {
    final today = StudentProgressState.todayKey();
    var streak = current.streakDays;
    if (current.lastActiveDate.isNotEmpty && current.lastActiveDate != today) {
      final lastDate = DateTime.tryParse(current.lastActiveDate);
      final nowDate = DateTime.tryParse(today);
      if (lastDate != null && nowDate != null) {
        final diff = nowDate.difference(lastDate).inDays;
        if (diff == 1) {
          streak += 1;
        } else if (diff > 1) {
          streak = 1;
        }
      }
    }
    return current.copyWith(
      streakDays: streak < 1 ? 1 : streak,
      lastActiveDate: today,
      questsDate: today,
    );
  }

  /// Attempts native Google Sign-In. Returns null if the user needs to pick/enter
  /// their Google account via the built-in Google Account Modal.
  Future<GoogleUserProfile?> tryNativeGoogleSignIn() async {
    _isBusy = true;
    notifyListeners();
    try {
      return await _googleAuth.tryNativeGoogleSignIn();
    } finally {
      _isBusy = false;
      notifyListeners();
    }
  }

  /// Signs in with a Google profile (from native Google Sign-In or built-in chooser)
  /// and restores any existing progress for that email.
  Future<void> signInWithGoogleProfile(GoogleUserProfile profile) async {
    _isBusy = true;
    _isReviewingPlacementResult = false;
    notifyListeners();
    try {
      final existing = await _storage.loadProgressForEmail(profile.email);
      if (existing != null) {
        _state = _refreshStreakAndDailyQuests(
          existing.copyWith(
            user: profile.copyWith(
              universityName: profile.universityName.isNotEmpty
                  ? profile.universityName
                  : existing.user.universityName,
              academicYear: profile.academicYear.isNotEmpty
                  ? profile.academicYear
                  : existing.user.academicYear,
              majorField: profile.majorField.isNotEmpty
                  ? profile.majorField
                  : existing.user.majorField,
              targetGoal: profile.targetGoal.isNotEmpty
                  ? profile.targetGoal
                  : existing.user.targetGoal,
              dailyTargetMinutes: profile.dailyTargetMinutes > 0
                  ? profile.dailyTargetMinutes
                  : existing.user.dailyTargetMinutes,
            ),
          ),
        );
      } else {
        final today = StudentProgressState.todayKey();
        _state = StudentProgressState(
          user: profile,
          streakDays: 1,
          lastActiveDate: today,
          questsDate: today,
          dailyQuests: StudentProgressState.defaultQuestsForToday(),
          savedVocab: <VocabFlashcard>[
            ...CurriculumRepository.listeningLessons.first.keyVocab,
            ...CurriculumRepository.readingPassages.first.highlights,
          ],
        );
      }
      await _storage.saveProgress(_state!);
      _knownAccounts = await _storage.loadKnownGoogleAccounts();
    } finally {
      _isBusy = false;
      notifyListeners();
    }
  }

  Future<void> updateUniversityProfile({
    required String universityName,
    required String academicYear,
    required String majorField,
    required String targetGoal,
    required int dailyTargetMinutes,
  }) async {
    if (_state == null) return;
    final updatedUser = _state!.user.copyWith(
      universityName: universityName.trim().isNotEmpty
          ? universityName.trim()
          : _state!.user.universityName,
      academicYear: academicYear,
      majorField: majorField,
      targetGoal: targetGoal,
      dailyTargetMinutes: dailyTargetMinutes,
    );
    _state = _state!.copyWith(user: updatedUser);
    await _storage.saveProgress(_state!);
    _knownAccounts = await _storage.loadKnownGoogleAccounts();
    notifyListeners();
  }

  Future<void> signOut() async {
    await tts.stop();
    await _googleAuth.signOut();
    await _storage.saveActiveEmail(null);
    _state = null;
    _isReviewingPlacementResult = false;
    notifyListeners();
  }

  /// Marks that the student has reviewed their Placement Report & 12-Week Roadmap
  /// and is ready to enter the main Home Dashboard.
  void completePlacementReview() {
    _isReviewingPlacementResult = false;
    notifyListeners();
  }

  /// Grades the 5-section University Placement Exam (17 MCQs + Dictation + Real Speaking + Real Writing),
  /// asks the hidden AI Tutor to evaluate the student's actual Speaking & Writing productions and craft
  /// a bespoke 12-week roadmap + daily schedule, and keeps the UI on the diagnostic reveal screen.
  Future<PlacementTestResult> submitPlacementExam(
    PlacementSubmissionPayload submission,
  ) async {
    final current = _state!;
    _isGradingPlacementExam = true;
    _isReviewingPlacementResult = true;
    notifyListeners();

    try {
      // 1. Objective + adaptive heuristic baseline (works even if offline)
      var result = CurriculumRepository.evaluatePlacementSubmission(
        submission: submission,
        user: current.user,
      );

      // 2. Call AI Tutor to deeply grade real Speaking & Writing answers and build custom 12-week roadmap
      final aiEnhanced = await _requestAiPlacementGradingAndRoadmap(
        baseResult: result,
        submission: submission,
        user: current.user,
      );
      if (aiEnhanced != null) {
        result = aiEnhanced;
      }

      // 3. Adapt Daily Quests immediately to prioritize the student's weakest skill from the exam
      final adaptiveQuests = StudentProgressState.adaptiveQuestsForToday(
        weakestSkill: result.weakestSkill,
        cefr: result.cefrLevel,
      );

      _state = current.copyWith(
        placementResult: result,
        listeningSkillScore: result.listeningScore,
        speakingSkillScore: result.speakingScore,
        readingSkillScore: result.readingScore,
        writingSkillScore: result.writingScore,
        dailyQuests: adaptiveQuests,
        totalXp: current.totalXp + 150,
        todayXp: current.todayXp + 150,
      );
      await _storage.saveProgress(_state!);
      return result;
    } finally {
      _isGradingPlacementExam = false;
      notifyListeners();
    }
  }

  Future<PlacementTestResult?> _requestAiPlacementGradingAndRoadmap({
    required PlacementTestResult baseResult,
    required PlacementSubmissionPayload submission,
    required GoogleUserProfile user,
  }) async {
    try {
      final mistakeSummary = baseResult.mistakes.isEmpty
          ? 'Không sai câu trắc nghiệm nào!'
          : baseResult.mistakes
              .map((m) => '- [${m.skill.shortVi} | ${m.cefrDifficulty}] ${m.topicTag}')
              .join('\n');

      final raw = await _aiTutor
          .completeText(
            systemPrompt:
                'Bạn là Giám đốc Học thuật & Giám khảo IELTS/CEFR của UniLingua dành riêng cho sinh viên đại học Việt Nam.\n'
                'Dựa trên kết quả bài test đầu vào 5 phần THỰC TẾ của sinh viên (gồm điểm trắc nghiệm từng phần, các câu làm sai, bài chép chính tả, 2 câu trả lời Nói thực tế và 1 đoạn luận Viết thực tế), hãy chấm điểm thật nghiêm túc và thiết kế lộ trình 12 tuần tối ưu nhất.\n'
                'BẮT BUỘC trả về DUY NHẤT 1 JSON object hợp lệ (không thêm văn bản thừa bên ngoài JSON) với cấu trúc:\n'
                '{\n'
                '  "speakingScore": 65,\n'
                '  "writingScore": 62,\n'
                '  "aiDiagnosticSummary": "Phân tích tổng quan sắc bén 120-160 từ bằng tiếng Việt chỉ rõ trình độ hiện tại, nguyên nhân yếu và chiến lược bứt phá riêng cho sinh viên này",\n'
                '  "speakingFeedbackVi": "Chấm & nhận xét cụ thể 2 câu trả lời Speaking thực tế của sinh viên (chỉ lỗi diễn đạt/từ vựng và câu mẫu nâng cấp)",\n'
                '  "writingFeedbackVi": "Chấm & sửa lỗi trực tiếp đoạn Writing thực tế sinh viên vừa viết (chỉ rõ lỗi ngữ pháp/từ nối và cách sửa chuẩn học thuật)",\n'
                '  "keyStrengths": ["Điểm mạnh 1", "Điểm mạnh 2"],\n'
                '  "criticalGaps": ["Lỗ hổng 1 cần vá ngay", "Lỗ hổng 2", "Lỗ hổng 3"],\n'
                '  "roadmapPhases": [\n'
                '    {\n'
                '      "weekRange": "Giai đoạn 1 • Tuần 1 - 3",\n'
                '      "title": "...",\n'
                '      "focusGoal": "...",\n'
                '      "listeningTask": "...",\n'
                '      "speakingTask": "...",\n'
                '      "readingTask": "...",\n'
                '      "writingTask": "...",\n'
                '      "milestone": "..."\n'
                '    }\n'
                '  ]\n'
                '}\n'
                'Lưu ý: "roadmapPhases" phải có đúng 4 giai đoạn (Tuần 1-3, Tuần 4-6, Tuần 7-9, Tuần 10-12) được cá nhân hóa sâu theo đúng chuyên ngành, năm học, quỹ thời gian mỗi ngày và các câu sai của sinh viên.',
            userPrompt:
                'HỒ SƠ SINH VIÊN:\n'
                '- Họ tên: ${user.displayName} (${user.universityName})\n'
                '- Năm học: ${user.academicYear}\n'
                '- Chuyên ngành: ${user.majorField}\n'
                '- Mục tiêu đầu ra: ${user.targetGoal}\n'
                '- Quỹ thời gian học mỗi ngày: ${user.dailyTargetMinutes} phút/ngày\n\n'
                'KẾT QUẢ PHẦN KHÁCH QUAN:\n'
                '- Đúng ${baseResult.objectiveCorrectCount}/${baseResult.objectiveTotalCount} câu (A2 đến C1)\n'
                '- Điểm Listening sơ bộ: ${baseResult.listeningScore}/100 (Dictation chính xác ${baseResult.dictationAccuracyPercent}%)\n'
                '- Điểm Reading: ${baseResult.readingScore}/100\n'
                '- Các chuyên đề làm sai:\n$mistakeSummary\n\n'
                'BÀI NÓI THỰC TẾ CỦA SINH VIÊN (SPEAKING PRODUCTION):\n'
                '- Câu 1 (Giới thiệu bản thân & chuyên ngành): "${submission.speakingIntroAnswer.trim().isEmpty ? "(Bỏ trống)" : submission.speakingIntroAnswer.trim()}"\n'
                '- Câu 2 (Quan điểm học môn đại học bằng tiếng Anh): "${submission.speakingOpinionAnswer.trim().isEmpty ? "(Bỏ trống)" : submission.speakingOpinionAnswer.trim()}"\n\n'
                'BÀI VIẾT THỰC TẾ CỦA SINH VIÊN (WRITING PRODUCTION):\n'
                '- Đề bài: ${CurriculumRepository.placementWritingPrompt}\n'
                '- Bài làm: "${submission.writingEssayAnswer.trim().isEmpty ? "(Bỏ trống)" : submission.writingEssayAnswer.trim()}"',
            temperature: 0.55,
          )
          .timeout(const Duration(seconds: 28));

      final jsonStr = _extractJsonPayload(raw, isArray: false);
      final map = jsonDecode(jsonStr) as Map<String, dynamic>;

      final aiSpk = ((map['speakingScore'] as num?)?.toInt() ??
              baseResult.speakingScore)
          .clamp(25, 98);
      final aiWrt = ((map['writingScore'] as num?)?.toInt() ??
              baseResult.writingScore)
          .clamp(25, 98);

      // Blend AI production score with objective test scores for stability
      final finalSpk =
          ((baseResult.speakingScore * 0.35) + (aiSpk * 0.65)).round().clamp(25, 98);
      final finalWrt =
          ((baseResult.writingScore * 0.35) + (aiWrt * 0.65)).round().clamp(25, 98);
      final avg = ((baseResult.listeningScore +
                  finalSpk +
                  baseResult.readingScore +
                  finalWrt) /
              4)
          .round();
      final bands = CurriculumRepository.mapScoreToCefrIeltsToeic(avg);

      final parsedPhases = (map['roadmapPhases'] as List<dynamic>?)
              ?.whereType<Map<String, dynamic>>()
              .map(RoadmapPhase.fromJson)
              .where((p) => p.title.isNotEmpty)
              .toList() ??
          const <RoadmapPhase>[];

      final strengths = (map['keyStrengths'] as List<dynamic>?)
              ?.map((e) => e.toString())
              .where((s) => s.trim().isNotEmpty)
              .toList() ??
          baseResult.keyStrengths;

      final gaps = (map['criticalGaps'] as List<dynamic>?)
              ?.map((e) => e.toString())
              .where((s) => s.trim().isNotEmpty)
              .toList() ??
          baseResult.criticalGaps;

      final updatedSchedule = CurriculumRepository.buildAdaptiveDailySchedule(
        totalMinutes: user.dailyTargetMinutes,
        lScore: baseResult.listeningScore,
        sScore: finalSpk,
        rScore: baseResult.readingScore,
        wScore: finalWrt,
        major: user.majorField,
      );

      return baseResult.copyWith(
        speakingScore: finalSpk,
        writingScore: finalWrt,
        cefrLevel: bands.cefr,
        estimatedIelts: bands.ielts,
        estimatedToeic: bands.toeic,
        aiDiagnosticSummary:
            (map['aiDiagnosticSummary'] as String?)?.trim().isNotEmpty == true
                ? (map['aiDiagnosticSummary'] as String).trim()
                : baseResult.aiDiagnosticSummary,
        speakingFeedbackVi:
            (map['speakingFeedbackVi'] as String?)?.trim().isNotEmpty == true
                ? (map['speakingFeedbackVi'] as String).trim()
                : baseResult.speakingFeedbackVi,
        writingFeedbackVi:
            (map['writingFeedbackVi'] as String?)?.trim().isNotEmpty == true
                ? (map['writingFeedbackVi'] as String).trim()
                : baseResult.writingFeedbackVi,
        keyStrengths: strengths,
        criticalGaps: gaps,
        dailySchedule: updatedSchedule,
        roadmapPhases:
            parsedPhases.length >= 3 ? parsedPhases : baseResult.roadmapPhases,
        generatedByAi: true,
      );
    } catch (_) {
      return null;
    }
  }

  /// Awards XP, updates the corresponding Daily Quest, and boosts skill score.
  Future<void> recordActivityCompletion({
    required String questId,
    required SkillType skill,
    required int baseXp,
    String? lessonId,
    int skillBoost = 2,
  }) async {
    if (_state == null) return;
    final current = _state!;

    var bonusXp = baseXp;
    final updatedQuests = current.dailyQuests.map((q) {
      if (q.id == questId && !q.isCompleted) {
        final nextCount = q.currentCount + 1;
        if (nextCount >= q.targetCount) {
          bonusXp += q.xpReward;
        }
        return q.copyWith(currentCount: nextCount);
      }
      return q;
    }).toList();

    final completedIds = <String>{
      ...current.completedLessonIds,
      if (lessonId != null && lessonId.isNotEmpty) lessonId,
    }.toList();

    var lScore = current.listeningSkillScore;
    var sScore = current.speakingSkillScore;
    var rScore = current.readingSkillScore;
    var wScore = current.writingSkillScore;

    switch (skill) {
      case SkillType.listening:
        lScore = (lScore + skillBoost).clamp(0, 100);
        break;
      case SkillType.speaking:
        sScore = (sScore + skillBoost).clamp(0, 100);
        break;
      case SkillType.reading:
        rScore = (rScore + skillBoost).clamp(0, 100);
        break;
      case SkillType.writing:
        wScore = (wScore + skillBoost).clamp(0, 100);
        break;
    }

    _state = current.copyWith(
      totalXp: current.totalXp + bonusXp,
      todayXp: current.todayXp + bonusXp,
      dailyQuests: updatedQuests,
      dailyQuizCompletedToday:
          questId == 'q_quiz' ? true : current.dailyQuizCompletedToday,
      completedLessonIds: completedIds,
      listeningSkillScore: lScore,
      speakingSkillScore: sScore,
      readingSkillScore: rScore,
      writingSkillScore: wScore,
    );
    await _storage.saveProgress(_state!);
    notifyListeners();
  }

  /// Saves or toggles mastery of a vocabulary flashcard in the user's personal deck.
  Future<void> saveVocabFlashcard(VocabFlashcard card) async {
    if (_state == null) return;
    final existing = _state!.savedVocab;
    final index = existing.indexWhere(
      (v) => v.word.toLowerCase() == card.word.toLowerCase(),
    );
    List<VocabFlashcard> updated;
    if (index >= 0) {
      updated = List<VocabFlashcard>.from(existing);
      updated[index] = card;
    } else {
      updated = <VocabFlashcard>[card, ...existing];
    }
    _state = _state!.copyWith(
      savedVocab: updated,
      totalXp: _state!.totalXp + 5,
      todayXp: _state!.todayXp + 5,
    );
    await _storage.saveProgress(_state!);
    notifyListeners();
  }

  Future<void> toggleVocabMastery(String word) async {
    if (_state == null) return;
    final updated = _state!.savedVocab.map((v) {
      if (v.word.toLowerCase() == word.toLowerCase()) {
        return v.copyWith(isMastered: !v.isMastered);
      }
      return v;
    }).toList();
    _state = _state!.copyWith(savedVocab: updated);
    await _storage.saveProgress(_state!);
    notifyListeners();
  }

  /// Generates a fresh 5-question AI Daily Workout Quiz tailored to the student's major & CEFR.
  Future<bool> generateAiDailyWorkout() async {
    if (_state == null || _isGeneratingAiContent) return false;
    _isGeneratingAiContent = true;
    notifyListeners();

    try {
      final user = _state!.user;
      final cefr = _state!.currentCefr;
      final raw = await _aiTutor.completeText(
        systemPrompt:
            'You generate high-quality university English daily workout multiple-choice questions. Return ONLY a valid JSON array of 5 objects with keys: "question", "options" (array of 4 strings), "correctIndex" (0-3), "explanationVi" (Vietnamese explanation), "skillTag". Do not wrap in markdown code fences if possible.',
        userPrompt:
            'Create 5 university-level English questions (CEFR $cefr) tailored for a Vietnamese university student majoring in "${user.majorField}" with goal "${user.targetGoal}". Include Academic Vocabulary, Advanced Grammar, Reading Inference, Spoken Academic Discourse, and Writing Cohesion.',
        temperature: 0.7,
      );

      final jsonStr = _extractJsonPayload(raw, isArray: true);
      final decoded = jsonDecode(jsonStr) as List<dynamic>;
      final questions = decoded
          .whereType<Map<String, dynamic>>()
          .map(DailyQuizQuestion.fromJson)
          .where((q) => q.question.isNotEmpty && q.options.length >= 2)
          .toList();

      if (questions.isNotEmpty) {
        _dailyQuizQuestions = questions;
        return true;
      }
      return false;
    } catch (_) {
      return false;
    } finally {
      _isGeneratingAiContent = false;
      notifyListeners();
    }
  }

  /// Generates a custom AI Listening Lesson on any topic chosen by the university student.
  Future<ListeningLesson?> generateAiListeningLesson(String topic) async {
    if (_state == null || _isGeneratingAiContent) return null;
    _isGeneratingAiContent = true;
    notifyListeners();

    try {
      final cefr = _state!.currentCefr;
      final major = _state!.user.majorField;
      final raw = await _aiTutor.completeText(
        systemPrompt:
            'You are a university English listening curriculum designer. Return ONLY a valid JSON object with keys: "title", "audioTranscript" (70-100 words English academic lecture/dialogue), "vietnameseTranslation", "dictationSentence" (1 key sentence from transcript), "keyVocab" (array of 2 objects with "word", "ipa", "partOfSpeech", "meaningVi", "exampleEn"), "questions" (array of 2 objects with "question" in Vietnamese, "options" array of 4 strings, "correctIndex" 0-3, "explanationVi").',
        userPrompt:
            'Generate an engaging CEFR $cefr university listening lesson about "$topic" (relevant to $major).',
        temperature: 0.7,
      );

      final jsonStr = _extractJsonPayload(raw, isArray: false);
      final map = jsonDecode(jsonStr) as Map<String, dynamic>;

      final vocabList = (map['keyVocab'] as List<dynamic>?)
              ?.whereType<Map<String, dynamic>>()
              .map(VocabFlashcard.fromJson)
              .toList() ??
          const <VocabFlashcard>[];

      final qList = (map['questions'] as List<dynamic>?)
              ?.whereType<Map<String, dynamic>>()
              .map(
                (q) => ComprehensionMcq(
                  question: q['question'] as String? ?? '',
                  options: (q['options'] as List<dynamic>?)
                          ?.map((e) => e.toString())
                          .toList() ??
                      const <String>['A', 'B', 'C', 'D'],
                  correctIndex: q['correctIndex'] as int? ?? 0,
                  explanationVi: q['explanationVi'] as String? ?? '',
                ),
              )
              .toList() ??
          const <ComprehensionMcq>[];

      final lesson = ListeningLesson(
        id: 'ai_lis_${DateTime.now().millisecondsSinceEpoch}',
        title: map['title'] as String? ?? 'AI Lecture: $topic',
        category: 'AI Tạo theo chuyên ngành • $major',
        cefrLevel: cefr,
        durationLabel: '2 phút',
        audioTranscript: map['audioTranscript'] as String? ?? '',
        vietnameseTranslation: map['vietnameseTranslation'] as String? ?? '',
        dictationSentence: map['dictationSentence'] as String? ?? '',
        keyVocab: vocabList,
        questions: qList,
      );

      if (lesson.audioTranscript.isNotEmpty) {
        _customListeningLessons.insert(0, lesson);
        return lesson;
      }
      return null;
    } catch (_) {
      return null;
    } finally {
      _isGeneratingAiContent = false;
      notifyListeners();
    }
  }

  /// Generates a custom AI Reading Passage on any university topic.
  Future<ReadingPassage?> generateAiReadingPassage(String topic) async {
    if (_state == null || _isGeneratingAiContent) return null;
    _isGeneratingAiContent = true;
    notifyListeners();

    try {
      final cefr = _state!.currentCefr;
      final major = _state!.user.majorField;
      final raw = await _aiTutor.completeText(
        systemPrompt:
            'You are a university academic reading author. Return ONLY a valid JSON object with keys: "title", "paragraphsEn" (array of 2-3 academic English paragraphs), "paragraphsVi" (array of matching Vietnamese translations), "highlights" (array of 3 objects with "word", "ipa", "partOfSpeech", "meaningVi", "exampleEn"), "questions" (array of 2 objects with "question" in Vietnamese, "options" array of 4 strings, "correctIndex" 0-3, "explanationVi").',
        userPrompt:
            'Write a CEFR $cefr university academic reading passage on "$topic" for a student in $major.',
        temperature: 0.7,
      );

      final jsonStr = _extractJsonPayload(raw, isArray: false);
      final map = jsonDecode(jsonStr) as Map<String, dynamic>;

      final passage = ReadingPassage(
        id: 'ai_read_${DateTime.now().millisecondsSinceEpoch}',
        title: map['title'] as String? ?? 'Academic Article: $topic',
        majorTag: 'AI Chuyên ngành • $major',
        cefrLevel: cefr,
        readingTimeLabel: '4 phút đọc',
        paragraphsEn: (map['paragraphsEn'] as List<dynamic>?)
                ?.map((e) => e.toString())
                .toList() ??
            const <String>[],
        paragraphsVi: (map['paragraphsVi'] as List<dynamic>?)
                ?.map((e) => e.toString())
                .toList() ??
            const <String>[],
        highlights: (map['highlights'] as List<dynamic>?)
                ?.whereType<Map<String, dynamic>>()
                .map(VocabFlashcard.fromJson)
                .toList() ??
            const <VocabFlashcard>[],
        questions: (map['questions'] as List<dynamic>?)
                ?.whereType<Map<String, dynamic>>()
                .map(
                  (q) => ComprehensionMcq(
                    question: q['question'] as String? ?? '',
                    options: (q['options'] as List<dynamic>?)
                            ?.map((e) => e.toString())
                            .toList() ??
                        const <String>['A', 'B', 'C', 'D'],
                    correctIndex: q['correctIndex'] as int? ?? 0,
                    explanationVi: q['explanationVi'] as String? ?? '',
                  ),
                )
                .toList() ??
            const <ComprehensionMcq>[],
      );

      if (passage.paragraphsEn.isNotEmpty) {
        _customReadingPassages.insert(0, passage);
        return passage;
      }
      return null;
    } catch (_) {
      return null;
    } finally {
      _isGeneratingAiContent = false;
      notifyListeners();
    }
  }

  /// Speaking Roleplay conversation turns for a given scenario.
  List<RoleplayTurn> turnsForScenario(RoleplayScenario scenario) {
    return _roleplayHistories.putIfAbsent(
      scenario.id,
      () => <RoleplayTurn>[
        RoleplayTurn(isUser: false, text: scenario.openingLineEn),
      ],
    );
  }

  void resetRoleplayScenario(RoleplayScenario scenario) {
    _roleplayHistories[scenario.id] = <RoleplayTurn>[
      RoleplayTurn(isUser: false, text: scenario.openingLineEn),
    ];
    notifyListeners();
  }

  Future<void> sendRoleplayMessage({
    required RoleplayScenario scenario,
    required String userText,
    bool autoSpeakReply = true,
  }) async {
    final trimmed = userText.trim();
    if (trimmed.isEmpty || _isRoleplayStreaming) return;

    final turns = List<RoleplayTurn>.from(turnsForScenario(scenario))
      ..add(RoleplayTurn(isUser: true, text: trimmed))
      ..add(const RoleplayTurn(isUser: false, text: ''));
    _roleplayHistories[scenario.id] = turns;
    _isRoleplayStreaming = true;
    notifyListeners();

    final historyPayload = <Map<String, String>>[];
    for (var i = 0; i < turns.length - 1; i++) {
      final t = turns[i];
      historyPayload.add(<String, String>{
        'role': t.isUser ? 'user' : 'assistant',
        'content': t.text,
      });
    }

    final buffer = StringBuffer();
    try {
      await for (final chunk in _aiTutor.streamMessages(
        systemPrompt: scenario.systemInstruction,
        messages: historyPayload,
        temperature: 0.7,
      )) {
        buffer.write(chunk);
        final currentTurns = List<RoleplayTurn>.from(turns);
        currentTurns[currentTurns.length - 1] = RoleplayTurn(
          isUser: false,
          text: buffer.toString(),
        );
        _roleplayHistories[scenario.id] = currentTurns;
        notifyListeners();
      }

      await recordActivityCompletion(
        questId: 'q_speak',
        skill: SkillType.speaking,
        baseXp: 15,
        skillBoost: 1,
      );

      if (autoSpeakReply && buffer.isNotEmpty) {
        final fullReply = buffer.toString();
        final englishOnly = fullReply.split(RegExp(r'💡|🎯|🎓')).first.trim();
        if (englishOnly.isNotEmpty) {
          unawaited(
            tts.speak(
              englishOnly,
              id: 'rp_${scenario.id}_${turns.length}',
            ),
          );
        }
      }
    } catch (_) {
      final currentTurns = List<RoleplayTurn>.from(turns);
      currentTurns[currentTurns.length - 1] = const RoleplayTurn(
        isUser: false,
        text:
            'That is an insightful perspective! Could you elaborate further with a concrete academic example from your university coursework?\n\n💡 **Gợi ý nâng cấp câu nói (Better Phrasing):** Bạn có thể mở rộng câu trả lời bằng cấu trúc *"To illustrate this with a concrete example from my university project..."*',
      );
      _roleplayHistories[scenario.id] = currentTurns;
    } finally {
      _isRoleplayStreaming = false;
      notifyListeners();
    }
  }

  /// Evaluates a student's writing submission using AI IELTS & Academic Rubric.
  Future<WritingEvaluation> evaluateWritingSubmission({
    required WritingPrompt prompt,
    required String essayText,
  }) async {
    _isGradingWriting = true;
    notifyListeners();

    try {
      final user = _state?.user;
      final raw = await _aiTutor.completeText(
        systemPrompt:
            'Bạn là Giám khảo Chấm thi IELTS Writing & Cố vấn Viết Học thuật Đại học. Hãy chấm bài viết công tâm và trả về DUY NHẤT một JSON object hợp lệ với các trường:\n'
            '{\n'
            '  "overallBand": 7.0,\n'
            '  "taskResponseBand": 7.0,\n'
            '  "coherenceBand": 7.0,\n'
            '  "lexicalBand": 7.0,\n'
            '  "grammarBand": 6.5,\n'
            '  "feedbackMarkdown": "Nhận xét chi tiết bằng tiếng Việt về điểm mạnh, các lỗi ngữ pháp/từ vựng cụ thể và cách khắc phục...",\n'
            '  "upgradedEssay": "Bản viết lại hoàn chỉnh được nâng cấp lên chuẩn Band 8.0+ Academic English..."\n'
            '}',
        userPrompt:
            'Đề bài (${prompt.category} - ${prompt.title}):\n${prompt.promptEn}\n\n'
            'Chuyên ngành sinh viên: ${user?.majorField ?? "Đại học"}\n'
            'Bài làm của sinh viên:\n$essayText',
        temperature: 0.5,
      );

      WritingEvaluation evaluation;
      try {
        final jsonStr = _extractJsonPayload(raw, isArray: false);
        final map = jsonDecode(jsonStr) as Map<String, dynamic>;
        evaluation = WritingEvaluation(
          promptTitle: prompt.title,
          userEssay: essayText,
          overallBand: (map['overallBand'] as num?)?.toDouble() ?? 6.5,
          taskResponseBand:
              (map['taskResponseBand'] as num?)?.toDouble() ?? 6.5,
          coherenceBand: (map['coherenceBand'] as num?)?.toDouble() ?? 6.5,
          lexicalBand: (map['lexicalBand'] as num?)?.toDouble() ?? 6.5,
          grammarBand: (map['grammarBand'] as num?)?.toDouble() ?? 6.5,
          feedbackMarkdown: map['feedbackMarkdown'] as String? ?? raw,
          upgradedEssay: map['upgradedEssay'] as String? ?? '',
          submittedAt: DateTime.now(),
        );
      } catch (_) {
        evaluation = WritingEvaluation(
          promptTitle: prompt.title,
          userEssay: essayText,
          overallBand: 6.5,
          taskResponseBand: 6.5,
          coherenceBand: 6.5,
          lexicalBand: 6.5,
          grammarBand: 6.5,
          feedbackMarkdown: raw.isNotEmpty
              ? raw
              : 'Bài viết có bố cục rõ ràng, bám sát yêu cầu đề bài. Cần bổ sung thêm các liên từ học thuật (Consequently, Furthermore, Nevertheless) và mệnh đề phân từ để nâng lên Band 7.5+.',
          upgradedEssay:
              'In contemporary higher education, integrating advanced methodologies and critical analysis is paramount to achieving sustainable academic excellence.',
          submittedAt: DateTime.now(),
        );
      }

      if (_state != null) {
        final updatedHistory = <WritingEvaluation>[
          evaluation,
          ..._state!.writingHistory,
        ];
        _state = _state!.copyWith(writingHistory: updatedHistory);
        await recordActivityCompletion(
          questId: 'q_write',
          skill: SkillType.writing,
          baseXp: 50,
          lessonId: prompt.id,
          skillBoost: 3,
        );
      }
      return evaluation;
    } finally {
      _isGradingWriting = false;
      notifyListeners();
    }
  }

  /// Cloud sync export/import helpers
  String exportCloudSyncCode() {
    if (_state == null) return '';
    return _storage.exportSyncCode(_state!);
  }

  Future<bool> importCloudSyncCode(String code) async {
    final restored = _storage.importSyncCode(code);
    if (restored == null) return false;
    _state = _refreshStreakAndDailyQuests(restored);
    await _storage.saveProgress(_state!);
    _knownAccounts = await _storage.loadKnownGoogleAccounts();
    notifyListeners();
    return true;
  }

  String _extractJsonPayload(String raw, {required bool isArray}) {
    final startChar = isArray ? '[' : '{';
    final endChar = isArray ? ']' : '}';
    final startIdx = raw.indexOf(startChar);
    final endIdx = raw.lastIndexOf(endChar);
    if (startIdx >= 0 && endIdx > startIdx) {
      return raw.substring(startIdx, endIdx + 1);
    }
    return raw;
  }
}
