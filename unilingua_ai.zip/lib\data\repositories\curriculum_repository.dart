import '../../domain/models/learning_models.dart';

/// Repository containing university-level diagnostic placement exam (5 sections),
/// adaptive scoring & 12-week roadmaps, daily workout quizzes, and 4-skill lessons.
class CurriculumRepository {
  const CurriculumRepository._();

  static const List<String> academicYears = <String>[
    'Sinh viên Năm 1 (Mới nhập học)',
    'Sinh viên Năm 2 (Cơ sở ngành)',
    'Sinh viên Năm 3 (Chuyên ngành & Thực tập)',
    'Sinh viên Năm 4 / Năm cuối (Chuẩn đầu ra & Đồ án)',
    'Mới tốt nghiệp / Học viên Cao học',
  ];

  static const List<int> dailyMinuteOptions = <int>[15, 30, 45, 60];

  static const List<String> universityMajors = <String>[
    'CNTT & Khoa học Máy tính',
    'Kinh tế, Tài chính & Quản trị',
    'Kỹ thuật, Điện tử & Tự động hóa',
    'Y Sinh, Dược & Khoa học Tự nhiên',
    'Ngôn ngữ, Truyền thông & Xã hội',
  ];

  static const List<String> universityGoals = <String>[
    'Đạt chuẩn đầu ra IELTS 6.5+ / B2 Đại học',
    'Đạt TOEIC 785+ & Phỏng vấn Thực tập Tập đoàn MNC',
    'Đọc giáo trình chuyên ngành & Viết luận / Nghiên cứu',
    'Săn Học bổng Du học & Thuyết trình Học thuật Quốc tế',
  ];

  static const String placementDictationAudio =
      'Universities must emphasize critical verification rather than rote memorization.';

  static const String placementSpeakingPrompt1 =
      'Introduce yourself, your university major, and the English skill you want to improve most before graduation (3–4 sentences in English).';

  static const String placementSpeakingPrompt2 =
      'University Discussion (IELTS Part 3): Should core university subjects be taught in English? Explain your opinion with at least one clear reason or example.';

  static const String placementWritingPrompt =
      'Many university students increasingly rely on Artificial Intelligence tools for their coursework. Do the benefits of using AI in university education outweigh the drawbacks? Write a structured paragraph (60–150 words) in English.';

  /// 17-question objective diagnostic battery calibrated from A2 to C1
  /// across Listening (5), Reading (5), Academic Grammar & Writing (5), and Speaking (2).
  /// Combined with 1 Listening Dictation + 2 Real Speaking Prompts + 1 Real Writing Essay.
  static const List<PlacementQuestion> placementQuestions =
      <PlacementQuestion>[
    // ==================== PART 1: LISTENING (5 MCQs: A2 -> C1) ====================
    PlacementQuestion(
      id: 'pt_l1',
      skill: SkillType.listening,
      cefrDifficulty: 'A2',
      topicTag: 'Nghe thông báo học vụ (A2)',
      audioScript:
          'Good morning everyone. Due to maintenance in the main library, the deadline for submitting your group assignment has been extended until Thursday at five p.m. Please upload a PDF copy to the student portal instead of printing it.',
      prompt:
          'Nghe thông báo từ giảng viên: Sinh viên cần nộp bài tập nhóm bằng cách nào và trước thời hạn nào?',
      options: <String>[
        'In ra giấy và nộp tại thư viện chính vào thứ Tư',
        'Tải bản PDF lên cổng thông tin sinh viên (student portal) trước 17h thứ Năm',
        'Gửi bản Word qua email cá nhân cho trưởng nhóm vào thứ Sáu',
        'Nộp trực tiếp trên lớp vào sáng thứ Hai tuần sau',
      ],
      correctIndex: 1,
      explanationVi:
          'Bài nghe nêu rõ: "extended until Thursday at five p.m. Please upload a PDF copy to the student portal instead of printing it."',
      weight: 15,
    ),
    PlacementQuestion(
      id: 'pt_l2',
      skill: SkillType.listening,
      cefrDifficulty: 'B1',
      topicTag: 'Nghe hướng dẫn Seminar đại học (B1)',
      audioScript:
          'Attention all undergraduate students enrolled in Research Methodology. This Friday’s seminar has been relocated from Hall B to the Digital Innovation Lab on the third floor. Please bring your literature review draft for peer feedback.',
      prompt:
          'Sinh viên tham gia buổi seminar môn Phương pháp Nghiên cứu vào thứ Sáu cần mang theo tài liệu gì?',
      options: <String>[
        'Bản nháp tổng quan tài liệu (literature review draft) để nhận xét chéo',
        'Slide thuyết trình cuối kỳ đã hoàn thiện',
        'Phiếu đăng ký mượn thiết bị phòng thí nghiệm tầng 3',
        'Báo cáo chi phí dự án nghiên cứu nhóm',
      ],
      correctIndex: 0,
      explanationVi:
          'Giảng viên dặn rõ: "Please bring your literature review draft for peer feedback."',
      weight: 20,
    ),
    PlacementQuestion(
      id: 'pt_l3',
      skill: SkillType.listening,
      cefrDifficulty: 'B2',
      topicTag: 'Nghe hội thoại tuyển dụng Thực tập (B2)',
      audioScript:
          'Interviewer: We noticed you led a student hackathon team last semester. What was your biggest hurdle? Candidate: Honestly, technical coding wasn’t the primary bottleneck; aligning four teammates from different faculties with conflicting exam schedules was far more demanding.',
      prompt:
          'Theo ứng viên sinh viên vừa trả lời phỏng vấn, khó khăn lớn nhất (biggest hurdle) khi dẫn dắt nhóm thi hackathon là gì?',
      options: <String>[
        'Thiếu kỹ năng lập trình và gặp nhiều lỗi kỹ thuật phức tạp',
        'Điều phối 4 thành viên từ các khoa khác nhau có lịch thi chồng chéo',
        'Không có đủ kinh phí để thuê máy chủ chạy dự án',
        'Không kịp nộp bài trước thời hạn của ban tổ chức',
      ],
      correctIndex: 1,
      explanationVi:
          'Ứng viên dùng bẫy đối lập (distractor): "technical coding wasn’t the primary bottleneck; aligning four teammates from different faculties with conflicting exam schedules was far more demanding."',
      weight: 25,
    ),
    PlacementQuestion(
      id: 'pt_l4',
      skill: SkillType.listening,
      cefrDifficulty: 'B2',
      topicTag: 'Nghe bài giảng Học thuật về AI (B2)',
      audioScript:
          'While early automation primarily displaced routine manual labor, generative artificial intelligence increasingly augments cognitive tasks such as software debugging, financial modeling, and legal document synthesis. Consequently, universities must emphasize critical verification rather than rote memorization.',
      prompt:
          'Theo bài giảng đại học vừa nghe, các trường đại học cần nhấn mạnh năng lực nào trước sự phát triển của AI tạo sinh?',
      options: <String>[
        'Học thuộc lòng máy móc các tài liệu cũ',
        'Tư duy kiểm chứng phản biện (critical verification) thay vì học vẹt',
        'Cấm sinh viên tiếp cận các công cụ phân tích dữ liệu',
        'Chỉ tập trung đào tạo kỹ năng lao động thủ công',
      ],
      correctIndex: 1,
      explanationVi:
          'Câu kết luận nêu rõ: "universities must emphasize critical verification rather than rote memorization."',
      weight: 25,
    ),
    PlacementQuestion(
      id: 'pt_l5',
      skill: SkillType.listening,
      cefrDifficulty: 'C1',
      topicTag: 'Nghe phân tích Kinh tế Vĩ mô & Hàm ý (C1)',
      audioScript:
          'Had the central bank anticipated the supply-side bottleneck earlier, it might have refrained from aggressive monetary tightening, which inadvertently exacerbated borrowing costs for emerging tech startups.',
      prompt:
          'Tác giả ngụ ý điều gì về chính sách thắt chặt tiền tệ (monetary tightening) của ngân hàng trung ương?',
      options: <String>[
        'Ngân hàng trung ương đã dự báo sớm và giải quyết triệt để tắc nghẽn nguồn cung',
        'Chính sách này giúp các startup công nghệ vay vốn với lãi suất cực thấp',
        'Chính sách này vô tình làm trầm trọng thêm chi phí vay vốn của các startup công nghệ mới nổi',
        'Các doanh nghiệp công nghệ không chịu bất kỳ tác động nào từ chính sách tiền tệ',
      ],
      correctIndex: 2,
      explanationVi:
          'Cấu trúc đảo ngữ điều kiện loại 3 "Had the central bank anticipated..." kết hợp "inadvertently exacerbated borrowing costs" cho thấy hệ quả ngoài ý muốn là làm tăng chi phí vay vốn.',
      weight: 30,
    ),

    // ==================== PART 2: READING & VOCABULARY (5 MCQs: A2 -> C1) ====================
    PlacementQuestion(
      id: 'pt_r1',
      skill: SkillType.reading,
      cefrDifficulty: 'A2',
      topicTag: 'Đọc hiểu thông tin cơ bản (A2)',
      readingContext:
          'Campus Study Center Policy: Quiet study rooms on Floor 2 can be booked online up to 48 hours in advance. Each student group of three to six members may reserve a room for a maximum of two hours per day. Food is not permitted inside, though sealed water bottles are allowed.',
      prompt:
          'Theo quy định của Trung tâm Tự học, điều nào sau đây là ĐÚNG?',
      options: <String>[
        'Sinh viên đi một mình có thể đặt phòng nhóm cho cả ngày',
        'Nhóm từ 3 đến 6 sinh viên có thể đặt phòng tối đa 2 giờ mỗi ngày và được mang bình nước đậy nắp kín',
        'Sinh viên được phép mang đồ ăn nhẹ vào phòng miễn là dọn sạch sau đó',
        'Phải đến trực tiếp quầy lễ tân trước 1 tuần mới được đặt phòng',
      ],
      correctIndex: 1,
      explanationVi:
          'Đoạn văn nêu rõ: "group of three to six members may reserve a room for a maximum of two hours per day" và "sealed water bottles are allowed".',
      weight: 15,
    ),
    PlacementQuestion(
      id: 'pt_r2',
      skill: SkillType.reading,
      cefrDifficulty: 'B1',
      topicTag: 'Đọc hiểu Khoa học Giáo dục (B1)',
      readingContext:
          'Spaced repetition is an evidence-based learning technique that incorporates increasing intervals of time between subsequent reviews of previously learned material. Unlike cramming before an exam, spaced repetition leverages the psychological spacing effect to encode information into long-term memory.',
      prompt:
          'Điểm vượt trội cốt lõi của "Spaced repetition" so với việc học dồn (cramming) trước kỳ thi là gì?',
      options: <String>[
        'Tận dụng hiệu ứng giãn cách thời gian ôn tập tăng dần để mã hóa kiến thức vào trí nhớ dài hạn',
        'Giúp sinh viên học hết toàn bộ giáo trình chỉ trong một đêm trước khi thi',
        'Chỉ hiệu quả khi học từ vựng mà không áp dụng được cho môn chuyên ngành',
        'Loại bỏ hoàn toàn nhu cầu ôn tập lại kiến thức cũ',
      ],
      correctIndex: 0,
      explanationVi:
          'Đoạn văn chỉ rõ: "incorporates increasing intervals of time... to encode information into long-term memory".',
      weight: 20,
    ),
    PlacementQuestion(
      id: 'pt_r3',
      skill: SkillType.reading,
      cefrDifficulty: 'B2',
      topicTag: 'Từ vựng học thuật trong ngữ cảnh (B2)',
      readingContext:
          'Despite the proliferation of renewable energy sources, grid stability remains a formidable engineering challenge. Solar and wind power are inherently intermittent, necessitating utility-scale battery storage and smart demand-response algorithms to reconcile peak generation with fluctuating consumer demand.',
      prompt:
          'Từ "intermittent" trong đoạn trích chuyên ngành năng lượng trên có nghĩa gần nhất với phương án nào?',
      options: <String>[
        'Liên tục và ổn định tuyệt đối 24/7',
        'Gián đoạn, không đều đặn (phụ thuộc vào thời tiết, nắng gió)',
        'Gây ô nhiễm môi trường nghiêm trọng',
        'Không thể đo lường được bằng thiết bị kỹ thuật',
      ],
      correctIndex: 1,
      explanationVi:
          '"Intermittent" = occurring at irregular intervals (gián đoạn/không liên tục), vì vậy mới cần pin lưu trữ quy mô lớn để cân bằng lưới điện.',
      weight: 25,
    ),
    PlacementQuestion(
      id: 'pt_r4',
      skill: SkillType.reading,
      cefrDifficulty: 'B2',
      topicTag: 'Đọc suy luận học thuật (B2+)',
      readingContext:
          'Although digital note-taking enables undergraduates to transcribe lectures verbatim at high speed, empirical studies reveal that students who summarize concepts by hand demonstrate superior conceptual recall. Typing encourages shallow orthographic processing, whereas handwriting forces immediate cognitive synthesis.',
      prompt:
          'Tại sao các nghiên cứu thực nghiệm cho thấy ghi chép tóm tắt bằng tay giúp hiểu sâu khái niệm hơn so với gõ máy nguyên văn (verbatim)?',
      options: <String>[
        'Vì máy tính thường bị hết pin giữa giờ giảng',
        'Vì viết tay buộc não bộ phải tổng hợp và xử lý khái niệm ngay lập tức thay vì chép lại cơ học nông cạn',
        'Vì sinh viên viết tay luôn ghi được nhiều chữ hơn sinh viên gõ bàn phím',
        'Vì giảng viên chỉ chấm điểm cao cho sinh viên dùng vở giấy',
      ],
      correctIndex: 1,
      explanationVi:
          'Đoạn văn giải thích: "Typing encourages shallow orthographic processing, whereas handwriting forces immediate cognitive synthesis."',
      weight: 25,
    ),
    PlacementQuestion(
      id: 'pt_r5',
      skill: SkillType.reading,
      cefrDifficulty: 'C1',
      topicTag: 'Phân tích Luận điểm Tạp chí Khoa học (C1)',
      readingContext:
          'Algorithmic bias often stems not from malicious intent by software engineers, but from historical asymmetries embedded within uncurated training datasets. Consequently, deploying predictive models in high-stakes domains—such as healthcare diagnostics or credit scoring—without rigorous auditing risks perpetuating systemic inequities under a veneer of mathematical objectivity.',
      prompt:
          'Luận điểm chính (Main Argument) mà tác giả muốn cảnh báo trong đoạn trích cấp độ C1 trên là gì?',
      options: <String>[
        'Các lập trình viên luôn cố tình cài cắm sự thiên vị vào mã nguồn AI',
        'Các mô hình toán học hoàn toàn trung lập nên không cần kiểm toán dữ liệu',
        'Triển khai mô hình dự đoán từ dữ liệu lịch sử chưa kiểm duyệt có nguy cơ duy trì bất bình đẳng hệ thống dưới lớp vỏ khách quan toán học',
        'Không bao giờ được ứng dụng phần mềm trong lĩnh vực y tế và tài chính',
      ],
      correctIndex: 2,
      explanationVi:
          'Cụm "risks perpetuating systemic inequities under a veneer of mathematical objectivity" khái quát trọn vẹn luận điểm cảnh báo của tác giả.',
      weight: 30,
    ),

    // ==================== PART 3: ACADEMIC GRAMMAR & WRITTEN ACCURACY (5 MCQs: A2 -> C1) ====================
    PlacementQuestion(
      id: 'pt_g1',
      skill: SkillType.writing,
      cefrDifficulty: 'A2',
      topicTag: 'Thì động từ & Hòa hợp Chủ-Vị (A2)',
      prompt:
          'Chọn đáp án đúng ngữ pháp để hoàn thành câu sau:\n"Neither the lab equipment nor the newly installed computers ________ ready for tomorrow’s experiment."',
      options: <String>[
        'is',
        'are',
        'was being',
        'has been',
      ],
      correctIndex: 1,
      explanationVi:
          'Với cấu trúc "Neither A nor B", động từ chia theo danh từ gần nhất (B = "the newly installed computers" — số nhiều) và ngữ cảnh cho ngày mai nên dùng "are".',
      weight: 15,
    ),
    PlacementQuestion(
      id: 'pt_g2',
      skill: SkillType.writing,
      cefrDifficulty: 'B1',
      topicTag: 'Mệnh đề quan hệ & Bị động học thuật (B1)',
      prompt:
          'Chọn phương án điền vào chỗ trống chuẩn ngữ pháp học thuật:\n"The scholarship program, ________ was launched in 2022, has supported over 500 STEM undergraduates."',
      options: <String>[
        'that',
        'which',
        'what',
        'where',
      ],
      correctIndex: 1,
      explanationVi:
          'Trong mệnh đề quan hệ không xác định (có dấu phẩy ngăn cách), bắt buộc dùng "which" cho vật, tuyệt đối không dùng "that".',
      weight: 20,
    ),
    PlacementQuestion(
      id: 'pt_g3',
      skill: SkillType.writing,
      cefrDifficulty: 'B1',
      topicTag: 'Văn phong Email Học thuật Trang trọng (B1+)',
      prompt:
          'Chọn câu mở đầu Email chuẩn mực (Formal Academic Register) nhất khi viết cho Giáo sư hướng dẫn:',
      options: <String>[
        'Hey Prof, please tell me if you free to check my thesis next term.',
        'I am writing to inquire whether you would be available to supervise my undergraduate thesis next semester.',
        'I writing for asking about my graduation project right now.',
        'Can you be my supervisor next semester? Reply me ASAP.',
      ],
      correctIndex: 1,
      explanationVi:
          '"I am writing to inquire whether you would be available to..." là mẫu câu chuẩn mực trang trọng dùng trong giao tiếp đại học quốc tế.',
      weight: 20,
    ),
    PlacementQuestion(
      id: 'pt_g4',
      skill: SkillType.writing,
      cefrDifficulty: 'B2',
      topicTag: 'Mệnh đề Phân từ & IELTS Writing Band 7.0+ (B2)',
      prompt:
          'Câu nào dưới đây sử dụng đúng Mệnh đề Phân từ rút gọn (Participle Clause) và từ vựng học thuật cho IELTS Writing Task 2?',
      options: <String>[
        'Facing with high tuition fees, students working part-time and get bad grades.',
        'Faced with escalating tuition fees, many undergraduates resort to part-time employment, which can detrimentally affect their academic performance.',
        'Because escalating tuition fees, so many undergraduates resort to part-time employment.',
        'Despite tuition fees are escalating, many undergraduates still have to work.',
      ],
      correctIndex: 1,
      explanationVi:
          'Cấu trúc đúng là "Faced with + N" (bị động rút gọn: Đối mặt với...), kết hợp collocation "escalating tuition fees", "resort to", và mệnh đề quan hệ "which can detrimentally affect...".',
      weight: 25,
    ),
    PlacementQuestion(
      id: 'pt_g5',
      skill: SkillType.writing,
      cefrDifficulty: 'C1',
      topicTag: 'Đảo ngữ nâng cao C1 (Inversion)',
      prompt:
          'Hoàn thành cấu trúc Đảo ngữ nâng cao (C1 Academic Writing):\n"________ had the research team published their empirical findings than independent laboratories replicated the experiment."',
      options: <String>[
        'Not only',
        'No sooner',
        'Hardly',
        'Scarcely',
      ],
      correctIndex: 1,
      explanationVi:
          'Cấu trúc đảo ngữ chuẩn C1: "No sooner + had + S + V3/ed + than + S + V2/ed". ("Hardly/Scarcely" phải đi với "when", không đi với "than").',
      weight: 30,
    ),

    // ==================== PART 4: SPEAKING PHONETICS & ACADEMIC DISCOURSE (2 MCQs: B2 -> C1) ====================
    PlacementQuestion(
      id: 'pt_s1',
      skill: SkillType.speaking,
      cefrDifficulty: 'B2',
      topicTag: 'Trọng âm Từ vựng Học thuật (B2)',
      audioScript: 'economy, economist, economical, academy',
      prompt:
          'Kiểm tra Trọng âm Học thuật (Word Stress): Từ nào có trọng âm chính rơi vào âm tiết KHÁC với 3 từ còn lại?',
      options: <String>[
        'eCONomy (/ɪˈkɒnəmi/ — âm tiết 2)',
        'eCONomist (/ɪˈkɒnəmɪst/ — âm tiết 2)',
        'ecoNOMical (/ˌiːkəˈnɒmɪkl/ — âm tiết 3)',
        'aCADemy (/əˈkædəmi/ — âm tiết 2)',
      ],
      correctIndex: 2,
      explanationVi:
          'Quy tắc trọng âm: Hậu tố "-ical" kéo trọng âm vào ngay âm tiết đứng trước nó -> ecoNOMical (âm tiết 3), trong khi 3 từ còn lại nhấn âm 2.',
      weight: 25,
    ),
    PlacementQuestion(
      id: 'pt_s2',
      skill: SkillType.speaking,
      cefrDifficulty: 'C1',
      topicTag: 'Phản biện Học thuật & Ngữ điệu Nói (C1)',
      audioScript:
          'While I see the merit in your proposal, we need to factor in the long-term scalability constraints.',
      prompt:
          'Trong buổi thảo luận nhóm quốc tế hoặc bảo vệ đồ án, câu nói nào thể hiện kỹ năng phản biện lịch sự (Academic Hedging) đạt chuẩn IELTS Speaking 7.5+?',
      options: <String>[
        'Your idea is completely wrong and cannot work in practice.',
        'While I see the merit in your proposal, we need to factor in the long-term scalability constraints.',
        'I disagree with everything because it is too expensive.',
        'Stop explaining that, let’s just follow my slide instead.',
      ],
      correctIndex: 1,
      explanationVi:
          '"While I see the merit in..., we need to factor in..." là kỹ thuật Academic Hedging chuẩn C1 giúp phản biện sắc bén nhưng vẫn tôn trọng đối phương.',
      weight: 30,
    ),
  ];

  /// Computes objective scores, dictation accuracy, mistake list, and an intelligent
  /// adaptive baseline diagnostic + 12-week roadmap + daily schedule tailored to the
  /// student's actual answers, spoken responses, written essay, major, year, and time budget.
  static PlacementTestResult evaluatePlacementSubmission({
    required PlacementSubmissionPayload submission,
    required GoogleUserProfile user,
  }) {
    final mistakes = <PlacementMistakeReview>[];
    var totalCorrect = 0;

    int calcObjectivePercent(SkillType skill) {
      final qs = placementQuestions.where((q) => q.skill == skill).toList();
      if (qs.isEmpty) return 60;
      var earned = 0;
      var totalWeight = 0;
      for (final q in qs) {
        totalWeight += q.weight;
        final chosen = submission.selectedAnswers[q.id];
        if (chosen == q.correctIndex) {
          earned += q.weight;
          totalCorrect++;
        } else {
          final userTxt = (chosen != null &&
                  chosen >= 0 &&
                  chosen < q.options.length)
              ? q.options[chosen]
              : '(Chưa chọn đáp án)';
          mistakes.add(
            PlacementMistakeReview(
              questionId: q.id,
              skill: q.skill,
              cefrDifficulty: q.cefrDifficulty,
              topicTag: q.topicTag,
              questionSummary: q.prompt,
              userAnswerText: userTxt,
              correctAnswerText: q.options[q.correctIndex],
              explanationVi: q.explanationVi,
            ),
          );
        }
      }
      return totalWeight > 0 ? ((earned / totalWeight) * 100).round() : 50;
    }

    final lisMcqPercent = calcObjectivePercent(SkillType.listening);
    final readMcqPercent = calcObjectivePercent(SkillType.reading);
    final gramMcqPercent = calcObjectivePercent(SkillType.writing);
    final spkMcqPercent = calcObjectivePercent(SkillType.speaking);

    // Evaluate real Dictation accuracy
    final dictAcc = _computeDictationPercent(
      submission.listeningDictationInput,
      placementDictationAudio,
    );

    // Evaluate real Speaking production richness (heuristic baseline before AI refinement)
    final spkProdScore = _evaluateOpenTextQuality(
      '${submission.speakingIntroAnswer} ${submission.speakingOpinionAnswer}',
      idealMinWords: 35,
    );

    // Evaluate real Writing essay quality (heuristic baseline before AI refinement)
    final wrtProdScore = _evaluateOpenTextQuality(
      submission.writingEssayAnswer,
      idealMinWords: 60,
    );

    // Combine objective & productive components
    final lScore = ((lisMcqPercent * 0.78) + (dictAcc * 0.22))
        .round()
        .clamp(25, 98);
    final rScore = (20 + readMcqPercent * 0.78).round().clamp(25, 98);
    final sScore = ((spkMcqPercent * 0.45) + (spkProdScore * 0.55))
        .round()
        .clamp(25, 98);
    final wScore = ((gramMcqPercent * 0.48) + (wrtProdScore * 0.52))
        .round()
        .clamp(25, 98);

    final avg = ((lScore + sScore + rScore + wScore) / 4).round();
    final bands = mapScoreToCefrIeltsToeic(avg);

    // Identify critical knowledge gaps directly from mistakes + lowest skills
    final gapTopics = mistakes.map((m) => m.topicTag).toSet().take(4).toList();
    if (dictAcc < 70) {
      gapTopics.add('Bắt âm cuối & từ nối khi Nghe chép chính tả ($dictAcc%)');
    }
    if (submission.writingEssayAnswer.trim().split(RegExp(r'\s+')).length < 40) {
      gapTopics.add('Triển khai ý & độ dài đoạn văn Writing học thuật');
    }

    final strengths = <String>[];
    if (lScore >= 72) strengths.add('Khả năng nắm bắt ý chính bài giảng tiếng Anh tốt ($lScore/100)');
    if (rScore >= 72) strengths.add('Nền tảng đọc hiểu tài liệu học thuật vững ($rScore/100)');
    if (sScore >= 72) strengths.add('Phản xạ diễn đạt và tư duy nói tiếng Anh tự tin ($sScore/100)');
    if (wScore >= 72) strengths.add('Kiểm soát ngữ pháp và cấu trúc câu viết tốt ($wScore/100)');
    if (strengths.isEmpty) {
      strengths.add('Tinh thần chủ động hoàn thành trọn vẹn bài kiểm tra 5 phần — nền tảng tốt để bứt phá theo lộ trình!');
    }

    final dailySchedule = buildAdaptiveDailySchedule(
      totalMinutes: user.dailyTargetMinutes,
      lScore: lScore,
      sScore: sScore,
      rScore: rScore,
      wScore: wScore,
      major: user.majorField,
    );

    final roadmap = buildAdaptiveRoadmap(
      cefr: bands.cefr,
      academicYear: user.academicYear,
      major: user.majorField,
      goal: user.targetGoal,
      dailyMinutes: user.dailyTargetMinutes,
      lScore: lScore,
      sScore: sScore,
      rScore: rScore,
      wScore: wScore,
      criticalGaps: gapTopics,
    );

    final weakest = _findWeakestSkill(lScore, sScore, rScore, wScore);
    final strongest = _findStrongestSkill(lScore, sScore, rScore, wScore);

    final summary =
        'Bạn đạt **$totalCorrect/${placementQuestions.length} câu trắc nghiệm chuẩn hóa** (Dictation chính xác **$dictAcc%**), tương đương trình độ **CEFR ${bands.cefr}** (**IELTS ${bands.ielts}** | **TOEIC ~${bands.toeic}**).\n\n'
        '• **Điểm mạnh nổi bật**: ${strongest.labelVi} — đây là bệ phóng tốt cho chuyên ngành **${user.majorField}** (${user.academicYear}).\n'
        '• **Kỹ năng cần ưu tiên khắc phục ngay**: ${weakest.labelVi} (đã được phân bổ **40% quỹ thời gian ${user.dailyTargetMinutes} phút/ngày** trong lộ trình).\n'
        '• **Mục tiêu hướng tới**: Lộ trình 12 tuần bên dưới được thiết kế sát với các lỗ hổng thực tế trong bài test của bạn để chinh phục **${user.targetGoal}**.';

    return PlacementTestResult(
      completedAt: DateTime.now(),
      listeningScore: lScore,
      speakingScore: sScore,
      readingScore: rScore,
      writingScore: wScore,
      dictationAccuracyPercent: dictAcc,
      objectiveCorrectCount: totalCorrect,
      objectiveTotalCount: placementQuestions.length,
      cefrLevel: bands.cefr,
      estimatedIelts: bands.ielts,
      estimatedToeic: bands.toeic,
      aiDiagnosticSummary: summary,
      speakingFeedbackVi: submission.speakingIntroAnswer.trim().isEmpty &&
              submission.speakingOpinionAnswer.trim().isEmpty
          ? 'Bạn chưa nhập/nói câu trả lời ở phần Speaking thực tế. Lộ trình đã tự động tăng cường bài luyện Shadowing & AI Roleplay hàng ngày để giúp bạn bật phản xạ nói tự tin.'
          : 'Bạn đã hoàn thành phần phản xạ Nói thực tế. Hệ thống đã ghi nhận câu trả lời của bạn để luyện nâng cấp từ vựng học thuật (Academic Collocations) và phát âm trọng âm trong Phòng Nói AI.',
      writingFeedbackVi: submission.writingEssayAnswer.trim().isEmpty
          ? 'Bạn chưa viết đoạn luận thực tế ở phần Writing. Lộ trình đã ưu tiên bổ sung bài tập cấu trúc câu phức và viết đoạn văn ngắn có AI sửa lỗi hàng ngày.'
          : 'Bài viết thực tế của bạn đã được phân tích sơ bộ về độ dài, từ nối học thuật và cấu trúc câu. Xem chi tiết nhận xét và bản nâng cấp từ Giám khảo AI.',
      keyStrengths: strengths,
      criticalGaps: gapTopics.isEmpty
          ? const <String>['Nâng cấp từ vựng chuyên ngành C1 & phản xạ thuyết trình học thuật']
          : gapTopics,
      dailySchedule: dailySchedule,
      mistakes: mistakes,
      roadmapPhases: roadmap,
      generatedByAi: false,
    );
  }

  static ({String cefr, String ielts, int toeic}) mapScoreToCefrIeltsToeic(
      int avgScore) {
    if (avgScore >= 85) {
      return (cefr: 'C1', ielts: '7.0 - 7.5', toeic: 880);
    } else if (avgScore >= 70) {
      return (cefr: 'B2', ielts: '6.0 - 6.5', toeic: 750);
    } else if (avgScore >= 52) {
      return (cefr: 'B1', ielts: '5.0 - 5.5', toeic: 600);
    } else if (avgScore >= 38) {
      return (cefr: 'A2', ielts: '4.0 - 4.5', toeic: 460);
    } else {
      return (cefr: 'A1-A2', ielts: '3.5 - 4.0', toeic: 380);
    }
  }

  static int _computeDictationPercent(String input, String target) {
    final cleanedInput = input
        .toLowerCase()
        .replaceAll(RegExp(r'[^\w\s]'), '')
        .trim();
    if (cleanedInput.isEmpty) return 25;
    final userWords =
        cleanedInput.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    final targetWords = target
        .toLowerCase()
        .replaceAll(RegExp(r'[^\w\s]'), '')
        .split(RegExp(r'\s+'))
        .where((w) => w.isNotEmpty)
        .toList();
    if (targetWords.isEmpty) return 50;
    var hit = 0;
    for (final tw in targetWords) {
      if (userWords.contains(tw)) hit++;
    }
    return ((hit / targetWords.length) * 100).round().clamp(15, 100);
  }

  static int _evaluateOpenTextQuality(
    String rawText, {
    required int idealMinWords,
  }) {
    final trimmed = rawText.trim();
    if (trimmed.isEmpty) return 32;
    final words = trimmed.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    final wordCount = words.length;
    final uniqueRatio =
        wordCount > 0 ? (words.map((w) => w.toLowerCase()).toSet().length / wordCount) : 0.0;

    // Check presence of academic linking / reasoning words
    final lower = trimmed.toLowerCase();
    const linkers = <String>[
      'however',
      'therefore',
      'moreover',
      'furthermore',
      'although',
      'while',
      'because',
      'consequently',
      'example',
      'opinion',
      'believe',
      'university',
      'critical',
      'important',
      'advantage',
      'disadvantage',
    ];
    var linkerHits = 0;
    for (final l in linkers) {
      if (lower.contains(l)) linkerHits++;
    }

    final lengthScore = ((wordCount / idealMinWords).clamp(0.0, 1.0) * 45).round();
    final diversityScore = (uniqueRatio.clamp(0.0, 0.85) / 0.85 * 25).round();
    final academicScore = (linkerHits.clamp(0, 5) * 6);
    return (24 + lengthScore + diversityScore + academicScore).clamp(32, 92);
  }

  static SkillType _findWeakestSkill(int l, int s, int r, int w) {
    final map = <SkillType, int>{
      SkillType.listening: l,
      SkillType.speaking: s,
      SkillType.reading: r,
      SkillType.writing: w,
    };
    return map.entries.reduce((a, b) => a.value <= b.value ? a : b).key;
  }

  static SkillType _findStrongestSkill(int l, int s, int r, int w) {
    final map = <SkillType, int>{
      SkillType.listening: l,
      SkillType.speaking: s,
      SkillType.reading: r,
      SkillType.writing: w,
    };
    return map.entries.reduce((a, b) => a.value >= b.value ? a : b).key;
  }

  static List<DailyScheduleSlot> buildAdaptiveDailySchedule({
    required int totalMinutes,
    required int lScore,
    required int sScore,
    required int rScore,
    required int wScore,
    required String major,
  }) {
    final ranked = <MapEntry<SkillType, int>>[
      MapEntry(SkillType.listening, lScore),
      MapEntry(SkillType.speaking, sScore),
      MapEntry(SkillType.reading, rScore),
      MapEntry(SkillType.writing, wScore),
    ]..sort((a, b) => a.value.compareTo(b.value)); // Weakest first

    final m1 = (totalMinutes * 0.40).round().clamp(5, totalMinutes);
    final m2 = (totalMinutes * 0.25).round().clamp(4, totalMinutes);
    final m3 = (totalMinutes * 0.20).round().clamp(3, totalMinutes);
    final m4 = (totalMinutes - m1 - m2 - m3).clamp(3, totalMinutes);
    final allocations = <int>[m1, m2, m3, m4];

    String titleFor(SkillType skill, bool isTopPriority) {
      final tag = isTopPriority ? '⭐ Ưu tiên #1: ' : '';
      switch (skill) {
        case SkillType.listening:
          return '${tag}Nghe Giảng đường & Chép chính tả (Dictation)';
        case SkillType.speaking:
          return '${tag}Shadowing IPA & Hội thoại AI 1-1';
        case SkillType.reading:
          return '${tag}Đọc Bài báo Chuyên ngành & Flashcard';
        case SkillType.writing:
          return '${tag}Viết đoạn Học thuật & Sửa lỗi AI';
      }
    }

    String detailFor(SkillType skill) {
      switch (skill) {
        case SkillType.listening:
          return 'Nghe bài giảng tốc độ 1.0x (không bật transcript lần đầu), kiểm tra Dictation bắt âm nối.';
        case SkillType.speaking:
          return 'Đọc đuổi 3 câu học thuật theo IPA rồi hội thoại 3 lượt cùng AI Partner.';
        case SkillType.reading:
          return 'Đọc 1 đoạn tài liệu $major song ngữ và lưu 3–5 thuật ngữ chuyên ngành.';
        case SkillType.writing:
          return 'Viết 1 đoạn văn/email đại học và nộp cho Giám khảo AI chấm Band + sửa ngữ pháp.';
      }
    }

    return List<DailyScheduleSlot>.generate(4, (i) {
      final skill = ranked[i].key;
      return DailyScheduleSlot(
        skill: skill,
        minutes: allocations[i],
        activityTitle: titleFor(skill, i == 0),
        detail: detailFor(skill),
      );
    });
  }

  static List<RoadmapPhase> buildAdaptiveRoadmap({
    required String cefr,
    required String academicYear,
    required String major,
    required String goal,
    required int dailyMinutes,
    required int lScore,
    required int sScore,
    required int rScore,
    required int wScore,
    List<String> criticalGaps = const <String>[],
  }) {
    final weakest = _findWeakestSkill(lScore, sScore, rScore, wScore);
    final gapNote = criticalGaps.isNotEmpty
        ? criticalGaps.take(2).join(' & ')
        : 'nền tảng từ vựng học thuật và phản xạ giao tiếp';

    return <RoadmapPhase>[
      RoadmapPhase(
        weekRange: 'Giai đoạn 1 • Tuần 1 - 3',
        title: 'Vá lỗ hổng đầu vào ($cefr) & Bứt phá ${weakest.shortVi}',
        focusGoal:
            'Tập trung xử lý trực diện các lỗ hổng phát hiện từ bài test ($gapNote) với kỷ luật $dailyMinutes phút/ngày dành cho $academicYear.',
        listeningTask: lScore < 65
            ? 'Nghe tốc độ 0.75x–1.0x các thông báo giảng đường & chép chính tả (Dictation) 1 câu/ngày để bắt âm cuối.'
            : 'Nghe bài giảng đại học tốc độ 1.0x không bật phụ đề, ghi chú 3 từ khóa chính mỗi bài.',
        speakingTask: sScore < 65
            ? 'Luyện Shadowing 4 câu IPA cơ bản/ngày, chú trọng trọng âm từ đa âm tiết và phát âm âm cuối.'
            : 'Thực hành AI Roleplay 5 phút/ngày về chủ đề đời sống sinh viên & giới thiệu chuyên ngành $major.',
        readingTask:
            'Đọc 1 bài ngắn song ngữ thuộc lĩnh vực $major mỗi ngày, tích lũy 120 từ vựng Academic Word List.',
        writingTask: wScore < 65
            ? 'Ôn chuẩn hóa thì động từ, hòa hợp chủ vị, mệnh đề quan hệ và viết đoạn 80 từ gửi AI sửa từng lỗi.'
            : 'Luyện viết Email học thuật gửi giảng viên & đoạn văn có câu phức (Complex Sentences) đạt chuẩn B2.',
        milestone:
            'Khắc phục triệt để lỗi cơ bản từ bài Test đầu vào & tăng ít nhất +15 điểm ở kỹ năng ${weakest.shortVi}.',
      ),
      RoadmapPhase(
        weekRange: 'Giai đoạn 2 • Tuần 4 - 6',
        title: 'Tiếng Anh Chuyên Ngành ($major) & Thảo luận Học thuật',
        focusGoal:
            'Làm chủ thuật ngữ chuyên ngành $major, đọc hiểu giáo trình tiếng Anh nhanh và tự tin trao đổi trong seminar.',
        listeningTask:
            'Luyện nghe hội thoại thảo luận nhóm & phỏng vấn thực tập tốc độ 1.0x–1.25x, nhận diện bẫy Distractors.',
        speakingTask:
            'Hội thoại AI 1-1 tình huống thảo luận nhóm quốc tế, ứng dụng cấu trúc phản biện lịch sự (Academic Hedging).',
        readingTask:
            'Áp dụng Skimming & Scanning đọc bài báo chuyên ngành $major, trả lời câu hỏi Suy luận (Inference).',
        writingTask:
            'Viết đoạn văn học thuật 150 từ sử dụng Mệnh đề Phân từ rút gọn và từ nối nguyên nhân–kết quả.',
        milestone:
            'Đọc hiểu ≥75% tài liệu tiếng Anh chuyên ngành $major & duy trì chuỗi Streak 30+ ngày.',
      ),
      RoadmapPhase(
        weekRange: 'Giai đoạn 3 • Tuần 7 - 9',
        title: 'Nâng cấp Chuẩn B2+/C1 • Luận văn & Thuyết trình',
        focusGoal:
            'Đẩy mạnh điểm số 4 kỹ năng tiệm cận mục tiêu "$goal" qua các bài tập cường độ chuẩn đề thi quốc tế.',
        listeningTask:
            'Nghe bài giảng khoa học dài & phân tích kinh tế–công nghệ ở tốc độ 1.25x, làm bài tập AI tạo mới hàng ngày.',
        speakingTask:
            'Thực chiến mô phỏng phòng thi IELTS Speaking Part 2 & 3 và Bảo vệ Đồ án bằng tiếng Anh cùng AI.',
        readingTask:
            'Phân tích bài trích tạp chí khoa học cấp độ B2–C1, nâng cao vốn collocations học thuật.',
        writingTask:
            'Viết bài luận IELTS Task 2 hoàn chỉnh 250 từ hoặc Abstract nghiên cứu, đạt chấm điểm AI từ Band 6.5–7.5.',
        milestone:
            'Tự tin thuyết trình học thuật 5 phút & viết luận chuẩn mạch lạc ít lỗi ngữ pháp.',
      ),
      RoadmapPhase(
        weekRange: 'Giai đoạn 4 • Tuần 10 - 12',
        title: 'Về Đích Đầu Ra Đại Học & Thực chiến Phỏng vấn MNC',
        focusGoal:
            'Tổng ôn 4 kỹ năng đồng đều, sẵn sàng thi chứng chỉ quốc tế và chinh phục nhà tuyển dụng / học bổng.',
        listeningTask:
            'Luyện nghe tổng hợp đa giọng điệu & xử lý Paraphrase trong bài thi chuẩn quốc tế.',
        speakingTask:
            'Phỏng vấn Thực tập / Tuyển dụng MNC theo mô hình STAR cùng HR Manager AI không cần kịch bản sẵn.',
        readingTask:
            'Luyện đọc hiểu tốc độ cao có bấm giờ, đạt độ chính xác ≥85% các câu hỏi C1.',
        writingTask:
            'Hoàn thiện Cover Letter, Email xin học bổng/thực tập & bài luận IELTS Task 2 đạt mục tiêu đề ra.',
        milestone:
            'Sẵn sàng thi lại Placement Test tăng 1–2 bậc CEFR và đạt trọn vẹn mục tiêu "$goal".',
      ),
    ];
  }

  /// Default daily workout quiz questions (5 questions per day + AI can generate new ones).
  static const List<DailyQuizQuestion> defaultDailyQuiz = <DailyQuizQuestion>[
    DailyQuizQuestion(
      question:
          'Chọn từ học thuật phù hợp nhất để điền vào câu:\n"The empirical data ________ the hypothesis proposed by the research team."',
      options: <String>[
        'corroborates (củng cố, xác nhận)',
        'hesitates (do dự)',
        'evaporates (bay hơi)',
        'decorates (trang trí)',
      ],
      correctIndex: 0,
      explanationVi:
          '"Corroborate a hypothesis/theory" là collocation học thuật chuẩn C1 có nghĩa là củng cố/xác nhận một giả thuyết bằng bằng chứng thực nghiệm.',
      skillTag: 'Academic Vocabulary',
    ),
    DailyQuizQuestion(
      question:
          'Cấu trúc ngữ pháp nào dưới đây dùng đúng mệnh đề nhượng bộ nâng cao (Advanced Concession)?',
      options: <String>[
        'Despite the algorithm is fast, it consumes excessive memory.',
        'Much as the new policy aims to reduce inflation, its short-term impact remains controversial.',
        'Although the budget was limited, but the students completed the prototype.',
        'In spite of they studied hard, the exam was challenging.',
      ],
      correctIndex: 1,
      explanationVi:
          '"Much as + S + V, S + V" là cấu trúc nhượng bộ trang trọng (= Although). Các câu còn lại sai ngữ pháp.',
      skillTag: 'Academic Grammar',
    ),
    DailyQuizQuestion(
      question:
          'Khi viết báo cáo nghiên cứu, cụm từ nào thay thế tốt nhất cho "Look into" ở văn phong trang trọng (Formal Register)?',
      options: <String>[
        'Check out',
        'Investigate / Examine comprehensively',
        'See about',
        'Talk over',
      ],
      correctIndex: 1,
      explanationVi:
          'Trong Academic Writing, tránh dùng phrasal verb thông tục như "look into" mà nên dùng động từ đơn trang trọng như "investigate", "examine".',
      skillTag: 'Writing Register',
    ),
    DailyQuizQuestion(
      question:
          'Trong giao tiếp thuyết trình đại học, câu nào dùng để chuyển sang phần kết luận mượt mà nhất?',
      options: <String>[
        'To synthesize the key findings we have discussed today...',
        'Now I stop talking because slides are finished.',
        'That is all, goodbye teacher and friends.',
        'Finally I have nothing more to say.',
      ],
      correctIndex: 0,
      explanationVi:
          '"To synthesize the key findings we have discussed today..." là cách chuyển ý kết luận chuẩn mực trong thuyết trình học thuật.',
      skillTag: 'Speaking & Presentation',
    ),
    DailyQuizQuestion(
      question:
          'Chọn từ nối chỉ quan hệ Nguyên nhân - Kết quả đúng ngữ pháp:\n"The sample size was relatively small; ________, the findings cannot be generalized to the entire population."',
      options: <String>[
        'consequently',
        'nevertheless',
        'whereas',
        'because of',
      ],
      correctIndex: 0,
      explanationVi:
          '"Consequently" (do đó, kết quả là) đứng sau dấu chấm phẩy và trước dấu phẩy để nối mệnh đề kết quả.',
      skillTag: 'Cohesion & Linking',
    ),
  ];

  /// Built-in Listening Lab lessons for university students.
  static const List<ListeningLesson> listeningLessons = <ListeningLesson>[
    ListeningLesson(
      id: 'lis_1',
      title: 'Lecture: Artificial Intelligence & Academic Integrity',
      category: 'Giảng đường Đại học • CNTT & Giáo dục',
      cefrLevel: 'B2',
      durationLabel: '2 phút',
      audioTranscript:
          'Welcome to our orientation lecture on Academic Integrity in the Age of Artificial Intelligence. As university students, you are encouraged to utilize large language models as brainstorming partners, code debuggers, and language tutors. However, submitting AI-generated essays as your own original research constitutes plagiarism. Always verify citations against primary peer-reviewed journals and disclose how computational tools assisted your workflow.',
      vietnameseTranslation:
          'Chào mừng các bạn đến với bài giảng định hướng về Liêm chính Học thuật trong Kỷ nguyên Trí tuệ Nhân tạo. Là sinh viên đại học, các bạn được khuyến khích sử dụng các mô hình ngôn ngữ lớn làm người bạn đồng hành lên ý tưởng, gỡ lỗi mã nguồn và gia sư ngôn ngữ. Tuy nhiên, việc nộp các bài luận do AI tạo ra như nghiên cứu gốc của chính bạn bị coi là đạo văn. Hãy luôn kiểm chứng trích dẫn với các tạp chí khoa học bình duyệt gốc và minh bạch cách các công cụ tính toán đã hỗ trợ quy trình làm việc của bạn.',
      dictationSentence:
          'Always verify citations against primary peer-reviewed journals.',
      keyVocab: <VocabFlashcard>[
        VocabFlashcard(
          word: 'academic integrity',
          ipa: '/ˌækəˈdemɪk ɪnˈteɡrəti/',
          partOfSpeech: 'n. phr.',
          meaningVi: 'liêm chính học thuật',
          exampleEn:
              'Universities enforce strict policies to uphold academic integrity.',
          topic: 'University Life',
        ),
        VocabFlashcard(
          word: 'plagiarism',
          ipa: '/ˈpleɪdʒərɪzəm/',
          partOfSpeech: 'n.',
          meaningVi: 'sự đạo văn',
          exampleEn:
              'Proper citation is essential to avoid unintentional plagiarism.',
          topic: 'Academic Writing',
        ),
        VocabFlashcard(
          word: 'peer-reviewed',
          ipa: '/ˈpɪə rɪˌvjuːd/',
          partOfSpeech: 'adj.',
          meaningVi: 'được bình duyệt bởi chuyên gia cùng ngành',
          exampleEn:
              'You should cite at least five peer-reviewed articles in your thesis.',
          topic: 'Research',
        ),
      ],
      questions: <ComprehensionMcq>[
        ComprehensionMcq(
          question:
              'Theo bài giảng, sinh viên ĐƯỢC khuyến khích sử dụng AI vào mục đích nào?',
          options: <String>[
            'Làm trợ lý lên ý tưởng (brainstorming), gỡ lỗi code và gia sư ngôn ngữ',
            'Viết toàn bộ bài luận tốt nghiệp rồi nộp trực tiếp không cần chỉnh sửa',
            'Tự bịa ra danh mục tài liệu tham khảo khoa học',
            'Thay thế hoàn toàn việc đọc các tạp chí chuyên ngành',
          ],
          correctIndex: 0,
          explanationVi:
              'Bài giảng nêu rõ: "you are encouraged to utilize large language models as brainstorming partners, code debuggers, and language tutors."',
        ),
        ComprehensionMcq(
          question:
              'Sinh viên phải làm gì với các nguồn trích dẫn tài liệu (citations)?',
          options: <String>[
            'Không cần ghi nguồn nếu lấy từ Internet',
            'Kiểm chứng trực tiếp với các tạp chí khoa học bình duyệt gốc (primary peer-reviewed journals)',
            'Chỉ trích dẫn từ mạng xã hội',
            'Giấu quy trình sử dụng công cụ hỗ trợ',
          ],
          correctIndex: 1,
          explanationVi:
              'Giảng viên nhấn mạnh: "Always verify citations against primary peer-reviewed journals and disclose how computational tools assisted your workflow."',
        ),
      ],
    ),
    ListeningLesson(
      id: 'lis_2',
      title: 'Seminar: Global Supply Chain & Green Logistics',
      category: 'Thảo luận Kinh tế & Quản trị • IELTS Listening Part 3',
      cefrLevel: 'B2 - C1',
      durationLabel: '3 phút',
      audioTranscript:
          'In today’s economics seminar, we examine how multinational corporations are restructuring their supply chains. Rather than relying solely on just-in-time inventory to minimize warehousing costs, firms are adopting a diversification strategy known as China Plus One, alongside decarbonizing maritime freight. Notice how resilience and sustainability have superseded pure cost reduction as the primary metrics for executive decision-making.',
      vietnameseTranslation:
          'Trong buổi thảo luận kinh tế hôm nay, chúng ta phân tích cách các tập đoàn đa quốc gia đang tái cấu trúc chuỗi cung ứng. Thay vì chỉ dựa vào mô hình tồn kho tức thời (just-in-time) để tối thiểu hóa chi phí lưu kho, các doanh nghiệp đang áp dụng chiến lược đa dạng hóa cùng với việc giảm phát thải carbon trong vận tải đường biển. Hãy chú ý cách tính bền vững và khả năng chống chịu đã vượt qua việc cắt giảm chi phí thuần túy để trở thành thước đo chính cho việc ra quyết định.',
      dictationSentence:
          'Resilience and sustainability have superseded pure cost reduction.',
      keyVocab: <VocabFlashcard>[
        VocabFlashcard(
          word: 'supply chain resilience',
          ipa: '/səˈplaɪ tʃeɪn rɪˈzɪliəns/',
          partOfSpeech: 'n. phr.',
          meaningVi: 'khả năng chống chịu và phục hồi của chuỗi cung ứng',
          exampleEn:
              'Global disruptions highlighted the need for supply chain resilience.',
          topic: 'Economics & Business',
        ),
        VocabFlashcard(
          word: 'supersede',
          ipa: '/ˌsuːpəˈsiːd/',
          partOfSpeech: 'v.',
          meaningVi: 'thay thế, vượt lên chiếm vị trí quan trọng hơn',
          exampleEn:
              'Cloud computing has largely superseded local tape backups.',
          topic: 'Academic Core',
        ),
      ],
      questions: <ComprehensionMcq>[
        ComprehensionMcq(
          question:
              'Trước đây, mô hình tồn kho "just-in-time" chủ yếu nhằm mục đích gì?',
          options: <String>[
            'Tối thiểu hóa chi phí lưu kho (minimize warehousing costs)',
            'Tăng lượng khí thải carbon trong vận tải biển',
            'Mở rộng nhà máy sang 10 quốc gia cùng lúc',
            'Tăng lượng hàng tồn kho dự trữ trong 5 năm',
          ],
          correctIndex: 0,
          explanationVi:
              'Bài nghe nêu rõ: "relying solely on just-in-time inventory to minimize warehousing costs".',
        ),
        ComprehensionMcq(
          question:
              'Hai tiêu chí nào hiện nay đã vượt lên trên việc cắt giảm chi phí thuần túy?',
          options: <String>[
            'Tốc độ quảng cáo và số lượng nhân sự',
            'Khả năng chống chịu (Resilience) và Tính bền vững (Sustainability)',
            'Chi phí thuê văn phòng và thuế nhập khẩu',
            'Sản xuất thủ công và vận chuyển đường bộ',
          ],
          correctIndex: 1,
          explanationVi:
              '"Notice how resilience and sustainability have superseded pure cost reduction..."',
        ),
      ],
    ),
    ListeningLesson(
      id: 'lis_3',
      title: 'Campus Advisory: Applying for Research Internships',
      category: 'Hỗ trợ Sinh viên & Sự nghiệp • IELTS Listening Part 2',
      cefrLevel: 'B1 - B2',
      durationLabel: '2 phút',
      audioTranscript:
          'If you plan to apply for a summer undergraduate research internship, start contacting faculty advisors at least three months before the deadline. Avoid sending generic mass emails. Instead, read two of the professor’s recent publications, highlight a specific research question that intrigues you, and attach a concise one-page curriculum vitae emphasizing your laboratory or programming coursework.',
      vietnameseTranslation:
          'Nếu bạn dự định ứng tuyển kỳ thực tập nghiên cứu mùa hè dành cho sinh viên đại học, hãy bắt đầu liên hệ với các giảng viên hướng dẫn ít nhất ba tháng trước hạn chót. Tránh gửi email hàng loạt chung chung. Thay vào đó, hãy đọc hai công bố khoa học gần đây của giáo sư, nêu bật một câu hỏi nghiên cứu cụ thể khiến bạn hứng thú, và đính kèm một bản CV súc tích dài một trang nhấn mạnh các môn học thí nghiệm hoặc lập trình của bạn.',
      dictationSentence:
          'Avoid sending generic mass emails to faculty advisors.',
      keyVocab: <VocabFlashcard>[
        VocabFlashcard(
          word: 'faculty advisor',
          ipa: '/ˈfæklti ədˈvaɪzər/',
          partOfSpeech: 'n. phr.',
          meaningVi: 'cố vấn học tập / giảng viên hướng dẫn khoa',
          exampleEn:
              'Consult your faculty advisor before finalizing your thesis topic.',
          topic: 'University Life',
        ),
        VocabFlashcard(
          word: 'concise',
          ipa: '/kənˈsaɪs/',
          partOfSpeech: 'adj.',
          meaningVi: 'ngắn gọn, súc tích',
          exampleEn: 'Keep your research abstract clear and concise.',
          topic: 'Academic Writing',
        ),
      ],
      questions: <ComprehensionMcq>[
        ComprehensionMcq(
          question:
              'Sinh viên nên làm gì trước khi gửi email xin thực tập nghiên cứu cho Giáo sư?',
          options: <String>[
            'Gửi một mẫu email giống hệt nhau cho 50 giáo sư cùng lúc',
            'Đọc 2 bài báo khoa học gần đây của giáo sư và nêu câu hỏi nghiên cứu mình tâm đắc',
            'Viết một bản CV dài 10 trang kể về sở thích cá nhân',
            'Đợi đến đúng ngày hết hạn mới bắt đầu gửi email',
          ],
          correctIndex: 1,
          explanationVi:
              'Đoạn nghe khuyên: "read two of the professor’s recent publications, highlight a specific research question that intrigues you..."',
        ),
      ],
    ),
  ];

  /// Built-in Speaking Drills for pronunciation & shadowing practice.
  static const List<SpeakingDrill> speakingDrills = <SpeakingDrill>[
    SpeakingDrill(
      id: 'spk_1',
      category: 'Thuyết trình Đồ án & Seminar',
      cefrLevel: 'B2',
      sentenceEn:
          'Our empirical findings demonstrate a statistically significant correlation between the two variables.',
      ipa:
          '/aʊər ɪmˈpɪrɪkl ˈfaɪndɪŋz ˈdemənstreɪt ə stəˈtɪstɪkli sɪɡˈnɪfɪkənt ˌkɒrəˈleɪʃn bɪˈtwiːn ðə tuː ˈveəriəblz/',
      meaningVi:
          'Các kết quả thực nghiệm của chúng tôi chứng minh mối tương quan có ý nghĩa thống kê giữa hai biến số.',
      tipVi:
          'Nhấn rõ trọng âm ở "emPIrical", "staTIStically", "sigNIficant" và "correLAtion". Đừng quên âm /z/ cuối từ "findings".',
    ),
    SpeakingDrill(
      id: 'spk_2',
      category: 'Phỏng vấn Thực tập MNC',
      cefrLevel: 'B2',
      sentenceEn:
          'During my junior year at university, I spearheaded a cross-functional team to optimize our database architecture.',
      ipa:
          '/ˈdjʊərɪŋ maɪ ˈdʒuːniər jɪər æt ˌjuːnɪˈvɜːsəti aɪ ˈspɪəhedɪd ə ˌkrɒs ˈfʌŋkʃənl tiːm tuː ˈɒptɪmaɪz aʊər ˈdeɪtəbeɪs ˈɑːkɪtektʃər/',
      meaningVi:
          'Trong năm ba đại học, tôi đã dẫn dắt một nhóm liên chức năng để tối ưu hóa kiến trúc cơ sở dữ liệu của chúng tôi.',
      tipVi:
          'Từ "spearheaded" (/ˈspɪəhedɪd/ - dẫn dắt/tiên phong) là động từ hành động cực kỳ ăn điểm khi phỏng vấn thực tập.',
    ),
    SpeakingDrill(
      id: 'spk_3',
      category: 'IELTS Speaking Part 3 • Công nghệ',
      cefrLevel: 'C1',
      sentenceEn:
          'From a macroeconomic perspective, technological innovation acts as a catalyst for sustainable productivity growth.',
      ipa:
          '/frɒm ə ˌmækrəʊˌiːkəˈnɒmɪk pəˈspektɪv ˌteknəˈlɒdʒɪkl ˌɪnəˈveɪʃn ækts æz ə ˈkætəlɪst fɔːr səˈsteɪnəbl ˌprɒdʌkˈtɪvəti ɡrəʊθ/',
      meaningVi:
          'Từ góc độ kinh tế vĩ mô, đổi mới công nghệ đóng vai trò là chất xúc tác cho tăng trưởng năng suất bền vững.',
      tipVi:
          'Chú ý phát âm chuẩn từ "catalyst" (/ˈkætəlɪst/ - chất xúc tác) và giữ nhịp ngắt hơi tự nhiên sau từ "perspective".',
    ),
    SpeakingDrill(
      id: 'spk_4',
      category: 'Thảo luận & Phản biện Học thuật',
      cefrLevel: 'B1 - B2',
      sentenceEn:
          'While that approach is cost-effective in the short term, we must consider its long-term environmental implications.',
      ipa:
          '/waɪl ðæt əˈprəʊtʃ ɪz ˈkɒst ɪˈfektɪv ɪn ðə ʃɔːt tɜːm wiː mʌst kənˈsɪdər ɪts ˈlɒŋ tɜːm ɪnˌvaɪrənˈmentl ˌɪmplɪˈkeɪʃnz/',
      meaningVi:
          'Mặc dù cách tiếp cận đó tiết kiệm chi phí trong ngắn hạn, chúng ta phải cân nhắc các hệ quả môi trường dài hạn của nó.',
      tipVi:
          'Lên giọng nhẹ ở cuối vế đầu ("short term ↗") và hạ giọng dứt khoát ở cuối câu ("implications ↘").',
    ),
  ];

  /// Interactive AI 1-1 Roleplay Scenarios for university students.
  static const List<RoleplayScenario> roleplayScenarios = <RoleplayScenario>[
    RoleplayScenario(
      id: 'rp_internship',
      title: 'Phỏng vấn Thực tập Tập đoàn Đa quốc gia (MNC)',
      subtitle: 'Luyện trả lời phỏng vấn bằng phương pháp STAR với HR Manager',
      cefrLevel: 'B2',
      aiRoleName: 'Ms. Clara (Global Talent Acquisition)',
      systemInstruction:
          'You are Ms. Clara, an encouraging yet professional HR Manager at a multinational tech and business corporation interviewing a Vietnamese university student for a Summer Internship. Speak in clear, natural English (2-3 sentences per turn). After responding in character, ALWAYS add a short section starting with "💡 **Gợi ý nâng cấp câu nói (Better Phrasing):**" in Vietnamese/English showing how the student can make their answer sound more natural, confident, and Band 7.5+.',
      openingLineEn:
          'Welcome to our final internship interview! To start off, could you tell me about your university major and one academic project you are most proud of?',
      openingLineVi:
          'Chào mừng bạn đến với buổi phỏng vấn thực tập! Để bắt đầu, bạn có thể giới thiệu về chuyên ngành đại học và một dự án học thuật mà bạn tự hào nhất không?',
      suggestedReplies: <String>[
        'I am a third-year student majoring in Computer Science, and I recently built an AI-powered learning application.',
        'I study Economics and Business Administration. Last semester, my team conducted a market analysis on renewable energy.',
        'Could you give me a moment to structure my answer using the STAR method?',
      ],
    ),
    RoleplayScenario(
      id: 'rp_ielts',
      title: 'Mô phỏng Phòng thi IELTS Speaking Part 2 & 3',
      subtitle: 'Thực chiến cùng Giám khảo IELTS với chấm điểm & sửa lỗi tức thì',
      cefrLevel: 'B1 - C1',
      aiRoleName: 'Examiner David (Certified IELTS Examiner)',
      systemInstruction:
          'You are Examiner David, a certified IELTS Speaking examiner coaching a university student. Ask engaging IELTS Speaking Part 2 and Part 3 questions about education, technology, career, and society. After each user response, reply naturally in English with a follow-up question, AND include a concise block "🎯 **Nhận xét Band IELTS & Từ vựng nâng cấp:**" giving an estimated Band score for that turn plus 1-2 C1 collocations.',
      openingLineEn:
          'Good afternoon! Let’s dive into IELTS Speaking Part 3. In your opinion, how has technology transformed the way university students conduct research compared to ten years ago?',
      openingLineVi:
          'Chào buổi chiều! Hãy bắt đầu với IELTS Speaking Part 3. Theo bạn, công nghệ đã thay đổi cách sinh viên đại học thực hiện nghiên cứu như thế nào so với 10 năm trước?',
      suggestedReplies: <String>[
        'Technology has revolutionized academic research by providing instant access to digital libraries and AI analysis tools.',
        'Compared to a decade ago, students can collaborate remotely and process massive datasets in seconds.',
      ],
    ),
    RoleplayScenario(
      id: 'rp_thesis',
      title: 'Bảo vệ Đồ án / Khóa luận Tốt nghiệp bằng Tiếng Anh',
      subtitle: 'Trả lời câu hỏi phản biện từ Hội đồng Giáo sư hướng dẫn',
      cefrLevel: 'B2 - C1',
      aiRoleName: 'Prof. Anderson (Thesis Defense Committee)',
      systemInstruction:
          'You are Professor Anderson on a university thesis defense committee. Ask thoughtful academic questions about research methodology, limitations, practical applications, and future work. After responding in English, add "🎓 **Gợi ý diễn đạt Học thuật (Academic Upgrade):**" to help the student refine their academic English.',
      openingLineEn:
          'Thank you for your presentation. Could you clarify the primary limitation of your current research methodology and how you plan to address it in future iterations?',
      openingLineVi:
          'Cảm ơn phần trình bày của bạn. Bạn có thể làm rõ hạn chế chính trong phương pháp nghiên cứu hiện tại và cách bạn dự định khắc phục trong các giai đoạn tiếp theo không?',
      suggestedReplies: <String>[
        'The primary limitation is our sample size of 150 participants, which we plan to expand across multiple universities next semester.',
        'While our prototype performs well in controlled simulations, we need real-world deployment data to validate its scalability.',
      ],
    ),
  ];

  /// Built-in Academic Reading Passages with bilingual support & tap-to-save vocabulary.
  static const List<ReadingPassage> readingPassages = <ReadingPassage>[
    ReadingPassage(
      id: 'read_1',
      title: 'Neuroplasticity & Cognitive Load in Higher Education',
      majorTag: 'Khoa học Nhận thức & Giáo dục Đại học',
      cefrLevel: 'B2',
      readingTimeLabel: '4 phút đọc',
      paragraphsEn: <String>[
        'For decades, neuroscientists believed that the adult brain was largely immutable after early childhood. Contemporary neuroimaging studies, however, have conclusively demonstrated that neuroplasticity—the brain’s ability to reorganize synaptic connections in response to learning—persists throughout university years and adulthood.',
        'When university students acquire a second language or master complex analytical frameworks, active retrieval practice strengthens neural pathways far more effectively than passive re-reading. Nevertheless, cognitive load theory warns that bombarding working memory with unstructured multitasking impedes schema consolidation.',
        'Consequently, educators advocate interleaving different problem types and incorporating deliberate rest intervals. By aligning study habits with neurobiological mechanisms, students can achieve durable mastery while mitigating academic burnout.',
      ],
      paragraphsVi: <String>[
        'Trong nhiều thập kỷ, các nhà thần kinh học từng tin rằng bộ não người trưởng thành hầu như không thay đổi sau thời thơ ấu. Tuy nhiên, các nghiên cứu hình ảnh thần kinh hiện đại đã chứng minh thuyết phục rằng tính khả biến thần kinh (neuroplasticity) — khả năng tái tổ chức các kết nối khớp thần kinh để đáp ứng với việc học — vẫn tiếp diễn trong suốt những năm đại học và tuổi trưởng thành.',
        'Khi sinh viên đại học tiếp thu ngôn ngữ thứ hai hoặc làm chủ các khung phân tích phức tạp, việc thực hành chủ động truy xuất thông tin (active retrieval) củng cố các đường dẫn truyền thần kinh hiệu quả hơn nhiều so với việc đọc lại thụ động. Tuy nhiên, lý thuyết tải nhận thức cảnh báo rằng việc dồn ép trí nhớ làm việc bằng sự đa nhiệm thiếu cấu trúc sẽ cản trở quá trình củng cố kiến thức.',
        'Do đó, các nhà giáo dục khuyến nghị đan xen các dạng bài tập khác nhau (interleaving) và kết hợp các khoảng nghỉ có chủ đích. Bằng cách điều chỉnh thói quen học tập phù hợp với cơ chế sinh học thần kinh, sinh viên có thể đạt được sự thông thạo bền vững đồng thời giảm thiểu tình trạng kiệt sức học tập.',
      ],
      highlights: <VocabFlashcard>[
        VocabFlashcard(
          word: 'immutable',
          ipa: '/ɪˈmjuːtəbl/',
          partOfSpeech: 'adj.',
          meaningVi: 'bất biến, không thể thay đổi',
          exampleEn: 'The laws of physics are considered immutable.',
          topic: 'Academic Reading',
        ),
        VocabFlashcard(
          word: 'impede',
          ipa: '/ɪmˈpiːd/',
          partOfSpeech: 'v.',
          meaningVi: 'cản trở, làm chậm tiến độ',
          exampleEn:
              'Lack of sleep severely impedes cognitive performance.',
          topic: 'Academic Reading',
        ),
        VocabFlashcard(
          word: 'mitigate',
          ipa: '/ˈmɪtɪɡeɪt/',
          partOfSpeech: 'v.',
          meaningVi: 'giảm nhẹ, làm dịu bớt (rủi ro/tác động xấu)',
          exampleEn:
              'Proper time management helps mitigate academic burnout.',
          topic: 'Academic Core',
        ),
      ],
      questions: <ComprehensionMcq>[
        ComprehensionMcq(
          question:
              'Theo đoạn 2, phương pháp học tập nào giúp củng cố đường dẫn truyền thần kinh hiệu quả hơn đọc lại thụ động?',
          options: <String>[
            'Active retrieval practice (Thực hành chủ động truy xuất thông tin)',
            'Vừa học vừa làm nhiều việc không cấu trúc (Unstructured multitasking)',
            'Học thuộc lòng trong một đêm duy nhất',
            'Chỉ nghe nhạc mà không làm bài tập',
          ],
          correctIndex: 0,
          explanationVi:
              'Đoạn 2 nêu rõ: "active retrieval practice strengthens neural pathways far more effectively than passive re-reading."',
        ),
        ComprehensionMcq(
          question:
              'Lý thuyết tải nhận thức (Cognitive load theory) cảnh báo điều gì?',
          options: <String>[
            'Bộ não người trưởng thành không thể học thêm ngôn ngữ thứ hai',
            'Việc đa nhiệm thiếu cấu trúc gây quá tải trí nhớ làm việc và cản trở việc củng cố kiến thức',
            'Sinh viên không bao giờ nên nghỉ ngơi giữa các giờ học',
            'Việc đan xen các dạng bài tập làm giảm hiệu quả ghi nhớ',
          ],
          correctIndex: 1,
          explanationVi:
              '"cognitive load theory warns that bombarding working memory with unstructured multitasking impedes schema consolidation."',
        ),
      ],
    ),
    ReadingPassage(
      id: 'read_2',
      title: 'Algorithmic Governance & Ethical AI Deployment',
      majorTag: 'CNTT, Khoa học Dữ liệu & Luật Công nghệ',
      cefrLevel: 'C1',
      readingTimeLabel: '5 phút đọc',
      paragraphsEn: <String>[
        'As autonomous decision-making systems permeate financial markets, healthcare triage, and recruitment pipelines, the demand for explainable artificial intelligence (XAI) has intensified. Deep neural networks often operate as opaque "black boxes," rendering it arduous for auditors to trace how specific inputs yield a given classification.',
        'To foster public trust, regulatory frameworks increasingly mandate algorithmic transparency and human-in-the-loop oversight. Computer science graduates entering the workforce must therefore balance predictive accuracy with ethical accountability and fairness constraints.',
      ],
      paragraphsVi: <String>[
        'Khi các hệ thống ra quyết định tự động thâm nhập vào thị trường tài chính, phân loại y tế và quy trình tuyển dụng, nhu cầu về trí tuệ nhân tạo có thể giải thích được (XAI) ngày càng gia tăng. Các mạng nơ-ron sâu thường hoạt động như những "hộp đen" mờ đục, khiến các kiểm toán viên rất khó truy vết cách các đầu vào cụ thể tạo ra một kết quả phân loại nhất định.',
        'Để củng cố niềm tin của công chúng, các khung pháp lý ngày càng bắt buộc tính minh bạch của thuật toán và sự giám sát có con người tham gia (human-in-the-loop). Do đó, sinh viên tốt nghiệp ngành khoa học máy tính khi bước vào thị trường lao động phải cân bằng giữa độ chính xác dự đoán với trách nhiệm đạo đức và các ràng buộc về sự công bằng.',
      ],
      highlights: <VocabFlashcard>[
        VocabFlashcard(
          word: 'permeate',
          ipa: '/ˈpɜːmieɪt/',
          partOfSpeech: 'v.',
          meaningVi: 'thâm nhập, lan tỏa khắp mọi lĩnh vực',
          exampleEn:
              'Digital technology has permeated every aspect of modern university education.',
          topic: 'Technology & AI',
        ),
        VocabFlashcard(
          word: 'opaque',
          ipa: '/əʊˈpeɪk/',
          partOfSpeech: 'adj.',
          meaningVi: 'mờ đục, khó hiểu, thiếu minh bạch',
          exampleEn:
              'Regulators criticized the opaque decision-making process of the model.',
          topic: 'Academic Reading',
        ),
        VocabFlashcard(
          word: 'accountability',
          ipa: '/əˌkaʊntəˈbɪləti/',
          partOfSpeech: 'n.',
          meaningVi: 'trách nhiệm giải trình',
          exampleEn:
              'Ethical AI requires clear accountability when errors occur.',
          topic: 'Ethics & Law',
        ),
      ],
      questions: <ComprehensionMcq>[
        ComprehensionMcq(
          question:
              'Tại sao các mạng nơ-ron sâu thường được mô tả là "opaque black boxes"?',
          options: <String>[
            'Vì chúng được sơn màu đen trong phòng máy chủ',
            'Vì rất khó để kiểm toán viên truy vết cách dữ liệu đầu vào tạo ra kết quả phân loại cụ thể',
            'Vì chúng không cần sử dụng điện năng để vận hành',
            'Vì mã nguồn của chúng chỉ dài dưới 10 dòng lệnh',
          ],
          correctIndex: 1,
          explanationVi:
              'Đoạn 1 giải thích: "rendering it arduous for auditors to trace how specific inputs yield a given classification."',
        ),
      ],
    ),
  ];

  /// Built-in Academic Writing Prompts for university students.
  static const List<WritingPrompt> writingPrompts = <WritingPrompt>[
    WritingPrompt(
      id: 'wrt_1',
      title: 'IELTS Writing Task 2: AI & University Education',
      category: 'IELTS Writing Task 2 • Academic Essay',
      cefrLevel: 'B2 - C1',
      minWords: 80,
      promptEn:
          'Some educators argue that universities should restrict the use of Artificial Intelligence tools in coursework, while others believe mastering AI is essential for future graduates. Discuss both views and give your own opinion.',
      guideVi:
          'Cấu trúc gợi ý (4 đoạn):\n1. Introduction: Paraphrase đề bài + Nêu rõ Thesis Statement (quan điểm cân bằng: không cấm tuyệt đối mà tích hợp có kiểm soát).\n2. Body 1: Lý do một số giảng viên lo ngại (phụ thuộc AI, suy giảm tư duy độc lập).\n3. Body 2: Lợi ích thiết yếu cho sinh viên khi ra trường (tăng năng suất, yêu cầu của nhà tuyển dụng).\n4. Conclusion: Khẳng định lại quan điểm.',
      keyStructures: <String>[
        'While critics contend that..., proponents maintain that...',
        'Strike a balance between technological integration and academic integrity',
        'Equip undergraduates with future-proof analytical competencies',
      ],
    ),
    WritingPrompt(
      id: 'wrt_2',
      title: 'Formal Email: Xin tham gia Nhóm Nghiên cứu / Khóa luận với Giáo sư',
      category: 'Academic Email • Giao tiếp Đại học',
      cefrLevel: 'B1 - B2',
      minWords: 50,
      promptEn:
          'Write a formal email to Professor Nguyen requesting an opportunity to join their research laboratory as an undergraduate assistant next semester. Mention your major, relevant skills, and why their recent paper interested you.',
      guideVi:
          'Bố cục chuẩn Email Học thuật:\n• Subject Line rõ ràng (e.g., Inquiry Regarding Undergraduate Research Assistant Opportunity)\n• Lời chào trang trọng (Dear Professor...)\n• Giới thiệu ngắn gọn bản thân (Năm học, chuyên ngành, GPA/kỹ năng)\n• Nêu lý do quan tâm đến hướng nghiên cứu của Giáo sư\n• Đề xuất lịch hẹn trao đổi ngắn & lời kết (Sincerely / Best regards).',
      keyStructures: <String>[
        'I am writing to express my strong interest in joining your research group...',
        'Having recently read your publication on..., I was particularly intrigued by...',
        'I have attached my curriculum vitae and academic transcript for your review.',
      ],
    ),
    WritingPrompt(
      id: 'wrt_3',
      title: 'Cover Letter: Ứng tuyển Thực tập sinh Tập đoàn Đa quốc gia (MNC)',
      category: 'Career & Internship • Business Writing',
      cefrLevel: 'B2',
      minWords: 60,
      promptEn:
          'Write a professional cover letter applying for a Management Trainee or Software Engineering Internship at a multinational company. Highlight one university project where you solved a challenging problem.',
      guideVi:
          'Nhấn mạnh sự phù hợp giữa kiến thức đại học và giá trị mang lại cho doanh nghiệp. Sử dụng các động từ hành động mạnh (spearheaded, optimized, collaborated, analyzed) và số liệu cụ thể.',
      keyStructures: <String>[
        'I am thrilled to submit my application for the Summer Internship position...',
        'Through my academic capstone project, I honed my ability to...',
        'I would welcome the opportunity to discuss how my analytical background aligns with your team’s goals.',
      ],
    ),
  ];
}
