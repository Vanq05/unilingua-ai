import 'dart:math';

import '../../domain/models/learning_models.dart';

/// A uniquely generated Placement Exam instance (different questions every attempt).
class PlacementExamSet {
  const PlacementExamSet({
    required this.examCode,
    required this.questions,
    required this.dictationAudio,
    required this.speakingPrompt1,
    required this.speakingPrompt2,
    required this.writingPrompt,
  });

  final String examCode;
  final List<PlacementQuestion> questions;
  final String dictationAudio;
  final String speakingPrompt1;
  final String speakingPrompt2;
  final String writingPrompt;
}

/// Curriculum starting from A1 (beginner / mất gốc) and progressing step by step
/// to A2 -> B1 -> B2 with practical daily communication and a 30+ question
/// multi-bank randomized Placement Test generator.
class CurriculumRepository {
  const CurriculumRepository._();

  static const List<int> dailyMinuteOptions = <int>[15, 30, 45];
  static const List<int> targetWeekOptions = <int>[4, 8, 12, 16];

  static const String placementDictationAudio =
      'I want to speak English every day.';

  static const String placementSpeakingPrompt1 =
      'Giới thiệu ngắn về bản thân bạn bằng 1–3 câu tiếng Anh.';

  static const String placementSpeakingPrompt2 =
      'Nói 1–2 câu tiếng Anh về việc bạn thường làm vào cuối tuần.';

  static const String placementWritingPrompt =
      'Viết 2–5 câu tiếng Anh về bản thân hoặc lý do bạn muốn học tiếng Anh.';

  // ==================== MULTI-BANK PLACEMENT POOLS (30+ QUESTIONS) ====================

  static const List<PlacementQuestion> _listeningA1Pool = <PlacementQuestion>[
    PlacementQuestion(
      id: 'l_a1_1',
      skill: SkillType.listening,
      cefrDifficulty: 'A1',
      topicTag: 'Nghe thời gian (A1)',
      audioScript:
          'Hi, my name is Anna. I am a student. I wake up at seven o clock every morning.',
      prompt: 'Nghe đoạn ngắn: Anna thức dậy lúc mấy giờ mỗi sáng?',
      options: <String>['6 giờ sáng', '7 giờ sáng', '8 giờ sáng', '9 giờ sáng'],
      correctIndex: 1,
      explanationVi: 'Anna nói: "I wake up at seven o\'clock" (7 giờ sáng).',
      weight: 20,
    ),
    PlacementQuestion(
      id: 'l_a1_2',
      skill: SkillType.listening,
      cefrDifficulty: 'A1',
      topicTag: 'Nghe đồ ăn thức uống (A1)',
      audioScript:
          'Hello, I am Tom. For breakfast, I usually eat bread and drink a cup of warm milk.',
      prompt: 'Nghe đoạn ngắn: Tom thường uống gì vào bữa sáng?',
      options: <String>['Nước cam', 'Cà phê đá', 'Sữa ấm', 'Trà xanh'],
      correctIndex: 2,
      explanationVi: 'Tom nói: "drink a cup of warm milk" (một ly sữa ấm).',
      weight: 20,
    ),
    PlacementQuestion(
      id: 'l_a1_3',
      skill: SkillType.listening,
      cefrDifficulty: 'A1',
      topicTag: 'Nghe số đếm & gia đình (A1)',
      audioScript:
          'My name is Lan. I have two younger brothers and one dog at home.',
      prompt: 'Nghe đoạn ngắn: Lan có mấy người em trai?',
      options: <String>['1 người', '2 người', '3 người', 'Không có'],
      correctIndex: 1,
      explanationVi: 'Lan nói: "I have two younger brothers" (2 người em trai).',
      weight: 20,
    ),
  ];

  static const List<PlacementQuestion> _listeningA2Pool = <PlacementQuestion>[
    PlacementQuestion(
      id: 'l_a2_1',
      skill: SkillType.listening,
      cefrDifficulty: 'A2',
      topicTag: 'Nghe mua đồ uống (A2)',
      audioScript:
          'Customer: Excuse me, how much is this iced coffee? Staff: It is three dollars.',
      prompt: 'Ly cà phê đá trong đoạn hội thoại giá bao nhiêu?',
      options: <String>['2 đô la', '3 đô la', '4 đô la', '5 đô la'],
      correctIndex: 1,
      explanationVi: 'Nhân viên trả lời: "It is three dollars" (3 đô la).',
      weight: 30,
    ),
    PlacementQuestion(
      id: 'l_a2_2',
      skill: SkillType.listening,
      cefrDifficulty: 'A2',
      topicTag: 'Nghe hỏi đường (A2)',
      audioScript:
          'Excuse me, where is the library? Go straight for two blocks, then turn left. It is next to the bank.',
      prompt: 'Thư viện nằm ở đâu?',
      options: <String>[
        'Bên cạnh ngân hàng',
        'Trong công viên',
        'Đối diện sân bay',
        'Phía sau bệnh viện',
      ],
      correctIndex: 0,
      explanationVi: 'Người chỉ đường nói: "It is next to the bank."',
      weight: 30,
    ),
    PlacementQuestion(
      id: 'l_a2_3',
      skill: SkillType.listening,
      cefrDifficulty: 'A2',
      topicTag: 'Nghe hẹn bạn cuối tuần (A2)',
      audioScript:
          'Hey Minh, are you free on Saturday afternoon? Let us watch a movie at the mall at three p.m.',
      prompt: 'Hai người bạn hẹn đi xem phim vào lúc nào?',
      options: <String>[
        'Sáng thứ Sáu lúc 8 giờ',
        'Chiều thứ Bảy lúc 3 giờ',
        'Tối Chủ nhật lúc 7 giờ',
        'Chiều thứ Hai lúc 2 giờ',
      ],
      correctIndex: 1,
      explanationVi: '"on Saturday afternoon... at three p.m."',
      weight: 30,
    ),
  ];

  static const List<PlacementQuestion> _listeningB1Pool = <PlacementQuestion>[
    PlacementQuestion(
      id: 'l_b1_1',
      skill: SkillType.listening,
      cefrDifficulty: 'B1',
      topicTag: 'Nghe đổi lịch học (B1)',
      audioScript:
          'Tomorrow our English class will start at nine thirty instead of eight o clock because our teacher has a morning meeting.',
      prompt: 'Ngày mai lớp tiếng Anh sẽ bắt đầu lúc mấy giờ?',
      options: <String>[
        '8:00 sáng như cũ',
        '9:30 sáng vì giáo viên bận họp',
        '10:00 sáng',
        'Lớp được nghỉ cả ngày',
      ],
      correctIndex: 1,
      explanationVi: '"will start at nine thirty instead of eight o\'clock".',
      weight: 40,
    ),
    PlacementQuestion(
      id: 'l_b1_2',
      skill: SkillType.listening,
      cefrDifficulty: 'B1',
      topicTag: 'Nghe phỏng vấn làm thêm (B1)',
      audioScript:
          'I would like to apply for the weekend cashier position because I have classes from Monday to Friday.',
      prompt: 'Tại sao bạn sinh viên muốn làm vị trí thu ngân vào cuối tuần?',
      options: <String>[
        'Vì lương cuối tuần thấp hơn',
        'Vì bạn ấy có lịch học từ thứ Hai đến thứ Sáu',
        'Vì quán đóng cửa các ngày trong tuần',
        'Vì bạn ấy không thích đi học',
      ],
      correctIndex: 1,
      explanationVi: '"because I have classes from Monday to Friday."',
      weight: 40,
    ),
    PlacementQuestion(
      id: 'l_b1_3',
      skill: SkillType.listening,
      cefrDifficulty: 'B1',
      topicTag: 'Nghe mẹo học tiếng Anh (B1)',
      audioScript:
          'Instead of memorizing long lists of words, try using each new word in a short spoken sentence every day.',
      prompt: 'Người nói khuyên cách học từ vựng nào hiệu quả hơn?',
      options: <String>[
        'Chép danh sách 100 từ mỗi đêm',
        'Đưa mỗi từ mới vào một câu nói ngắn hàng ngày',
        'Chỉ đọc thầm không bao giờ phát âm',
        'Không cần học từ mới',
      ],
      correctIndex: 1,
      explanationVi: '"try using each new word in a short spoken sentence every day."',
      weight: 40,
    ),
  ];

  static const List<PlacementQuestion> _readingA1Pool = <PlacementQuestion>[
    PlacementQuestion(
      id: 'r_a1_1',
      skill: SkillType.reading,
      cefrDifficulty: 'A1',
      topicTag: 'Đọc tin nhắn ngắn (A1)',
      readingContext:
          'Hi Nam, I am at the coffee shop near our school. Let\'s study English together after class!',
      prompt: 'Người nhắn tin đang ở đâu?',
      options: <String>[
        'Ở nhà',
        'Ở quán cà phê gần trường',
        'Ở rạp phim',
        'Ở bến xe buýt',
      ],
      correctIndex: 1,
      explanationVi: '"I am at the coffee shop near our school."',
      weight: 20,
    ),
    PlacementQuestion(
      id: 'r_a1_2',
      skill: SkillType.reading,
      cefrDifficulty: 'A1',
      topicTag: 'Đọc biển báo cơ bản (A1)',
      readingContext:
          'Bookstore Opening Hours: Open Monday to Saturday, 8:00 AM to 8:00 PM. Closed on Sunday.',
      prompt: 'Hiệu sách đóng cửa vào ngày nào?',
      options: <String>['Thứ Hai', 'Thứ Tư', 'Thứ Bảy', 'Chủ nhật'],
      correctIndex: 3,
      explanationVi: '"Closed on Sunday" (Đóng cửa ngày Chủ nhật).',
      weight: 20,
    ),
    PlacementQuestion(
      id: 'r_a1_3',
      skill: SkillType.reading,
      cefrDifficulty: 'A1',
      topicTag: 'Đọc giới thiệu sở thích (A1)',
      readingContext:
          'My best friend is Hoa. She loves cooking Vietnamese food and listening to pop music in the evening.',
      prompt: 'Hoa thích làm gì vào buổi tối?',
      options: <String>[
        'Chơi bóng rổ',
        'Nghe nhạc pop',
        'Đi bơi ở biển',
        'Sửa xe đạp',
      ],
      correctIndex: 1,
      explanationVi: '"listening to pop music in the evening."',
      weight: 20,
    ),
  ];

  static const List<PlacementQuestion> _readingA2Pool = <PlacementQuestion>[
    PlacementQuestion(
      id: 'r_a2_1',
      skill: SkillType.reading,
      cefrDifficulty: 'A2',
      topicTag: 'Đọc thói quen học tập (A2)',
      readingContext:
          'Minh studies English for 20 minutes every evening. First, he learns 5 new words. Then, he listens to a short dialogue and repeats it out loud.',
      prompt: 'Mỗi tối Minh học tiếng Anh bao nhiêu phút?',
      options: <String>['10 phút', '20 phút', '45 phút', '2 tiếng'],
      correctIndex: 1,
      explanationVi: '"Minh studies English for 20 minutes every evening."',
      weight: 30,
    ),
    PlacementQuestion(
      id: 'r_a2_2',
      skill: SkillType.reading,
      cefrDifficulty: 'A2',
      topicTag: 'Đọc thông báo câu lạc bộ (A2)',
      readingContext:
          'Join our English Speaking Club every Wednesday at 5:30 PM in Room 204! Entry is free for all students, and beginners are always welcome.',
      prompt: 'Ai có thể tham gia Câu lạc bộ Nói Tiếng Anh?',
      options: <String>[
        'Chỉ người đã đạt IELTS 8.0',
        'Mọi sinh viên, kể cả người mới bắt đầu (miễn phí)',
        'Phải đóng học phí 500 nghìn mỗi buổi',
        'Chỉ dành cho giáo viên nước ngoài',
      ],
      correctIndex: 1,
      explanationVi: '"Entry is free for all students, and beginners are always welcome."',
      weight: 30,
    ),
    PlacementQuestion(
      id: 'r_a2_3',
      skill: SkillType.reading,
      cefrDifficulty: 'A2',
      topicTag: 'Đọc hiểu du lịch cơ bản (A2)',
      readingContext:
          'Last summer, Linh traveled to Da Nang by train. Although the trip took 14 hours, she enjoyed watching the ocean view through the window.',
      prompt: 'Linh đi Đà Nẵng bằng phương tiện nào?',
      options: <String>['Máy bay', 'Tàu hỏa', 'Xe máy', 'Tàu thủy'],
      correctIndex: 1,
      explanationVi: '"traveled to Da Nang by train" (đi bằng tàu hỏa).',
      weight: 30,
    ),
  ];

  static const List<PlacementQuestion> _readingB1Pool = <PlacementQuestion>[
    PlacementQuestion(
      id: 'r_b1_1',
      skill: SkillType.reading,
      cefrDifficulty: 'B1',
      topicTag: 'Đọc hiểu việc làm thêm (B1)',
      readingContext:
          'Having a part-time job during university helps students earn extra income and build communication skills. However, students should manage their schedule carefully so work does not hurt exam results.',
      prompt: 'Đoạn văn khuyên sinh viên đi làm thêm cần chú ý điều gì?',
      options: <String>[
        'Nghỉ học để đi làm cả ngày',
        'Sắp xếp lịch cẩn thận để không ảnh hưởng kết quả thi',
        'Không cần giao tiếp với ai ở chỗ làm',
        'Chỉ làm việc vào lúc nửa đêm',
      ],
      correctIndex: 1,
      explanationVi: '"manage their schedule carefully so work does not hurt exam results."',
      weight: 40,
    ),
    PlacementQuestion(
      id: 'r_b1_2',
      skill: SkillType.reading,
      cefrDifficulty: 'B1',
      topicTag: 'Đọc hiểu giấc ngủ & trí nhớ (B1)',
      readingContext:
          'Staying up all night before an exam might feel productive, yet studies show that getting seven to eight hours of sleep helps your brain organize and remember what you studied much more effectively.',
      prompt: 'Theo đoạn văn, việc ngủ đủ 7–8 tiếng giúp ích gì trước kỳ thi?',
      options: <String>[
        'Làm bạn quên hết kiến thức đã học',
        'Giúp não sắp xếp và ghi nhớ bài học hiệu quả hơn',
        'Kém hiệu quả hơn thức trắng đêm',
        'Không có tác dụng gì với trí nhớ',
      ],
      correctIndex: 1,
      explanationVi: '"helps your brain organize and remember what you studied much more effectively."',
      weight: 40,
    ),
    PlacementQuestion(
      id: 'r_b1_3',
      skill: SkillType.reading,
      cefrDifficulty: 'B1',
      topicTag: 'Đọc hiểu giao tiếp tự tin (B1)',
      readingContext:
          'Most English learners wait until their grammar is perfect before speaking. In reality, fluency develops faster when you communicate regularly and learn from small mistakes along the way.',
      prompt: 'Tác giả muốn nhấn mạnh điều gì về việc luyện nói tiếng Anh?',
      options: <String>[
        'Phải giỏi ngữ pháp 100% rồi mới được mở miệng nói',
        'Sự trôi chảy tiến bộ nhanh hơn khi bạn giao tiếp thường xuyên và sửa dần lỗi nhỏ',
        'Không bao giờ được mắc bất kỳ lỗi nào khi mới học',
        'Chỉ nên học đọc, không cần luyện nói',
      ],
      correctIndex: 1,
      explanationVi: '"fluency develops faster when you communicate regularly and learn from small mistakes."',
      weight: 40,
    ),
  ];

  static const List<PlacementQuestion> _grammarA1Pool = <PlacementQuestion>[
    PlacementQuestion(
      id: 'g_a1_1',
      skill: SkillType.writing,
      cefrDifficulty: 'A1',
      topicTag: 'Động từ To Be (A1)',
      prompt: 'Chọn từ đúng:\n"She _____ a university student."',
      options: <String>['am', 'is', 'are', 'be'],
      correctIndex: 1,
      explanationVi: 'Chủ ngữ "She" đi với "is".',
      weight: 20,
    ),
    PlacementQuestion(
      id: 'g_a1_2',
      skill: SkillType.writing,
      cefrDifficulty: 'A1',
      topicTag: 'Thì hiện tại đơn (A1)',
      prompt: 'Chọn đáp án đúng:\n"We _____ English every evening."',
      options: <String>['study', 'studies', 'studying', 'studied'],
      correctIndex: 0,
      explanationVi: 'Chủ ngữ "We" với thói quen "every evening" dùng "study".',
      weight: 20,
    ),
    PlacementQuestion(
      id: 'g_a1_3',
      skill: SkillType.writing,
      cefrDifficulty: 'A1',
      topicTag: 'Mạo từ a / an (A1)',
      prompt: 'Chọn từ đúng:\n"I eat _____ apple after lunch."',
      options: <String>['a', 'an', 'two', 'are'],
      correctIndex: 1,
      explanationVi: 'Trước danh từ số ít bắt đầu bằng nguyên âm ("apple") dùng "an".',
      weight: 20,
    ),
  ];

  static const List<PlacementQuestion> _grammarA2Pool = <PlacementQuestion>[
    PlacementQuestion(
      id: 'g_a2_1',
      skill: SkillType.writing,
      cefrDifficulty: 'A2',
      topicTag: 'Thì quá khứ đơn (A2)',
      prompt: 'Chọn đáp án đúng:\n"Yesterday, I _____ to the bookstore with my friends."',
      options: <String>['go', 'goes', 'went', 'going'],
      correctIndex: 2,
      explanationVi: '"Yesterday" dùng quá khứ đơn → quá khứ của "go" là "went".',
      weight: 30,
    ),
    PlacementQuestion(
      id: 'g_a2_2',
      skill: SkillType.writing,
      cefrDifficulty: 'A2',
      topicTag: 'Giới từ thời gian (A2)',
      prompt: 'Chọn giới từ đúng:\n"Our meeting starts _____ 9:00 AM tomorrow."',
      options: <String>['in', 'on', 'at', 'by'],
      correctIndex: 2,
      explanationVi: 'Trước giờ cụ thể luôn dùng "at".',
      weight: 30,
    ),
    PlacementQuestion(
      id: 'g_a2_3',
      skill: SkillType.writing,
      cefrDifficulty: 'A2',
      topicTag: 'So sánh hơn (A2)',
      prompt: 'Chọn đáp án đúng:\n"Listening every day makes my English _____ than before."',
      options: <String>['good', 'better', 'best', 'well'],
      correctIndex: 1,
      explanationVi: 'Có "than" dùng so sánh hơn → so sánh hơn của "good" là "better".',
      weight: 30,
    ),
  ];

  static const List<PlacementQuestion> _grammarB1Pool = <PlacementQuestion>[
    PlacementQuestion(
      id: 'g_b1_1',
      skill: SkillType.writing,
      cefrDifficulty: 'B1',
      topicTag: 'Câu điều kiện loại 1 (B1)',
      prompt: 'Chọn đáp án đúng:\n"If I practice speaking every day, my English _____ much better."',
      options: <String>['will become', 'became', 'becoming', 'was'],
      correctIndex: 0,
      explanationVi: 'Câu điều kiện loại 1: If + hiện tại đơn, S + will + V.',
      weight: 40,
    ),
    PlacementQuestion(
      id: 'g_b1_2',
      skill: SkillType.writing,
      cefrDifficulty: 'B1',
      topicTag: 'Thì hiện tại hoàn thành (B1)',
      prompt: 'Chọn đáp án đúng:\n"I _____ in this city since 2023."',
      options: <String>['live', 'lived', 'have lived', 'living'],
      correctIndex: 2,
      explanationVi: 'Có "since 2023" dùng thì hiện tại hoàn thành "have lived".',
      weight: 40,
    ),
    PlacementQuestion(
      id: 'g_b1_3',
      skill: SkillType.writing,
      cefrDifficulty: 'B1',
      topicTag: 'Liên từ tương phản (B1)',
      prompt: 'Chọn đáp án đúng:\n"_____ it was raining heavily, we still went to class on time."',
      options: <String>['Although', 'Because', 'So', 'Despite'],
      correctIndex: 0,
      explanationVi: '"Although + mệnh đề (S + V)" diễn tả sự tương phản ("Mặc dù...").',
      weight: 40,
    ),
  ];

  static const List<PlacementQuestion> _speakingCommPool = <PlacementQuestion>[
    PlacementQuestion(
      id: 's_a1_1',
      skill: SkillType.speaking,
      cefrDifficulty: 'A1',
      topicTag: 'Chào hỏi cơ bản (A1)',
      audioScript: 'Hi! How are you doing today?',
      prompt: 'Khi ai đó hỏi "How are you doing today?", câu đáp tự nhiên nhất là gì?',
      options: <String>[
        'I am 20 years old.',
        'I\'m doing great, thanks! How about you?',
        'Yes, I like coffee.',
        'Goodbye, see you tomorrow.',
      ],
      correctIndex: 1,
      explanationVi: '"I\'m doing great, thanks! How about you?" là cách đáp tự nhiên nhất.',
      weight: 30,
    ),
    PlacementQuestion(
      id: 's_a2_2',
      skill: SkillType.speaking,
      cefrDifficulty: 'A2',
      topicTag: 'Nhờ nói chậm lại (A2)',
      audioScript: 'Sorry, I did not catch that.',
      prompt: 'Khi người nước ngoài nói quá nhanh và bạn chưa nghe rõ, câu lịch sự nhất để nói là gì?',
      options: <String>[
        'Stop talking right now.',
        'Could you speak a little slower, please?',
        'I do not like English.',
        'You are too loud.',
      ],
      correctIndex: 1,
      explanationVi: '"Could you speak a little slower, please?" lịch sự và rất tự nhiên.',
      weight: 30,
    ),
    PlacementQuestion(
      id: 's_a2_3',
      skill: SkillType.speaking,
      cefrDifficulty: 'A2',
      topicTag: 'Cảm ơn & Đáp lại (A2)',
      audioScript: 'Thank you so much for helping me with my homework!',
      prompt: 'Khi bạn bè cảm ơn bạn ("Thank you so much!"), câu đáp thân thiện nhất là gì?',
      options: <String>[
        'You\'re welcome! Anytime.',
        'Good morning!',
        'I am a student.',
        'How much is it?',
      ],
      correctIndex: 0,
      explanationVi: '"You\'re welcome! Anytime." nghĩa là "Không có gì đâu! Lúc nào cũng sẵn lòng."',
      weight: 30,
    ),
  ];

  static const List<String> _dictationPool = <String>[
    'I want to speak English every day.',
    'Nice to meet you. Where are you from?',
    'Can I have an iced coffee, please?',
    'She studies English for twenty minutes every night.',
    'Let us practice speaking together after class.',
    'Good morning! How are you doing today?',
  ];

  static const List<Map<String, String>> _openPromptSets = <Map<String, String>>[
    <String, String>{
      's1': 'Giới thiệu ngắn về bản thân bạn bằng 1–3 câu tiếng Anh.',
      's2': 'Nói 1–2 câu tiếng Anh về việc bạn thường làm vào cuối tuần.',
      'w': 'Viết 2–5 câu tiếng Anh về bản thân hoặc lý do bạn muốn học tiếng Anh.',
    },
    <String, String>{
      's1': 'Kể ngắn về sở thích hoặc món ăn yêu thích của bạn bằng 1–3 câu tiếng Anh.',
      's2': 'Bạn thường đi học hoặc đi làm bằng phương tiện gì? Nói 1–2 câu tiếng Anh.',
      'w': 'Viết 2–5 câu tiếng Anh mô tả một ngày bình thường của bạn.',
    },
    <String, String>{
      's1': 'Giới thiệu ngắn về nơi bạn đang sống bằng 1–3 câu tiếng Anh.',
      's2': 'Nói 1–2 câu tiếng Anh về một người bạn thân hoặc thành viên gia đình bạn.',
      'w': 'Viết 2–5 câu tiếng Anh về mục tiêu tiếng Anh bạn muốn đạt được năm nay.',
    },
    <String, String>{
      's1': 'Nói 1–3 câu tiếng Anh về những gì bạn hay làm vào buổi tối.',
      's2': 'Bạn thích học tiếng Anh vào buổi sáng hay buổi tối? Nói ngắn lý do bằng tiếng Anh.',
      'w': 'Viết 2–5 câu tiếng Anh về một bộ phim, bài hát hoặc cuốn sách bạn thích.',
    },
  ];

  /// Default static list for backwards compatibility in tests.
  static List<PlacementQuestion> get placementQuestions => <PlacementQuestion>[
        _listeningA1Pool.first,
        _listeningA2Pool.first,
        _listeningB1Pool.first,
        _readingA1Pool.first,
        _readingA2Pool.first,
        _readingB1Pool.first,
        _grammarA1Pool.first,
        _grammarA2Pool.first,
        _grammarB1Pool.first,
        _speakingCommPool.first,
      ];

  /// Generates a brand-new randomized Placement Exam set (different every attempt / every user).
  static PlacementExamSet generateUniquePlacementExam({int? seed}) {
    final rng = seed != null
        ? Random(seed)
        : Random(DateTime.now().microsecondsSinceEpoch);
    T pick<T>(List<T> pool) => pool[rng.nextInt(pool.length)];

    final selectedQuestions = <PlacementQuestion>[
      pick(_listeningA1Pool),
      pick(_listeningA2Pool),
      pick(_listeningB1Pool),
      pick(_readingA1Pool),
      pick(_readingA2Pool),
      pick(_readingB1Pool),
      pick(_grammarA1Pool),
      pick(_grammarA2Pool),
      pick(_grammarB1Pool),
      pick(_speakingCommPool),
    ];

    final openSet = pick(_openPromptSets);
    final code = 'DE-${(1000 + rng.nextInt(9000))}';

    return PlacementExamSet(
      examCode: code,
      questions: selectedQuestions,
      dictationAudio: pick(_dictationPool),
      speakingPrompt1: openSet['s1']!,
      speakingPrompt2: openSet['s2']!,
      writingPrompt: openSet['w']!,
    );
  }

  /// Evaluates a Placement Exam submission against the exact PlacementExamSet taken.
  static PlacementTestResult evaluatePlacementSubmission({
    required PlacementSubmissionPayload submission,
    required GoogleUserProfile user,
    PlacementExamSet? examSet,
  }) {
    final activeQuestions = examSet?.questions ?? placementQuestions;
    final activeDictation = examSet?.dictationAudio ?? placementDictationAudio;
    final mistakes = <PlacementMistakeReview>[];
    var totalCorrect = 0;

    int calcObjectivePercent(SkillType skill) {
      final qs = activeQuestions.where((q) => q.skill == skill).toList();
      if (qs.isEmpty) return 50;
      var earned = 0;
      var totalWeight = 0;
      for (final q in qs) {
        totalWeight += q.weight;
        final chosen = submission.selectedAnswers[q.id];
        if (chosen == q.correctIndex) {
          earned += q.weight;
          totalCorrect++;
        } else {
          final userTxt = (chosen != null &&
                  chosen >= 0 &&
                  chosen < q.options.length)
              ? q.options[chosen]
              : '(Chưa chọn)';
          mistakes.add(
            PlacementMistakeReview(
              questionId: q.id,
              skill: q.skill,
              cefrDifficulty: q.cefrDifficulty,
              topicTag: q.topicTag,
              questionSummary: q.prompt,
              userAnswerText: userTxt,
              correctAnswerText: q.options[q.correctIndex],
              explanationVi: q.explanationVi,
            ),
          );
        }
      }
      return totalWeight > 0 ? ((earned / totalWeight) * 100).round() : 50;
    }

    final lisMcqPercent = calcObjectivePercent(SkillType.listening);
    final readMcqPercent = calcObjectivePercent(SkillType.reading);
    final gramMcqPercent = calcObjectivePercent(SkillType.writing);
    final spkMcqPercent = calcObjectivePercent(SkillType.speaking);

    final dictAcc = _computeDictationPercent(
      submission.listeningDictationInput,
      activeDictation,
    );

    final spkProdScore = _evaluateOpenTextQuality(
      '${submission.speakingIntroAnswer} ${submission.speakingOpinionAnswer}',
      idealMinWords: 15,
    );

    final wrtProdScore = _evaluateOpenTextQuality(
      submission.writingEssayAnswer,
      idealMinWords: 20,
    );

    final lScore =
        ((lisMcqPercent * 0.75) + (dictAcc * 0.25)).round().clamp(20, 95);
    final rScore = (15 + readMcqPercent * 0.80).round().clamp(20, 95);
    final sScore =
        ((spkMcqPercent * 0.45) + (spkProdScore * 0.55)).round().clamp(20, 95);
    final wScore =
        ((gramMcqPercent * 0.50) + (wrtProdScore * 0.50)).round().clamp(20, 95);

    final avg = ((lScore + sScore + rScore + wScore) / 4).round();
    final bands = mapScoreToCefrIeltsToeic(avg);

    final gapTopics = mistakes.map((m) => m.topicTag).toSet().take(3).toList();
    if (dictAcc < 70) {
      gapTopics.add('Nghe và gõ lại câu cơ bản ($dictAcc%)');
    }

    final strengths = <String>[];
    if (lScore >= 65) strengths.add('Nghe hiểu hội thoại cơ bản tốt ($lScore%)');
    if (rScore >= 65) strengths.add('Đọc hiểu đoạn ngắn nhanh ($rScore%)');
    if (sScore >= 65) strengths.add('Phản xạ nói tự tin ($sScore%)');
    if (wScore >= 65) strengths.add('Nắm chắc ngữ pháp cơ bản ($wScore%)');
    if (strengths.isEmpty) {
      strengths.add('Bắt đầu lại từ gốc A1 bài bản — tiến bộ rất nhanh!');
    }

    final dailySchedule = buildAdaptiveDailySchedule(
      totalMinutes: user.dailyTargetMinutes,
      lScore: lScore,
      sScore: sScore,
      rScore: rScore,
      wScore: wScore,
    );

    final roadmap = buildAdaptiveRoadmap(
      cefr: bands.cefr,
      dailyMinutes: user.dailyTargetMinutes,
      targetWeeks: user.targetWeeks,
      lScore: lScore,
      sScore: sScore,
      rScore: rScore,
      wScore: wScore,
    );

    final weakest = _findWeakestSkill(lScore, sScore, rScore, wScore);
    final levelNote = (bands.cefr == 'A1' || bands.cefr == 'A2')
        ? 'Lộ trình bắt đầu từ **lấy lại gốc & giao tiếp hàng ngày thật dễ hiểu**.'
        : 'Bạn đã có nền tảng tốt! Lộ trình tập trung **bật phản xạ giao tiếp & nâng điểm**.';

    final summary =
        'Bạn đúng **$totalCorrect/${activeQuestions.length} câu** (Nghe chép: **$dictAcc%**), trình độ hiện tại là **${bands.cefr}** (IELTS ~${bands.ielts} | TOEIC ~${bands.toeic}).\n\n'
        '• $levelNote\n'
        '• Kỹ năng cần ưu tiên nhất: **${weakest.shortVi}** — lộ trình ${user.targetWeeks} tuần (${user.dailyTargetMinutes} phút/ngày) đã được tối ưu cho bạn.';

    return PlacementTestResult(
      completedAt: DateTime.now(),
      listeningScore: lScore,
      speakingScore: sScore,
      readingScore: rScore,
      writingScore: wScore,
      dictationAccuracyPercent: dictAcc,
      objectiveCorrectCount: totalCorrect,
      objectiveTotalCount: activeQuestions.length,
      cefrLevel: bands.cefr,
      estimatedIelts: bands.ielts,
      estimatedToeic: bands.toeic,
      aiDiagnosticSummary: summary,
      speakingFeedbackVi: submission.speakingIntroAnswer.trim().isEmpty &&
              submission.speakingOpinionAnswer.trim().isEmpty
          ? 'Bạn bỏ qua phần nói — hãy bắt đầu với câu chào hỏi A1 trong Phòng Nói nhé.'
          : 'Rất tốt vì bạn đã tự trả lời! Hãy luyện nói 5 phút mỗi ngày để tự tin hơn.',
      writingFeedbackVi: submission.writingEssayAnswer.trim().isEmpty
          ? 'Bạn chưa viết câu nào — hãy thử bài viết 3 câu giới thiệu trong Phòng Viết nhé.'
          : 'Bạn đã diễn đạt được ý chính. Vào Phòng Viết để AI sửa chi tiết từng câu.',
      keyStrengths: strengths,
      criticalGaps: gapTopics.isEmpty
          ? const <String>['Luyện phản xạ nói hàng ngày & mở rộng từ vựng']
          : gapTopics,
      dailySchedule: dailySchedule,
      mistakes: mistakes,
      roadmapPhases: roadmap,
      generatedByAi: false,
    );
  }

  static ({String cefr, String ielts, int toeic}) mapScoreToCefrIeltsToeic(
      int avgScore) {
    if (avgScore >= 82) {
      return (cefr: 'B2', ielts: '6.0 - 6.5', toeic: 720);
    } else if (avgScore >= 65) {
      return (cefr: 'B1', ielts: '5.0 - 5.5', toeic: 560);
    } else if (avgScore >= 45) {
      return (cefr: 'A2', ielts: '4.0 - 4.5', toeic: 430);
    } else {
      return (cefr: 'A1', ielts: '3.0 - 3.5', toeic: 300);
    }
  }

  static int _computeDictationPercent(String input, String target) {
    final cleanedInput = input
        .toLowerCase()
        .replaceAll(RegExp(r'[^\w\s]'), '')
        .trim();
    if (cleanedInput.isEmpty) return 20;
    final userWords =
        cleanedInput.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    final targetWords = target
        .toLowerCase()
        .replaceAll(RegExp(r'[^\w\s]'), '')
        .split(RegExp(r'\s+'))
        .where((w) => w.isNotEmpty)
        .toList();
    if (targetWords.isEmpty) return 50;
    var hit = 0;
    for (final tw in targetWords) {
      if (userWords.contains(tw)) hit++;
    }
    return ((hit / targetWords.length) * 100).round().clamp(15, 100);
  }

  static int _evaluateOpenTextQuality(
    String rawText, {
    required int idealMinWords,
  }) {
    final trimmed = rawText.trim();
    if (trimmed.isEmpty) return 25;
    final words =
        trimmed.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    final wordCount = words.length;
    final lengthScore =
        ((wordCount / idealMinWords).clamp(0.0, 1.0) * 55).round();
    return (25 + lengthScore).clamp(25, 88);
  }

  static SkillType _findWeakestSkill(int l, int s, int r, int w) {
    final map = <SkillType, int>{
      SkillType.listening: l,
      SkillType.speaking: s,
      SkillType.reading: r,
      SkillType.writing: w,
    };
    return map.entries.reduce((a, b) => a.value <= b.value ? a : b).key;
  }

  static List<DailyScheduleSlot> buildAdaptiveDailySchedule({
    required int totalMinutes,
    required int lScore,
    required int sScore,
    required int rScore,
    required int wScore,
  }) {
    final ranked = <MapEntry<SkillType, int>>[
      MapEntry(SkillType.listening, lScore),
      MapEntry(SkillType.speaking, sScore),
      MapEntry(SkillType.reading, rScore),
      MapEntry(SkillType.writing, wScore),
    ]..sort((a, b) => a.value.compareTo(b.value));

    final m1 = (totalMinutes * 0.40).round().clamp(5, totalMinutes);
    final m2 = (totalMinutes * 0.25).round().clamp(3, totalMinutes);
    final m3 = (totalMinutes * 0.20).round().clamp(3, totalMinutes);
    final m4 = (totalMinutes - m1 - m2 - m3).clamp(2, totalMinutes);
    final allocations = <int>[m1, m2, m3, m4];

    String titleFor(SkillType skill, bool isTop) {
      final tag = isTop ? '⭐ Ưu tiên: ' : '';
      switch (skill) {
        case SkillType.listening:
          return '${tag}Nghe hội thoại ngắn';
        case SkillType.speaking:
          return '${tag}Nói & Gọi AI';
        case SkillType.reading:
          return '${tag}Đọc đoạn ngắn song ngữ';
        case SkillType.writing:
          return '${tag}Viết 3–5 câu để AI sửa';
      }
    }

    String detailFor(SkillType skill) {
      switch (skill) {
        case SkillType.listening:
          return 'Nghe tốc độ 0.75x rồi tăng lên 1.0x và làm câu hỏi.';
        case SkillType.speaking:
          return 'Đọc vượt 70% hoặc gọi thoại ngắn cùng bạn AI.';
        case SkillType.reading:
          return 'Đọc 1 bài ngắn Anh–Việt và lưu 3 từ mới.';
        case SkillType.writing:
          return 'Viết vài câu đơn giản để AI chỉ lỗi sửa ngay.';
      }
    }

    return List<DailyScheduleSlot>.generate(4, (i) {
      final skill = ranked[i].key;
      return DailyScheduleSlot(
        skill: skill,
        minutes: allocations[i],
        activityTitle: titleFor(skill, i == 0),
        detail: detailFor(skill),
      );
    });
  }

  static List<String> weekLabelsForTotal(int totalWeeks) {
    final safeTotal = totalWeeks < 4 ? 4 : totalWeeks;
    final perPhase = (safeTotal / 4).floor();
    final r1End = perPhase;
    final r2End = perPhase * 2;
    final r3End = perPhase * 3;
    String range(int a, int b) => a == b ? 'Tuần $a' : 'Tuần $a - $b';
    return <String>[
      range(1, r1End),
      range(r1End + 1, r2End),
      range(r2End + 1, r3End),
      range(r3End + 1, safeTotal),
    ];
  }

  static List<RoadmapPhase> buildAdaptiveRoadmap({
    required String cefr,
    required int dailyMinutes,
    int targetWeeks = 8,
    required int lScore,
    required int sScore,
    required int rScore,
    required int wScore,
  }) {
    final weakest = _findWeakestSkill(lScore, sScore, rScore, wScore);
    final labels = weekLabelsForTotal(targetWeeks);
    return <RoadmapPhase>[
      RoadmapPhase(
        weekRange: '${labels[0]} • Lấy lại gốc ($cefr)',
        title: 'Nền tảng Giao tiếp Cơ bản & Vá kỹ năng ${weakest.shortVi}',
        focusGoal:
            'Học $dailyMinutes phút/ngày: nắm từ vựng đời sống, câu đơn giản và nghe quen tai.',
        listeningTask: 'Nghe hội thoại chào hỏi, mua sắm tốc độ chậm 0.75x.',
        speakingTask: 'Đọc theo 3 câu giao tiếp mỗi ngày đạt trên 70%.',
        readingTask: 'Đọc đoạn ngắn song ngữ và lưu 5 từ mới mỗi ngày.',
        writingTask: 'Tập viết câu đơn đúng thì hiện tại & quá khứ.',
        milestone: 'Tự giới thiệu bản thân trôi chảy & hiểu câu cơ bản.',
      ),
      RoadmapPhase(
        weekRange: '${labels[1]} • Giao tiếp Hàng ngày (A2)',
        title: 'Phản xạ Hội thoại Đời sống & Trường học',
        focusGoal: 'Tự tin nghe nói ở quán cà phê, hỏi đường, kết bạn.',
        listeningTask: 'Nghe tốc độ chuẩn 1.0x không cần phụ đề lần đầu.',
        speakingTask: 'Gọi thoại AI 1-1 tình huống mua đồ, hẹn bạn, sở thích.',
        readingTask: 'Đọc bài ngắn về sinh viên & thói quen hàng ngày.',
        writingTask: 'Viết tin nhắn, email ngắn để AI sửa lỗi trực tiếp.',
        milestone: 'Giao tiếp thoải mái các tình huống quen thuộc.',
      ),
      RoadmapPhase(
        weekRange: '${labels[2]} • Trung cấp (B1)',
        title: 'Giao tiếp Tự nhiên & Mở rộng Ý tưởng',
        focusGoal: 'Biết giải thích lý do, nêu quan điểm rõ ràng.',
        listeningTask: 'Nghe thông báo, hội thoại dài hơn và chép chính tả.',
        speakingTask: 'Gọi thoại AI về học tập và công việc làm thêm.',
        readingTask: 'Đọc bài 2–3 đoạn ít phụ thuộc bản dịch.',
        writingTask: 'Viết đoạn 60–100 từ có câu nối mạch lạc.',
        milestone: 'Đạt mức giao tiếp tự tin B1.',
      ),
      RoadmapPhase(
        weekRange: '${labels[3]} • Bứt phá (B1+ / B2)',
        title: 'Phỏng vấn Thực tập & Chuẩn Đầu Ra',
        focusGoal: 'Hoàn thiện đều cả 4 kỹ năng Nghe – Nói – Đọc – Viết.',
        listeningTask: 'Nghe tốc độ 1.0x–1.25x và luyện câu hỏi hiểu ý.',
        speakingTask: 'Gọi thoại phỏng vấn xin việc / thực tập cùng AI.',
        readingTask: 'Đọc hiểu bài ngắn và tóm tắt ý chính.',
        writingTask: 'Viết email xin việc / đoạn văn để AI chấm điểm.',
        milestone: 'Tự tin giao tiếp thực tế & thi đạt chuẩn đầu ra.',
      ),
    ];
  }

  /// Daily Workout Quiz (5 quick questions progressing from A1 -> B1)
  static const List<DailyQuizQuestion> defaultDailyQuiz = <DailyQuizQuestion>[
    DailyQuizQuestion(
      question: 'Chọn từ đúng:\n"They _____ students at this university."',
      options: <String>['am', 'is', 'are', 'be'],
      correctIndex: 2,
      explanationVi: 'Chủ ngữ số nhiều "They" luôn đi với "are".',
      skillTag: 'A1 • Cơ bản',
    ),
    DailyQuizQuestion(
      question: 'Khi muốn cảm ơn ai đó một cách lịch sự, bạn nói gì?',
      options: <String>[
        'Thank you so much!',
        'No, I am busy.',
        'Where is the bus?',
        'Good night!',
      ],
      correctIndex: 0,
      explanationVi: '"Thank you so much!" nghĩa là "Cảm ơn bạn rất nhiều!".',
      skillTag: 'A1 • Giao tiếp',
    ),
    DailyQuizQuestion(
      question: 'Chọn đáp án đúng:\n"I _____ coffee every morning."',
      options: <String>['drink', 'drinks', 'drinking', 'drank'],
      correctIndex: 0,
      explanationVi: 'Thói quen hàng ngày ("every morning") với "I" dùng "drink".',
      skillTag: 'A2 • Thì hiện tại',
    ),
    DailyQuizQuestion(
      question: 'Chọn giới từ đúng:\n"My English class starts _____ 8:00 AM."',
      options: <String>['in', 'on', 'at', 'to'],
      correctIndex: 2,
      explanationVi: 'Trước giờ giấc cụ thể (8:00 AM) luôn dùng giới từ "at".',
      skillTag: 'A2 • Giới từ',
    ),
    DailyQuizQuestion(
      question: 'Chọn từ nối phù hợp:\n"I was tired, _____ I still finished my homework."',
      options: <String>['but', 'because', 'or', 'if'],
      correctIndex: 0,
      explanationVi: '"but" (nhưng) nối hai vế đối lập: mệt nhưng vẫn làm xong bài.',
      skillTag: 'B1 • Câu nối',
    ),
  ];

  /// Listening lessons ordered from A1 (Mất gốc) -> A2 -> B1
  static const List<ListeningLesson> listeningLessons = <ListeningLesson>[
    ListeningLesson(
      id: 'lis_a1_1',
      title: 'Bài 1 (A1): Chào hỏi & Làm quen bạn mới',
      category: 'Giao tiếp cho người mất gốc • Cơ bản',
      cefrLevel: 'A1',
      durationLabel: '1 phút',
      audioTranscript:
          'Hi! Nice to meet you. My name is Linh. I am twenty years old and I am a student. I live in Hanoi. In my free time, I like listening to music and drinking milk tea with my friends.',
      vietnameseTranslation:
          'Chào bạn! Rất vui được gặp bạn. Tên mình là Linh. Mình 20 tuổi và là sinh viên. Mình sống ở Hà Nội. Lúc rảnh rỗi, mình thích nghe nhạc và uống trà sữa cùng bạn bè.',
      dictationSentence: 'Nice to meet you. My name is Linh.',
      keyVocab: <VocabFlashcard>[
        VocabFlashcard(
          word: 'nice to meet you',
          ipa: '/naɪs tuː miːt juː/',
          partOfSpeech: 'cụm câu',
          meaningVi: 'rất vui được gặp bạn',
          exampleEn: 'Hi Tom, nice to meet you!',
          topic: 'Giao tiếp A1',
        ),
        VocabFlashcard(
          word: 'free time',
          ipa: '/friː taɪm/',
          partOfSpeech: 'n.',
          meaningVi: 'thời gian rảnh rỗi',
          exampleEn: 'What do you do in your free time?',
          topic: 'Giao tiếp A1',
        ),
      ],
      questions: <ComprehensionMcq>[
        ComprehensionMcq(
          question: 'Linh bao nhiêu tuổi?',
          options: <String>['18 tuổi', '19 tuổi', '20 tuổi', '22 tuổi'],
          correctIndex: 2,
          explanationVi: 'Linh nói: "I am twenty years old" (20 tuổi).',
        ),
        ComprehensionMcq(
          question: 'Lúc rảnh rỗi Linh thích làm gì?',
          options: <String>[
            'Nghe nhạc và uống trà sữa với bạn',
            'Đi bơi một mình',
            'Nấu ăn ở nhà',
            'Chơi đá bóng',
          ],
          correctIndex: 0,
          explanationVi: '"listening to music and drinking milk tea with my friends."',
        ),
      ],
    ),
    ListeningLesson(
      id: 'lis_a2_2',
      title: 'Bài 2 (A2): Gọi đồ uống ở quán Cà phê',
      category: 'Giao tiếp hàng ngày • Thực tế',
      cefrLevel: 'A2',
      durationLabel: '1 phút',
      audioTranscript:
          'Staff: Good morning! What can I get for you today? Customer: Hi, can I have a large iced latte with less sugar, please? Staff: Sure! Anything else? Customer: No, that is all. How much is it? Staff: It is four dollars. You can pay by card or cash.',
      vietnameseTranslation:
          'Nhân viên: Chào buổi sáng! Bạn muốn gọi gì hôm nay? Khách: Chào bạn, cho mình một ly latte đá cỡ lớn ít đường nhé? Nhân viên: Được ạ! Bạn gọi thêm gì không? Khách: Không, vậy thôi ạ. Bao nhiêu tiền thế? Nhân viên: 4 đô la ạ. Bạn có thể trả bằng thẻ hoặc tiền mặt.',
      dictationSentence: 'Can I have a large iced latte, please?',
      keyVocab: <VocabFlashcard>[
        VocabFlashcard(
          word: 'less sugar',
          ipa: '/les ˈʃʊɡər/',
          partOfSpeech: 'n. phr.',
          meaningVi: 'ít đường',
          exampleEn: 'I would like milk tea with less sugar.',
          topic: 'Giao tiếp A2',
        ),
        VocabFlashcard(
          word: 'pay by card',
          ipa: '/peɪ baɪ kɑːrd/',
          partOfSpeech: 'v. phr.',
          meaningVi: 'thanh toán bằng thẻ',
          exampleEn: 'Can I pay by card here?',
          topic: 'Giao tiếp A2',
        ),
      ],
      questions: <ComprehensionMcq>[
        ComprehensionMcq(
          question: 'Khách hàng yêu cầu ly latte như thế nào?',
          options: <String>[
            'Cỡ nhỏ, nhiều đường',
            'Cỡ lớn, đá, ít đường',
            'Uống nóng không đá',
            'Thêm kem tươi',
          ],
          correctIndex: 1,
          explanationVi: 'Khách nói: "a large iced latte with less sugar".',
        ),
      ],
    ),
    ListeningLesson(
      id: 'lis_b1_3',
      title: 'Bài 3 (B1): Phỏng vấn xin việc làm thêm',
      category: 'Sinh viên & Công việc • Trung cấp',
      cefrLevel: 'B1',
      durationLabel: '2 phút',
      audioTranscript:
          'Interviewer: Why do you want to work part-time at our bookstore? Student: First, I love reading books and helping customers. Second, I want to practice my English speaking skills and become more independent. I can work three evenings a week after my classes.',
      vietnameseTranslation:
          'Người phỏng vấn: Tại sao bạn muốn làm thêm tại hiệu sách của chúng tôi? Sinh viên: Thứ nhất, mình rất thích đọc sách và hỗ trợ khách hàng. Thứ hai, mình muốn luyện kỹ năng nói tiếng Anh và tự lập hơn. Mình có thể làm 3 buổi tối mỗi tuần sau giờ học.',
      dictationSentence: 'I want to practice my English speaking skills.',
      keyVocab: <VocabFlashcard>[
        VocabFlashcard(
          word: 'part-time',
          ipa: '/ˌpɑːrt ˈtaɪm/',
          partOfSpeech: 'adj./adv.',
          meaningVi: 'bán thời gian (làm thêm)',
          exampleEn: 'Many students have a part-time job.',
          topic: 'Sinh viên B1',
        ),
        VocabFlashcard(
          word: 'independent',
          ipa: '/ˌɪndɪˈpendənt/',
          partOfSpeech: 'adj.',
          meaningVi: 'tự lập, độc lập',
          exampleEn: 'Working helps me become more independent.',
          topic: 'Sinh viên B1',
        ),
      ],
      questions: <ComprehensionMcq>[
        ComprehensionMcq(
          question: 'Sinh viên có thể đi làm mấy buổi tối mỗi tuần?',
          options: <String>['1 buổi', '2 buổi', '3 buổi tối', 'Cả 7 ngày'],
          correctIndex: 2,
          explanationVi: '"I can work three evenings a week after my classes."',
        ),
      ],
    ),
  ];

  /// Speaking pronunciation drills ordered from A1 (Mất gốc) -> A2 -> B1
  static const List<SpeakingDrill> speakingDrills = <SpeakingDrill>[
    SpeakingDrill(
      id: 'spk_a1_1',
      category: 'A1 • Chào hỏi cơ bản',
      cefrLevel: 'A1',
      sentenceEn: 'Hi, nice to meet you! How are you today?',
      ipa: '/haɪ naɪs tuː miːt juː haʊ ɑːr juː təˈdeɪ/',
      meaningVi: 'Chào bạn, rất vui được gặp bạn! Hôm nay bạn khỏe không?',
      tipVi: 'Nói chậm rãi, thân thiện và lên giọng nhẹ ở cuối câu hỏi "today?".',
    ),
    SpeakingDrill(
      id: 'spk_a1_2',
      category: 'A1 • Nhờ người khác nói chậm lại',
      cefrLevel: 'A1',
      sentenceEn: 'Excuse me, could you speak a little slower, please?',
      ipa: '/ɪkˈskjuːz miː kʊd juː spiːk ə ˈlɪtl ˈsləʊər pliːz/',
      meaningVi: 'Xin lỗi, bạn có thể nói chậm lại một chút được không?',
      tipVi: 'Câu cực hữu ích khi mới tập giao tiếp với người nước ngoài!',
    ),
    SpeakingDrill(
      id: 'spk_a2_3',
      category: 'A2 • Gọi đồ ăn & Cà phê',
      cefrLevel: 'A2',
      sentenceEn: 'Can I have an iced coffee with less sugar, please?',
      ipa: '/kæn aɪ hæv ən aɪst ˈkɒfi wɪð les ˈʃʊɡər pliːz/',
      meaningVi: 'Cho mình một ly cà phê đá ít đường nhé?',
      tipVi: 'Nhớ bật nhẹ âm /s/ ở cuối "less" và âm /z/ ở cuối "please".',
    ),
    SpeakingDrill(
      id: 'spk_b1_4',
      category: 'B1 • Giới thiệu khi phỏng vấn',
      cefrLevel: 'B1',
      sentenceEn: 'I am a fast learner and I enjoy working in a team.',
      ipa: '/aɪ æm ə fɑːst ˈlɜːrnər ænd aɪ ɪnˈdʒɔɪ ˈwɜːrkɪŋ ɪn ə tiːm/',
      meaningVi: 'Mình là người học hỏi nhanh và thích làm việc nhóm.',
      tipVi: 'Nhấn rõ vào 2 từ khóa chính: "FAST learner" và "WORKING in a TEAM".',
    ),
  ];

  /// AI 1-1 Roleplay Scenarios ordered from A1 (Mất gốc) -> A2 -> B1
  static const List<RoleplayScenario> roleplayScenarios = <RoleplayScenario>[
    RoleplayScenario(
      id: 'rp_a1_friend',
      title: 'A1 • Làm quen (Mất gốc)',
      subtitle: 'AI nói câu siêu ngắn, kèm dịch tiếng Việt mỗi lượt',
      cefrLevel: 'A1',
      aiRoleName: 'Emma (Bạn nước ngoài)',
      systemInstruction:
          'You are Emma, a warm, super patient English friend chatting with a Vietnamese A1 beginner student. Use VERY SHORT, SIMPLE English sentences (max 1-2 short sentences per reply). After your English reply, ALWAYS add:\n- 🇻🇳 Dịch: (simple Vietnamese translation)\n- 💡 Gợi ý: (short friendly tip in Vietnamese, max 1 line). Keep it super short!',
      openingLineEn:
          'Hi! I am Emma. Nice to meet you! What is your name?\n\n🇻🇳 Dịch: Chào bạn! Mình là Emma. Rất vui được gặp bạn! Bạn tên là gì?',
      openingLineVi: 'Chào bạn! Mình là Emma. Bạn tên là gì?',
      suggestedReplies: <String>[
        'Hi Emma! My name is Minh. Nice to meet you!',
        'Hello! I am a student from Vietnam.',
      ],
    ),
    RoleplayScenario(
      id: 'rp_a2_coffee',
      title: 'A2 • Quán Cà phê',
      subtitle: 'Gọi đồ uống & thanh toán thực tế',
      cefrLevel: 'A2',
      aiRoleName: 'Alex (Quán Cà phê)',
      systemInstruction:
          'You are Alex, a friendly cafe barista talking to a Vietnamese student at A2 level. Keep replies short (1-2 simple English sentences). Then add a brief 1-line Vietnamese translation ("🇻🇳 Dịch:") and 1-line helpful tip ("💡 Gợi ý:").',
      openingLineEn:
          'Welcome to Sunny Cafe! What would you like to drink today?\n\n🇻🇳 Dịch: Chào mừng đến Sunny Cafe! Hôm nay bạn muốn uống gì?',
      openingLineVi: 'Hôm nay bạn muốn uống gì?',
      suggestedReplies: <String>[
        'Can I have an iced coffee with milk, please?',
        'How much is a large iced latte?',
      ],
    ),
    RoleplayScenario(
      id: 'rp_b1_interview',
      title: 'B1 • Phỏng vấn Thực tập',
      subtitle: 'Tập trả lời câu hỏi phỏng vấn tự nhiên',
      cefrLevel: 'B1',
      aiRoleName: 'Ms. Clara (Tuyển dụng)',
      systemInstruction:
          'You are Ms. Clara, a friendly interviewer talking to a student at B1 level. Ask simple, practical interview questions (1-2 sentences). After responding in English, add a short block "💡 Gợi ý nói hay hơn:" (max 2 short lines in Vietnamese).',
      openingLineEn:
          'Hello! Thanks for coming today. Can you tell me a little bit about yourself?',
      openingLineVi: 'Chào bạn! Bạn có thể giới thiệu ngắn gọn về bản thân không?',
      suggestedReplies: <String>[
        'Hi! I am a university student. I am hardworking and I love learning new things.',
      ],
    ),
  ];

  /// Reading Passages ordered from A1 (Mất gốc) -> A2 -> B1
  static const List<ReadingPassage> readingPassages = <ReadingPassage>[
    ReadingPassage(
      id: 'read_a1_1',
      title: 'Bài 1 (A1): My Daily Routine (Một ngày của mình)',
      majorTag: 'Giao tiếp cơ bản • A1',
      cefrLevel: 'A1',
      readingTimeLabel: '1 phút đọc',
      paragraphsEn: <String>[
        'My name is Tuan. Every day, I wake up at 6:30 AM. I brush my teeth, wash my face, and eat bread for breakfast.',
        'In the morning, I go to school by motorbike. At noon, I have lunch with my friends at the canteen. In the evening, I practice English for 15 minutes before going to bed.',
      ],
      paragraphsVi: <String>[
        'Tên mình là Tuấn. Mỗi ngày, mình thức dậy lúc 6 giờ 30 sáng. Mình đánh răng, rửa mặt và ăn bánh mì cho bữa sáng.',
        'Buổi sáng, mình đi học bằng xe máy. Buổi trưa, mình ăn cơm cùng bạn bè ở căng tin. Buổi tối, mình luyện tiếng Anh 15 phút trước khi đi ngủ.',
      ],
      highlights: <VocabFlashcard>[
        VocabFlashcard(
          word: 'wake up',
          ipa: '/weɪk ʌp/',
          partOfSpeech: 'v.',
          meaningVi: 'thức dậy',
          exampleEn: 'I usually wake up at 7 AM.',
          topic: 'Cơ bản A1',
        ),
        VocabFlashcard(
          word: 'breakfast',
          ipa: '/ˈbrekfəst/',
          partOfSpeech: 'n.',
          meaningVi: 'bữa ăn sáng',
          exampleEn: 'I eat pho for breakfast.',
          topic: 'Cơ bản A1',
        ),
        VocabFlashcard(
          word: 'practice',
          ipa: '/ˈpræktɪs/',
          partOfSpeech: 'v.',
          meaningVi: 'luyện tập, thực hành',
          exampleEn: 'I practice speaking English every night.',
          topic: 'Cơ bản A1',
        ),
      ],
      questions: <ComprehensionMcq>[
        ComprehensionMcq(
          question: 'Tuấn đi học bằng phương tiện gì?',
          options: <String>['Xe buýt', 'Xe máy', 'Xe đạp', 'Đi bộ'],
          correctIndex: 1,
          explanationVi: 'Bài đọc ghi: "I go to school by motorbike".',
        ),
        ComprehensionMcq(
          question: 'Buổi tối Tuấn luyện tiếng Anh bao lâu?',
          options: <String>['5 phút', '15 phút', '1 tiếng', 'Không học'],
          correctIndex: 1,
          explanationVi: '"I practice English for 15 minutes before going to bed."',
        ),
      ],
    ),
    ReadingPassage(
      id: 'read_a2_2',
      title: 'Bài 2 (A2): 3 Mẹo Nói Tiếng Anh Tự Tin Hơn',
      majorTag: 'Giao tiếp hàng ngày • A2',
      cefrLevel: 'A2',
      readingTimeLabel: '2 phút đọc',
      paragraphsEn: <String>[
        'Many students are afraid of making mistakes when speaking English. However, making mistakes is a normal part of learning any new language.',
        'To improve quickly, try speaking out loud for 5 minutes every day. You can talk about your day, describe things around your room, or chat with an AI tutor without feeling shy.',
      ],
      paragraphsVi: <String>[
        'Nhiều sinh viên sợ mắc lỗi khi nói tiếng Anh. Tuy nhiên, mắc lỗi là chuyện hoàn toàn bình thường khi học bất kỳ ngôn ngữ mới nào.',
        'Để tiến bộ nhanh, hãy thử nói thành tiếng 5 phút mỗi ngày. Bạn có thể kể về ngày hôm nay của mình, mô tả đồ vật quanh phòng hoặc trò chuyện với gia sư AI mà không cần ngại.',
      ],
      highlights: <VocabFlashcard>[
        VocabFlashcard(
          word: 'make mistakes',
          ipa: '/meɪk mɪˈsteɪks/',
          partOfSpeech: 'v. phr.',
          meaningVi: 'mắc lỗi sai',
          exampleEn: 'Don\'t be afraid to make mistakes!',
          topic: 'Giao tiếp A2',
        ),
        VocabFlashcard(
          word: 'confident',
          ipa: '/ˈkɒnfɪdənt/',
          partOfSpeech: 'adj.',
          meaningVi: 'tự tin',
          exampleEn: 'Practice helps you feel more confident.',
          topic: 'Giao tiếp A2',
        ),
      ],
      questions: <ComprehensionMcq>[
        ComprehensionMcq(
          question: 'Bài đọc khuyên bạn nên nói thành tiếng ít nhất mấy phút mỗi ngày?',
          options: <String>['5 phút', '30 phút', '2 giờ', 'Chỉ cuối tuần'],
          correctIndex: 0,
          explanationVi: '"try speaking out loud for 5 minutes every day."',
        ),
      ],
    ),
    ReadingPassage(
      id: 'read_b1_3',
      title: 'Bài 3 (B1): How English Opens New Opportunities',
      majorTag: 'Sinh viên & Tương lai • B1',
      cefrLevel: 'B1',
      readingTimeLabel: '2 phút đọc',
      paragraphsEn: <String>[
        'Learning English is one of the best investments a university student can make. With good English skills, you can access free online courses from top universities around the world and read updated information easily.',
        'Moreover, companies today prefer candidates who can communicate comfortably with international clients. Starting with just 15 to 30 minutes a day will create a big difference after one year.',
      ],
      paragraphsVi: <String>[
        'Học tiếng Anh là một trong những khoản đầu tư tốt nhất của sinh viên đại học. Với kỹ năng tiếng Anh tốt, bạn có thể tiếp cận các khóa học trực tuyến miễn phí từ các trường hàng đầu thế giới và đọc thông tin mới dễ dàng.',
        'Hơn nữa, các công ty hiện nay ưu tiên ứng viên có thể giao tiếp thoải mái với khách hàng quốc tế. Chỉ cần bắt đầu 15 đến 30 phút mỗi ngày sẽ tạo ra sự khác biệt lớn sau một năm.',
      ],
      highlights: <VocabFlashcard>[
        VocabFlashcard(
          word: 'opportunity',
          ipa: '/ˌɒpərˈtjuːnəti/',
          partOfSpeech: 'n.',
          meaningVi: 'cơ hội',
          exampleEn: 'English gives you better job opportunities.',
          topic: 'Sinh viên B1',
        ),
        VocabFlashcard(
          word: 'communicate',
          ipa: '/kəˈmjuːnɪkeɪt/',
          partOfSpeech: 'v.',
          meaningVi: 'giao tiếp',
          exampleEn: 'I want to communicate clearly in English.',
          topic: 'Sinh viên B1',
        ),
      ],
      questions: <ComprehensionMcq>[
        ComprehensionMcq(
          question: 'Theo bài đọc, các công ty hiện nay ưu tiên ứng viên có khả năng gì?',
          options: <String>[
            'Giao tiếp thoải mái với khách hàng quốc tế',
            'Chỉ biết đọc sách giấy',
            'Không sử dụng internet',
            'Học thuộc lòng từ điển',
          ],
          correctIndex: 0,
          explanationVi: '"companies today prefer candidates who can communicate comfortably with international clients."',
        ),
      ],
    ),
  ];

  /// Writing Prompts ordered from A1 (Mất gốc) -> A2 -> B1
  static const List<WritingPrompt> writingPrompts = <WritingPrompt>[
    WritingPrompt(
      id: 'wrt_a1_1',
      title: 'Bài 1 (A1): Giới thiệu bản thân (3–5 câu)',
      category: 'Cơ bản cho người mất gốc',
      cefrLevel: 'A1',
      minWords: 20,
      promptEn:
          'Write 3 to 5 simple sentences about yourself (your name, age, hobbies, and why you want to learn English).',
      guideVi: 'Viết 3–5 câu ngắn thôi, chạm mẫu câu bên dưới để ghép nhanh.',
      keyStructures: <String>[
        'Hi, my name is ... and I am a student.',
        'In my free time, I like ...',
        'I want to learn English because ...',
      ],
    ),
    WritingPrompt(
      id: 'wrt_a2_2',
      title: 'Bài 2 (A2): Kể về một ngày của bạn',
      category: 'Giao tiếp hàng ngày',
      cefrLevel: 'A2',
      minWords: 35,
      promptEn:
          'Describe your typical day as a student (morning, afternoon, and evening activities).',
      guideVi: 'Dùng thì hiện tại đơn kể 4–6 câu theo thứ tự Sáng → Chiều → Tối.',
      keyStructures: <String>[
        'Every morning, I wake up at ...',
        'In the afternoon, I usually ...',
        'Before going to bed, I ...',
      ],
    ),
    WritingPrompt(
      id: 'wrt_b1_3',
      title: 'Bài 3 (B1): Email ngắn xin nghỉ học hoặc hỏi bài',
      category: 'Thực tế sinh viên',
      cefrLevel: 'B1',
      minWords: 45,
      promptEn:
          'Write a short polite email to your teacher to say you cannot attend tomorrow\'s class because you have a fever, and ask about the homework.',
      guideVi: 'Lời chào → Lý do nghỉ & hỏi bài tập → Cảm ơn.',
      keyStructures: <String>[
        'I am writing to let you know that I cannot attend class tomorrow.',
        'Could you please tell me if there is any homework?',
        'Thank you for your understanding.',
      ],
    ),
  ];
}
