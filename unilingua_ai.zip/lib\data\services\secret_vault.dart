import 'dart:convert';

/// Internal credential vault keeping API endpoint and key hidden from the UI
/// and obfuscated from plain-text inspection.
class SecretVault {
  const SecretVault._();

  static const List<int> _u = <int>[
    51, 22, 29, 0, 4, 68, 170, 163, 240, 245, 197, 205, 215, 152, 219, 171,
    184, 166, 184, 206, 134, 158, 133, 211, 117, 59,
  ];

  static const List<int> _k = <int>[
    250, 251, 186, 174, 149, 201, 210, 216, 241, 252, 249, 181, 235, 214,
    141, 150, 204, 98, 53, 35, 96, 118, 75, 79, 7, 79, 11, 51, 34, 57, 61,
    80, 11, 67, 78, 7, 168, 186, 165, 172, 151, 206, 159, 135, 139,
  ];

  static String _decode(List<int> bytes, int seed) {
    final out = List<int>.generate(
      bytes.length,
      (i) => bytes[i] ^ ((seed + i * 7) & 0xFF),
    );
    return utf8.decode(out);
  }

  static String get baseUrl => _decode(_u, 91);
  static String get apiKey => _decode(_k, 137);
}
