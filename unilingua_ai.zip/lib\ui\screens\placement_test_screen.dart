import 'dart:async';

import 'package:flutter/material.dart';

import '../../data/repositories/curriculum_repository.dart';
import '../../domain/models/learning_models.dart';
import '../theme/app_theme.dart';
import '../view_models/learning_view_model.dart';

class PlacementTestScreen extends StatefulWidget {
  const PlacementTestScreen({
    super.key,
    required this.viewModel,
    this.isRetake = false,
  });

  final LearningViewModel viewModel;
  final bool isRetake;

  @override
  State<PlacementTestScreen> createState() => _PlacementTestScreenState();
}

class _PlacementTestScreenState extends State<PlacementTestScreen> {
  // Exam progress state:
  // 0..16: 17 standardized MCQs (Listening 5, Reading 5, Grammar 5, Speaking 2)
  // 17: Listening Dictation
  // 18: Real Speaking Production (2 prompts)
  // 19: Real Academic Writing Production (1 essay prompt)
  static const int _dictationStepIndex = 17;
  static const int _speakingStepIndex = 18;
  static const int _writingStepIndex = 19;
  static const int _totalSteps = 20;

  bool _hasStarted = false;
  int _currentStep = 0;
  final Map<String, int> _selectedAnswers = <String, int>{};
  final Map<String, int> _audioPlayCounts = <String, int>{};

  final TextEditingController _dictationCtrl = TextEditingController();
  final TextEditingController _speakingIntroCtrl = TextEditingController();
  final TextEditingController _speakingOpinionCtrl = TextEditingController();
  final TextEditingController _writingEssayCtrl = TextEditingController();

  PlacementTestResult? _completedResult;
  Timer? _examTimer;
  int _elapsedSeconds = 0;

  late String _selectedAcademicYear;
  late String _selectedMajor;
  late String _selectedGoal;
  late int _selectedDailyMinutes;
  late TextEditingController _uniController;

  @override
  void initState() {
    super.initState();
    final user = widget.viewModel.state?.user;
    _selectedAcademicYear =
        user?.academicYear ?? CurriculumRepository.academicYears[1];
    _selectedMajor =
        user?.majorField ?? CurriculumRepository.universityMajors.first;
    _selectedGoal =
        user?.targetGoal ?? CurriculumRepository.universityGoals.first;
    _selectedDailyMinutes = user?.dailyTargetMinutes ?? 30;
    _uniController = TextEditingController(
      text: user?.universityName ?? 'Đại học Quốc gia',
    );

    // If we are returning to review an already graded result
    if (!widget.isRetake &&
        widget.viewModel.isReviewingPlacementResult &&
        widget.viewModel.state?.placementResult != null) {
      _completedResult = widget.viewModel.state!.placementResult;
    }

    _writingEssayCtrl.addListener(() {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _examTimer?.cancel();
    _uniController.dispose();
    _dictationCtrl.dispose();
    _speakingIntroCtrl.dispose();
    _speakingOpinionCtrl.dispose();
    _writingEssayCtrl.dispose();
    super.dispose();
  }

  List<PlacementQuestion> get _questions =>
      CurriculumRepository.placementQuestions;

  String get _formattedTimer {
    final m = (_elapsedSeconds ~/ 60).toString().padLeft(2, '0');
    final s = (_elapsedSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  int get _writingWordCount {
    final trimmed = _writingEssayCtrl.text.trim();
    if (trimmed.isEmpty) return 0;
    return trimmed.split(RegExp(r'\s+')).length;
  }

  Future<void> _startDiagnosticExam() async {
    await widget.viewModel.updateUniversityProfile(
      universityName: _uniController.text,
      academicYear: _selectedAcademicYear,
      majorField: _selectedMajor,
      targetGoal: _selectedGoal,
      dailyTargetMinutes: _selectedDailyMinutes,
    );
    _examTimer?.cancel();
    _elapsedSeconds = 0;
    _examTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) {
        setState(() => _elapsedSeconds++);
      }
    });
    setState(() {
      _hasStarted = true;
      _currentStep = 0;
      _selectedAnswers.clear();
      _audioPlayCounts.clear();
      _dictationCtrl.clear();
      _speakingIntroCtrl.clear();
      _speakingOpinionCtrl.clear();
      _writingEssayCtrl.clear();
      _completedResult = null;
    });
  }

  Future<void> _submitFullExam() async {
    _examTimer?.cancel();
    await widget.viewModel.tts.stop();

    final payload = PlacementSubmissionPayload(
      selectedAnswers: Map<String, int>.from(_selectedAnswers),
      listeningDictationInput: _dictationCtrl.text.trim(),
      speakingIntroAnswer: _speakingIntroCtrl.text.trim(),
      speakingOpinionAnswer: _speakingOpinionCtrl.text.trim(),
      writingEssayAnswer: _writingEssayCtrl.text.trim(),
      elapsedSeconds: _elapsedSeconds,
    );

    final result = await widget.viewModel.submitPlacementExam(payload);
    if (!mounted) return;
    setState(() {
      _completedResult = result;
    });
  }

  void _playExamAudio(String id, String text) {
    setState(() {
      _audioPlayCounts[id] = (_audioPlayCounts[id] ?? 0) + 1;
    });
    widget.viewModel.tts.speak(text, id: id);
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.viewModel,
      builder: (context, _) {
        if (widget.viewModel.isGradingPlacementExam) {
          return _buildAiGradingScreen();
        }
        final resultToShow = _completedResult ??
            (!widget.isRetake && widget.viewModel.isReviewingPlacementResult
                ? widget.viewModel.state?.placementResult
                : null);
        if (resultToShow != null) {
          return _buildResultAndRoadmapView(resultToShow);
        }
        if (!_hasStarted) {
          return _buildIntroView();
        }
        return _buildExamStepView();
      },
    );
  }

  Widget _buildIntroView() {
    final user = widget.viewModel.state?.user;
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Bài Test Đầu Vào Đại Học',
          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18),
        ),
        actions: <Widget>[
          if (widget.isRetake)
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Đóng'),
            ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              // Hero Exam Blueprint Card
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: <Color>[Color(0xFF1E1B4B), Color(0xFF0F172A)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                    color: AppTheme.cyanPrimary.withValues(alpha: 0.45),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color:
                                AppTheme.cyanPrimary.withValues(alpha: 0.16),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: const Icon(
                            Icons.workspace_premium_rounded,
                            color: AppTheme.cyanPrimary,
                            size: 32,
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                'Chào ${user?.displayName ?? "bạn"}! 🎓',
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 4),
                              const Text(
                                'Hãy làm Bài Test Chẩn Đoán 5 Phần chuẩn Đại học ngay bây giờ để AI đo chính xác năng lực thật và vẽ Lộ trình 12 tuần tốt nhất cho riêng bạn.',
                                style: TextStyle(
                                  fontSize: 13,
                                  height: 1.4,
                                  color: AppTheme.textSecondary,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    const _ExamSectionItem(
                      badge: 'Phần 1',
                      title: 'Nghe Giảng Đường & Dictation (A2 → C1)',
                      detail: '5 câu nghe hiểu thực tế + 1 câu chép chính tả bắt âm nối',
                      color: AppTheme.cyanPrimary,
                    ),
                    const _ExamSectionItem(
                      badge: 'Phần 2',
                      title: 'Đọc Giáo Trình & Báo Khoa Học (A2 → C1)',
                      detail: '5 câu đọc hiểu suy luận & từ vựng học thuật',
                      color: AppTheme.emeraldSuccess,
                    ),
                    const _ExamSectionItem(
                      badge: 'Phần 3',
                      title: 'Ngữ Pháp & Văn Phong Học Thuật (A2 → C1)',
                      detail: '5 câu phát hiện lỗ hổng ngữ pháp hay gặp nhất của sinh viên',
                      color: AppTheme.violetAccent,
                    ),
                    const _ExamSectionItem(
                      badge: 'Phần 4',
                      title: 'Nói Thực Tế & Trọng Âm (AI Chấm Trực Tiếp)',
                      detail: '2 câu trọng âm/phản biện + 2 câu trả lời Nói thật bằng tiếng Anh',
                      color: AppTheme.goldAccent,
                    ),
                    const _ExamSectionItem(
                      badge: 'Phần 5',
                      title: 'Viết Đoạn Luận Đại Học (AI Chấm Band IELTS)',
                      detail: 'Viết 1 đoạn 60–150 từ để Giám khảo AI chỉ lỗi & định vị trình độ',
                      color: Color(0xFFFF6B35),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: AppTheme.bgDeep.withValues(alpha: 0.6),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Row(
                        children: <Widget>[
                          Icon(
                            Icons.verified_outlined,
                            size: 16,
                            color: AppTheme.goldAccent,
                          ),
                          SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'Chế độ thi chuẩn: Không hiện đáp án trong lúc làm bài. Nộp bài xong sẽ có bảng phân tích lỗi sai chi tiết & Lộ trình AI 12 tuần.',
                              style: TextStyle(
                                fontSize: 12,
                                color: AppTheme.goldAccent,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 22),

              const Text(
                'Hồ sơ Sinh viên Đại học của bạn',
                style: TextStyle(
                  fontSize: 16.5,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 6),
              const Text(
                'AI sẽ kết hợp thông tin này với kết quả bài test để lập lịch học ngày và lộ trình 12 tuần sát thực tế nhất.',
                style: TextStyle(fontSize: 13, color: AppTheme.textSecondary),
              ),
              const SizedBox(height: 14),

              const Text(
                'Trường Đại học / Học viện',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textSecondary,
                ),
              ),
              const SizedBox(height: 6),
              TextField(
                controller: _uniController,
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.account_balance_rounded),
                  hintText: 'VD: ĐH Bách Khoa, ĐH Kinh tế Quốc dân, ĐH Quốc Gia...',
                ),
              ),
              const SizedBox(height: 12),

              const Text(
                'Bạn đang là sinh viên năm mấy?',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textSecondary,
                ),
              ),
              const SizedBox(height: 6),
              DropdownButtonFormField<String>(
                value: CurriculumRepository.academicYears
                        .contains(_selectedAcademicYear)
                    ? _selectedAcademicYear
                    : CurriculumRepository.academicYears[1],
                isExpanded: true,
                dropdownColor: AppTheme.bgCardElevated,
                items: CurriculumRepository.academicYears
                    .map(
                      (y) => DropdownMenuItem<String>(
                        value: y,
                        child: Text(y, overflow: TextOverflow.ellipsis),
                      ),
                    )
                    .toList(),
                onChanged: (v) {
                  if (v != null) setState(() => _selectedAcademicYear = v);
                },
              ),
              const SizedBox(height: 12),

              const Text(
                'Chuyên ngành đang theo học',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textSecondary,
                ),
              ),
              const SizedBox(height: 6),
              DropdownButtonFormField<String>(
                value: CurriculumRepository.universityMajors
                        .contains(_selectedMajor)
                    ? _selectedMajor
                    : CurriculumRepository.universityMajors.first,
                isExpanded: true,
                dropdownColor: AppTheme.bgCardElevated,
                items: CurriculumRepository.universityMajors
                    .map(
                      (m) => DropdownMenuItem<String>(
                        value: m,
                        child: Text(m, overflow: TextOverflow.ellipsis),
                      ),
                    )
                    .toList(),
                onChanged: (v) {
                  if (v != null) setState(() => _selectedMajor = v);
                },
              ),
              const SizedBox(height: 12),

              const Text(
                'Mục tiêu Tiếng Anh quan trọng nhất',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textSecondary,
                ),
              ),
              const SizedBox(height: 6),
              DropdownButtonFormField<String>(
                value: CurriculumRepository.universityGoals
                        .contains(_selectedGoal)
                    ? _selectedGoal
                    : CurriculumRepository.universityGoals.first,
                isExpanded: true,
                dropdownColor: AppTheme.bgCardElevated,
                items: CurriculumRepository.universityGoals
                    .map(
                      (g) => DropdownMenuItem<String>(
                        value: g,
                        child: Text(g, overflow: TextOverflow.ellipsis),
                      ),
                    )
                    .toList(),
                onChanged: (v) {
                  if (v != null) setState(() => _selectedGoal = v);
                },
              ),
              const SizedBox(height: 14),

              const Text(
                'Quỹ thời gian bạn có thể cam kết học mỗi ngày:',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textSecondary,
                ),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 10,
                runSpacing: 8,
                children: CurriculumRepository.dailyMinuteOptions.map((mins) {
                  final selected = _selectedDailyMinutes == mins;
                  return ChoiceChip(
                    label: Text(
                      '$mins phút/ngày',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        color: selected
                            ? const Color(0xFF04101E)
                            : AppTheme.textPrimary,
                      ),
                    ),
                    selected: selected,
                    selectedColor: AppTheme.cyanPrimary,
                    onSelected: (_) =>
                        setState(() => _selectedDailyMinutes = mins),
                  );
                }).toList(),
              ),
              const SizedBox(height: 26),

              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton.icon(
                  onPressed: _startDiagnosticExam,
                  icon: const Icon(Icons.play_arrow_rounded, size: 24),
                  label: const Text(
                    'Bắt Đầu Bài Test Chuẩn 5 Phần (20 Bước)',
                    style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w800),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildExamStepView() {
    final progress = (_currentStep + 1) / _totalSteps;
    String sectionLabel;
    if (_currentStep < 5) {
      sectionLabel = 'Phần 1/5 • Listening';
    } else if (_currentStep < 10) {
      sectionLabel = 'Phần 2/5 • Reading';
    } else if (_currentStep < 15) {
      sectionLabel = 'Phần 3/5 • Grammar';
    } else if (_currentStep < 17) {
      sectionLabel = 'Phần 4/5 • Speaking';
    } else if (_currentStep == _dictationStepIndex) {
      sectionLabel = 'Phần 1B • Nghe Chép Chính Tả';
    } else if (_currentStep == _speakingStepIndex) {
      sectionLabel = 'Phần 4B • Nói Thực Tế (AI Chấm)';
    } else {
      sectionLabel = 'Phần 5/5 • Viết Luận Thực Tế (AI Chấm)';
    }

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              sectionLabel,
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
            ),
            Text(
              'Bước ${_currentStep + 1}/$_totalSteps • Chế độ thi chẩn đoán',
              style: const TextStyle(
                fontSize: 11.5,
                color: AppTheme.textSecondary,
              ),
            ),
          ],
        ),
        actions: <Widget>[
          Container(
            margin: const EdgeInsets.only(right: 14),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: AppTheme.bgCardElevated,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppTheme.borderSubtle),
            ),
            child: Row(
              children: <Widget>[
                const Icon(
                  Icons.timer_outlined,
                  size: 15,
                  color: AppTheme.cyanPrimary,
                ),
                const SizedBox(width: 4),
                Text(
                  _formattedTimer,
                  style: const TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 13,
                    fontFamily: 'monospace',
                  ),
                ),
              ],
            ),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(6),
          child: LinearProgressIndicator(
            value: progress,
            minHeight: 6,
            backgroundColor: AppTheme.bgCard,
            valueColor:
                const AlwaysStoppedAnimation<Color>(AppTheme.cyanPrimary),
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              if (_currentStep < _questions.length)
                _buildMcqStep(_questions[_currentStep])
              else if (_currentStep == _dictationStepIndex)
                _buildDictationStep()
              else if (_currentStep == _speakingStepIndex)
                _buildRealSpeakingStep()
              else
                _buildRealWritingStep(),

              const SizedBox(height: 24),
              _buildExamBottomNav(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMcqStep(PlacementQuestion q) {
    final selectedIdx = _selectedAnswers[q.id];
    final plays = _audioPlayCounts[q.id] ?? 0;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Wrap(
          spacing: 8,
          runSpacing: 6,
          children: <Widget>[
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 5),
              decoration: BoxDecoration(
                color: AppTheme.cyanPrimary.withValues(alpha: 0.14),
                borderRadius: BorderRadius.circular(999),
              ),
              child: Text(
                q.topicTag,
                style: const TextStyle(
                  color: AppTheme.cyanPrimary,
                  fontWeight: FontWeight.w700,
                  fontSize: 12,
                ),
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: AppTheme.goldAccent.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(999),
              ),
              child: Text(
                'Mức chuẩn ${q.cefrDifficulty}',
                style: const TextStyle(
                  color: AppTheme.goldAccent,
                  fontWeight: FontWeight.w800,
                  fontSize: 12,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),

        // Exam-mode Audio Player (NO transcript spoiler during exam!)
        if (q.audioScript.isNotEmpty) ...<Widget>[
          ListenableBuilder(
            listenable: widget.viewModel.tts,
            builder: (context, _) {
              final isPlaying = widget.viewModel.tts.isSpeaking &&
                  widget.viewModel.tts.currentSpeakingId == q.id;
              return Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppTheme.bgCardElevated,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(
                    color: AppTheme.cyanPrimary.withValues(alpha: 0.45),
                  ),
                ),
                child: Row(
                  children: <Widget>[
                    IconButton.filled(
                      onPressed: () => _playExamAudio(q.id, q.audioScript),
                      style: IconButton.styleFrom(
                        backgroundColor: AppTheme.cyanPrimary,
                        foregroundColor: const Color(0xFF04101E),
                      ),
                      icon: Icon(
                        isPlaying
                            ? Icons.stop_rounded
                            : Icons.volume_up_rounded,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            isPlaying
                                ? 'Đang phát Audio bài thi...'
                                : 'Bấm để nghe Audio (Khuyên nghe tối đa 2 lần)',
                            style: const TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 14,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            'Đã nghe: $plays lần • Ẩn Transcript trong lúc thi để đo trình độ chính xác',
                            style: const TextStyle(
                              fontSize: 11.5,
                              color: AppTheme.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ),
                    TextButton(
                      onPressed: widget.viewModel.tts.cycleSpeed,
                      child: Text(
                        widget.viewModel.tts.speedLabel,
                        style: const TextStyle(
                          color: AppTheme.goldAccent,
                          fontWeight: FontWeight.w700,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
          const SizedBox(height: 16),
        ],

        // Reading Passage Container
        if (q.readingContext.isNotEmpty) ...<Widget>[
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.bgSurface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppTheme.borderSubtle),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                const Row(
                  children: <Widget>[
                    Icon(
                      Icons.menu_book_rounded,
                      size: 16,
                      color: AppTheme.emeraldSuccess,
                    ),
                    SizedBox(width: 6),
                    Text(
                      'ACADEMIC READING PASSAGE',
                      style: TextStyle(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w800,
                        color: AppTheme.emeraldSuccess,
                        letterSpacing: 0.7,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  q.readingContext,
                  style: const TextStyle(
                    fontSize: 14.5,
                    height: 1.55,
                    color: AppTheme.textPrimary,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
        ],

        Text(
          q.prompt,
          style: const TextStyle(
            fontSize: 16.5,
            fontWeight: FontWeight.w800,
            height: 1.4,
          ),
        ),
        const SizedBox(height: 16),

        ...List<Widget>.generate(q.options.length, (idx) {
          final isSelected = selectedIdx == idx;
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () => setState(() => _selectedAnswers[q.id] = idx),
              child: Container(
                padding: const EdgeInsets.all(15),
                decoration: BoxDecoration(
                  color: isSelected
                      ? AppTheme.cyanPrimary.withValues(alpha: 0.16)
                      : AppTheme.bgCard,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: isSelected
                        ? AppTheme.cyanPrimary
                        : AppTheme.borderSubtle,
                    width: isSelected ? 1.8 : 1,
                  ),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      width: 28,
                      height: 28,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: isSelected
                            ? AppTheme.cyanPrimary
                            : AppTheme.bgSurface,
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        String.fromCharCode(65 + idx),
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          color: isSelected
                              ? const Color(0xFF04101E)
                              : AppTheme.textSecondary,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        q.options[idx],
                        style: const TextStyle(
                          fontSize: 14.5,
                          height: 1.4,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ],
    );
  }

  Widget _buildDictationStep() {
    final plays = _audioPlayCounts['pt_dictation'] ?? 0;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        const Text(
          '🎧 Kiểm Tra Nghe Chép Chính Tả (Academic Dictation)',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 6),
        const Text(
          'Bài tập này giúp hệ thống đo chính xác khả năng bắt từ nối, trọng âm và âm cuối của bạn khi nghe giảng bằng tiếng Anh.',
          style: TextStyle(fontSize: 13.5, color: AppTheme.textSecondary),
        ),
        const SizedBox(height: 16),
        ListenableBuilder(
          listenable: widget.viewModel.tts,
          builder: (context, _) {
            final isPlaying = widget.viewModel.tts.isSpeaking &&
                widget.viewModel.tts.currentSpeakingId == 'pt_dictation';
            return Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: AppTheme.bgCardElevated,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: AppTheme.cyanPrimary.withValues(alpha: 0.45),
                ),
              ),
              child: Row(
                children: <Widget>[
                  IconButton.filled(
                    onPressed: () => _playExamAudio(
                      'pt_dictation',
                      CurriculumRepository.placementDictationAudio,
                    ),
                    style: IconButton.styleFrom(
                      backgroundColor: AppTheme.cyanPrimary,
                      foregroundColor: const Color(0xFF04101E),
                    ),
                    icon: Icon(
                      isPlaying
                          ? Icons.stop_rounded
                          : Icons.volume_up_rounded,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          isPlaying
                              ? 'Đang đọc câu giảng đường...'
                              : 'Bấm để nghe câu tiếng Anh cần chép lại',
                          style: const TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 14.5,
                          ),
                        ),
                        Text(
                          'Đã phát $plays lần • Tốc độ: ${widget.viewModel.tts.speedLabel}',
                          style: const TextStyle(
                            fontSize: 12,
                            color: AppTheme.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                  TextButton(
                    onPressed: widget.viewModel.tts.cycleSpeed,
                    child: const Text('Đổi tốc độ'),
                  ),
                ],
              ),
            );
          },
        ),
        const SizedBox(height: 16),
        TextField(
          controller: _dictationCtrl,
          minLines: 3,
          maxLines: 5,
          decoration: const InputDecoration(
            hintText: 'Gõ lại chính xác câu tiếng Anh bạn vừa nghe được...',
          ),
        ),
      ],
    );
  }

  Widget _buildRealSpeakingStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        const Text(
          '🎙️ Phần Thi Nói Thực Tế (AI Đánh Giá Trực Tiếp)',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 6),
        const Text(
          'Hãy bật Micro trên bàn phím điện thoại (nhập liệu bằng giọng nói tiếng Anh) hoặc tự diễn đạt câu trả lời tự nhiên như đang phỏng vấn thật. Giám khảo AI sẽ chấm độ trôi chảy, từ vựng và cách diễn đạt của bạn.',
          style: TextStyle(
            fontSize: 13,
            height: 1.45,
            color: AppTheme.textSecondary,
          ),
        ),
        const SizedBox(height: 16),

        // Speaking Task 1
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.bgCard,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: AppTheme.goldAccent.withValues(alpha: 0.4),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                children: <Widget>[
                  const Expanded(
                    child: Text(
                      'Câu Nói 1 • Giới thiệu Sinh viên (Part 1)',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        color: AppTheme.goldAccent,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () => widget.viewModel.tts.speak(
                      CurriculumRepository.placementSpeakingPrompt1,
                      id: 'spk_p1',
                    ),
                    icon: const Icon(
                      Icons.volume_up_rounded,
                      color: AppTheme.cyanPrimary,
                    ),
                  ),
                ],
              ),
              const Text(
                CurriculumRepository.placementSpeakingPrompt1,
                style: TextStyle(
                  fontSize: 14.5,
                  fontWeight: FontWeight.w700,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _speakingIntroCtrl,
                minLines: 3,
                maxLines: 5,
                decoration: const InputDecoration(
                  hintText:
                      'VD: Hi, I am a second-year student majoring in Computer Science. I want to improve my academic speaking...',
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),

        // Speaking Task 2
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.bgCard,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: AppTheme.cyanPrimary.withValues(alpha: 0.4),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                children: <Widget>[
                  const Expanded(
                    child: Text(
                      'Câu Nói 2 • Phản biện Đại học (IELTS Part 3)',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        color: AppTheme.cyanPrimary,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () => widget.viewModel.tts.speak(
                      CurriculumRepository.placementSpeakingPrompt2,
                      id: 'spk_p2',
                    ),
                    icon: const Icon(
                      Icons.volume_up_rounded,
                      color: AppTheme.cyanPrimary,
                    ),
                  ),
                ],
              ),
              const Text(
                CurriculumRepository.placementSpeakingPrompt2,
                style: TextStyle(
                  fontSize: 14.5,
                  fontWeight: FontWeight.w700,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _speakingOpinionCtrl,
                minLines: 3,
                maxLines: 6,
                decoration: const InputDecoration(
                  hintText:
                      'Trình bày quan điểm của bạn bằng tiếng Anh (có ít nhất 1 lý do và ví dụ)...',
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildRealWritingStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        const Text(
          '✍️ Phần Thi Viết Học Thuật Thực Tế (AI Chấm Band IELTS)',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 6),
        const Text(
          'Đây là bước cuối cùng của bài Test đầu vào. Hãy viết trung thực bằng chính năng lực của bạn (không cần quá hoàn hảo) để AI nhìn ra đúng lỗi ngữ pháp/từ vựng cần sửa trong lộ trình 12 tuần.',
          style: TextStyle(
            fontSize: 13,
            height: 1.45,
            color: AppTheme.textSecondary,
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.bgCardElevated,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: AppTheme.violetAccent.withValues(alpha: 0.55),
            ),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                'ĐỀ BÀI VIẾT CHẨN ĐOÁN (ACADEMIC MINI-ESSAY)',
                style: TextStyle(
                  fontSize: 11.5,
                  fontWeight: FontWeight.w800,
                  color: AppTheme.cyanPrimary,
                  letterSpacing: 0.7,
                ),
              ),
              SizedBox(height: 8),
              Text(
                CurriculumRepository.placementWritingPrompt,
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  height: 1.45,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Text(
              'Số từ hiện tại: $_writingWordCount từ (Gợi ý: 60–150 từ)',
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: _writingWordCount >= 50
                    ? AppTheme.emeraldSuccess
                    : AppTheme.goldAccent,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _writingEssayCtrl,
          minLines: 7,
          maxLines: 14,
          decoration: const InputDecoration(
            hintText:
                'Viết đoạn văn tiếng Anh của bạn tại đây...\n(Nêu rõ quan điểm -> 1-2 luận điểm kèm ví dụ sinh viên -> Câu kết luận)',
          ),
        ),
      ],
    );
  }

  Widget _buildExamBottomNav() {
    final isMcqStep = _currentStep < _questions.length;
    final canProceed = !isMcqStep ||
        _selectedAnswers.containsKey(_questions[_currentStep].id);
    final isLastStep = _currentStep == _writingStepIndex;

    return Row(
      children: <Widget>[
        if (_currentStep > 0)
          Expanded(
            child: OutlinedButton(
              onPressed: () {
                widget.viewModel.tts.stop();
                setState(() => _currentStep--);
              },
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              child: const Text('← Bước trước'),
            ),
          ),
        if (_currentStep > 0) const SizedBox(width: 12),
        Expanded(
          flex: 2,
          child: ElevatedButton.icon(
            onPressed: !canProceed
                ? null
                : () {
                    if (!isLastStep) {
                      widget.viewModel.tts.stop();
                      setState(() => _currentStep++);
                    } else {
                      _submitFullExam();
                    }
                  },
            icon: Icon(
              isLastStep
                  ? Icons.auto_awesome_rounded
                  : Icons.arrow_forward_rounded,
            ),
            label: Text(
              isLastStep
                  ? 'Nộp Bài Thi & Lập Lộ Trình AI'
                  : 'Tiếp tục →',
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildAiGradingScreen() {
    final user = widget.viewModel.state?.user;
    return Scaffold(
      body: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(28),
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, -0.3),
            radius: 1.2,
            colors: <Color>[Color(0xFF1E1B4B), AppTheme.bgDeep],
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const SizedBox(
              width: 72,
              height: 72,
              child: CircularProgressIndicator(
                strokeWidth: 5,
                color: AppTheme.cyanPrimary,
              ),
            ),
            const SizedBox(height: 26),
            const Text(
              'Giám khảo AI đang Chấm Bài & Thiết Kế Lộ Trình...',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'Đang chấm 17 câu A2–C1, bài Nghe chép chính tả, bài Nói thực tế và đoạn luận Viết của bạn để tạo lộ trình 12 tuần tối ưu cho ${user?.majorField ?? "Sinh viên Đại học"} (${user?.dailyTargetMinutes ?? 30} phút/ngày).',
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 14,
                height: 1.5,
                color: AppTheme.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildResultAndRoadmapView(PlacementTestResult result) {
    final user = widget.viewModel.state?.user;

    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: widget.isRetake,
        title: const Text(
          'Báo Cáo Chẩn Đoán & Lộ Trình AI 12 Tuần',
          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16.5),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              // 1. Overall Score & CEFR/IELTS/TOEIC Card
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: <Color>[Color(0xFF1E1B4B), Color(0xFF0F172A)],
                  ),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                    color: AppTheme.cyanPrimary.withValues(alpha: 0.55),
                  ),
                ),
                child: Column(
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Icon(
                          result.generatedByAi
                              ? Icons.auto_awesome_rounded
                              : Icons.verified_rounded,
                          size: 16,
                          color: AppTheme.goldAccent,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          result.generatedByAi
                              ? 'ĐÃ CHẤM TRỰC TIẾP BỞI GIÁM KHẢO AI'
                              : 'KẾT QUẢ CHẨN ĐOÁN 4 KỸ NĂNG CHUẨN ĐẠI HỌC',
                          style: const TextStyle(
                            fontSize: 11.5,
                            fontWeight: FontWeight.w800,
                            color: AppTheme.goldAccent,
                            letterSpacing: 0.8,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: <Widget>[
                        _ScoreStatBox(
                          label: 'Trình độ CEFR',
                          value: result.cefrLevel,
                          color: AppTheme.cyanPrimary,
                        ),
                        _ScoreStatBox(
                          label: 'Quy đổi IELTS',
                          value: result.estimatedIelts,
                          color: AppTheme.goldAccent,
                        ),
                        _ScoreStatBox(
                          label: 'Quy đổi TOEIC',
                          value: '~${result.estimatedToeic}',
                          color: AppTheme.emeraldSuccess,
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Trắc nghiệm chuẩn hóa: ${result.objectiveCorrectCount}/${result.objectiveTotalCount} câu đúng • Nghe Dictation: ${result.dictationAccuracyPercent}%',
                      style: const TextStyle(
                        fontSize: 12.5,
                        color: AppTheme.textSecondary,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const Divider(height: 24),
                    _SkillScoreBar(
                      label: '🎧 Nghe (Listening)',
                      score: result.listeningScore,
                      color: AppTheme.cyanPrimary,
                      isWeakest: result.weakestSkill == SkillType.listening,
                    ),
                    const SizedBox(height: 8),
                    _SkillScoreBar(
                      label: '🎙️ Nói (Speaking — AI chấm bài nói thật)',
                      score: result.speakingScore,
                      color: AppTheme.goldAccent,
                      isWeakest: result.weakestSkill == SkillType.speaking,
                    ),
                    const SizedBox(height: 8),
                    _SkillScoreBar(
                      label: '📖 Đọc (Reading)',
                      score: result.readingScore,
                      color: AppTheme.emeraldSuccess,
                      isWeakest: result.weakestSkill == SkillType.reading,
                    ),
                    const SizedBox(height: 8),
                    _SkillScoreBar(
                      label: '✍️ Viết (Writing — AI chấm bài luận thật)',
                      score: result.writingScore,
                      color: AppTheme.violetAccent,
                      isWeakest: result.weakestSkill == SkillType.writing,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 18),

              // 2. AI Diagnostic Summary + Strengths & Critical Gaps
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: AppTheme.bgCard,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppTheme.borderSubtle),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const Row(
                      children: <Widget>[
                        Icon(
                          Icons.psychology_rounded,
                          color: AppTheme.cyanPrimary,
                          size: 22,
                        ),
                        SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Phân Tích Chuyên Sâu Từ Giám Khảo AI',
                            style: TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 15.5,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Text(
                      result.aiDiagnosticSummary,
                      style: const TextStyle(
                        fontSize: 13.5,
                        height: 1.5,
                        color: AppTheme.textPrimary,
                      ),
                    ),
                    if (result.keyStrengths.isNotEmpty) ...<Widget>[
                      const SizedBox(height: 14),
                      const Text(
                        '✅ Điểm mạnh cần phát huy:',
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 13.5,
                          color: AppTheme.emeraldSuccess,
                        ),
                      ),
                      const SizedBox(height: 4),
                      ...result.keyStrengths.map(
                        (s) => Padding(
                          padding: const EdgeInsets.only(bottom: 4),
                          child: Text(
                            '• $s',
                            style: const TextStyle(fontSize: 13, height: 1.4),
                          ),
                        ),
                      ),
                    ],
                    if (result.criticalGaps.isNotEmpty) ...<Widget>[
                      const SizedBox(height: 12),
                      const Text(
                        '🎯 Lỗ hổng trọng điểm cần vá ngay:',
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 13.5,
                          color: AppTheme.coralDanger,
                        ),
                      ),
                      const SizedBox(height: 4),
                      ...result.criticalGaps.map(
                        (g) => Padding(
                          padding: const EdgeInsets.only(bottom: 4),
                          child: Text(
                            '• $g',
                            style: const TextStyle(fontSize: 13, height: 1.4),
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // 3. Direct Feedback on Student's Real Speaking & Writing
              if (result.speakingFeedbackVi.isNotEmpty ||
                  result.writingFeedbackVi.isNotEmpty) ...<Widget>[
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: AppTheme.bgCard,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: AppTheme.goldAccent.withValues(alpha: 0.35),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      const Text(
                        '🔍 Nhận Xét Bài Nói & Bài Viết Thực Tế Của Bạn',
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 15,
                          color: AppTheme.goldAccent,
                        ),
                      ),
                      if (result.speakingFeedbackVi.isNotEmpty) ...<Widget>[
                        const SizedBox(height: 10),
                        const Text(
                          '🎙️ Bài Nói Thực Tế (Speaking):',
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 13.5,
                            color: AppTheme.cyanPrimary,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          result.speakingFeedbackVi,
                          style: const TextStyle(fontSize: 13, height: 1.45),
                        ),
                      ],
                      if (result.writingFeedbackVi.isNotEmpty) ...<Widget>[
                        const SizedBox(height: 12),
                        const Text(
                          '✍️ Bài Luận Thực Tế (Writing):',
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 13.5,
                            color: AppTheme.violetAccent,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          result.writingFeedbackVi,
                          style: const TextStyle(fontSize: 13, height: 1.45),
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(height: 18),
              ],

              // 4. Adaptive Daily Schedule Plan
              if (result.dailySchedule.isNotEmpty) ...<Widget>[
                Text(
                  '⏱️ Lịch Học Mẫu Hàng Ngày (${user?.dailyTargetMinutes ?? 30} Phút/Ngày)',
                  style: const TextStyle(
                    fontSize: 16.5,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Phân bổ tự động 40% thời gian mỗi ngày để kéo mạnh kỹ năng yếu nhất của bạn lên chuẩn mục tiêu:',
                  style: TextStyle(fontSize: 12.5, color: AppTheme.textSecondary),
                ),
                const SizedBox(height: 10),
                ...result.dailySchedule.map(
                  (slot) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: AppTheme.bgCard,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: AppTheme.borderSubtle),
                      ),
                      child: Row(
                        children: <Widget>[
                          Container(
                            width: 56,
                            height: 50,
                            decoration: BoxDecoration(
                              color: AppTheme.cyanPrimary
                                  .withValues(alpha: 0.14),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            alignment: Alignment.center,
                            child: Text(
                              '${slot.minutes}\'\n/ngày',
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                color: AppTheme.cyanPrimary,
                                fontWeight: FontWeight.w900,
                                fontSize: 12,
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  slot.activityTitle,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w800,
                                    fontSize: 14,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  slot.detail,
                                  style: const TextStyle(
                                    fontSize: 12.5,
                                    color: AppTheme.textSecondary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
              ],

              // 5. Personalized 12-Week University Roadmap
              Text(
                '🗺️ Lộ Trình 12 Tuần Cá Nhân Hóa (${user?.majorField ?? "Đại học"})',
                style: const TextStyle(
                  fontSize: 16.5,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 10),
              ...result.roadmapPhases.map(
                (phase) => Padding(
                  padding: const EdgeInsets.only(bottom: 14),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppTheme.bgCard,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: AppTheme.borderSubtle),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: AppTheme.cyanPrimary.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            phase.weekRange,
                            style: const TextStyle(
                              color: AppTheme.cyanPrimary,
                              fontWeight: FontWeight.w800,
                              fontSize: 12,
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          phase.title,
                          style: const TextStyle(
                            fontSize: 15.5,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          phase.focusGoal,
                          style: const TextStyle(
                            fontSize: 13,
                            color: AppTheme.textSecondary,
                          ),
                        ),
                        const Divider(height: 20),
                        _PhaseTaskLine(
                          prefix: '🎧 Nghe:',
                          text: phase.listeningTask,
                        ),
                        _PhaseTaskLine(
                          prefix: '🎙️ Nói:',
                          text: phase.speakingTask,
                        ),
                        _PhaseTaskLine(
                          prefix: '📖 Đọc:',
                          text: phase.readingTask,
                        ),
                        _PhaseTaskLine(
                          prefix: '✍️ Viết:',
                          text: phase.writingTask,
                        ),
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color:
                                AppTheme.emeraldSuccess.withValues(alpha: 0.12),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Row(
                            children: <Widget>[
                              const Icon(
                                Icons.flag_rounded,
                                size: 16,
                                color: AppTheme.emeraldSuccess,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  'Cột mốc: ${phase.milestone}',
                                  style: const TextStyle(
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w700,
                                    color: AppTheme.emeraldSuccess,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              // 6. Detailed Mistake Review (revealed ONLY after submission)
              if (result.mistakes.isNotEmpty) ...<Widget>[
                const SizedBox(height: 8),
                ExpansionTile(
                  tilePadding: const EdgeInsets.symmetric(horizontal: 14),
                  collapsedBackgroundColor: AppTheme.bgCard,
                  backgroundColor: AppTheme.bgCard,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                    side: const BorderSide(color: AppTheme.borderSubtle),
                  ),
                  collapsedShape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                    side: const BorderSide(color: AppTheme.borderSubtle),
                  ),
                  title: Text(
                    '📝 Xem lại ${result.mistakes.length} câu làm sai & Giải thích chi tiết',
                    style: const TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 14.5,
                      color: AppTheme.goldAccent,
                    ),
                  ),
                  children: result.mistakes
                      .map(
                        (m) => Padding(
                          padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
                          child: Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: AppTheme.bgSurface,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  '[${m.skill.shortVi} • ${m.cefrDifficulty}] ${m.topicTag}',
                                  style: const TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w800,
                                    color: AppTheme.cyanPrimary,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  'Bạn chọn: ${m.userAnswerText}',
                                  style: const TextStyle(
                                    fontSize: 12.5,
                                    color: AppTheme.coralDanger,
                                  ),
                                ),
                                Text(
                                  'Đáp án đúng: ${m.correctAnswerText}',
                                  style: const TextStyle(
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w700,
                                    color: AppTheme.emeraldSuccess,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  '💡 ${m.explanationVi}',
                                  style: const TextStyle(
                                    fontSize: 12.5,
                                    color: AppTheme.textSecondary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      )
                      .toList(),
                ),
              ],

              const SizedBox(height: 22),
              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton.icon(
                  onPressed: () {
                    widget.viewModel.completePlacementReview();
                    if (widget.isRetake && Navigator.of(context).canPop()) {
                      Navigator.of(context).pop();
                    }
                  },
                  icon: const Icon(Icons.rocket_launch_rounded),
                  label: const Text(
                    'Lưu Lộ Trình & Vào Học Ngay (+150 XP)',
                    style: TextStyle(
                      fontSize: 15.5,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }
}

class _ExamSectionItem extends StatelessWidget {
  const _ExamSectionItem({
    required this.badge,
    required this.title,
    required this.detail,
    required this.color,
  });

  final String badge;
  final String title;
  final String detail;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.16),
              borderRadius: BorderRadius.circular(7),
              border: Border.all(color: color.withValues(alpha: 0.45)),
            ),
            child: Text(
              badge,
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                color: color,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 13.5,
                  ),
                ),
                Text(
                  detail,
                  style: const TextStyle(
                    fontSize: 12,
                    color: AppTheme.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ScoreStatBox extends StatelessWidget {
  const _ScoreStatBox({
    required this.label,
    required this.value,
    required this.color,
  });

  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Text(
          value,
          style: TextStyle(
            fontSize: 23,
            fontWeight: FontWeight.w900,
            color: color,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: const TextStyle(
            fontSize: 12,
            color: AppTheme.textSecondary,
          ),
        ),
      ],
    );
  }
}

class _SkillScoreBar extends StatelessWidget {
  const _SkillScoreBar({
    required this.label,
    required this.score,
    required this.color,
    this.isWeakest = false,
  });

  final String label;
  final int score;
  final Color color;
  final bool isWeakest;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Expanded(
              child: Text(
                isWeakest ? '$label  [Ưu tiên #1]' : label,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: isWeakest ? FontWeight.w800 : FontWeight.w600,
                  color: isWeakest ? AppTheme.coralDanger : AppTheme.textPrimary,
                ),
              ),
            ),
            Text(
              '$score/100',
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w800,
                color: color,
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        ClipRRect(
          borderRadius: BorderRadius.circular(999),
          child: LinearProgressIndicator(
            value: (score / 100).clamp(0.0, 1.0),
            minHeight: 7,
            backgroundColor: AppTheme.bgSurface,
            valueColor: AlwaysStoppedAnimation<Color>(color),
          ),
        ),
      ],
    );
  }
}

class _PhaseTaskLine extends StatelessWidget {
  const _PhaseTaskLine({
    required this.prefix,
    required this.text,
  });

  final String prefix;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: RichText(
        text: TextSpan(
          style: const TextStyle(
            fontSize: 13,
            height: 1.4,
            color: AppTheme.textPrimary,
          ),
          children: <TextSpan>[
            TextSpan(
              text: '$prefix ',
              style: const TextStyle(
                fontWeight: FontWeight.w800,
                color: AppTheme.cyanPrimary,
              ),
            ),
            TextSpan(text: text),
          ],
        ),
      ),
    );
  }
}
