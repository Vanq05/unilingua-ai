import 'dart:async';

import 'package:flutter/material.dart';

import '../../data/repositories/curriculum_repository.dart';
import '../../domain/models/learning_models.dart';
import '../theme/app_theme.dart';
import '../view_models/learning_view_model.dart';

class PlacementTestScreen extends StatefulWidget {
  const PlacementTestScreen({
    super.key,
    required this.viewModel,
    this.isRetake = false,
  });

  final LearningViewModel viewModel;
  final bool isRetake;

  @override
  State<PlacementTestScreen> createState() => _PlacementTestScreenState();
}

class _PlacementTestScreenState extends State<PlacementTestScreen> {
  // 0..9: 10 progressive MCQs (A1 -> B1)
  // 10: Easy Dictation
  // 11: Short Speaking (1-3 sentences)
  // 12: Short Writing (2-5 sentences)
  static const int _dictationStepIndex = 10;
  static const int _speakingStepIndex = 11;
  static const int _writingStepIndex = 12;
  static const int _totalSteps = 13;

  bool _hasStarted = false;
  int _currentStep = 0;
  final Map<String, int> _selectedAnswers = <String, int>{};

  final TextEditingController _dictationCtrl = TextEditingController();
  final TextEditingController _speakingIntroCtrl = TextEditingController();
  final TextEditingController _speakingOpinionCtrl = TextEditingController();
  final TextEditingController _writingEssayCtrl = TextEditingController();

  PlacementTestResult? _completedResult;
  Timer? _examTimer;
  int _elapsedSeconds = 0;

  late int _selectedDailyMinutes;

  @override
  void initState() {
    super.initState();
    _selectedDailyMinutes =
        widget.viewModel.state?.user.dailyTargetMinutes ?? 30;

    if (!widget.isRetake &&
        widget.viewModel.isReviewingPlacementResult &&
        widget.viewModel.state?.placementResult != null) {
      _completedResult = widget.viewModel.state!.placementResult;
    }

    _writingEssayCtrl.addListener(() {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _examTimer?.cancel();
    _dictationCtrl.dispose();
    _speakingIntroCtrl.dispose();
    _speakingOpinionCtrl.dispose();
    _writingEssayCtrl.dispose();
    super.dispose();
  }

  List<PlacementQuestion> get _questions =>
      CurriculumRepository.placementQuestions;

  String get _formattedTimer {
    final m = (_elapsedSeconds ~/ 60).toString().padLeft(2, '0');
    final s = (_elapsedSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  Future<void> _startDiagnosticExam() async {
    await widget.viewModel.updateDailyTargetMinutes(_selectedDailyMinutes);
    _examTimer?.cancel();
    _elapsedSeconds = 0;
    _examTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _elapsedSeconds++);
    });
    setState(() {
      _hasStarted = true;
      _currentStep = 0;
      _selectedAnswers.clear();
      _dictationCtrl.clear();
      _speakingIntroCtrl.clear();
      _speakingOpinionCtrl.clear();
      _writingEssayCtrl.clear();
      _completedResult = null;
    });
  }

  Future<void> _submitFullExam() async {
    _examTimer?.cancel();
    await widget.viewModel.tts.stop();

    final payload = PlacementSubmissionPayload(
      selectedAnswers: Map<String, int>.from(_selectedAnswers),
      listeningDictationInput: _dictationCtrl.text.trim(),
      speakingIntroAnswer: _speakingIntroCtrl.text.trim(),
      speakingOpinionAnswer: _speakingOpinionCtrl.text.trim(),
      writingEssayAnswer: _writingEssayCtrl.text.trim(),
      elapsedSeconds: _elapsedSeconds,
    );

    final result = await widget.viewModel.submitPlacementExam(payload);
    if (!mounted) return;
    setState(() {
      _completedResult = result;
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.viewModel,
      builder: (context, _) {
        if (widget.viewModel.isGradingPlacementExam) {
          return _buildAiGradingScreen();
        }
        final resultToShow = _completedResult ??
            (!widget.isRetake && widget.viewModel.isReviewingPlacementResult
                ? widget.viewModel.state?.placementResult
                : null);
        if (resultToShow != null) {
          return _buildResultAndRoadmapView(resultToShow);
        }
        if (!_hasStarted) {
          return _buildIntroView();
        }
        return _buildExamStepView();
      },
    );
  }

  Widget _buildIntroView() {
    final user = widget.viewModel.state?.user;
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Kiểm tra Trình độ Đầu vào',
          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18),
        ),
        actions: <Widget>[
          if (widget.isRetake)
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Đóng'),
            ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: <Color>[Color(0xFF1E1B4B), Color(0xFF0F172A)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(
                    color: AppTheme.cyanPrimary.withValues(alpha: 0.45),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'Chào ${user?.displayName ?? "bạn"}! 👋',
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Làm nhanh bài test 5 phút (đi từ rất dễ A1 đến khó dần) để AI đo đúng trình độ và lập lộ trình học tốt nhất cho bạn.',
                      style: TextStyle(
                        fontSize: 14,
                        height: 1.45,
                        color: AppTheme.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 16),
                    const _SimpleBullet(
                      icon: Icons.headphones_rounded,
                      color: AppTheme.cyanPrimary,
                      text: 'Nghe: 3 câu ngắn (A1 → B1) + 1 câu chép đơn giản',
                    ),
                    const _SimpleBullet(
                      icon: Icons.menu_book_rounded,
                      color: AppTheme.emeraldSuccess,
                      text: 'Đọc & Ngữ pháp: 6 câu ngắn cơ bản đến trung cấp',
                    ),
                    const _SimpleBullet(
                      icon: Icons.mic_rounded,
                      color: AppTheme.goldAccent,
                      text: 'Nói & Viết: 1 câu trắc nghiệm + vài câu giới thiệu ngắn',
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 22),
              const Text(
                'Bạn muốn học bao nhiêu phút mỗi ngày?',
                style: TextStyle(
                  fontSize: 15.5,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 10,
                runSpacing: 8,
                children: CurriculumRepository.dailyMinuteOptions.map((mins) {
                  final selected = _selectedDailyMinutes == mins;
                  return ChoiceChip(
                    label: Text(
                      '$mins phút / ngày',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        color: selected
                            ? const Color(0xFF04101E)
                            : AppTheme.textPrimary,
                      ),
                    ),
                    selected: selected,
                    selectedColor: AppTheme.cyanPrimary,
                    onSelected: (_) =>
                        setState(() => _selectedDailyMinutes = mins),
                  );
                }).toList(),
              ),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton.icon(
                  onPressed: _startDiagnosticExam,
                  icon: const Icon(Icons.play_arrow_rounded, size: 24),
                  label: const Text(
                    'Bắt đầu Bài Test (Dễ → Khó dần)',
                    style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w800),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildExamStepView() {
    final progress = (_currentStep + 1) / _totalSteps;
    String sectionLabel;
    if (_currentStep < 3) {
      sectionLabel = 'Phần 1 • Nghe cơ bản → Nâng dần';
    } else if (_currentStep < 6) {
      sectionLabel = 'Phần 2 • Đọc hiểu ngắn';
    } else if (_currentStep < 9) {
      sectionLabel = 'Phần 3 • Ngữ pháp căn bản';
    } else if (_currentStep == 9) {
      sectionLabel = 'Phần 4 • Giao tiếp cơ bản';
    } else if (_currentStep == _dictationStepIndex) {
      sectionLabel = 'Nghe & Gõ lại 1 câu ngắn';
    } else if (_currentStep == _speakingStepIndex) {
      sectionLabel = 'Nói thử 1–2 câu ngắn';
    } else {
      sectionLabel = 'Viết thử 2–4 câu ngắn';
    }

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              sectionLabel,
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
            ),
            Text(
              'Bước ${_currentStep + 1}/$_totalSteps',
              style: const TextStyle(
                fontSize: 11.5,
                color: AppTheme.textSecondary,
              ),
            ),
          ],
        ),
        actions: <Widget>[
          Container(
            margin: const EdgeInsets.only(right: 14),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: AppTheme.bgCardElevated,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              _formattedTimer,
              style: const TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 13,
                color: AppTheme.cyanPrimary,
              ),
            ),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(6),
          child: LinearProgressIndicator(
            value: progress,
            minHeight: 6,
            backgroundColor: AppTheme.bgCard,
            valueColor:
                const AlwaysStoppedAnimation<Color>(AppTheme.cyanPrimary),
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              if (_currentStep < _questions.length)
                _buildMcqStep(_questions[_currentStep])
              else if (_currentStep == _dictationStepIndex)
                _buildDictationStep()
              else if (_currentStep == _speakingStepIndex)
                _buildRealSpeakingStep()
              else
                _buildRealWritingStep(),

              const SizedBox(height: 24),
              _buildExamBottomNav(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMcqStep(PlacementQuestion q) {
    final selectedIdx = _selectedAnswers[q.id];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: AppTheme.goldAccent.withValues(alpha: 0.16),
            borderRadius: BorderRadius.circular(999),
          ),
          child: Text(
            'Mức ${q.cefrDifficulty} • ${q.topicTag}',
            style: const TextStyle(
              color: AppTheme.goldAccent,
              fontWeight: FontWeight.w800,
              fontSize: 12,
            ),
          ),
        ),
        const SizedBox(height: 14),

        if (q.audioScript.isNotEmpty) ...<Widget>[
          ListenableBuilder(
            listenable: widget.viewModel.tts,
            builder: (context, _) {
              final isPlaying = widget.viewModel.tts.isSpeaking &&
                  widget.viewModel.tts.currentSpeakingId == q.id;
              return Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppTheme.bgCardElevated,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: AppTheme.cyanPrimary.withValues(alpha: 0.45),
                  ),
                ),
                child: Row(
                  children: <Widget>[
                    IconButton.filled(
                      onPressed: () =>
                          widget.viewModel.tts.speak(q.audioScript, id: q.id),
                      style: IconButton.styleFrom(
                        backgroundColor: AppTheme.cyanPrimary,
                        foregroundColor: const Color(0xFF04101E),
                      ),
                      icon: Icon(
                        isPlaying
                            ? Icons.stop_rounded
                            : Icons.volume_up_rounded,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        isPlaying ? 'Đang phát...' : 'Bấm loa để nghe',
                        style: const TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 14.5,
                        ),
                      ),
                    ),
                    TextButton(
                      onPressed: widget.viewModel.tts.cycleSpeed,
                      child: Text(
                        widget.viewModel.tts.speedLabel,
                        style: const TextStyle(
                          color: AppTheme.goldAccent,
                          fontWeight: FontWeight.w700,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
          const SizedBox(height: 16),
        ],

        if (q.readingContext.isNotEmpty) ...<Widget>[
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.bgSurface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppTheme.borderSubtle),
            ),
            child: Text(
              q.readingContext,
              style: const TextStyle(
                fontSize: 15,
                height: 1.55,
                color: AppTheme.textPrimary,
              ),
            ),
          ),
          const SizedBox(height: 16),
        ],

        Text(
          q.prompt,
          style: const TextStyle(
            fontSize: 16.5,
            fontWeight: FontWeight.w800,
            height: 1.4,
          ),
        ),
        const SizedBox(height: 14),

        ...List<Widget>.generate(q.options.length, (idx) {
          final isSelected = selectedIdx == idx;
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () => setState(() => _selectedAnswers[q.id] = idx),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: isSelected
                      ? AppTheme.cyanPrimary.withValues(alpha: 0.16)
                      : AppTheme.bgCard,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: isSelected
                        ? AppTheme.cyanPrimary
                        : AppTheme.borderSubtle,
                    width: isSelected ? 1.8 : 1,
                  ),
                ),
                child: Row(
                  children: <Widget>[
                    Container(
                      width: 28,
                      height: 28,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: isSelected
                            ? AppTheme.cyanPrimary
                            : AppTheme.bgSurface,
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        String.fromCharCode(65 + idx),
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          color: isSelected
                              ? const Color(0xFF04101E)
                              : AppTheme.textSecondary,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        q.options[idx],
                        style: const TextStyle(
                          fontSize: 14.5,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ],
    );
  }

  Widget _buildDictationStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        const Text(
          '🎧 Nghe và gõ lại câu ngắn',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 6),
        const Text(
          'Bấm loa nghe câu tiếng Anh đơn giản rồi gõ lại những từ bạn nghe được (không sao nếu thiếu từ).',
          style: TextStyle(fontSize: 13.5, color: AppTheme.textSecondary),
        ),
        const SizedBox(height: 16),
        ListenableBuilder(
          listenable: widget.viewModel.tts,
          builder: (context, _) {
            final isPlaying = widget.viewModel.tts.isSpeaking &&
                widget.viewModel.tts.currentSpeakingId == 'pt_dictation';
            return Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppTheme.bgCardElevated,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: AppTheme.cyanPrimary.withValues(alpha: 0.45),
                ),
              ),
              child: Row(
                children: <Widget>[
                  IconButton.filled(
                    onPressed: () => widget.viewModel.tts.speak(
                      CurriculumRepository.placementDictationAudio,
                      id: 'pt_dictation',
                    ),
                    style: IconButton.styleFrom(
                      backgroundColor: AppTheme.cyanPrimary,
                      foregroundColor: const Color(0xFF04101E),
                    ),
                    icon: Icon(
                      isPlaying
                          ? Icons.stop_rounded
                          : Icons.volume_up_rounded,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      isPlaying ? 'Đang đọc...' : 'Bấm để nghe câu ngắn',
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                  ),
                  TextButton(
                    onPressed: widget.viewModel.tts.cycleSpeed,
                    child: Text(widget.viewModel.tts.speedLabel),
                  ),
                ],
              ),
            );
          },
        ),
        const SizedBox(height: 14),
        TextField(
          controller: _dictationCtrl,
          minLines: 2,
          maxLines: 3,
          decoration: const InputDecoration(
            hintText: 'Gõ lại câu bạn nghe được...',
          ),
        ),
      ],
    );
  }

  Widget _buildRealSpeakingStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        const Text(
          '🎙️ Nói / Trả lời ngắn bằng tiếng Anh',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 6),
        const Text(
          'Bấm micro bàn phím để nói hoặc gõ câu trả lời ngắn (1–3 câu). Cứ nói thoải mái theo khả năng hiện tại!',
          style: TextStyle(fontSize: 13.5, color: AppTheme.textSecondary),
        ),
        const SizedBox(height: 16),
        const Text(
          '1. ${CurriculumRepository.placementSpeakingPrompt1}',
          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14.5),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _speakingIntroCtrl,
          minLines: 2,
          maxLines: 4,
          decoration: const InputDecoration(
            hintText: 'VD: Hi, my name is Minh. I am a student. I like music.',
          ),
        ),
        const SizedBox(height: 16),
        const Text(
          '2. ${CurriculumRepository.placementSpeakingPrompt2}',
          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14.5),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _speakingOpinionCtrl,
          minLines: 2,
          maxLines: 4,
          decoration: const InputDecoration(
            hintText: 'VD: On weekends, I usually sleep and hang out with friends.',
          ),
        ),
      ],
    );
  }

  Widget _buildRealWritingStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        const Text(
          '✍️ Bước cuối: Viết 2–5 câu tiếng Anh ngắn',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppTheme.bgCardElevated,
            borderRadius: BorderRadius.circular(16),
          ),
          child: const Text(
            CurriculumRepository.placementWritingPrompt,
            style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w700),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _writingEssayCtrl,
          minLines: 5,
          maxLines: 10,
          decoration: const InputDecoration(
            hintText:
                'VD: I am a student. I want to learn English to communicate with foreigners and find a good job...',
          ),
        ),
      ],
    );
  }

  Widget _buildExamBottomNav() {
    final isMcqStep = _currentStep < _questions.length;
    final canProceed = !isMcqStep ||
        _selectedAnswers.containsKey(_questions[_currentStep].id);
    final isLastStep = _currentStep == _writingStepIndex;

    return Row(
      children: <Widget>[
        if (_currentStep > 0)
          Expanded(
            child: OutlinedButton(
              onPressed: () {
                widget.viewModel.tts.stop();
                setState(() => _currentStep--);
              },
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              child: const Text('Quay lại'),
            ),
          ),
        if (_currentStep > 0) const SizedBox(width: 12),
        Expanded(
          flex: 2,
          child: ElevatedButton.icon(
            onPressed: !canProceed
                ? null
                : () {
                    if (!isLastStep) {
                      widget.viewModel.tts.stop();
                      setState(() => _currentStep++);
                    } else {
                      _submitFullExam();
                    }
                  },
            icon: Icon(
              isLastStep
                  ? Icons.auto_awesome_rounded
                  : Icons.arrow_forward_rounded,
            ),
            label: Text(
              isLastStep ? 'Nộp bài & Tạo Lộ Trình AI' : 'Tiếp theo →',
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildAiGradingScreen() {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const <Widget>[
              SizedBox(
                width: 64,
                height: 64,
                child: CircularProgressIndicator(
                  strokeWidth: 5,
                  color: AppTheme.cyanPrimary,
                ),
              ),
              SizedBox(height: 22),
              Text(
                'AI đang chấm bài & lập lộ trình cho bạn...',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
              ),
              SizedBox(height: 8),
              Text(
                'Đợi vài giây để nhận kết quả 4 kỹ năng và kế hoạch học từ dễ đến khó nhé!',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13.5, color: AppTheme.textSecondary),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildResultAndRoadmapView(PlacementTestResult result) {
    final user = widget.viewModel.state?.user;

    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: widget.isRetake,
        title: const Text(
          'Kết quả Test & Lộ trình của bạn',
          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              // 1. Score Banner
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: <Color>[Color(0xFF1E1B4B), Color(0xFF0F172A)],
                  ),
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(
                    color: AppTheme.cyanPrimary.withValues(alpha: 0.5),
                  ),
                ),
                child: Column(
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: <Widget>[
                        _ScoreStatBox(
                          label: 'Trình độ',
                          value: result.cefrLevel,
                          color: AppTheme.cyanPrimary,
                        ),
                        _ScoreStatBox(
                          label: 'IELTS ~',
                          value: result.estimatedIelts,
                          color: AppTheme.goldAccent,
                        ),
                        _ScoreStatBox(
                          label: 'TOEIC ~',
                          value: '${result.estimatedToeic}',
                          color: AppTheme.emeraldSuccess,
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Đúng ${result.objectiveCorrectCount}/${result.objectiveTotalCount} câu • Nghe chép: ${result.dictationAccuracyPercent}%',
                      style: const TextStyle(
                        fontSize: 12.5,
                        color: AppTheme.textSecondary,
                      ),
                    ),
                    const Divider(height: 22),
                    _SkillScoreBar(
                      label: '🎧 Nghe',
                      score: result.listeningScore,
                      color: AppTheme.cyanPrimary,
                      isWeakest: result.weakestSkill == SkillType.listening,
                    ),
                    const SizedBox(height: 8),
                    _SkillScoreBar(
                      label: '🎙️ Nói',
                      score: result.speakingScore,
                      color: AppTheme.goldAccent,
                      isWeakest: result.weakestSkill == SkillType.speaking,
                    ),
                    const SizedBox(height: 8),
                    _SkillScoreBar(
                      label: '📖 Đọc',
                      score: result.readingScore,
                      color: AppTheme.emeraldSuccess,
                      isWeakest: result.weakestSkill == SkillType.reading,
                    ),
                    const SizedBox(height: 8),
                    _SkillScoreBar(
                      label: '✍️ Viết',
                      score: result.writingScore,
                      color: AppTheme.violetAccent,
                      isWeakest: result.weakestSkill == SkillType.writing,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // 2. Concise AI Summary
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppTheme.bgCard,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: AppTheme.borderSubtle),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const Text(
                      '💡 Nhận xét từ AI',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 15,
                        color: AppTheme.cyanPrimary,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      result.aiDiagnosticSummary,
                      style: const TextStyle(fontSize: 13.5, height: 1.48),
                    ),
                    if (result.speakingFeedbackVi.isNotEmpty) ...<Widget>[
                      const SizedBox(height: 10),
                      Text(
                        '🎙️ Nói: ${result.speakingFeedbackVi}',
                        style: const TextStyle(
                          fontSize: 13,
                          color: AppTheme.textSecondary,
                        ),
                      ),
                    ],
                    if (result.writingFeedbackVi.isNotEmpty) ...<Widget>[
                      const SizedBox(height: 6),
                      Text(
                        '✍️ Viết: ${result.writingFeedbackVi}',
                        style: const TextStyle(
                          fontSize: 13,
                          color: AppTheme.textSecondary,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // 3. Daily Schedule
              if (result.dailySchedule.isNotEmpty) ...<Widget>[
                Text(
                  '⏱️ Lịch học gợi ý (${user?.dailyTargetMinutes ?? 30} phút/ngày)',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 8),
                ...result.dailySchedule.map(
                  (slot) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppTheme.bgCard,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: AppTheme.borderSubtle),
                      ),
                      child: Row(
                        children: <Widget>[
                          Container(
                            width: 48,
                            padding: const EdgeInsets.symmetric(vertical: 6),
                            decoration: BoxDecoration(
                              color:
                                  AppTheme.cyanPrimary.withValues(alpha: 0.14),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            alignment: Alignment.center,
                            child: Text(
                              '${slot.minutes}\'',
                              style: const TextStyle(
                                color: AppTheme.cyanPrimary,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  slot.activityTitle,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w800,
                                    fontSize: 13.5,
                                  ),
                                ),
                                Text(
                                  slot.detail,
                                  style: const TextStyle(
                                    fontSize: 12,
                                    color: AppTheme.textSecondary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
              ],

              // 4. 12-Week Roadmap
              const Text(
                '🗺️ Lộ trình 12 tuần (Dễ → Khó dần)',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 8),
              ...result.roadmapPhases.map(
                (phase) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: AppTheme.bgCard,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppTheme.borderSubtle),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          phase.weekRange,
                          style: const TextStyle(
                            color: AppTheme.cyanPrimary,
                            fontWeight: FontWeight.w800,
                            fontSize: 12,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          phase.title,
                          style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          phase.focusGoal,
                          style: const TextStyle(
                            fontSize: 12.5,
                            color: AppTheme.textSecondary,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          '🏁 ${phase.milestone}',
                          style: const TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w700,
                            color: AppTheme.emeraldSuccess,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              // 5. Optional Mistake Review
              if (result.mistakes.isNotEmpty) ...<Widget>[
                const SizedBox(height: 6),
                ExpansionTile(
                  tilePadding: const EdgeInsets.symmetric(horizontal: 14),
                  collapsedBackgroundColor: AppTheme.bgCard,
                  backgroundColor: AppTheme.bgCard,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                    side: const BorderSide(color: AppTheme.borderSubtle),
                  ),
                  collapsedShape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                    side: const BorderSide(color: AppTheme.borderSubtle),
                  ),
                  title: Text(
                    'Xem lại ${result.mistakes.length} câu làm sai',
                    style: const TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 14,
                      color: AppTheme.goldAccent,
                    ),
                  ),
                  children: result.mistakes
                      .map(
                        (m) => Padding(
                          padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
                          child: Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: AppTheme.bgSurface,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  m.topicTag,
                                  style: const TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w800,
                                    color: AppTheme.cyanPrimary,
                                  ),
                                ),
                                Text(
                                  'Đáp án đúng: ${m.correctAnswerText}',
                                  style: const TextStyle(
                                    fontSize: 12.5,
                                    color: AppTheme.emeraldSuccess,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                Text(
                                  m.explanationVi,
                                  style: const TextStyle(
                                    fontSize: 12,
                                    color: AppTheme.textSecondary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      )
                      .toList(),
                ),
              ],

              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton.icon(
                  onPressed: () {
                    widget.viewModel.completePlacementReview();
                    if (widget.isRetake && Navigator.of(context).canPop()) {
                      Navigator.of(context).pop();
                    }
                  },
                  icon: const Icon(Icons.rocket_launch_rounded),
                  label: const Text(
                    'Bắt đầu học theo Lộ trình ngay!',
                    style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w800),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SimpleBullet extends StatelessWidget {
  const _SimpleBullet({
    required this.icon,
    required this.color,
    required this.text,
  });

  final IconData icon;
  final Color color;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: <Widget>[
          Icon(icon, size: 18, color: color),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }
}

class _ScoreStatBox extends StatelessWidget {
  const _ScoreStatBox({
    required this.label,
    required this.value,
    required this.color,
  });

  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Text(
          value,
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.w900,
            color: color,
          ),
        ),
        Text(
          label,
          style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary),
        ),
      ],
    );
  }
}

class _SkillScoreBar extends StatelessWidget {
  const _SkillScoreBar({
    required this.label,
    required this.score,
    required this.color,
    this.isWeakest = false,
  });

  final String label;
  final int score;
  final Color color;
  final bool isWeakest;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Text(
              isWeakest ? '$label (Ưu tiên học trước)' : label,
              style: TextStyle(
                fontSize: 13,
                fontWeight: isWeakest ? FontWeight.w800 : FontWeight.w600,
                color: isWeakest ? AppTheme.coralDanger : AppTheme.textPrimary,
              ),
            ),
            Text(
              '$score/100',
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w800,
                color: color,
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        ClipRRect(
          borderRadius: BorderRadius.circular(999),
          child: LinearProgressIndicator(
            value: (score / 100).clamp(0.0, 1.0),
            minHeight: 7,
            backgroundColor: AppTheme.bgSurface,
            valueColor: AlwaysStoppedAnimation<Color>(color),
          ),
        ),
      ],
    );
  }
}
