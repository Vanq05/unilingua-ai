import 'dart:async';

import 'package:flutter/material.dart';

import '../../data/repositories/curriculum_repository.dart';
import '../../domain/models/learning_models.dart';
import '../theme/app_theme.dart';
import '../view_models/learning_view_model.dart';
import '../widgets/competency_overview_card.dart';

class PlacementTestScreen extends StatefulWidget {
  const PlacementTestScreen({
    super.key,
    required this.viewModel,
    this.isRetake = false,
  });

  final LearningViewModel viewModel;
  final bool isRetake;

  @override
  State<PlacementTestScreen> createState() => _PlacementTestScreenState();
}

class _PlacementTestScreenState extends State<PlacementTestScreen> {
  // 0..9: 10 unique randomized MCQs (A1 -> B1)
  // 10: Listening Dictation (NO mic, typing only)
  // 11: Speaking Step (Real Mic ONLY here!)
  // 12: Writing Step (NO mic, typing only!)
  static const int _dictationStepIndex = 10;
  static const int _speakingStepIndex = 11;
  static const int _writingStepIndex = 12;
  static const int _totalSteps = 13;

  bool _hasStarted = false;
  int _currentStep = 0;
  late PlacementExamSet _examSet;
  final Map<String, int> _selectedAnswers = <String, int>{};

  final TextEditingController _dictationCtrl = TextEditingController();
  final TextEditingController _speakingIntroCtrl = TextEditingController();
  final TextEditingController _speakingOpinionCtrl = TextEditingController();
  final TextEditingController _writingEssayCtrl = TextEditingController();

  PlacementTestResult? _completedResult;
  Timer? _examTimer;
  int _elapsedSeconds = 0;

  late int _selectedDailyMinutes;
  late int _selectedTargetWeeks;

  @override
  void initState() {
    super.initState();
    _examSet = widget.viewModel.createUniquePlacementExam();
    _selectedDailyMinutes =
        widget.viewModel.state?.user.dailyTargetMinutes ?? 30;
    _selectedTargetWeeks = widget.viewModel.state?.user.targetWeeks ?? 8;

    if (!widget.isRetake &&
        widget.viewModel.isReviewingPlacementResult &&
        widget.viewModel.state?.placementResult != null) {
      _completedResult = widget.viewModel.state!.placementResult;
    }

    _writingEssayCtrl.addListener(() {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _examTimer?.cancel();
    _dictationCtrl.dispose();
    _speakingIntroCtrl.dispose();
    _speakingOpinionCtrl.dispose();
    _writingEssayCtrl.dispose();
    super.dispose();
  }

  List<PlacementQuestion> get _questions => _examSet.questions;

  String get _formattedTimer {
    final m = (_elapsedSeconds ~/ 60).toString().padLeft(2, '0');
    final s = (_elapsedSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  Future<void> _startDiagnosticExam() async {
    await widget.viewModel.updateStudyPlan(
      dailyTargetMinutes: _selectedDailyMinutes,
      targetWeeks: _selectedTargetWeeks,
    );
    _examTimer?.cancel();
    _elapsedSeconds = 0;
    _examTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _elapsedSeconds++);
    });
    setState(() {
      // Generate a brand-new unique randomized exam every single time!
      _examSet = widget.viewModel.createUniquePlacementExam();
      _hasStarted = true;
      _currentStep = 0;
      _selectedAnswers.clear();
      _dictationCtrl.clear();
      _speakingIntroCtrl.clear();
      _speakingOpinionCtrl.clear();
      _writingEssayCtrl.clear();
      _completedResult = null;
    });
  }

  Future<void> _submitFullExam() async {
    _examTimer?.cancel();
    await widget.viewModel.tts.stop();
    await widget.viewModel.voiceRecorder.stopListening();

    final payload = PlacementSubmissionPayload(
      selectedAnswers: Map<String, int>.from(_selectedAnswers),
      listeningDictationInput: _dictationCtrl.text.trim(),
      speakingIntroAnswer: _speakingIntroCtrl.text.trim(),
      speakingOpinionAnswer: _speakingOpinionCtrl.text.trim(),
      writingEssayAnswer: _writingEssayCtrl.text.trim(),
      elapsedSeconds: _elapsedSeconds,
    );

    final result = await widget.viewModel.submitPlacementExam(
      payload,
      examSet: _examSet,
    );
    if (!mounted) return;
    setState(() {
      _completedResult = result;
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.viewModel,
      builder: (context, _) {
        if (widget.viewModel.isGradingPlacementExam) {
          return _buildAiGradingScreen();
        }
        final resultToShow = _completedResult ??
            (!widget.isRetake && widget.viewModel.isReviewingPlacementResult
                ? widget.viewModel.state?.placementResult
                : null);
        if (resultToShow != null) {
          return _buildResultAndRoadmapView(resultToShow);
        }
        if (!_hasStarted) {
          return _buildIntroView();
        }
        return _buildExamStepView();
      },
    );
  }

  Widget _buildIntroView() {
    final p = AppPalette.of(context);
    final user = widget.viewModel.state?.user;
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Kiểm tra Trình độ Đầu vào',
          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18),
        ),
        actions: <Widget>[
          if (widget.isRetake)
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Đóng'),
            ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: <Color>[p.heroStart, p.heroEnd],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'Chào ${user?.displayName ?? "bạn"}! 👋',
                      style: const TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Bài test nhanh 5 phút (mỗi lần 1 đề riêng, từ cơ bản A1 đến khó dần) để AI chấm năng lực và tạo lộ trình học phù hợp nhất cho bạn.',
                      style: TextStyle(
                        fontSize: 14,
                        height: 1.45,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 14),
                    const _WhiteBullet(text: '🎧 Nghe 3 câu ngắn + 1 câu chép'),
                    const _WhiteBullet(text: '📖 Đọc & Ngữ pháp 6 câu (A1 → B1)'),
                    const _WhiteBullet(text: '🎙️ Nói 1–2 câu & ✍️ Viết 2–5 câu'),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Text(
                'Bạn muốn học lộ trình trong mấy tuần?',
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  color: p.textPrimary,
                ),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 10,
                runSpacing: 8,
                children: CurriculumRepository.targetWeekOptions.map((weeks) {
                  final selected = _selectedTargetWeeks == weeks;
                  return ChoiceChip(
                    label: Text(
                      '$weeks tuần',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        color: selected ? Colors.white : p.textPrimary,
                      ),
                    ),
                    selected: selected,
                    selectedColor: p.primary,
                    onSelected: (_) =>
                        setState(() => _selectedTargetWeeks = weeks),
                  );
                }).toList(),
              ),
              const SizedBox(height: 16),
              Text(
                'Thời gian học mỗi ngày:',
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  color: p.textPrimary,
                ),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 10,
                runSpacing: 8,
                children: CurriculumRepository.dailyMinuteOptions.map((mins) {
                  final selected = _selectedDailyMinutes == mins;
                  return ChoiceChip(
                    label: Text(
                      '$mins phút / ngày',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        color: selected ? Colors.white : p.textPrimary,
                      ),
                    ),
                    selected: selected,
                    selectedColor: p.secondary,
                    onSelected: (_) =>
                        setState(() => _selectedDailyMinutes = mins),
                  );
                }).toList(),
              ),
              const SizedBox(height: 26),
              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton.icon(
                  onPressed: _startDiagnosticExam,
                  icon: const Icon(Icons.play_arrow_rounded, size: 24),
                  label: const Text(
                    'Bắt đầu Làm Bài Test',
                    style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w800),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildExamStepView() {
    final p = AppPalette.of(context);
    final progress = (_currentStep + 1) / _totalSteps;
    String sectionLabel;
    if (_currentStep < 3) {
      sectionLabel = 'Phần 1 • Nghe';
    } else if (_currentStep < 6) {
      sectionLabel = 'Phần 2 • Đọc hiểu';
    } else if (_currentStep < 9) {
      sectionLabel = 'Phần 3 • Ngữ pháp';
    } else if (_currentStep == 9) {
      sectionLabel = 'Phần 4 • Giao tiếp';
    } else if (_currentStep == _dictationStepIndex) {
      sectionLabel = 'Nghe & Gõ lại câu';
    } else if (_currentStep == _speakingStepIndex) {
      sectionLabel = 'Phần Nói (Dùng Mic)';
    } else {
      sectionLabel = 'Phần Viết (Gõ câu ngắn)';
    }

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              '$sectionLabel • Mã ${_examSet.examCode}',
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
            ),
            Text(
              'Bước ${_currentStep + 1}/$_totalSteps',
              style: TextStyle(fontSize: 11.5, color: p.textSecondary),
            ),
          ],
        ),
        actions: <Widget>[
          Container(
            margin: const EdgeInsets.only(right: 14),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: p.cardElevated,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              _formattedTimer,
              style: TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 13,
                color: p.primary,
              ),
            ),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(6),
          child: LinearProgressIndicator(
            value: progress,
            minHeight: 6,
            backgroundColor: p.cardElevated,
            valueColor: AlwaysStoppedAnimation<Color>(p.primary),
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              if (_currentStep < _questions.length)
                _buildMcqStep(_questions[_currentStep])
              else if (_currentStep == _dictationStepIndex)
                _buildDictationStep()
              else if (_currentStep == _speakingStepIndex)
                _buildRealSpeakingStep()
              else
                _buildRealWritingStep(),

              const SizedBox(height: 24),
              _buildExamBottomNav(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMcqStep(PlacementQuestion q) {
    final p = AppPalette.of(context);
    final selectedIdx = _selectedAnswers[q.id];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: p.primary.withValues(alpha: 0.14),
            borderRadius: BorderRadius.circular(999),
          ),
          child: Text(
            'Mức ${q.cefrDifficulty} • ${q.topicTag}',
            style: TextStyle(
              color: p.primary,
              fontWeight: FontWeight.w800,
              fontSize: 12,
            ),
          ),
        ),
        const SizedBox(height: 14),

        if (q.audioScript.isNotEmpty) ...<Widget>[
          ListenableBuilder(
            listenable: widget.viewModel.tts,
            builder: (context, _) {
              final isPlaying = widget.viewModel.tts.isSpeaking &&
                  widget.viewModel.tts.currentSpeakingId == q.id;
              return Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: p.card,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: p.primary.withValues(alpha: 0.4)),
                ),
                child: Row(
                  children: <Widget>[
                    IconButton.filled(
                      onPressed: () =>
                          widget.viewModel.tts.speak(q.audioScript, id: q.id),
                      style: IconButton.styleFrom(
                        backgroundColor: p.primary,
                        foregroundColor: Colors.white,
                      ),
                      icon: Icon(
                        isPlaying
                            ? Icons.stop_rounded
                            : Icons.volume_up_rounded,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        isPlaying ? 'Đang phát...' : 'Bấm loa để nghe',
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 14.5,
                          color: p.textPrimary,
                        ),
                      ),
                    ),
                    TextButton(
                      onPressed: widget.viewModel.tts.cycleSpeed,
                      child: Text(
                        widget.viewModel.tts.speedLabel,
                        style: TextStyle(
                          color: p.gold,
                          fontWeight: FontWeight.w700,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
          const SizedBox(height: 16),
        ],

        if (q.readingContext.isNotEmpty) ...<Widget>[
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: p.card,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: p.border),
            ),
            child: Text(
              q.readingContext,
              style: TextStyle(
                fontSize: 15,
                height: 1.55,
                color: p.textPrimary,
              ),
            ),
          ),
          const SizedBox(height: 16),
        ],

        Text(
          q.prompt,
          style: TextStyle(
            fontSize: 16.5,
            fontWeight: FontWeight.w800,
            height: 1.4,
            color: p.textPrimary,
          ),
        ),
        const SizedBox(height: 14),

        ...List<Widget>.generate(q.options.length, (idx) {
          final isSelected = selectedIdx == idx;
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () => setState(() => _selectedAnswers[q.id] = idx),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: isSelected
                      ? p.primary.withValues(alpha: 0.14)
                      : p.card,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: isSelected ? p.primary : p.border,
                    width: isSelected ? 1.8 : 1,
                  ),
                ),
                child: Row(
                  children: <Widget>[
                    Container(
                      width: 28,
                      height: 28,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: isSelected ? p.primary : p.cardElevated,
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        String.fromCharCode(65 + idx),
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          color: isSelected ? Colors.white : p.textSecondary,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        q.options[idx],
                        style: TextStyle(
                          fontSize: 14.5,
                          fontWeight: FontWeight.w600,
                          color: p.textPrimary,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ],
    );
  }

  Widget _buildDictationStep() {
    final p = AppPalette.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(
          '🎧 Nghe và gõ lại câu ngắn',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w900,
            color: p.textPrimary,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          'Bấm loa nghe rồi gõ lại những từ bạn nghe được.',
          style: TextStyle(fontSize: 13.5, color: p.textSecondary),
        ),
        const SizedBox(height: 16),
        ListenableBuilder(
          listenable: widget.viewModel.tts,
          builder: (context, _) {
            final isPlaying = widget.viewModel.tts.isSpeaking &&
                widget.viewModel.tts.currentSpeakingId == 'pt_dictation';
            return Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: p.card,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: p.primary.withValues(alpha: 0.45)),
              ),
              child: Row(
                children: <Widget>[
                  IconButton.filled(
                    onPressed: () => widget.viewModel.tts.speak(
                      _examSet.dictationAudio,
                      id: 'pt_dictation',
                    ),
                    style: IconButton.styleFrom(
                      backgroundColor: p.primary,
                      foregroundColor: Colors.white,
                    ),
                    icon: Icon(
                      isPlaying
                          ? Icons.stop_rounded
                          : Icons.volume_up_rounded,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      isPlaying ? 'Đang đọc...' : 'Bấm để nghe',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        color: p.textPrimary,
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: widget.viewModel.tts.cycleSpeed,
                    child: Text(widget.viewModel.tts.speedLabel),
                  ),
                ],
              ),
            );
          },
        ),
        const SizedBox(height: 14),
        TextField(
          controller: _dictationCtrl,
          minLines: 2,
          maxLines: 3,
          decoration: const InputDecoration(
            hintText: 'Gõ lại câu tiếng Anh bạn nghe được...',
          ),
        ),
      ],
    );
  }

  /// Speaking Step: Real Microphone enabled here ONLY (NOT on Writing!)
  Widget _buildRealSpeakingStep() {
    final p = AppPalette.of(context);
    return ListenableBuilder(
      listenable: widget.viewModel.voiceRecorder,
      builder: (context, _) {
        final isListening = widget.viewModel.voiceRecorder.isListening;
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              '🎙️ Nói ngắn bằng tiếng Anh',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w900,
                color: p.textPrimary,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'Bấm biểu tượng Mic để nói trực tiếp bằng tiếng Anh.',
              style: TextStyle(fontSize: 13, color: p.textSecondary),
            ),
            const SizedBox(height: 16),
            Text(
              '1. ${_examSet.speakingPrompt1}',
              style: TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 14.5,
                color: p.textPrimary,
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _speakingIntroCtrl,
              minLines: 2,
              maxLines: 4,
              decoration: InputDecoration(
                hintText: 'Bấm Mic để nói...',
                suffixIcon: IconButton(
                  onPressed: () async {
                    if (isListening) {
                      await widget.viewModel.voiceRecorder.stopListening();
                    } else {
                      await widget.viewModel.voiceRecorder.startListening(
                        onTranscript: (words, _) {
                          if (words.isNotEmpty) {
                            _speakingIntroCtrl.text = words;
                          }
                        },
                      );
                    }
                  },
                  icon: Icon(
                    isListening
                        ? Icons.stop_circle_rounded
                        : Icons.mic_rounded,
                    color: isListening ? p.danger : p.primary,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              '2. ${_examSet.speakingPrompt2}',
              style: TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 14.5,
                color: p.textPrimary,
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _speakingOpinionCtrl,
              minLines: 2,
              maxLines: 4,
              decoration: InputDecoration(
                hintText: 'Bấm Mic để nói...',
                suffixIcon: IconButton(
                  onPressed: () async {
                    if (isListening) {
                      await widget.viewModel.voiceRecorder.stopListening();
                    } else {
                      await widget.viewModel.voiceRecorder.startListening(
                        onTranscript: (words, _) {
                          if (words.isNotEmpty) {
                            _speakingOpinionCtrl.text = words;
                          }
                        },
                      );
                    }
                  },
                  icon: Icon(
                    isListening
                        ? Icons.stop_circle_rounded
                        : Icons.mic_rounded,
                    color: isListening ? p.danger : p.primary,
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  /// Writing Step: Typing ONLY (ZERO mic icon, ZERO examples!)
  Widget _buildRealWritingStep() {
    final p = AppPalette.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(
          '✍️ Bước cuối: Viết ngắn bằng tiếng Anh',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w900,
            color: p.textPrimary,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: p.card,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: p.border),
          ),
          child: Text(
            _examSet.writingPrompt,
            style: TextStyle(
              fontSize: 14.5,
              fontWeight: FontWeight.w700,
              color: p.textPrimary,
            ),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _writingEssayCtrl,
          minLines: 5,
          maxLines: 10,
          decoration: const InputDecoration(
            hintText: 'Viết câu trả lời tiếng Anh của bạn tại đây...',
          ),
        ),
      ],
    );
  }

  Widget _buildExamBottomNav() {
    final isMcqStep = _currentStep < _questions.length;
    final canProceed = !isMcqStep ||
        _selectedAnswers.containsKey(_questions[_currentStep].id);
    final isLastStep = _currentStep == _writingStepIndex;

    return Row(
      children: <Widget>[
        if (_currentStep > 0)
          Expanded(
            child: OutlinedButton(
              onPressed: () {
                widget.viewModel.tts.stop();
                widget.viewModel.voiceRecorder.stopListening();
                setState(() => _currentStep--);
              },
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: const Text('Quay lại'),
            ),
          ),
        if (_currentStep > 0) const SizedBox(width: 12),
        Expanded(
          flex: 2,
          child: ElevatedButton.icon(
            onPressed: !canProceed
                ? null
                : () {
                    if (!isLastStep) {
                      widget.viewModel.tts.stop();
                      widget.viewModel.voiceRecorder.stopListening();
                      setState(() => _currentStep++);
                    } else {
                      _submitFullExam();
                    }
                  },
            icon: Icon(
              isLastStep
                  ? Icons.auto_awesome_rounded
                  : Icons.arrow_forward_rounded,
            ),
            label: Text(
              isLastStep ? 'Nộp bài & Tạo Lộ Trình AI' : 'Tiếp theo →',
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildAiGradingScreen() {
    final p = AppPalette.of(context);
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              SizedBox(
                width: 64,
                height: 64,
                child: CircularProgressIndicator(
                  strokeWidth: 5,
                  color: p.primary,
                ),
              ),
              const SizedBox(height: 22),
              Text(
                'AI đang chấm bài & lập lộ trình...',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.w900,
                  color: p.textPrimary,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Đợi vài giây để xem biểu đồ Đánh giá Năng lực và lộ trình riêng cho bạn!',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13.5, color: p.textSecondary),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildResultAndRoadmapView(PlacementTestResult result) {
    final p = AppPalette.of(context);
    final user = widget.viewModel.state?.user;

    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: widget.isRetake,
        title: const Text(
          'Kết quả Test & Lộ trình của bạn',
          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              // 1. Beautiful Radar + Overall Ring Competency Card
              CompetencyOverviewCard(
                title: 'Đánh Giá Năng Lực Đầu Vào',
                listeningScore: result.listeningScore,
                speakingScore: result.speakingScore,
                readingScore: result.readingScore,
                writingScore: result.writingScore,
                cefrLevel: result.cefrLevel,
                estimatedIelts: result.estimatedIelts,
                estimatedToeic: result.estimatedToeic,
              ),
              const SizedBox(height: 16),

              // 2. Concise AI Summary
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: p.card,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: p.border),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      '💡 Nhận xét từ AI',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 15,
                        color: p.primary,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      result.aiDiagnosticSummary,
                      style: TextStyle(
                        fontSize: 13.5,
                        height: 1.48,
                        color: p.textPrimary,
                      ),
                    ),
                    if (result.speakingFeedbackVi.isNotEmpty) ...<Widget>[
                      const SizedBox(height: 8),
                      Text(
                        '🎙️ Nói: ${result.speakingFeedbackVi}',
                        style: TextStyle(
                          fontSize: 13,
                          color: p.textSecondary,
                        ),
                      ),
                    ],
                    if (result.writingFeedbackVi.isNotEmpty) ...<Widget>[
                      const SizedBox(height: 4),
                      Text(
                        '✍️ Viết: ${result.writingFeedbackVi}',
                        style: TextStyle(
                          fontSize: 13,
                          color: p.textSecondary,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // 3. Roadmap for chosen number of weeks
              Text(
                '🗺️ Lộ trình ${user?.targetWeeks ?? 8} tuần (${user?.dailyTargetMinutes ?? 30} phút/ngày)',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                  color: p.textPrimary,
                ),
              ),
              const SizedBox(height: 8),
              ...result.roadmapPhases.map(
                (phase) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: p.card,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: p.border),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          phase.weekRange,
                          style: TextStyle(
                            color: p.primary,
                            fontWeight: FontWeight.w800,
                            fontSize: 12,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          phase.title,
                          style: TextStyle(
                            fontSize: 14.5,
                            fontWeight: FontWeight.w800,
                            color: p.textPrimary,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          phase.focusGoal,
                          style: TextStyle(
                            fontSize: 12.5,
                            color: p.textSecondary,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          '🏁 ${phase.milestone}',
                          style: TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w700,
                            color: p.success,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              if (result.mistakes.isNotEmpty) ...<Widget>[
                const SizedBox(height: 6),
                ExpansionTile(
                  tilePadding: const EdgeInsets.symmetric(horizontal: 14),
                  collapsedBackgroundColor: p.card,
                  backgroundColor: p.card,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                    side: BorderSide(color: p.border),
                  ),
                  collapsedShape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                    side: BorderSide(color: p.border),
                  ),
                  title: Text(
                    'Xem lại ${result.mistakes.length} câu làm sai',
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 14,
                      color: p.gold,
                    ),
                  ),
                  children: result.mistakes
                      .map(
                        (m) => Padding(
                          padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
                          child: Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: p.cardElevated,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  m.topicTag,
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w800,
                                    color: p.primary,
                                  ),
                                ),
                                Text(
                                  'Đáp án đúng: ${m.correctAnswerText}',
                                  style: TextStyle(
                                    fontSize: 12.5,
                                    color: p.success,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                Text(
                                  m.explanationVi,
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: p.textSecondary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      )
                      .toList(),
                ),
              ],

              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton.icon(
                  onPressed: () {
                    widget.viewModel.completePlacementReview();
                    if (widget.isRetake && Navigator.of(context).canPop()) {
                      Navigator.of(context).pop();
                    }
                  },
                  icon: const Icon(Icons.rocket_launch_rounded),
                  label: const Text(
                    'Bắt đầu học theo Lộ trình ngay!',
                    style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w800),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _WhiteBullet extends StatelessWidget {
  const _WhiteBullet({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 5),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 13.5,
          fontWeight: FontWeight.w700,
          color: Colors.white,
        ),
      ),
    );
  }
}
