import 'package:flutter/material.dart';

import '../../../domain/models/learning_models.dart';
import '../../theme/app_theme.dart';
import '../../view_models/learning_view_model.dart';

class ReadingScreen extends StatefulWidget {
  const ReadingScreen({
    super.key,
    required this.viewModel,
  });

  final LearningViewModel viewModel;

  @override
  State<ReadingScreen> createState() => _ReadingScreenState();
}

class _ReadingScreenState extends State<ReadingScreen> {
  int _selectedPassageIndex = 0;
  bool _showBilingual = true;
  final Map<int, int> _quizAnswers = <int, int>{};

  Future<void> _showAiPassageDialog() async {
    final ctrl = TextEditingController(
      text: 'Renewable Energy & Smart Grid Economics',
    );
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.bgCard,
        title: const Text('✨ AI Tạo Bài Đọc Chuyên Ngành'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const Text(
              'Nhập chủ đề học thuật hoặc chuyên ngành đại học để AI biên soạn bài đọc song ngữ + từ vựng + câu hỏi:',
              style: TextStyle(fontSize: 13, color: AppTheme.textSecondary),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: ctrl,
              decoration: const InputDecoration(
                hintText: 'VD: Semiconductor Supply Chain, CRISPR Biology...',
              ),
            ),
          ],
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Hủy'),
          ),
          ElevatedButton.icon(
            onPressed: () async {
              final topic = ctrl.text.trim();
              Navigator.of(ctx).pop();
              if (topic.isEmpty) return;
              final created =
                  await widget.viewModel.generateAiReadingPassage(topic);
              if (!mounted) return;
              if (created != null) {
                setState(() {
                  _selectedPassageIndex = 0;
                  _quizAnswers.clear();
                });
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Đã tạo bài đọc AI: ${created.title}'),
                  ),
                );
              }
            },
            icon: const Icon(Icons.auto_awesome_rounded, size: 18),
            label: const Text('Tạo Bài Đọc'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.viewModel,
      builder: (context, _) {
        final passages = widget.viewModel.readingPassages;
        final safeIdx =
            _selectedPassageIndex.clamp(0, passages.length - 1);
        final passage = passages[safeIdx];

        return Scaffold(
          appBar: AppBar(
            title: const Text(
              '📖 Phòng Luyện Đọc (Academic Reading)',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17),
            ),
            actions: <Widget>[
              Padding(
                padding: const EdgeInsets.only(right: 12),
                child: TextButton.icon(
                  onPressed: widget.viewModel.isGeneratingAiContent
                      ? null
                      : _showAiPassageDialog,
                  icon: widget.viewModel.isGeneratingAiContent
                      ? const SizedBox(
                          width: 14,
                          height: 14,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(
                          Icons.auto_awesome_rounded,
                          color: AppTheme.goldAccent,
                          size: 18,
                        ),
                  label: const Text(
                    'AI Tạo Bài',
                    style: TextStyle(
                      color: AppTheme.goldAccent,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
            ],
          ),
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                // Passage Selector
                SizedBox(
                  height: 80,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: passages.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 10),
                    itemBuilder: (context, index) {
                      final item = passages[index];
                      final selected = index == safeIdx;
                      return InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: () => setState(() {
                          _selectedPassageIndex = index;
                          _quizAnswers.clear();
                        }),
                        child: Container(
                          width: 240,
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: selected
                                ? AppTheme.emeraldSuccess
                                    .withValues(alpha: 0.16)
                                : AppTheme.bgCard,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: selected
                                  ? AppTheme.emeraldSuccess
                                  : AppTheme.borderSubtle,
                              width: selected ? 1.6 : 1,
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                item.title,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontSize: 13.5,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '${item.cefrLevel} • ${item.majorTag}',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontSize: 11.5,
                                  color: AppTheme.textSecondary,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 16),

                // Article Reader Card
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: AppTheme.bgCard,
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: AppTheme.borderSubtle),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: AppTheme.emeraldSuccess
                                  .withValues(alpha: 0.15),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              'CEFR ${passage.cefrLevel} • ${passage.readingTimeLabel}',
                              style: const TextStyle(
                                color: AppTheme.emeraldSuccess,
                                fontWeight: FontWeight.w800,
                                fontSize: 12,
                              ),
                            ),
                          ),
                          const Spacer(),
                          Switch(
                            value: _showBilingual,
                            activeColor: AppTheme.cyanPrimary,
                            onChanged: (v) =>
                                setState(() => _showBilingual = v),
                          ),
                          const Text(
                            'Song ngữ',
                            style: TextStyle(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        passage.title,
                        style: const TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.w900,
                          height: 1.3,
                        ),
                      ),
                      const SizedBox(height: 14),
                      ...List<Widget>.generate(
                        passage.paragraphsEn.length,
                        (pIdx) {
                          final en = passage.paragraphsEn[pIdx];
                          final vi = pIdx < passage.paragraphsVi.length
                              ? passage.paragraphsVi[pIdx]
                              : '';
                          return Padding(
                            padding: const EdgeInsets.only(bottom: 14),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  en,
                                  style: const TextStyle(
                                    fontSize: 15,
                                    height: 1.6,
                                    color: AppTheme.textPrimary,
                                  ),
                                ),
                                if (_showBilingual && vi.isNotEmpty) ...<Widget>[
                                  const SizedBox(height: 6),
                                  Container(
                                    padding: const EdgeInsets.all(10),
                                    decoration: BoxDecoration(
                                      color: AppTheme.bgSurface,
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Text(
                                      vi,
                                      style: const TextStyle(
                                        fontSize: 13.5,
                                        height: 1.5,
                                        color: AppTheme.textSecondary,
                                        fontStyle: FontStyle.italic,
                                      ),
                                    ),
                                  ),
                                ],
                              ],
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),

                // Highlighted Academic Vocabulary
                const Text(
                  'Thuật ngữ Học thuật Trọng tâm (Bấm + lưu vào Sổ tay)',
                  style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 10),
                ...passage.highlights.map(
                  (v) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: AppTheme.bgCard,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: AppTheme.borderSubtle),
                      ),
                      child: Row(
                        children: <Widget>[
                          IconButton(
                            onPressed: () => widget.viewModel.tts.speak(
                              v.word,
                              id: 'rv_${v.word}',
                            ),
                            icon: const Icon(
                              Icons.volume_up_rounded,
                              color: AppTheme.cyanPrimary,
                            ),
                          ),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  '${v.word}  ${v.ipa} (${v.partOfSpeech})',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w800,
                                    fontSize: 14,
                                  ),
                                ),
                                Text(
                                  v.meaningVi,
                                  style: const TextStyle(
                                    color: AppTheme.goldAccent,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 13,
                                  ),
                                ),
                                Text(
                                  v.exampleEn,
                                  style: const TextStyle(
                                    fontSize: 12,
                                    color: AppTheme.textSecondary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          IconButton(
                            onPressed: () {
                              widget.viewModel.saveVocabFlashcard(v);
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                    'Đã lưu "${v.word}" vào Sổ tay Flashcard (+5 XP)',
                                  ),
                                ),
                              );
                            },
                            icon: const Icon(
                              Icons.bookmark_add_outlined,
                              color: AppTheme.emeraldSuccess,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 14),

                // Reading Comprehension Questions
                const Text(
                  'Kiểm tra Đọc hiểu Suy luận (Reading Comprehension)',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 10),
                ...List<Widget>.generate(passage.questions.length, (qIdx) {
                  final q = passage.questions[qIdx];
                  final selected = _quizAnswers[qIdx];

                  return Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppTheme.bgCard,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: AppTheme.borderSubtle),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Câu ${qIdx + 1}: ${q.question}',
                            style: const TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 14.5,
                            ),
                          ),
                          const SizedBox(height: 10),
                          ...List<Widget>.generate(q.options.length, (optIdx) {
                            final isChosen = selected == optIdx;
                            final isRight = optIdx == q.correctIndex;
                            Color border = AppTheme.borderSubtle;
                            if (selected != null) {
                              if (isRight) {
                                border = AppTheme.emeraldSuccess;
                              } else if (isChosen) {
                                border = AppTheme.coralDanger;
                              }
                            }
                            return Padding(
                              padding: const EdgeInsets.only(bottom: 8),
                              child: InkWell(
                                borderRadius: BorderRadius.circular(12),
                                onTap: () {
                                  setState(() => _quizAnswers[qIdx] = optIdx);
                                  if (_quizAnswers.length ==
                                      passage.questions.length) {
                                    widget.viewModel.recordActivityCompletion(
                                      questId: 'q_read',
                                      skill: SkillType.reading,
                                      baseXp: 35,
                                      lessonId: passage.id,
                                    );
                                  }
                                },
                                child: Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: AppTheme.bgSurface,
                                    borderRadius: BorderRadius.circular(12),
                                    border:
                                        Border.all(color: border, width: 1.4),
                                  ),
                                  child: Row(
                                    children: <Widget>[
                                      Text(
                                        '${String.fromCharCode(65 + optIdx)}. ',
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w800,
                                          color: AppTheme.emeraldSuccess,
                                        ),
                                      ),
                                      Expanded(
                                        child: Text(
                                          q.options[optIdx],
                                          style:
                                              const TextStyle(fontSize: 13.5),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          }),
                          if (selected != null) ...<Widget>[
                            const SizedBox(height: 6),
                            Text(
                              '💡 Giải thích: ${q.explanationVi}',
                              style: const TextStyle(
                                fontSize: 12.5,
                                color: AppTheme.goldAccent,
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  );
                }),
              ],
            ),
          ),
        );
      },
    );
  }
}
