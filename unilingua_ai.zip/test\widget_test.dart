import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:unilingua_ai/data/repositories/curriculum_repository.dart';
import 'package:unilingua_ai/data/services/ai_tutor_service.dart';
import 'package:unilingua_ai/data/services/app_update_service.dart';
import 'package:unilingua_ai/data/services/progress_storage_service.dart';
import 'package:unilingua_ai/data/services/secret_vault.dart';
import 'package:unilingua_ai/domain/models/learning_models.dart';
import 'package:unilingua_ai/main.dart';
import 'package:unilingua_ai/ui/view_models/learning_view_model.dart';

class _FakeProgressStorage extends ProgressStorageService {
  String? _activeEmail;
  final Map<String, StudentProgressState> _store =
      <String, StudentProgressState>{};
  final List<GoogleUserProfile> _accounts = <GoogleUserProfile>[];

  @override
  Future<String?> loadActiveEmail() async => _activeEmail;

  @override
  Future<void> saveActiveEmail(String? email) async {
    _activeEmail = email;
  }

  @override
  Future<List<GoogleUserProfile>> loadKnownGoogleAccounts() async => _accounts;

  @override
  Future<void> upsertKnownGoogleAccount(GoogleUserProfile profile) async {
    _accounts.removeWhere(
      (a) => a.email.toLowerCase() == profile.email.toLowerCase(),
    );
    _accounts.insert(0, profile);
  }

  @override
  Future<StudentProgressState?> loadProgressForEmail(String email) async =>
      _store[email.toLowerCase()];

  @override
  Future<void> saveProgress(StudentProgressState state) async {
    final key = state.user.email.toLowerCase();
    _store[key] = state;
    _activeEmail = key;
    await upsertKnownGoogleAccount(state.user);
  }
}

class _FakeAiTutorService extends AiTutorService {
  @override
  Future<void> ensureModelInitialized() async {}

  @override
  Future<String> completeText({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.65,
  }) async {
    return jsonEncode(<String, dynamic>{
      'speakingScore': 72,
      'writingScore': 70,
      'aiDiagnosticSummary':
          'Bạn có nền tảng cơ bản tốt, hãy bắt đầu từ giao tiếp hàng ngày.',
      'speakingFeedbackVi': 'Câu nói rõ ràng, tự tin.',
      'writingFeedbackVi': 'Viết đúng ý, ngắn gọn.',
      'keyStrengths': <String>['Đọc hiểu nhanh'],
      'criticalGaps': <String>['Phản xạ giao tiếp'],
      'roadmapPhases': CurriculumRepository.buildAdaptiveRoadmap(
        cefr: 'B1',
        dailyMinutes: 30,
        targetWeeks: 8,
        lScore: 75,
        sScore: 72,
        rScore: 80,
        wScore: 70,
      ).map((p) => p.toJson()).toList(),
    });
  }
}

class _FakeUpdateService extends AppUpdateService {
  const _FakeUpdateService();

  @override
  Future<AppUpdateInfo?> checkForUpdate() async => null;
}

void main() {
  test('SecretVault decodes hidden endpoint and API key accurately', () {
    expect(SecretVault.baseUrl.startsWith('https://'), isTrue);
    expect(SecretVault.apiKey.startsWith('sk-'), isTrue);
  });

  test('Week range builder adapts to 4, 8, 12, and 16 weeks', () {
    expect(CurriculumRepository.weekLabelsForTotal(4).first, equals('Tuần 1'));
    expect(CurriculumRepository.weekLabelsForTotal(8).last, equals('Tuần 7 - 8'));
    expect(CurriculumRepository.weekLabelsForTotal(12).last, equals('Tuần 10 - 12'));
    expect(CurriculumRepository.weekLabelsForTotal(16).last, equals('Tuần 13 - 16'));
  });

  testWidgets(
      '1-tap Google Sign-In -> Placement Test -> Competency Rings & Clean Checklist Home',
      (tester) async {
    final vm = LearningViewModel(
      storage: _FakeProgressStorage(),
      aiTutor: _FakeAiTutorService(),
      updateService: const _FakeUpdateService(),
    );
    await vm.initialize();

    await tester.pumpWidget(UniLinguaApp(viewModel: vm));
    await tester.pumpAndSettle();

    expect(find.text('Tiếp tục với Google'), findsOneWidget);

    await vm.signInWithGoogleProfile(
      const GoogleUserProfile(
        id: 'g_sv1',
        email: 'sv@gmail.com',
        displayName: 'Minh',
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('Kiểm tra Trình độ Đầu vào'), findsOneWidget);

    await vm.submitPlacementExam(
      PlacementSubmissionPayload(
        selectedAnswers: <String, int>{
          for (final q in CurriculumRepository.placementQuestions)
            q.id: q.correctIndex,
        },
        listeningDictationInput: CurriculumRepository.placementDictationAudio,
        speakingIntroAnswer: 'Hi, my name is Minh.',
        speakingOpinionAnswer: 'I study on weekends.',
        writingEssayAnswer: 'I want to learn English every day.',
      ),
    );
    await tester.pumpAndSettle();

    expect(vm.isReviewingPlacementResult, isTrue);
    expect(find.text('Kết quả Test & Lộ trình của bạn'), findsOneWidget);

    vm.completePlacementReview();
    await tester.pumpAndSettle();

    expect(find.text('Vòng Năng Lực Hiện Tại'), findsOneWidget);
    expect(find.text('✅ Việc hôm nay'), findsOneWidget);
  });
}
