import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:unilingua_ai/data/repositories/curriculum_repository.dart';
import 'package:unilingua_ai/data/services/ai_tutor_service.dart';
import 'package:unilingua_ai/data/services/app_update_service.dart';
import 'package:unilingua_ai/data/services/central_drive_server_service.dart';
import 'package:unilingua_ai/data/services/google_auth_service.dart';
import 'package:unilingua_ai/data/services/progress_storage_service.dart';
import 'package:unilingua_ai/data/services/secret_vault.dart';
import 'package:unilingua_ai/domain/models/learning_models.dart';
import 'package:unilingua_ai/main.dart';
import 'package:unilingua_ai/ui/view_models/learning_view_model.dart';

class _FakeProgressStorage extends ProgressStorageService {
  String? _activeEmail;
  bool _isDark = false;
  final Map<String, StudentProgressState> _store =
      <String, StudentProgressState>{};
  final List<GoogleUserProfile> _accounts = <GoogleUserProfile>[];

  @override
  Future<bool> loadIsDarkMode() async => _isDark;

  @override
  Future<void> saveIsDarkMode(bool isDark) async {
    _isDark = isDark;
  }

  @override
  Future<String?> loadActiveEmail() async => _activeEmail;

  @override
  Future<void> saveActiveEmail(String? email) async {
    _activeEmail = email;
  }

  @override
  Future<List<GoogleUserProfile>> loadKnownGoogleAccounts() async => _accounts;

  @override
  Future<void> upsertKnownGoogleAccount(GoogleUserProfile profile) async {
    _accounts.removeWhere(
      (a) => a.email.toLowerCase() == profile.email.toLowerCase(),
    );
    _accounts.insert(0, profile);
  }

  @override
  Future<StudentProgressState?> loadProgressForEmail(String email) async =>
      _store[email.toLowerCase()];

  @override
  Future<void> saveProgress(StudentProgressState state) async {
    final key = state.user.email.toLowerCase();
    _store[key] = state;
    _activeEmail = key;
    await upsertKnownGoogleAccount(state.user);
  }
}

class _FakeAiTutorService extends AiTutorService {
  @override
  Future<void> ensureModelInitialized() async {}

  @override
  Future<String> completeText({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.65,
  }) async {
    return jsonEncode(<String, dynamic>{
      'speakingScore': 72,
      'writingScore': 70,
      'aiDiagnosticSummary': 'Bạn có nền tảng cơ bản tốt.',
      'speakingFeedbackVi': 'Câu nói rõ ràng.',
      'writingFeedbackVi': 'Viết đúng ý.',
      'keyStrengths': <String>['Đọc hiểu nhanh'],
      'criticalGaps': <String>['Phản xạ giao tiếp'],
      'roadmapPhases': CurriculumRepository.buildAdaptiveRoadmap(
        cefr: 'B1',
        dailyMinutes: 30,
        targetWeeks: 8,
        lScore: 75,
        sScore: 72,
        rScore: 80,
        wScore: 70,
      ).map((p) => p.toJson()).toList(),
    });
  }
}

class _FakeUpdateService extends AppUpdateService {
  const _FakeUpdateService();

  @override
  Future<AppUpdateInfo?> checkForUpdate() async => null;
}

class _FakeCentralServer extends CentralDriveServerService {
  const _FakeCentralServer();

  @override
  bool get isConfigured => false;
}

class _FakeGoogleAuthService extends GoogleAuthService {
  @override
  Future<GoogleAuthResult?> signInSilently() async => null;

  @override
  Future<GoogleAuthResult> signInWithGoogle() async =>
      const GoogleAuthResult(errorReason: 'mock');

  @override
  Future<void> signOut() async {}
}

void main() {
  test('SecretVault decodes hidden endpoint, API key, and Drive Server URL', () {
    expect(SecretVault.baseUrl.startsWith('https://'), isTrue);
    expect(SecretVault.apiKey.startsWith('sk-'), isTrue);
    expect(
      SecretVault.driveServerUrl.startsWith('https://script.google.com/macros/s/'),
      isTrue,
    );
  });

  test('Unique Placement Exam generator creates randomized sets across seeds', () {
    final exam1 = CurriculumRepository.generateUniquePlacementExam(seed: 101);
    final exam2 = CurriculumRepository.generateUniquePlacementExam(seed: 999);
    expect(exam1.questions.length, equals(10));
    expect(exam2.questions.length, equals(10));
    expect(exam1.examCode != exam2.examCode, isTrue);
  });

  testWidgets(
      'Fresh Sky-Blue Light Mode default -> Google Sign-In -> Unique Placement Test -> Radar Competency Home',
      (tester) async {
    final vm = LearningViewModel(
      storage: _FakeProgressStorage(),
      googleAuth: _FakeGoogleAuthService(),
      centralServer: const _FakeCentralServer(),
      aiTutor: _FakeAiTutorService(),
      updateService: const _FakeUpdateService(),
    );
    await vm.initialize();

    expect(vm.isDarkMode, isFalse);

    await tester.pumpWidget(UniLinguaApp(viewModel: vm));
    await tester.pumpAndSettle();

    expect(find.text('Đăng nhập bằng Google'), findsOneWidget);

    await vm.signInWithGoogleProfile(
      const GoogleUserProfile(
        id: 'g_sv1',
        email: 'sv@gmail.com',
        displayName: 'Minh',
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('Kiểm tra Trình độ Đầu vào'), findsOneWidget);

    final exam = vm.createUniquePlacementExam();
    await vm.submitPlacementExam(
      PlacementSubmissionPayload(
        selectedAnswers: <String, int>{
          for (final q in exam.questions) q.id: q.correctIndex,
        },
        listeningDictationInput: exam.dictationAudio,
        speakingIntroAnswer: 'Hi, my name is Minh.',
        speakingOpinionAnswer: 'I study on weekends.',
        writingEssayAnswer: 'I want to learn English every day.',
      ),
      examSet: exam,
    );
    await tester.pumpAndSettle();

    expect(vm.isReviewingPlacementResult, isTrue);
    expect(find.text('Kết quả Test & Lộ trình của bạn'), findsOneWidget);

    vm.completePlacementReview();
    await tester.pumpAndSettle();

    expect(find.text('Đánh Giá Năng Lực Bản Thân'), findsOneWidget);
    expect(find.text('✅ Việc hôm nay'), findsOneWidget);

    // Toggle Dark Mode cleanly
    await vm.setDarkMode(true);
    await tester.pumpAndSettle();
    expect(vm.isDarkMode, isTrue);
  });
}
