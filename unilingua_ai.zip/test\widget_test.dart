import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:unilingua_ai/data/repositories/curriculum_repository.dart';
import 'package:unilingua_ai/data/services/ai_tutor_service.dart';
import 'package:unilingua_ai/data/services/app_update_service.dart';
import 'package:unilingua_ai/data/services/central_drive_server_service.dart';
import 'package:unilingua_ai/data/services/google_auth_service.dart';
import 'package:unilingua_ai/data/services/progress_storage_service.dart';
import 'package:unilingua_ai/data/services/secret_vault.dart';
import 'package:unilingua_ai/data/services/voice_recorder_service.dart';
import 'package:unilingua_ai/domain/models/learning_models.dart';
import 'package:unilingua_ai/main.dart';
import 'package:unilingua_ai/ui/view_models/learning_view_model.dart';

class _FakeProgressStorage extends ProgressStorageService {
  String? _activeEmail;
  bool _isDark = false;
  final Map<String, StudentProgressState> _store =
      <String, StudentProgressState>{};
  final List<GoogleUserProfile> _accounts = <GoogleUserProfile>[];

  @override
  Future<bool> loadIsDarkMode() async => _isDark;

  @override
  Future<void> saveIsDarkMode(bool isDark) async {
    _isDark = isDark;
  }

  @override
  Future<String?> loadActiveEmail() async => _activeEmail;

  @override
  Future<void> saveActiveEmail(String? email) async {
    _activeEmail = email;
  }

  @override
  Future<List<GoogleUserProfile>> loadKnownGoogleAccounts() async => _accounts;

  @override
  Future<void> upsertKnownGoogleAccount(GoogleUserProfile profile) async {
    _accounts.removeWhere(
      (a) => a.email.toLowerCase() == profile.email.toLowerCase(),
    );
    _accounts.insert(0, profile);
  }

  @override
  Future<StudentProgressState?> loadProgressForEmail(String email) async =>
      _store[email.toLowerCase()];

  @override
  Future<void> saveProgress(StudentProgressState state) async {
    final key = state.user.email.toLowerCase();
    _store[key] = state;
    _activeEmail = key;
    await upsertKnownGoogleAccount(state.user);
  }
}

class _FakeAiTutorService extends AiTutorService {
  @override
  Future<void> ensureModelInitialized() async {}

  @override
  Future<String> completeText({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.65,
  }) async {
    return jsonEncode(<String, dynamic>{
      'speakingScore': 72,
      'writingScore': 70,
      'aiDiagnosticSummary': 'Bạn có nền tảng cơ bản tốt.',
      'speakingFeedbackVi': 'Câu nói rõ ràng.',
      'writingFeedbackVi': 'Viết đúng ý.',
      'keyStrengths': <String>['Đọc hiểu nhanh'],
      'criticalGaps': <String>['Phản xạ giao tiếp'],
      'roadmapPhases': CurriculumRepository.buildAdaptiveRoadmap(
        cefr: 'B1',
        dailyMinutes: 30,
        targetWeeks: 8,
        lScore: 75,
        sScore: 72,
        rScore: 80,
        wScore: 70,
      ).map((p) => p.toJson()).toList(),
    });
  }
}

class _FakeUpdateService extends AppUpdateService {
  const _FakeUpdateService();

  @override
  Future<AppUpdateInfo?> checkForUpdate() async => null;
}

class _FakeCentralServer extends CentralDriveServerService {
  const _FakeCentralServer();

  @override
  bool get isConfigured => false;
}

class _FakeGoogleAuthService extends GoogleAuthService {
  @override
  Future<GoogleAuthResult?> signInSilently() async => null;

  @override
  Future<GoogleAuthResult> signInWithGoogle() async =>
      const GoogleAuthResult(errorReason: 'mock');

  @override
  Future<void> signOut() async {}
}

void main() {
  test('SecretVault decodes hidden endpoint, API key, and Drive Server URL', () {
    expect(SecretVault.baseUrl.startsWith('https://'), isTrue);
    expect(SecretVault.apiKey.startsWith('sk-'), isTrue);
    expect(
      SecretVault.driveServerUrl.startsWith('https://script.google.com/macros/s/'),
      isTrue,
    );
  });

  test('CentralDriveServerService SHA-256 salted digest matches GAS & FIPS 180-4', () {
    expect(
      CentralDriveServerService.sha256Hex('abc'),
      equals('ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'),
    );
    expect(
      CentralDriveServerService.hashPasswordSha256('123456'),
      equals('cff891c12c0b8c71732c1ba4d41e59608aa323ce8dc0a01b85f88dcb7e1d6257'),
    );
  });

  test('VoiceRecorderService normalizes Vietnamese proper names and places', () {
    expect(
      VoiceRecorderService.normalizeVietnameseProperNouns(
        'ten van',
        userDisplayName: 'Vang',
      ),
      equals('my name is Vang'),
    );
    expect(
      VoiceRecorderService.normalizeVietnameseProperNouns(
        'Hello my name is van and I am from tynguah',
        userDisplayName: 'Vang',
      ),
      equals('Hello my name is Vang and I am from Thai Nguyen'),
    );
  });

  test('Tailored Placement Exam generator creates unique non-repeating English exams', () {
    final examBeg = CurriculumRepository.generateUniquePlacementExam(
      seed: 101,
      selfAssessedLevel: GoogleUserProfile.levelBeginner,
      age: 19,
    );
    final examAdv = CurriculumRepository.generateUniquePlacementExam(
      seed: 202,
      selfAssessedLevel: GoogleUserProfile.levelAdvanced,
      age: 25,
    );

    expect(examBeg.questions.length, equals(10));
    expect(examAdv.questions.length, equals(10));
    expect(examBeg.questions.map((q) => q.id).toSet().length, equals(10));
    expect(examAdv.questions.map((q) => q.id).toSet().length, equals(10));
    expect(examBeg.questions.every((q) => q.promptVi.isNotEmpty), isTrue);
    expect(examBeg.examCode != examAdv.examCode, isTrue);
  });

  testWidgets(
      'SHA-256 Register -> Profile Setup -> Tailored Placement -> 5-Tab Shell -> Change Password -> Forgot Password OTP',
      (tester) async {
    tester.view.physicalSize = const Size(1080, 2400);
    tester.view.devicePixelRatio = 2.0;
    addTearDown(tester.view.reset);

    final vm = LearningViewModel(
      storage: _FakeProgressStorage(),
      googleAuth: _FakeGoogleAuthService(),
      centralServer: const _FakeCentralServer(),
      aiTutor: _FakeAiTutorService(),
      updateService: const _FakeUpdateService(),
      enableAutoSyncTimer: false,
    );
    await vm.initialize();

    await tester.pumpWidget(UniLinguaApp(viewModel: vm));
    await tester.pumpAndSettle();

    // 1. Register Screen with FullName, Email & SHA-256 Password
    expect(find.text('Đăng nhập bằng Tài khoản'), findsOneWidget);
    await tester.tap(find.text('Đăng ký mới'));
    await tester.pumpAndSettle();

    await tester.enterText(
      find.byKey(const Key('auth_fullname_field')),
      'Vũ Hồng Vang',
    );
    await tester.enterText(
      find.byKey(const Key('auth_username_field')),
      'vang@gmail.com',
    );
    await tester.enterText(
      find.byKey(const Key('auth_password_field')),
      '123456',
    );
    await tester.tap(find.byKey(const Key('auth_submit_button')));
    await tester.pumpAndSettle();

    // Verify password was stored as SHA-256 hash, NOT plain text
    expect(
      vm.state!.user.passwordHash,
      equals('cff891c12c0b8c71732c1ba4d41e59608aa323ce8dc0a01b85f88dcb7e1d6257'),
    );

    // 2. Initial Profile Setup (Name, Age, Level)
    expect(find.text('Thiết lập Hồ sơ Ban đầu'), findsOneWidget);
    await tester.enterText(find.byKey(const Key('profile_name_field')), 'Vang');
    await tester.enterText(find.byKey(const Key('profile_age_field')), '21');
    await tester.tap(find.text(GoogleUserProfile.levelBasic));
    await tester.pumpAndSettle();

    await tester.ensureVisible(find.byKey(const Key('profile_setup_continue_btn')));
    await tester.tap(find.byKey(const Key('profile_setup_continue_btn')));
    await tester.pumpAndSettle();

    // 3. Tailored Placement Test
    expect(find.text('Kiểm tra Trình độ Đầu vào'), findsOneWidget);

    final exam = vm.createUniquePlacementExam();
    await vm.submitPlacementExam(
      PlacementSubmissionPayload(
        selectedAnswers: <String, int>{
          for (final q in exam.questions) q.id: q.correctIndex,
        },
        listeningDictationInput: exam.dictationAudio,
        speakingIntroAnswer: 'My name is Vang from Thai Nguyen.',
        speakingOpinionAnswer: 'I study on weekends.',
        writingEssayAnswer: 'I want to improve my speaking fluency.',
      ),
      examSet: exam,
    );
    await tester.pumpAndSettle();

    vm.completePlacementReview();
    await tester.pumpAndSettle();

    // 4. Profile Tab: check Role badge & open Change Password screen
    await tester.tap(find.text('Profile'));
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('profile_drive_sync_card')), findsOneWidget);
    expect(find.text('Role: USER'), findsOneWidget);

    final changePwdTile = find.byKey(const Key('profile_change_password_tile'));
    await tester.ensureVisible(changePwdTile);
    await tester.pumpAndSettle();
    await tester.tap(changePwdTile);
    await tester.pumpAndSettle();

    expect(find.text('Cập nhật mật khẩu'), findsOneWidget);
    await tester.enterText(find.byKey(const Key('old_password_field')), '123456');
    await tester.enterText(find.byKey(const Key('new_password_field')), '654321');
    await tester.enterText(find.byKey(const Key('confirm_password_field')), '654321');
    await tester.tap(find.byKey(const Key('change_password_submit_btn')));
    await tester.pumpAndSettle();

    expect(
      vm.state!.user.passwordHash,
      equals(CentralDriveServerService.hashPasswordSha256('654321')),
    );
    expect(find.textContaining('Đổi mật khẩu thành công'), findsOneWidget);
    await tester.pump(const Duration(seconds: 5));
    await tester.pumpAndSettle();

    // 5. Bài tập -> Translate toggle -> Lesson 1 Exit to Home
    await tester.tap(find.text('Bài tập'));
    await tester.pumpAndSettle();
    final translateBtn = find.text('Dịch sang tiếng Việt').first;
    await tester.ensureVisible(translateBtn);
    await tester.pumpAndSettle();
    await tester.tap(translateBtn);
    await tester.pumpAndSettle();
    expect(find.textContaining('🇻🇳'), findsWidgets);

    final areOption = find.text('are').first;
    await tester.ensureVisible(areOption);
    await tester.pumpAndSettle();
    await tester.tap(areOption);
    await tester.pumpAndSettle();

    final submitBtn = find.byKey(const Key('daily_quiz_submit_btn'));
    await tester.ensureVisible(submitBtn);
    await tester.pumpAndSettle();
    await tester.tap(submitBtn);
    await tester.pumpAndSettle();

    expect(find.text('Tiếp tục câu khác'), findsOneWidget);
    expect(find.text('Hoàn thành & Rời đi'), findsOneWidget);

    final exitBtn = find.text('Hoàn thành & Rời đi');
    await tester.ensureVisible(exitBtn);
    await tester.pumpAndSettle();
    await tester.tap(exitBtn);
    await tester.pumpAndSettle();

    expect(find.text('Đánh Giá Năng Lực Bản Thân'), findsOneWidget);

    // 6. Test Forgot Password 2-Step OTP Flow via ViewModel
    final otpRes = await vm.requestPasswordResetOtp(email: 'vang@gmail.com');
    expect(otpRes.ok, isTrue);
    expect(otpRes.fallbackOtp, isNotNull);
    final resetRes = await vm.resetPasswordWithOtp(
      email: 'vang@gmail.com',
      otp: otpRes.fallbackOtp!,
      newPassword: 'newpass999',
    );
    expect(resetRes.ok, isTrue);
  });
}
