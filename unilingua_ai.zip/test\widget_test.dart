import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:unilingua_ai/data/repositories/curriculum_repository.dart';
import 'package:unilingua_ai/data/services/ai_tutor_service.dart';
import 'package:unilingua_ai/data/services/progress_storage_service.dart';
import 'package:unilingua_ai/data/services/secret_vault.dart';
import 'package:unilingua_ai/domain/models/learning_models.dart';
import 'package:unilingua_ai/main.dart';
import 'package:unilingua_ai/ui/view_models/learning_view_model.dart';

class _FakeProgressStorage extends ProgressStorageService {
  String? _activeEmail;
  final Map<String, StudentProgressState> _store =
      <String, StudentProgressState>{};
  final List<GoogleUserProfile> _accounts = <GoogleUserProfile>[];

  @override
  Future<String?> loadActiveEmail() async => _activeEmail;

  @override
  Future<void> saveActiveEmail(String? email) async {
    _activeEmail = email;
  }

  @override
  Future<List<GoogleUserProfile>> loadKnownGoogleAccounts() async => _accounts;

  @override
  Future<void> upsertKnownGoogleAccount(GoogleUserProfile profile) async {
    _accounts.removeWhere(
      (a) => a.email.toLowerCase() == profile.email.toLowerCase(),
    );
    _accounts.insert(0, profile);
  }

  @override
  Future<StudentProgressState?> loadProgressForEmail(String email) async =>
      _store[email.toLowerCase()];

  @override
  Future<void> saveProgress(StudentProgressState state) async {
    final key = state.user.email.toLowerCase();
    _store[key] = state;
    _activeEmail = key;
    await upsertKnownGoogleAccount(state.user);
  }
}

class _FakeAiTutorService extends AiTutorService {
  @override
  Future<void> ensureModelInitialized() async {}

  @override
  Future<String> completeText({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.65,
  }) async {
    return jsonEncode(<String, dynamic>{
      'speakingScore': 78,
      'writingScore': 74,
      'aiDiagnosticSummary':
          'Báo cáo chẩn đoán AI: Trình độ B2 vững vàng, cần đẩy mạnh kỹ năng viết học thuật.',
      'speakingFeedbackVi': 'Phản xạ nói tự nhiên, rõ ý.',
      'writingFeedbackVi': 'Bố cục rõ ràng, nên bổ sung thêm collocations C1.',
      'keyStrengths': <String>['Đọc hiểu nhanh', 'Tư duy phản biện tốt'],
      'criticalGaps': <String>['Đảo ngữ C1', 'Collocations Writing'],
      'roadmapPhases': CurriculumRepository.buildAdaptiveRoadmap(
        cefr: 'B2',
        academicYear: 'Sinh viên Năm 3',
        major: 'CNTT & Khoa học Máy tính',
        goal: 'IELTS 6.5+',
        dailyMinutes: 30,
        lScore: 80,
        sScore: 78,
        rScore: 82,
        wScore: 74,
      ).map((p) => p.toJson()).toList(),
    });
  }
}

void main() {
  test('SecretVault decodes hidden endpoint and API key accurately', () {
    expect(SecretVault.baseUrl.startsWith('https://'), isTrue);
    expect(SecretVault.apiKey.startsWith('sk-'), isTrue);
  });

  test(
      '5-Section University Placement Exam evaluator computes CEFR, IELTS, TOEIC, daily schedule, mistakes and 12-week roadmap',
      () {
    const profile = GoogleUserProfile(
      id: 'g_1',
      email: 'student@gmail.com',
      displayName: 'Minh Anh',
      academicYear: 'Sinh viên Năm 3 (Chuyên ngành & Thực tập)',
      majorField: 'CNTT & Khoa học Máy tính',
      targetGoal: 'Đạt chuẩn đầu ra IELTS 6.5+ / B2 Đại học',
      dailyTargetMinutes: 45,
    );

    final allCorrect = <String, int>{
      for (final q in CurriculumRepository.placementQuestions)
        q.id: q.correctIndex,
    };

    final submission = PlacementSubmissionPayload(
      selectedAnswers: allCorrect,
      listeningDictationInput: CurriculumRepository.placementDictationAudio,
      speakingIntroAnswer:
          'I am a third-year university student majoring in Computer Science. I want to improve my academic speaking skills before graduation.',
      speakingOpinionAnswer:
          'I strongly believe core university courses should incorporate English because global research papers and engineering documentation are written in English.',
      writingEssayAnswer:
          'While some educators worry that artificial intelligence could reduce independent thinking, I firmly believe its benefits outweigh the drawbacks for university students. Consequently, universities should teach critical verification rather than banning AI tools completely.',
    );

    final result = CurriculumRepository.evaluatePlacementSubmission(
      submission: submission,
      user: profile,
    );

    expect(result.objectiveCorrectCount,
        equals(CurriculumRepository.placementQuestions.length));
    expect(result.dictationAccuracyPercent, equals(100));
    expect(result.mistakes, isEmpty);
    expect(result.dailySchedule.length, equals(4));
    expect(result.roadmapPhases.length, equals(4));
    expect(result.cefrLevel, anyOf(equals('B2'), equals('C1')));
  });

  testWidgets(
      'New Google account -> mandatory Placement Exam -> stays on Diagnostic Report -> enters Home Dashboard',
      (tester) async {
    final vm = LearningViewModel(
      storage: _FakeProgressStorage(),
      aiTutor: _FakeAiTutorService(),
    );
    await vm.initialize();

    await tester.pumpWidget(UniLinguaApp(viewModel: vm));
    await tester.pumpAndSettle();

    expect(find.text('UniLingua AI'), findsOneWidget);

    await vm.signInWithGoogleProfile(
      const GoogleUserProfile(
        id: 'g_sv1',
        email: 'sv@gmail.com',
        displayName: 'Sinh viên Bách Khoa',
      ),
    );
    await tester.pumpAndSettle();

    // Immediately goes to mandatory 5-section Placement Exam
    expect(find.text('Bài Test Đầu Vào Đại Học'), findsOneWidget);

    // Submit Placement Exam -> should remain on Diagnostic Report & Roadmap screen
    await vm.submitPlacementExam(
      PlacementSubmissionPayload(
        selectedAnswers: <String, int>{
          for (final q in CurriculumRepository.placementQuestions)
            q.id: q.correctIndex,
        },
        listeningDictationInput: CurriculumRepository.placementDictationAudio,
        speakingIntroAnswer: 'Hello, I am a university student.',
        speakingOpinionAnswer: 'Yes, English is important for university.',
        writingEssayAnswer:
            'Artificial intelligence helps university students learn faster, however we must verify all sources carefully.',
      ),
    );
    await tester.pumpAndSettle();

    expect(vm.isReviewingPlacementResult, isTrue);
    expect(
      find.text('Báo Cáo Chẩn Đoán & Lộ Trình AI 12 Tuần'),
      findsOneWidget,
    );

    // Confirm roadmap -> enters Home Dashboard
    vm.completePlacementReview();
    await tester.pumpAndSettle();

    expect(find.text('Mục Tiêu Bài Tập Hôm Nay'), findsOneWidget);
  });
}
