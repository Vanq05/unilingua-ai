# UniLingua AI — Ứng dụng Học Tiếng Anh Đại Học 4 Kỹ Năng (Android `.apk` & iOS `.ipa`)

Ứng dụng học tiếng Anh toàn diện **Nghe • Nói • Đọc • Viết** tích hợp AI Tutor dành riêng cho **Sinh viên Đại học**:

## ✨ Tính năng nổi bật
1. **Bảo mật API ẩn tuyệt đối & Không hiện bộ đếm Token (`SecretVault`)**:
   - Kết nối trực tiếp tới hệ thống AI qua `SecretVault` được mã hóa byte XOR (`lib/data/services/secret_vault.dart`).
   - Không hiển thị API Key, Base URL hay số lượng token đã sử dụng ở bất kỳ đâu trên giao diện.
2. **Đăng nhập bằng Google & Đồng bộ tiến trình (`GoogleAuthScreen`)**:
   - Đăng nhập bằng tài khoản Google (`@gmail.com` / `@edu.vn`) để lưu tiến trình học tập riêng biệt cho từng tài khoản (Điểm test đầu vào, Lộ trình 12 tuần, Chuỗi ngày học Streak 🔥, XP, Sổ tay từ vựng Flashcard).
   - Hỗ trợ xuất/nhập **Mã Đồng Bộ Đám Mây** để chuyển tiến trình qua thiết bị khác.
3. **Bài Test Đầu Vào Đại Học 4 Kỹ Năng & Lộ Trình AI 12 Tuần (`PlacementTestScreen`)**:
   - 12 câu hỏi chẩn đoán phân hóa từ **A2 đến C1** bao phủ cả **Nghe (có Audio bài giảng TTS), Nói & Trọng âm, Đọc học thuật, Viết & Ngữ pháp C1**.
   - Chấm điểm từng kỹ năng, quy đổi chuẩn **CEFR (A2–C1), IELTS (4.0–7.5+) & TOEIC (450–900)** và dùng AI thiết kế **Lộ trình học tập 12 tuần (4 giai đoạn)** theo đúng chuyên ngành đại học của sinh viên.
4. **Hệ thống Bài Tập Hàng Ngày (`Daily Quests & Daily Workout`)**:
   - Tự động làm mới 5 nhiệm vụ mỗi ngày (Nghe, Nói, Đọc, Viết, Bài tập Tổng hợp 5 câu) + nút **✨ AI Tạo Đề Bài Tập Mới** không giới hạn.
5. **Đầy đủ 4 Phòng Luyện Kỹ Năng Chuyên Sâu**:
   - 🎧 **Phòng Luyện Nghe (Listening Lab)**: Nghe bài giảng đại học với tốc độ `0.75x / 1.0x / 1.25x`, ẩn/hiện Transcript song ngữ, luyện **Nghe chép chính tả (Dictation)**, trả lời câu hỏi trắc nghiệm và **✨ AI tạo bài nghe mới theo chủ đề bất kỳ**.
   - 🎙️ **Phòng Luyện Nói (Speaking Studio)**:
     - **Hội thoại AI 1-1 (Roleplay)**: Đóng vai phỏng vấn thực tập tập đoàn đa quốc gia (MNC), phòng thi IELTS Speaking Part 2 & 3, hoặc bảo vệ khóa luận tốt nghiệp bằng tiếng Anh (có phát âm giọng nói AI & gợi ý nâng cấp câu nói *Better Phrasing* sau mỗi lượt).
     - **Luyện Phát âm & Shadowing IPA**: Nghe giọng mẫu và chấm điểm độ khớp từng từ.
   - 📖 **Phòng Luyện Đọc (Reading Room)**: Đọc bài báo học thuật song ngữ Anh - Việt, chạm để lưu từ vựng vào Sổ tay Flashcard, làm bài tập đọc hiểu suy luận và **✨ AI tạo bài đọc mới theo chuyên ngành**.
   - ✍️ **Phòng Luyện Viết (Writing Workshop)**: Luyện viết IELTS Writing Task 2, Email học thuật gửi Giáo sư, Cover Letter xin thực tập. **Giám khảo AI chấm điểm Overall Band + 4 tiêu chí IELTS**, sửa lỗi chi tiết và viết lại bản mẫu nâng cấp chuẩn **Band 8.0+**.

---

## 📦 Cách xuất file `UniLinguaAI.apk` (Android) và `UniLinguaAI.ipa` (iOS)

1. Tạo một repository mới trên GitHub.
2. Tải toàn bộ thư mục dự án này lên (bao gồm thư mục `.github/workflows/build-apk-ipa.yml` hoặc tải file nén `unilingua_ai.zip` kèm thư mục `.github`).
3. Vào tab **Actions** trên GitHub → chọn workflow **Build Android APK & iOS IPA (UniLingua AI)** → bấm **Run workflow**.
4. Sau vài phút khi workflow chạy xong, kéo xuống mục **Artifacts** để tải về:
   - **`UniLinguaAI-apk`** → giải nén lấy file **`UniLinguaAI.apk`** cài trực tiếp lên điện thoại Android.
   - **`UniLinguaAI-ipa`** → giải nén lấy file **`UniLinguaAI.ipa`** cài lên iPhone/iPad.
