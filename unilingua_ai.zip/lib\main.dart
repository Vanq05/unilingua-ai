import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'ui/screens/google_auth_screen.dart';
import 'ui/screens/home_shell_screen.dart';
import 'ui/screens/placement_test_screen.dart';
import 'ui/theme/app_theme.dart';
import 'ui/view_models/learning_view_model.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ),
  );
  final viewModel = LearningViewModel()..initialize();
  runApp(UniLinguaApp(viewModel: viewModel));
}

class UniLinguaApp extends StatelessWidget {
  const UniLinguaApp({
    super.key,
    required this.viewModel,
  });

  final LearningViewModel viewModel;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'UniLingua AI',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.darkTheme,
      home: ListenableBuilder(
        listenable: viewModel,
        builder: (context, _) {
          if (viewModel.isInitializing) {
            return const Scaffold(
              body: Center(
                child: CircularProgressIndicator(
                  color: AppTheme.cyanPrimary,
                ),
              ),
            );
          }

          // 1. Not signed in yet -> show Google Sign-In screen
          if (!viewModel.isSignedIn) {
            return GoogleAuthScreen(viewModel: viewModel);
          }

          // 2. Newly signed-in student -> mandatory 5-section University Placement Exam
          // Also keeps them on the screen while AI grades & while they review their 12-week Roadmap!
          if (!viewModel.state!.hasCompletedPlacement ||
              viewModel.isReviewingPlacementResult) {
            return PlacementTestScreen(viewModel: viewModel);
          }

          // 3. Ready -> show 4-skill Home, Adaptive Daily Quests & 12-Week Roadmap
          return HomeShellScreen(viewModel: viewModel);
        },
      ),
    );
  }
}
