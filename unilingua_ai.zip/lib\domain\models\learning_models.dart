import 'package:flutter/foundation.dart';

enum SkillType {
  listening,
  speaking,
  reading,
  writing,
}

extension SkillTypeX on SkillType {
  String get labelVi {
    switch (this) {
      case SkillType.listening:
        return 'Nghe (Listening)';
      case SkillType.speaking:
        return 'Nói (Speaking)';
      case SkillType.reading:
        return 'Đọc (Reading)';
      case SkillType.writing:
        return 'Viết (Writing)';
    }
  }

  String get shortVi {
    switch (this) {
      case SkillType.listening:
        return 'Nghe';
      case SkillType.speaking:
        return 'Nói';
      case SkillType.reading:
        return 'Đọc';
      case SkillType.writing:
        return 'Viết';
    }
  }
}

@immutable
class GoogleUserProfile {
  const GoogleUserProfile({
    required this.id,
    required this.email,
    required this.displayName,
    this.photoUrl = '',
    this.universityName = 'Đại học Quốc gia',
    this.academicYear = 'Sinh viên Năm 2',
    this.majorField = 'CNTT & Khoa học Máy tính',
    this.targetGoal = 'Đạt chuẩn đầu ra IELTS 6.5+ / B2 Đại học',
    this.dailyTargetMinutes = 30,
  });

  final String id;
  final String email;
  final String displayName;
  final String photoUrl;
  final String universityName;
  final String academicYear;
  final String majorField;
  final String targetGoal;
  final int dailyTargetMinutes;

  String get initials {
    final parts = displayName.trim().split(RegExp(r'\s+'));
    if (parts.isEmpty || parts.first.isEmpty) return 'SV';
    if (parts.length == 1) return parts.first.substring(0, 1).toUpperCase();
    return '${parts.first[0]}${parts.last[0]}'.toUpperCase();
  }

  GoogleUserProfile copyWith({
    String? id,
    String? email,
    String? displayName,
    String? photoUrl,
    String? universityName,
    String? academicYear,
    String? majorField,
    String? targetGoal,
    int? dailyTargetMinutes,
  }) {
    return GoogleUserProfile(
      id: id ?? this.id,
      email: email ?? this.email,
      displayName: displayName ?? this.displayName,
      photoUrl: photoUrl ?? this.photoUrl,
      universityName: universityName ?? this.universityName,
      academicYear: academicYear ?? this.academicYear,
      majorField: majorField ?? this.majorField,
      targetGoal: targetGoal ?? this.targetGoal,
      dailyTargetMinutes: dailyTargetMinutes ?? this.dailyTargetMinutes,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'email': email,
        'displayName': displayName,
        'photoUrl': photoUrl,
        'universityName': universityName,
        'academicYear': academicYear,
        'majorField': majorField,
        'targetGoal': targetGoal,
        'dailyTargetMinutes': dailyTargetMinutes,
      };

  factory GoogleUserProfile.fromJson(Map<String, dynamic> json) {
    return GoogleUserProfile(
      id: json['id'] as String? ?? 'usr_default',
      email: json['email'] as String? ?? 'student@gmail.com',
      displayName: json['displayName'] as String? ?? 'Sinh viên Đại học',
      photoUrl: json['photoUrl'] as String? ?? '',
      universityName:
          json['universityName'] as String? ?? 'Đại học Quốc gia',
      academicYear: json['academicYear'] as String? ?? 'Sinh viên Năm 2',
      majorField:
          json['majorField'] as String? ?? 'CNTT & Khoa học Máy tính',
      targetGoal: json['targetGoal'] as String? ??
          'Đạt chuẩn đầu ra IELTS 6.5+ / B2 Đại học',
      dailyTargetMinutes: json['dailyTargetMinutes'] as int? ?? 30,
    );
  }
}

@immutable
class PlacementQuestion {
  const PlacementQuestion({
    required this.id,
    required this.skill,
    required this.cefrDifficulty,
    required this.topicTag,
    required this.prompt,
    this.audioScript = '',
    this.readingContext = '',
    required this.options,
    required this.correctIndex,
    required this.explanationVi,
    this.weight = 10,
  });

  final String id;
  final SkillType skill;
  final String cefrDifficulty; // A2, B1, B2, C1
  final String topicTag;
  final String prompt;
  final String audioScript;
  final String readingContext;
  final List<String> options;
  final int correctIndex;
  final String explanationVi;
  final int weight;
}

@immutable
class PlacementSubmissionPayload {
  const PlacementSubmissionPayload({
    required this.selectedAnswers,
    required this.listeningDictationInput,
    required this.speakingIntroAnswer,
    required this.speakingOpinionAnswer,
    required this.writingEssayAnswer,
    this.elapsedSeconds = 0,
  });

  final Map<String, int> selectedAnswers;
  final String listeningDictationInput;
  final String speakingIntroAnswer;
  final String speakingOpinionAnswer;
  final String writingEssayAnswer;
  final int elapsedSeconds;
}

@immutable
class PlacementMistakeReview {
  const PlacementMistakeReview({
    required this.questionId,
    required this.skill,
    required this.cefrDifficulty,
    required this.topicTag,
    required this.questionSummary,
    required this.userAnswerText,
    required this.correctAnswerText,
    required this.explanationVi,
  });

  final String questionId;
  final SkillType skill;
  final String cefrDifficulty;
  final String topicTag;
  final String questionSummary;
  final String userAnswerText;
  final String correctAnswerText;
  final String explanationVi;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'questionId': questionId,
        'skill': skill.name,
        'cefrDifficulty': cefrDifficulty,
        'topicTag': topicTag,
        'questionSummary': questionSummary,
        'userAnswerText': userAnswerText,
        'correctAnswerText': correctAnswerText,
        'explanationVi': explanationVi,
      };

  factory PlacementMistakeReview.fromJson(Map<String, dynamic> json) {
    final sName = json['skill'] as String? ?? 'reading';
    final skill = SkillType.values.firstWhere(
      (s) => s.name == sName,
      orElse: () => SkillType.reading,
    );
    return PlacementMistakeReview(
      questionId: json['questionId'] as String? ?? '',
      skill: skill,
      cefrDifficulty: json['cefrDifficulty'] as String? ?? 'B1',
      topicTag: json['topicTag'] as String? ?? '',
      questionSummary: json['questionSummary'] as String? ?? '',
      userAnswerText: json['userAnswerText'] as String? ?? '',
      correctAnswerText: json['correctAnswerText'] as String? ?? '',
      explanationVi: json['explanationVi'] as String? ?? '',
    );
  }
}

@immutable
class RoadmapPhase {
  const RoadmapPhase({
    required this.weekRange,
    required this.title,
    required this.focusGoal,
    required this.listeningTask,
    required this.speakingTask,
    required this.readingTask,
    required this.writingTask,
    required this.milestone,
  });

  final String weekRange;
  final String title;
  final String focusGoal;
  final String listeningTask;
  final String speakingTask;
  final String readingTask;
  final String writingTask;
  final String milestone;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'weekRange': weekRange,
        'title': title,
        'focusGoal': focusGoal,
        'listeningTask': listeningTask,
        'speakingTask': speakingTask,
        'readingTask': readingTask,
        'writingTask': writingTask,
        'milestone': milestone,
      };

  factory RoadmapPhase.fromJson(Map<String, dynamic> json) {
    return RoadmapPhase(
      weekRange: json['weekRange'] as String? ?? 'Tuần 1 - 3',
      title: json['title'] as String? ?? 'Nền tảng Học thuật',
      focusGoal: json['focusGoal'] as String? ?? '',
      listeningTask: json['listeningTask'] as String? ?? '',
      speakingTask: json['speakingTask'] as String? ?? '',
      readingTask: json['readingTask'] as String? ?? '',
      writingTask: json['writingTask'] as String? ?? '',
      milestone: json['milestone'] as String? ?? '',
    );
  }
}

@immutable
class DailyScheduleSlot {
  const DailyScheduleSlot({
    required this.skill,
    required this.minutes,
    required this.activityTitle,
    required this.detail,
  });

  final SkillType skill;
  final int minutes;
  final String activityTitle;
  final String detail;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'skill': skill.name,
        'minutes': minutes,
        'activityTitle': activityTitle,
        'detail': detail,
      };

  factory DailyScheduleSlot.fromJson(Map<String, dynamic> json) {
    final sName = json['skill'] as String? ?? 'listening';
    final skill = SkillType.values.firstWhere(
      (s) => s.name == sName,
      orElse: () => SkillType.listening,
    );
    return DailyScheduleSlot(
      skill: skill,
      minutes: (json['minutes'] as num?)?.toInt() ?? 10,
      activityTitle: json['activityTitle'] as String? ?? '',
      detail: json['detail'] as String? ?? '',
    );
  }
}

@immutable
class PlacementTestResult {
  const PlacementTestResult({
    required this.completedAt,
    required this.listeningScore,
    required this.speakingScore,
    required this.readingScore,
    required this.writingScore,
    required this.dictationAccuracyPercent,
    required this.objectiveCorrectCount,
    required this.objectiveTotalCount,
    required this.cefrLevel,
    required this.estimatedIelts,
    required this.estimatedToeic,
    required this.aiDiagnosticSummary,
    this.speakingFeedbackVi = '',
    this.writingFeedbackVi = '',
    this.keyStrengths = const <String>[],
    this.criticalGaps = const <String>[],
    this.dailySchedule = const <DailyScheduleSlot>[],
    this.mistakes = const <PlacementMistakeReview>[],
    required this.roadmapPhases,
    this.generatedByAi = false,
  });

  final DateTime completedAt;
  final int listeningScore;
  final int speakingScore;
  final int readingScore;
  final int writingScore;
  final int dictationAccuracyPercent;
  final int objectiveCorrectCount;
  final int objectiveTotalCount;
  final String cefrLevel; // A1, A2, B1, B2, C1
  final String estimatedIelts;
  final int estimatedToeic;
  final String aiDiagnosticSummary;
  final String speakingFeedbackVi;
  final String writingFeedbackVi;
  final List<String> keyStrengths;
  final List<String> criticalGaps;
  final List<DailyScheduleSlot> dailySchedule;
  final List<PlacementMistakeReview> mistakes;
  final List<RoadmapPhase> roadmapPhases;
  final bool generatedByAi;

  int get overallScore =>
      ((listeningScore + speakingScore + readingScore + writingScore) / 4)
          .round();

  SkillType get weakestSkill {
    final entries = <SkillType, int>{
      SkillType.listening: listeningScore,
      SkillType.speaking: speakingScore,
      SkillType.reading: readingScore,
      SkillType.writing: writingScore,
    };
    var minSkill = SkillType.listening;
    var minVal = 999;
    entries.forEach((k, v) {
      if (v < minVal) {
        minVal = v;
        minSkill = k;
      }
    });
    return minSkill;
  }

  SkillType get strongestSkill {
    final entries = <SkillType, int>{
      SkillType.listening: listeningScore,
      SkillType.speaking: speakingScore,
      SkillType.reading: readingScore,
      SkillType.writing: writingScore,
    };
    var maxSkill = SkillType.reading;
    var maxVal = -1;
    entries.forEach((k, v) {
      if (v > maxVal) {
        maxVal = v;
        maxSkill = k;
      }
    });
    return maxSkill;
  }

  PlacementTestResult copyWith({
    int? listeningScore,
    int? speakingScore,
    int? readingScore,
    int? writingScore,
    String? cefrLevel,
    String? estimatedIelts,
    int? estimatedToeic,
    String? aiDiagnosticSummary,
    String? speakingFeedbackVi,
    String? writingFeedbackVi,
    List<String>? keyStrengths,
    List<String>? criticalGaps,
    List<DailyScheduleSlot>? dailySchedule,
    List<RoadmapPhase>? roadmapPhases,
    bool? generatedByAi,
  }) {
    return PlacementTestResult(
      completedAt: completedAt,
      listeningScore: listeningScore ?? this.listeningScore,
      speakingScore: speakingScore ?? this.speakingScore,
      readingScore: readingScore ?? this.readingScore,
      writingScore: writingScore ?? this.writingScore,
      dictationAccuracyPercent: dictationAccuracyPercent,
      objectiveCorrectCount: objectiveCorrectCount,
      objectiveTotalCount: objectiveTotalCount,
      cefrLevel: cefrLevel ?? this.cefrLevel,
      estimatedIelts: estimatedIelts ?? this.estimatedIelts,
      estimatedToeic: estimatedToeic ?? this.estimatedToeic,
      aiDiagnosticSummary: aiDiagnosticSummary ?? this.aiDiagnosticSummary,
      speakingFeedbackVi: speakingFeedbackVi ?? this.speakingFeedbackVi,
      writingFeedbackVi: writingFeedbackVi ?? this.writingFeedbackVi,
      keyStrengths: keyStrengths ?? this.keyStrengths,
      criticalGaps: criticalGaps ?? this.criticalGaps,
      dailySchedule: dailySchedule ?? this.dailySchedule,
      mistakes: mistakes,
      roadmapPhases: roadmapPhases ?? this.roadmapPhases,
      generatedByAi: generatedByAi ?? this.generatedByAi,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'completedAt': completedAt.toIso8601String(),
        'listeningScore': listeningScore,
        'speakingScore': speakingScore,
        'readingScore': readingScore,
        'writingScore': writingScore,
        'dictationAccuracyPercent': dictationAccuracyPercent,
        'objectiveCorrectCount': objectiveCorrectCount,
        'objectiveTotalCount': objectiveTotalCount,
        'cefrLevel': cefrLevel,
        'estimatedIelts': estimatedIelts,
        'estimatedToeic': estimatedToeic,
        'aiDiagnosticSummary': aiDiagnosticSummary,
        'speakingFeedbackVi': speakingFeedbackVi,
        'writingFeedbackVi': writingFeedbackVi,
        'keyStrengths': keyStrengths,
        'criticalGaps': criticalGaps,
        'dailySchedule': dailySchedule.map((s) => s.toJson()).toList(),
        'mistakes': mistakes.map((m) => m.toJson()).toList(),
        'roadmapPhases': roadmapPhases.map((p) => p.toJson()).toList(),
        'generatedByAi': generatedByAi,
      };

  factory PlacementTestResult.fromJson(Map<String, dynamic> json) {
    return PlacementTestResult(
      completedAt:
          DateTime.tryParse(json['completedAt'] as String? ?? '') ??
              DateTime.now(),
      listeningScore: json['listeningScore'] as int? ?? 60,
      speakingScore: json['speakingScore'] as int? ?? 60,
      readingScore: json['readingScore'] as int? ?? 65,
      writingScore: json['writingScore'] as int? ?? 58,
      dictationAccuracyPercent:
          json['dictationAccuracyPercent'] as int? ?? 70,
      objectiveCorrectCount: json['objectiveCorrectCount'] as int? ?? 10,
      objectiveTotalCount: json['objectiveTotalCount'] as int? ?? 17,
      cefrLevel: json['cefrLevel'] as String? ?? 'B1',
      estimatedIelts: json['estimatedIelts'] as String? ?? '5.5',
      estimatedToeic: json['estimatedToeic'] as int? ?? 620,
      aiDiagnosticSummary: json['aiDiagnosticSummary'] as String? ?? '',
      speakingFeedbackVi: json['speakingFeedbackVi'] as String? ?? '',
      writingFeedbackVi: json['writingFeedbackVi'] as String? ?? '',
      keyStrengths: (json['keyStrengths'] as List<dynamic>?)
              ?.map((e) => e.toString())
              .toList() ??
          const <String>[],
      criticalGaps: (json['criticalGaps'] as List<dynamic>?)
              ?.map((e) => e.toString())
              .toList() ??
          const <String>[],
      dailySchedule: (json['dailySchedule'] as List<dynamic>?)
              ?.whereType<Map<String, dynamic>>()
              .map(DailyScheduleSlot.fromJson)
              .toList() ??
          const <DailyScheduleSlot>[],
      mistakes: (json['mistakes'] as List<dynamic>?)
              ?.whereType<Map<String, dynamic>>()
              .map(PlacementMistakeReview.fromJson)
              .toList() ??
          const <PlacementMistakeReview>[],
      roadmapPhases: (json['roadmapPhases'] as List<dynamic>?)
              ?.whereType<Map<String, dynamic>>()
              .map(RoadmapPhase.fromJson)
              .toList() ??
          const <RoadmapPhase>[],
      generatedByAi: json['generatedByAi'] as bool? ?? false,
    );
  }
}

@immutable
class DailyQuestItem {
  const DailyQuestItem({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.skill,
    required this.xpReward,
    required this.targetCount,
    this.currentCount = 0,
  });

  final String id;
  final String title;
  final String subtitle;
  final SkillType skill;
  final int xpReward;
  final int targetCount;
  final int currentCount;

  bool get isCompleted => currentCount >= targetCount;
  double get progress =>
      targetCount > 0 ? (currentCount / targetCount).clamp(0.0, 1.0) : 1.0;

  DailyQuestItem copyWith({int? currentCount}) {
    return DailyQuestItem(
      id: id,
      title: title,
      subtitle: subtitle,
      skill: skill,
      xpReward: xpReward,
      targetCount: targetCount,
      currentCount: currentCount ?? this.currentCount,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'title': title,
        'subtitle': subtitle,
        'skill': skill.name,
        'xpReward': xpReward,
        'targetCount': targetCount,
        'currentCount': currentCount,
      };

  factory DailyQuestItem.fromJson(Map<String, dynamic> json) {
    final skillName = json['skill'] as String? ?? 'listening';
    final skill = SkillType.values.firstWhere(
      (s) => s.name == skillName,
      orElse: () => SkillType.listening,
    );
    return DailyQuestItem(
      id: json['id'] as String? ?? 'quest',
      title: json['title'] as String? ?? '',
      subtitle: json['subtitle'] as String? ?? '',
      skill: skill,
      xpReward: json['xpReward'] as int? ?? 30,
      targetCount: json['targetCount'] as int? ?? 1,
      currentCount: json['currentCount'] as int? ?? 0,
    );
  }
}

@immutable
class DailyQuizQuestion {
  const DailyQuizQuestion({
    required this.question,
    required this.options,
    required this.correctIndex,
    required this.explanationVi,
    required this.skillTag,
  });

  final String question;
  final List<String> options;
  final int correctIndex;
  final String explanationVi;
  final String skillTag;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'question': question,
        'options': options,
        'correctIndex': correctIndex,
        'explanationVi': explanationVi,
        'skillTag': skillTag,
      };

  factory DailyQuizQuestion.fromJson(Map<String, dynamic> json) {
    return DailyQuizQuestion(
      question: json['question'] as String? ?? '',
      options: (json['options'] as List<dynamic>?)
              ?.map((e) => e.toString())
              .toList() ??
          const <String>[],
      correctIndex: json['correctIndex'] as int? ?? 0,
      explanationVi: json['explanationVi'] as String? ?? '',
      skillTag: json['skillTag'] as String? ?? 'Academic Grammar',
    );
  }
}

@immutable
class VocabFlashcard {
  const VocabFlashcard({
    required this.word,
    required this.ipa,
    required this.partOfSpeech,
    required this.meaningVi,
    required this.exampleEn,
    this.topic = 'Academic Core',
    this.isMastered = false,
  });

  final String word;
  final String ipa;
  final String partOfSpeech;
  final String meaningVi;
  final String exampleEn;
  final String topic;
  final bool isMastered;

  VocabFlashcard copyWith({bool? isMastered}) {
    return VocabFlashcard(
      word: word,
      ipa: ipa,
      partOfSpeech: partOfSpeech,
      meaningVi: meaningVi,
      exampleEn: exampleEn,
      topic: topic,
      isMastered: isMastered ?? this.isMastered,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'word': word,
        'ipa': ipa,
        'partOfSpeech': partOfSpeech,
        'meaningVi': meaningVi,
        'exampleEn': exampleEn,
        'topic': topic,
        'isMastered': isMastered,
      };

  factory VocabFlashcard.fromJson(Map<String, dynamic> json) {
    return VocabFlashcard(
      word: json['word'] as String? ?? '',
      ipa: json['ipa'] as String? ?? '',
      partOfSpeech: json['partOfSpeech'] as String? ?? 'n.',
      meaningVi: json['meaningVi'] as String? ?? '',
      exampleEn: json['exampleEn'] as String? ?? '',
      topic: json['topic'] as String? ?? 'Academic Core',
      isMastered: json['isMastered'] as bool? ?? false,
    );
  }
}

@immutable
class ComprehensionMcq {
  const ComprehensionMcq({
    required this.question,
    required this.options,
    required this.correctIndex,
    required this.explanationVi,
  });

  final String question;
  final List<String> options;
  final int correctIndex;
  final String explanationVi;
}

@immutable
class ListeningLesson {
  const ListeningLesson({
    required this.id,
    required this.title,
    required this.category,
    required this.cefrLevel,
    required this.durationLabel,
    required this.audioTranscript,
    required this.vietnameseTranslation,
    required this.dictationSentence,
    required this.keyVocab,
    required this.questions,
  });

  final String id;
  final String title;
  final String category;
  final String cefrLevel;
  final String durationLabel;
  final String audioTranscript;
  final String vietnameseTranslation;
  final String dictationSentence;
  final List<VocabFlashcard> keyVocab;
  final List<ComprehensionMcq> questions;
}

@immutable
class SpeakingDrill {
  const SpeakingDrill({
    required this.id,
    required this.category,
    required this.cefrLevel,
    required this.sentenceEn,
    required this.ipa,
    required this.meaningVi,
    required this.tipVi,
  });

  final String id;
  final String category;
  final String cefrLevel;
  final String sentenceEn;
  final String ipa;
  final String meaningVi;
  final String tipVi;
}

@immutable
class RoleplayScenario {
  const RoleplayScenario({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.cefrLevel,
    required this.aiRoleName,
    required this.systemInstruction,
    required this.openingLineEn,
    required this.openingLineVi,
    required this.suggestedReplies,
  });

  final String id;
  final String title;
  final String subtitle;
  final String cefrLevel;
  final String aiRoleName;
  final String systemInstruction;
  final String openingLineEn;
  final String openingLineVi;
  final List<String> suggestedReplies;
}

@immutable
class ReadingPassage {
  const ReadingPassage({
    required this.id,
    required this.title,
    required this.majorTag,
    required this.cefrLevel,
    required this.readingTimeLabel,
    required this.paragraphsEn,
    required this.paragraphsVi,
    required this.highlights,
    required this.questions,
  });

  final String id;
  final String title;
  final String majorTag;
  final String cefrLevel;
  final String readingTimeLabel;
  final List<String> paragraphsEn;
  final List<String> paragraphsVi;
  final List<VocabFlashcard> highlights;
  final List<ComprehensionMcq> questions;
}

@immutable
class WritingPrompt {
  const WritingPrompt({
    required this.id,
    required this.title,
    required this.category,
    required this.cefrLevel,
    required this.minWords,
    required this.promptEn,
    required this.guideVi,
    required this.keyStructures,
  });

  final String id;
  final String title;
  final String category;
  final String cefrLevel;
  final int minWords;
  final String promptEn;
  final String guideVi;
  final List<String> keyStructures;
}

@immutable
class WritingEvaluation {
  const WritingEvaluation({
    required this.promptTitle,
    required this.userEssay,
    required this.overallBand,
    required this.taskResponseBand,
    required this.coherenceBand,
    required this.lexicalBand,
    required this.grammarBand,
    required this.feedbackMarkdown,
    required this.upgradedEssay,
    required this.submittedAt,
  });

  final String promptTitle;
  final String userEssay;
  final double overallBand;
  final double taskResponseBand;
  final double coherenceBand;
  final double lexicalBand;
  final double grammarBand;
  final String feedbackMarkdown;
  final String upgradedEssay;
  final DateTime submittedAt;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'promptTitle': promptTitle,
        'userEssay': userEssay,
        'overallBand': overallBand,
        'taskResponseBand': taskResponseBand,
        'coherenceBand': coherenceBand,
        'lexicalBand': lexicalBand,
        'grammarBand': grammarBand,
        'feedbackMarkdown': feedbackMarkdown,
        'upgradedEssay': upgradedEssay,
        'submittedAt': submittedAt.toIso8601String(),
      };

  factory WritingEvaluation.fromJson(Map<String, dynamic> json) {
    return WritingEvaluation(
      promptTitle: json['promptTitle'] as String? ?? '',
      userEssay: json['userEssay'] as String? ?? '',
      overallBand: (json['overallBand'] as num?)?.toDouble() ?? 6.5,
      taskResponseBand: (json['taskResponseBand'] as num?)?.toDouble() ?? 6.5,
      coherenceBand: (json['coherenceBand'] as num?)?.toDouble() ?? 6.5,
      lexicalBand: (json['lexicalBand'] as num?)?.toDouble() ?? 6.5,
      grammarBand: (json['grammarBand'] as num?)?.toDouble() ?? 6.5,
      feedbackMarkdown: json['feedbackMarkdown'] as String? ?? '',
      upgradedEssay: json['upgradedEssay'] as String? ?? '',
      submittedAt:
          DateTime.tryParse(json['submittedAt'] as String? ?? '') ??
              DateTime.now(),
    );
  }
}

@immutable
class StudentProgressState {
  const StudentProgressState({
    required this.user,
    this.placementResult,
    this.streakDays = 1,
    this.lastActiveDate = '',
    this.totalXp = 0,
    this.todayXp = 0,
    this.dailyGoalXp = 150,
    this.questsDate = '',
    this.dailyQuests = const <DailyQuestItem>[],
    this.dailyQuizCompletedToday = false,
    this.completedLessonIds = const <String>[],
    this.savedVocab = const <VocabFlashcard>[],
    this.writingHistory = const <WritingEvaluation>[],
    this.listeningSkillScore = 60,
    this.speakingSkillScore = 60,
    this.readingSkillScore = 60,
    this.writingSkillScore = 60,
  });

  final GoogleUserProfile user;
  final PlacementTestResult? placementResult;
  final int streakDays;
  final String lastActiveDate;
  final int totalXp;
  final int todayXp;
  final int dailyGoalXp;
  final String questsDate;
  final List<DailyQuestItem> dailyQuests;
  final bool dailyQuizCompletedToday;
  final List<String> completedLessonIds;
  final List<VocabFlashcard> savedVocab;
  final List<WritingEvaluation> writingHistory;
  final int listeningSkillScore;
  final int speakingSkillScore;
  final int readingSkillScore;
  final int writingSkillScore;

  bool get hasCompletedPlacement => placementResult != null;

  String get currentCefr => placementResult?.cefrLevel ?? 'B1';
  String get currentIelts => placementResult?.estimatedIelts ?? '5.5';
  int get currentToeic => placementResult?.estimatedToeic ?? 620;

  double get dailyGoalProgress =>
      dailyGoalXp > 0 ? (todayXp / dailyGoalXp).clamp(0.0, 1.0) : 1.0;

  int get completedQuestsCount =>
      dailyQuests.where((q) => q.isCompleted).length;

  static String todayKey() {
    final now = DateTime.now();
    final y = now.year.toString().padLeft(4, '0');
    final m = now.month.toString().padLeft(2, '0');
    final d = now.day.toString().padLeft(2, '0');
    return '$y-$m-$d';
  }

  /// Generates adaptive daily quests prioritizing the student's weakest skill
  /// identified in the Placement Test.
  static List<DailyQuestItem> adaptiveQuestsForToday({
    SkillType? weakestSkill,
    String cefr = 'B1',
  }) {
    final focusTag = weakestSkill != null
        ? '⭐ Ưu tiên khắc phục kỹ năng yếu nhất'
        : 'Bài tập bắt buộc mỗi ngày';
    return <DailyQuestItem>[
      DailyQuestItem(
        id: 'q_listen',
        title: weakestSkill == SkillType.listening
            ? '⭐ [Trọng tâm] Nghe Giảng đường ($cefr)'
            : 'Nghe hiểu Giảng đường (Listening)',
        subtitle: weakestSkill == SkillType.listening
            ? '$focusTag • Nghe bài giảng + Dictation'
            : 'Hoàn thành 1 bài nghe học thuật hoặc Dictation',
        skill: SkillType.listening,
        xpReward: weakestSkill == SkillType.listening ? 50 : 35,
        targetCount: 1,
      ),
      DailyQuestItem(
        id: 'q_speak',
        title: weakestSkill == SkillType.speaking
            ? '⭐ [Trọng tâm] Phản xạ Nói AI ($cefr)'
            : 'Phát âm & Hội thoại AI (Speaking)',
        subtitle: weakestSkill == SkillType.speaking
            ? '$focusTag • Shadowing & AI Roleplay'
            : 'Luyện phát âm 3 câu hoặc thực hành AI Roleplay',
        skill: SkillType.speaking,
        xpReward: weakestSkill == SkillType.speaking ? 50 : 40,
        targetCount: 3,
      ),
      DailyQuestItem(
        id: 'q_read',
        title: weakestSkill == SkillType.reading
            ? '⭐ [Trọng tâm] Đọc Chuyên ngành ($cefr)'
            : 'Đọc hiểu Chuyên ngành (Reading)',
        subtitle: weakestSkill == SkillType.reading
            ? '$focusTag • Đọc bài báo & Lưu từ vựng'
            : 'Hoàn thành 1 bài đọc học thuật & lưu từ vựng',
        skill: SkillType.reading,
        xpReward: weakestSkill == SkillType.reading ? 50 : 35,
        targetCount: 1,
      ),
      DailyQuestItem(
        id: 'q_write',
        title: weakestSkill == SkillType.writing
            ? '⭐ [Trọng tâm] Viết Học thuật AI ($cefr)'
            : 'Viết Học thuật cùng AI (Writing)',
        subtitle: weakestSkill == SkillType.writing
            ? '$focusTag • Viết đoạn văn để AI sửa lỗi'
            : 'Nộp 1 bài viết để AI chấm điểm Band IELTS',
        skill: SkillType.writing,
        xpReward: weakestSkill == SkillType.writing ? 60 : 50,
        targetCount: 1,
      ),
      const DailyQuestItem(
        id: 'q_quiz',
        title: 'Bài tập Tổng hợp Hàng ngày (Daily Workout)',
        subtitle: 'Vượt qua 5 câu hỏi Ngữ pháp & Từ vựng mỗi ngày',
        skill: SkillType.reading,
        xpReward: 40,
        targetCount: 1,
      ),
    ];
  }

  static List<DailyQuestItem> defaultQuestsForToday() =>
      adaptiveQuestsForToday();

  StudentProgressState copyWith({
    GoogleUserProfile? user,
    PlacementTestResult? placementResult,
    int? streakDays,
    String? lastActiveDate,
    int? totalXp,
    int? todayXp,
    int? dailyGoalXp,
    String? questsDate,
    List<DailyQuestItem>? dailyQuests,
    bool? dailyQuizCompletedToday,
    List<String>? completedLessonIds,
    List<VocabFlashcard>? savedVocab,
    List<WritingEvaluation>? writingHistory,
    int? listeningSkillScore,
    int? speakingSkillScore,
    int? readingSkillScore,
    int? writingSkillScore,
  }) {
    return StudentProgressState(
      user: user ?? this.user,
      placementResult: placementResult ?? this.placementResult,
      streakDays: streakDays ?? this.streakDays,
      lastActiveDate: lastActiveDate ?? this.lastActiveDate,
      totalXp: totalXp ?? this.totalXp,
      todayXp: todayXp ?? this.todayXp,
      dailyGoalXp: dailyGoalXp ?? this.dailyGoalXp,
      questsDate: questsDate ?? this.questsDate,
      dailyQuests: dailyQuests ?? this.dailyQuests,
      dailyQuizCompletedToday:
          dailyQuizCompletedToday ?? this.dailyQuizCompletedToday,
      completedLessonIds: completedLessonIds ?? this.completedLessonIds,
      savedVocab: savedVocab ?? this.savedVocab,
      writingHistory: writingHistory ?? this.writingHistory,
      listeningSkillScore: listeningScoreOr(listeningSkillScore),
      speakingSkillScore: speakingSkillScore ?? this.speakingSkillScore,
      readingSkillScore: readingSkillScore ?? this.readingSkillScore,
      writingSkillScore: writingSkillScore ?? this.writingSkillScore,
    );
  }

  int listeningScoreOr(int? override) => override ?? listeningSkillScore;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'user': user.toJson(),
        'placementResult': placementResult?.toJson(),
        'streakDays': streakDays,
        'lastActiveDate': lastActiveDate,
        'totalXp': totalXp,
        'todayXp': todayXp,
        'dailyGoalXp': dailyGoalXp,
        'questsDate': questsDate,
        'dailyQuests': dailyQuests.map((q) => q.toJson()).toList(),
        'dailyQuizCompletedToday': dailyQuizCompletedToday,
        'completedLessonIds': completedLessonIds,
        'savedVocab': savedVocab.map((v) => v.toJson()).toList(),
        'writingHistory': writingHistory.map((w) => w.toJson()).toList(),
        'listeningSkillScore': listeningSkillScore,
        'speakingSkillScore': speakingSkillScore,
        'readingSkillScore': readingSkillScore,
        'writingSkillScore': writingSkillScore,
      };

  factory StudentProgressState.fromJson(Map<String, dynamic> json) {
    final today = todayKey();
    final savedQuestsDate = json['questsDate'] as String? ?? '';
    final isSameDay = savedQuestsDate == today;

    final rawQuests = (json['dailyQuests'] as List<dynamic>?)
            ?.whereType<Map<String, dynamic>>()
            .map(DailyQuestItem.fromJson)
            .toList() ??
        const <DailyQuestItem>[];

    final placementJson = json['placementResult'] as Map<String, dynamic>?;
    final placement = placementJson != null
        ? PlacementTestResult.fromJson(placementJson)
        : null;

    return StudentProgressState(
      user: GoogleUserProfile.fromJson(
        json['user'] as Map<String, dynamic>? ?? const <String, dynamic>{},
      ),
      placementResult: placement,
      streakDays: json['streakDays'] as int? ?? 1,
      lastActiveDate: json['lastActiveDate'] as String? ?? today,
      totalXp: json['totalXp'] as int? ?? 0,
      todayXp: isSameDay ? (json['todayXp'] as int? ?? 0) : 0,
      dailyGoalXp: json['dailyGoalXp'] as int? ?? 150,
      questsDate: today,
      dailyQuests: isSameDay && rawQuests.isNotEmpty
          ? rawQuests
          : adaptiveQuestsForToday(
              weakestSkill: placement?.weakestSkill,
              cefr: placement?.cefrLevel ?? 'B1',
            ),
      dailyQuizCompletedToday:
          isSameDay ? (json['dailyQuizCompletedToday'] as bool? ?? false) : false,
      completedLessonIds: (json['completedLessonIds'] as List<dynamic>?)
              ?.map((e) => e.toString())
              .toList() ??
          const <String>[],
      savedVocab: (json['savedVocab'] as List<dynamic>?)
              ?.whereType<Map<String, dynamic>>()
              .map(VocabFlashcard.fromJson)
              .toList() ??
          const <VocabFlashcard>[],
      writingHistory: (json['writingHistory'] as List<dynamic>?)
              ?.whereType<Map<String, dynamic>>()
              .map(WritingEvaluation.fromJson)
              .toList() ??
          const <WritingEvaluation>[],
      listeningSkillScore:
          json['listeningSkillScore'] as int? ?? placement?.listeningScore ?? 60,
      speakingSkillScore:
          json['speakingSkillScore'] as int? ?? placement?.speakingScore ?? 60,
      readingSkillScore:
          json['readingSkillScore'] as int? ?? placement?.readingScore ?? 60,
      writingSkillScore:
          json['writingSkillScore'] as int? ?? placement?.writingScore ?? 60,
    );
  }
}
