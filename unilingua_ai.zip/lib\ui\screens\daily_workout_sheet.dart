import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../view_models/learning_view_model.dart';
import '../../domain/models/learning_models.dart';

class DailyWorkoutScreen extends StatefulWidget {
  const DailyWorkoutScreen({
    super.key,
    required this.viewModel,
    this.initialTab = 0,
  });

  final LearningViewModel viewModel;
  final int initialTab;

  @override
  State<DailyWorkoutScreen> createState() => _DailyWorkoutScreenState();
}

class _DailyWorkoutScreenState extends State<DailyWorkoutScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final Map<int, int> _selectedAnswers = <int, int>{};
  bool _submitted = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: 2,
      vsync: this,
      initialIndex: widget.initialTab,
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  int _calculateCorrectCount(List<DailyQuizQuestion> questions) {
    var count = 0;
    for (var i = 0; i < questions.length; i++) {
      if (_selectedAnswers[i] == questions[i].correctIndex) {
        count++;
      }
    }
    return count;
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.viewModel,
      builder: (context, _) {
        final questions = widget.viewModel.dailyQuizQuestions;
        final flashcards =
            widget.viewModel.state?.savedVocab ?? const <VocabFlashcard>[];

        return Scaffold(
          appBar: AppBar(
            title: const Text(
              '🔥 Bài Tập Hàng Ngày & Sổ Tay Từ Vựng',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17),
            ),
            bottom: TabBar(
              controller: _tabController,
              indicatorColor: AppTheme.cyanPrimary,
              labelColor: AppTheme.cyanPrimary,
              tabs: <Widget>[
                const Tab(text: 'Bài tập Hôm nay (5 Câu)'),
                Tab(text: 'Sổ tay Từ vựng (${flashcards.length})'),
              ],
            ),
          ),
          body: TabBarView(
            controller: _tabController,
            children: <Widget>[
              _buildDailyQuizTab(questions),
              _buildFlashcardsTab(flashcards),
            ],
          ),
        );
      },
    );
  }

  Widget _buildDailyQuizTab(List<DailyQuizQuestion> questions) {
    final correctCount = _calculateCorrectCount(questions);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: <Color>[Color(0xFF1E1B4B), Color(0xFF0F172A)],
              ),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: AppTheme.cyanPrimary.withValues(alpha: 0.4),
              ),
            ),
            child: Row(
              children: <Widget>[
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        'Thử thách Tổng hợp Mỗi Ngày (+40 XP)',
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 15.5,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Ôn luyện Từ vựng Học thuật, Ngữ pháp C1 & Phản xạ Giao tiếp đại học.',
                        style: TextStyle(
                          fontSize: 12.5,
                          color: AppTheme.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
                OutlinedButton.icon(
                  onPressed: widget.viewModel.isGeneratingAiContent
                      ? null
                      : () async {
                          final ok = await widget.viewModel
                              .generateAiDailyWorkout();
                          if (!mounted) return;
                          if (ok) {
                            setState(() {
                              _selectedAnswers.clear();
                              _submitted = false;
                            });
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text(
                                  '✨ AI đã tạo bộ 5 câu hỏi bài tập mới cho hôm nay!',
                                ),
                              ),
                            );
                          }
                        },
                  icon: widget.viewModel.isGeneratingAiContent
                      ? const SizedBox(
                          width: 14,
                          height: 14,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(
                          Icons.auto_awesome_rounded,
                          size: 16,
                          color: AppTheme.goldAccent,
                        ),
                  label: const Text('Đề AI Mới'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          ...List<Widget>.generate(questions.length, (qIdx) {
            final q = questions[qIdx];
            final selected = _selectedAnswers[qIdx];

            return Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppTheme.bgCard,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: AppTheme.borderSubtle),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: AppTheme.cyanPrimary.withValues(alpha: 0.14),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        'Câu ${qIdx + 1} • ${q.skillTag}',
                        style: const TextStyle(
                          fontSize: 11.5,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.cyanPrimary,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      q.question,
                      style: const TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 14.5,
                        height: 1.4,
                      ),
                    ),
                    const SizedBox(height: 10),
                    ...List<Widget>.generate(q.options.length, (optIdx) {
                      final isChosen = selected == optIdx;
                      final isRight = optIdx == q.correctIndex;
                      Color border = AppTheme.borderSubtle;
                      if (selected != null) {
                        if (isRight) {
                          border = AppTheme.emeraldSuccess;
                        } else if (isChosen) {
                          border = AppTheme.coralDanger;
                        }
                      }
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(12),
                          onTap: () {
                            setState(() => _selectedAnswers[qIdx] = optIdx);
                          },
                          child: Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: AppTheme.bgSurface,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: border, width: 1.4),
                            ),
                            child: Row(
                              children: <Widget>[
                                Text(
                                  '${String.fromCharCode(65 + optIdx)}. ',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w800,
                                    color: AppTheme.cyanPrimary,
                                  ),
                                ),
                                Expanded(
                                  child: Text(
                                    q.options[optIdx],
                                    style: const TextStyle(fontSize: 13.5),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    }),
                    if (selected != null) ...<Widget>[
                      const SizedBox(height: 6),
                      Text(
                        '💡 ${q.explanationVi}',
                        style: const TextStyle(
                          fontSize: 12.5,
                          color: AppTheme.goldAccent,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            );
          }),

          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton.icon(
              onPressed: _selectedAnswers.isEmpty
                  ? null
                  : () async {
                      setState(() => _submitted = true);
                      await widget.viewModel.recordActivityCompletion(
                        questId: 'q_quiz',
                        skill: SkillType.reading,
                        baseXp: 40,
                      );
                      if (!mounted) return;
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            'Hoàn thành Bài tập Hàng ngày: Đúng $correctCount/${questions.length} câu (+40 XP)!',
                          ),
                        ),
                      );
                    },
              icon: const Icon(Icons.task_alt_rounded),
              label: Text(
                _submitted
                    ? 'Đã hoàn thành ($correctCount/${questions.length} câu đúng) • Bấm để lưu XP'
                    : 'Nộp Bài Tập Hôm Nay & Nhận +40 XP',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFlashcardsTab(List<VocabFlashcard> cards) {
    if (cards.isEmpty) {
      return const Center(
        child: Text('Chưa có từ vựng nào được lưu.'),
      );
    }
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: cards.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (context, index) {
        final c = cards[index];
        return Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.bgCard,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: c.isMastered
                  ? AppTheme.emeraldSuccess
                  : AppTheme.borderSubtle,
            ),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              IconButton(
                onPressed: () => widget.viewModel.tts.speak(
                  '${c.word}. ${c.exampleEn}',
                  id: 'fc_${c.word}',
                ),
                icon: const Icon(
                  Icons.volume_up_rounded,
                  color: AppTheme.cyanPrimary,
                ),
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Flexible(
                          child: Text(
                            c.word,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          '${c.ipa} (${c.partOfSpeech})',
                          style: const TextStyle(
                            fontSize: 12.5,
                            color: AppTheme.textSecondary,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      c.meaningVi,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.goldAccent,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '"${c.exampleEn}"',
                      style: const TextStyle(
                        fontSize: 12.5,
                        fontStyle: FontStyle.italic,
                        color: AppTheme.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                onPressed: () =>
                    widget.viewModel.toggleVocabMastery(c.word),
                icon: Icon(
                  c.isMastered
                      ? Icons.check_circle_rounded
                      : Icons.radio_button_unchecked_rounded,
                  color: c.isMastered
                      ? AppTheme.emeraldSuccess
                      : AppTheme.textSecondary,
                ),
                tooltip: 'Đánh dấu đã thuộc',
              ),
            ],
          ),
        );
      },
    );
  }
}
