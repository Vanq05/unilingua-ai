import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../data/repositories/curriculum_repository.dart';
import '../../data/services/app_update_service.dart';
import '../../domain/models/learning_models.dart';
import '../theme/app_theme.dart';
import '../view_models/learning_view_model.dart';
import '../widgets/competency_overview_card.dart';
import 'daily_workout_sheet.dart';
import 'placement_test_screen.dart';
import 'skills/listening_screen.dart';
import 'skills/reading_screen.dart';
import 'skills/speaking_screen.dart';
import 'skills/writing_screen.dart';

class HomeShellScreen extends StatefulWidget {
  const HomeShellScreen({
    super.key,
    required this.viewModel,
  });

  final LearningViewModel viewModel;

  @override
  State<HomeShellScreen> createState() => _HomeShellScreenState();
}

class _HomeShellScreenState extends State<HomeShellScreen> {
  int _currentTab = 0;

  void _navigateToSkillTab(SkillType skill) {
    switch (skill) {
      case SkillType.listening:
        setState(() => _currentTab = 1);
        break;
      case SkillType.speaking:
        setState(() => _currentTab = 2);
        break;
      case SkillType.reading:
        setState(() => _currentTab = 3);
        break;
      case SkillType.writing:
        setState(() => _currentTab = 4);
        break;
    }
  }

  void _openDailyWorkout({int initialTab = 0}) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => DailyWorkoutScreen(
          viewModel: widget.viewModel,
          initialTab: initialTab,
        ),
      ),
    );
  }

  void _openRetakePlacement() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => PlacementTestScreen(
          viewModel: widget.viewModel,
          isRetake: true,
        ),
      ),
    );
  }

  Future<void> _showSettingsSheet(StudentProgressState state) async {
    final syncCode = widget.viewModel.exportCloudSyncCode();
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppPalette.of(context).card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return ListenableBuilder(
          listenable: widget.viewModel,
          builder: (ctx, _) {
            final p = AppPalette.of(ctx);
            final isDark = widget.viewModel.isDarkMode;
            return Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: p.border,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: <Widget>[
                      CircleAvatar(
                        radius: 22,
                        backgroundColor: p.primary,
                        backgroundImage: state.user.photoUrl.isNotEmpty
                            ? NetworkImage(state.user.photoUrl)
                            : null,
                        child: state.user.photoUrl.isEmpty
                            ? Text(
                                state.user.initials,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w800,
                                  fontSize: 15,
                                ),
                              )
                            : null,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              state.user.displayName,
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w800,
                                color: p.textPrimary,
                              ),
                            ),
                            Text(
                              state.user.email,
                              style: TextStyle(
                                fontSize: 12.5,
                                color: p.primary,
                              ),
                            ),
                            Text(
                              'v${AppUpdateService.currentVersion} • ${widget.viewModel.driveSyncStatus}',
                              style: TextStyle(
                                fontSize: 11.5,
                                color: p.textSecondary,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const Divider(height: 22),

                  // 2-Mode Light / Dark Theme Switcher
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    secondary: Icon(
                      isDark ? Icons.dark_mode_rounded : Icons.wb_sunny_rounded,
                      color: isDark ? p.gold : p.primary,
                    ),
                    title: Text(
                      isDark ? 'Chế độ Tối 🌙' : 'Chế độ Sáng Trong Xanh ☀️',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 14.5,
                        color: p.textPrimary,
                      ),
                    ),
                    subtitle: Text(
                      'Chuyển đổi giữa giao diện Sáng và Tối',
                      style: TextStyle(fontSize: 12, color: p.textSecondary),
                    ),
                    value: isDark,
                    activeColor: p.primary,
                    onChanged: widget.viewModel.setDarkMode,
                  ),

                  // Google Drive Database Sync
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    leading: Icon(
                      Icons.add_to_drive_rounded,
                      color: p.primary,
                    ),
                    title: Text(
                      'Đồng bộ Database lên Google Drive',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                        color: p.textPrimary,
                      ),
                    ),
                    subtitle: Text(
                      widget.viewModel.driveSyncStatus,
                      style: TextStyle(fontSize: 12, color: p.textSecondary),
                    ),
                    trailing: widget.viewModel.isSyncingDrive
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : null,
                    onTap: () async {
                      final ok =
                          await widget.viewModel.syncNowToGoogleDrive();
                      if (!mounted) return;
                      Navigator.of(ctx).pop();
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            ok
                                ? '☁️ Đã lưu toàn bộ dữ liệu vào Google Drive (UniLingua AI Data/unilingua_database.json)!'
                                : 'Cần đăng nhập Google OAuth thật (đã cấu hình SHA-1) để đồng bộ Drive.',
                          ),
                        ),
                      );
                    },
                  ),

                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    leading: Icon(
                      Icons.system_update_rounded,
                      color: p.success,
                    ),
                    title: Text(
                      'Kiểm tra cập nhật app (Cài đè)',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                        color: p.textPrimary,
                      ),
                    ),
                    onTap: () async {
                      Navigator.of(ctx).pop();
                      final update =
                          await widget.viewModel.checkForAppUpdate();
                      if (!mounted) return;
                      if (update != null) {
                        await widget.viewModel.openAvailableUpdate();
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Bạn đang dùng bản mới nhất!'),
                          ),
                        );
                      }
                    },
                  ),

                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    leading: Icon(
                      Icons.copy_rounded,
                      color: p.secondary,
                    ),
                    title: Text(
                      'Sao chép Mã Sao Lưu thủ công',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                        color: p.textPrimary,
                      ),
                    ),
                    onTap: () {
                      Clipboard.setData(ClipboardData(text: syncCode));
                      Navigator.of(ctx).pop();
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Đã sao chép mã sao lưu tiến trình!'),
                        ),
                      );
                    },
                  ),

                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    leading: Icon(
                      Icons.shuffle_rounded,
                      color: p.gold,
                    ),
                    title: Text(
                      'Làm Bài Test mới (Đề ngẫu nhiên mới)',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                        color: p.textPrimary,
                      ),
                    ),
                    onTap: () {
                      Navigator.of(ctx).pop();
                      _openRetakePlacement();
                    },
                  ),

                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    leading: Icon(
                      Icons.logout_rounded,
                      color: p.danger,
                    ),
                    title: Text(
                      'Đăng xuất / Đổi tài khoản Google',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                        color: p.danger,
                      ),
                    ),
                    onTap: () {
                      Navigator.of(ctx).pop();
                      widget.viewModel.signOut();
                    },
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      _buildDashboardTab(),
      ListeningScreen(viewModel: widget.viewModel),
      SpeakingScreen(viewModel: widget.viewModel),
      ReadingScreen(viewModel: widget.viewModel),
      WritingScreen(viewModel: widget.viewModel),
    ];

    return ListenableBuilder(
      listenable: widget.viewModel,
      builder: (context, _) {
        final p = AppPalette.of(context);
        final boost = widget.viewModel.latestSkillBoost;
        final state = widget.viewModel.state!;

        return Scaffold(
          body: Column(
            children: <Widget>[
              if (boost != null && _currentTab != 0)
                SafeArea(
                  bottom: false,
                  child: Container(
                    margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: p.success.withValues(alpha: 0.14),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: p.success),
                    ),
                    child: Row(
                      children: <Widget>[
                        SizedBox(
                          width: 34,
                          height: 34,
                          child: Stack(
                            alignment: Alignment.center,
                            children: <Widget>[
                              CircularProgressIndicator(
                                value: (boost.newScore / 100).clamp(0.0, 1.0),
                                strokeWidth: 4,
                                backgroundColor: p.surface,
                                valueColor:
                                    AlwaysStoppedAnimation<Color>(p.success),
                              ),
                              Text(
                                '${boost.newScore}%',
                                style: TextStyle(
                                  fontSize: 9.5,
                                  fontWeight: FontWeight.w900,
                                  color: p.success,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            '🎉 Năng lực ${boost.skill.shortVi}: ${boost.previousScore}% → ${boost.newScore}% (+${boost.delta}%) • Tổng ${state.overallCompetencyPercent}%',
                            style: TextStyle(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w800,
                              color: p.success,
                            ),
                          ),
                        ),
                        IconButton(
                          visualDensity: VisualDensity.compact,
                          onPressed: widget.viewModel.clearLatestSkillBoost,
                          icon: Icon(
                            Icons.close_rounded,
                            size: 16,
                            color: p.success,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              Expanded(
                child: IndexedStack(
                  index: _currentTab,
                  children: pages,
                ),
              ),
            ],
          ),
          bottomNavigationBar: NavigationBar(
            selectedIndex: _currentTab,
            onDestinationSelected: (idx) {
              widget.viewModel.tts.stop();
              widget.viewModel.voiceRecorder.stopListening();
              setState(() => _currentTab = idx);
            },
            backgroundColor: p.surface,
            indicatorColor: p.primary.withValues(alpha: 0.16),
            destinations: <NavigationDestination>[
              NavigationDestination(
                icon: const Icon(Icons.dashboard_outlined),
                selectedIcon: Icon(Icons.dashboard_rounded, color: p.primary),
                label: 'Trang chủ',
              ),
              NavigationDestination(
                icon: const Icon(Icons.headphones_outlined),
                selectedIcon: Icon(Icons.headphones_rounded, color: p.primary),
                label: 'Nghe',
              ),
              NavigationDestination(
                icon: const Icon(Icons.mic_none_rounded),
                selectedIcon: Icon(Icons.mic_rounded, color: p.primary),
                label: 'Nói AI',
              ),
              NavigationDestination(
                icon: const Icon(Icons.menu_book_outlined),
                selectedIcon: Icon(Icons.menu_book_rounded, color: p.primary),
                label: 'Đọc',
              ),
              NavigationDestination(
                icon: const Icon(Icons.edit_note_outlined),
                selectedIcon: Icon(Icons.edit_note_rounded, color: p.primary),
                label: 'Viết AI',
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildDashboardTab() {
    return ListenableBuilder(
      listenable: widget.viewModel,
      builder: (context, _) {
        final p = AppPalette.of(context);
        final state = widget.viewModel.state!;
        final placement = state.placementResult;
        final boost = widget.viewModel.latestSkillBoost;
        final update = widget.viewModel.availableUpdate;

        return SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                // 1. Crisp Top Bar: Google Avatar + Name + Streak + Settings (Light/Dark + Drive)
                Row(
                  children: <Widget>[
                    InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: () => _showSettingsSheet(state),
                      child: Row(
                        children: <Widget>[
                          CircleAvatar(
                            radius: 21,
                            backgroundColor: p.primary,
                            backgroundImage: state.user.photoUrl.isNotEmpty
                                ? NetworkImage(state.user.photoUrl)
                                : null,
                            child: state.user.photoUrl.isEmpty
                                ? Text(
                                    state.user.initials,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w800,
                                    ),
                                  )
                                : null,
                          ),
                          const SizedBox(width: 10),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                state.user.displayName,
                                style: TextStyle(
                                  fontWeight: FontWeight.w900,
                                  fontSize: 15.5,
                                  color: p.textPrimary,
                                ),
                              ),
                              Text(
                                widget.viewModel.driveSyncStatus,
                                style: TextStyle(
                                  fontSize: 11.5,
                                  color: p.textSecondary,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFF6B35).withValues(alpha: 0.14),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Row(
                        children: <Widget>[
                          const Icon(
                            Icons.local_fire_department_rounded,
                            color: Color(0xFFFF6B35),
                            size: 16,
                          ),
                          const SizedBox(width: 3),
                          Text(
                            '${state.streakDays}',
                            style: const TextStyle(
                              fontWeight: FontWeight.w900,
                              fontSize: 12.5,
                              color: Color(0xFFFF6B35),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 4),
                    IconButton(
                      tooltip: 'Cài đặt (Sáng/Tối & Drive)',
                      onPressed: () => _showSettingsSheet(state),
                      icon: Icon(Icons.settings_rounded, color: p.primary),
                    ),
                  ],
                ),

                if (update != null) ...<Widget>[
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 10,
                    ),
                    decoration: BoxDecoration(
                      color: p.success.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: p.success),
                    ),
                    child: Row(
                      children: <Widget>[
                        Icon(Icons.system_update_rounded, color: p.success),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'Có bản mới v${update.latestVersion} (Cài đè trực tiếp)',
                            style: TextStyle(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w700,
                              color: p.textPrimary,
                            ),
                          ),
                        ),
                        TextButton(
                          onPressed: widget.viewModel.openAvailableUpdate,
                          child: Text(
                            'Cập nhật',
                            style: TextStyle(
                              color: p.success,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
                const SizedBox(height: 14),

                // 2. BEAUTIFUL RADAR + RING COMPETENCY CARD
                CompetencyOverviewCard(
                  listeningScore: state.listeningSkillScore,
                  speakingScore: state.speakingSkillScore,
                  readingScore: state.readingSkillScore,
                  writingScore: state.writingSkillScore,
                  cefrLevel: state.currentCefr,
                  estimatedIelts: state.currentIelts,
                  estimatedToeic: state.currentToeic,
                  latestBoost: boost,
                  onDismissBoost: widget.viewModel.clearLatestSkillBoost,
                  onSkillTap: _navigateToSkillTab,
                ),
                const SizedBox(height: 16),

                // 3. ULTRA-CLEAN DAILY CHECKLIST
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: p.card,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: p.border),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Text(
                            '✅ Việc hôm nay',
                            style: TextStyle(
                              fontSize: 15.5,
                              fontWeight: FontWeight.w800,
                              color: p.textPrimary,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: p.primary.withValues(alpha: 0.14),
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Text(
                              '${state.completedQuestsCount}/${state.dailyQuests.length}',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w800,
                                color: p.primary,
                              ),
                            ),
                          ),
                          const Spacer(),
                          TextButton(
                            onPressed: () => _openDailyWorkout(initialTab: 0),
                            child: const Text(
                              'Bài tập 5 câu →',
                              style: TextStyle(
                                fontSize: 12.5,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const Divider(height: 12),
                      ...state.dailyQuests.map(
                        (quest) => InkWell(
                          borderRadius: BorderRadius.circular(10),
                          onTap: () => _navigateToSkillTab(quest.skill),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8),
                            child: Row(
                              children: <Widget>[
                                Icon(
                                  quest.isCompleted
                                      ? Icons.check_circle_rounded
                                      : Icons.radio_button_unchecked_rounded,
                                  size: 22,
                                  color: quest.isCompleted
                                      ? p.success
                                      : p.textSecondary,
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    quest.title,
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w700,
                                      decoration: quest.isCompleted
                                          ? TextDecoration.lineThrough
                                          : null,
                                      color: quest.isCompleted
                                          ? p.textSecondary
                                          : p.textPrimary,
                                    ),
                                  ),
                                ),
                                Text(
                                  quest.isCompleted ? 'Xong' : 'Học →',
                                  style: TextStyle(
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w800,
                                    color: quest.isCompleted
                                        ? p.success
                                        : p.primary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 6),
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          onPressed: () => _openDailyWorkout(initialTab: 1),
                          icon: const Icon(Icons.style_outlined, size: 16),
                          label: Text(
                            'Sổ từ vựng (${state.savedVocab.length})',
                            style: const TextStyle(fontSize: 12.5),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // 4. CUSTOMIZABLE-WEEK ROADMAP
                Row(
                  children: <Widget>[
                    Expanded(
                      child: Text(
                        '🗺️ Lộ trình ${state.user.targetWeeks} tuần',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          color: p.textPrimary,
                        ),
                      ),
                    ),
                    TextButton(
                      onPressed: _openRetakePlacement,
                      child: const Text('Test đề mới'),
                    ),
                  ],
                ),
                Wrap(
                  spacing: 8,
                  children: CurriculumRepository.targetWeekOptions.map((weeks) {
                    final selected = state.user.targetWeeks == weeks;
                    return ChoiceChip(
                      visualDensity: VisualDensity.compact,
                      label: Text(
                        '$weeks tuần',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: selected ? Colors.white : p.textPrimary,
                        ),
                      ),
                      selected: selected,
                      selectedColor: p.primary,
                      onSelected: (_) =>
                          widget.viewModel.updateStudyPlan(targetWeeks: weeks),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 10),
                if (placement != null) ...<Widget>[
                  ...placement.roadmapPhases.map(
                    (phase) => Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: p.card,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: p.border),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              phase.weekRange,
                              style: TextStyle(
                                color: p.primary,
                                fontWeight: FontWeight.w800,
                                fontSize: 12,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              phase.title,
                              style: TextStyle(
                                fontWeight: FontWeight.w800,
                                fontSize: 14.5,
                                color: p.textPrimary,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              phase.focusGoal,
                              style: TextStyle(
                                fontSize: 12.5,
                                color: p.textSecondary,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              '🏁 ${phase.milestone}',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                color: p.success,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}
