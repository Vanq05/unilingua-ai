import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../domain/models/learning_models.dart';
import '../theme/app_theme.dart';
import '../view_models/learning_view_model.dart';
import 'daily_workout_sheet.dart';
import 'placement_test_screen.dart';
import 'skills/listening_screen.dart';
import 'skills/reading_screen.dart';
import 'skills/speaking_screen.dart';
import 'skills/writing_screen.dart';

class HomeShellScreen extends StatefulWidget {
  const HomeShellScreen({
    super.key,
    required this.viewModel,
  });

  final LearningViewModel viewModel;

  @override
  State<HomeShellScreen> createState() => _HomeShellScreenState();
}

class _HomeShellScreenState extends State<HomeShellScreen> {
  int _currentTab = 0;

  void _navigateToSkillTab(SkillType skill) {
    switch (skill) {
      case SkillType.listening:
        setState(() => _currentTab = 1);
        break;
      case SkillType.speaking:
        setState(() => _currentTab = 2);
        break;
      case SkillType.reading:
        setState(() => _currentTab = 3);
        break;
      case SkillType.writing:
        setState(() => _currentTab = 4);
        break;
    }
  }

  void _openDailyWorkout({int initialTab = 0}) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => DailyWorkoutScreen(
          viewModel: widget.viewModel,
          initialTab: initialTab,
        ),
      ),
    );
  }

  void _openRetakePlacement() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => PlacementTestScreen(
          viewModel: widget.viewModel,
          isRetake: true,
        ),
      ),
    );
  }

  Future<void> _showGoogleAccountSheet(StudentProgressState state) async {
    final syncCode = widget.viewModel.exportCloudSyncCode();
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppTheme.bgCard,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                children: <Widget>[
                  CircleAvatar(
                    radius: 24,
                    backgroundColor: AppTheme.violetAccent,
                    child: Text(
                      state.user.initials,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 16,
                      ),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          state.user.displayName,
                          style: const TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        Text(
                          state.user.email,
                          style: const TextStyle(
                            fontSize: 13,
                            color: AppTheme.cyanPrimary,
                          ),
                        ),
                        Text(
                          '${state.user.universityName} • ${state.user.majorField}',
                          style: const TextStyle(
                            fontSize: 12,
                            color: AppTheme.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const Divider(height: 24),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(
                  Icons.cloud_upload_outlined,
                  color: AppTheme.cyanPrimary,
                ),
                title: const Text(
                  'Sao chép Mã Đồng Bộ Tiến Trình Google Cloud',
                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                ),
                subtitle: const Text(
                  'Lưu mã này để khôi phục Streak, XP & Lộ trình trên điện thoại khác',
                  style: TextStyle(fontSize: 12),
                ),
                onTap: () {
                  Clipboard.setData(ClipboardData(text: syncCode));
                  Navigator.of(ctx).pop();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text(
                        'Đã sao chép Mã Đồng Bộ Tiến Trình vào bộ nhớ tạm!',
                      ),
                    ),
                  );
                },
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(
                  Icons.quiz_outlined,
                  color: AppTheme.goldAccent,
                ),
                title: const Text(
                  'Làm lại Bài Test Đầu Vào Đại Học (Placement Test)',
                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                ),
                subtitle: const Text(
                  'Cập nhật lại trình độ CEFR / IELTS và tạo lộ trình 12 tuần mới',
                  style: TextStyle(fontSize: 12),
                ),
                onTap: () {
                  Navigator.of(ctx).pop();
                  _openRetakePlacement();
                },
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(
                  Icons.logout_rounded,
                  color: AppTheme.coralDanger,
                ),
                title: const Text(
                  'Đổi tài khoản Google / Đăng xuất',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 14,
                    color: AppTheme.coralDanger,
                  ),
                ),
                onTap: () {
                  Navigator.of(ctx).pop();
                  widget.viewModel.signOut();
                },
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      _buildDashboardTab(),
      ListeningScreen(viewModel: widget.viewModel),
      SpeakingScreen(viewModel: widget.viewModel),
      ReadingScreen(viewModel: widget.viewModel),
      WritingScreen(viewModel: widget.viewModel),
    ];

    return Scaffold(
      body: IndexedStack(
        index: _currentTab,
        children: pages,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentTab,
        onDestinationSelected: (idx) {
          widget.viewModel.tts.stop();
          setState(() => _currentTab = idx);
        },
        backgroundColor: AppTheme.bgSurface,
        indicatorColor: AppTheme.cyanPrimary.withValues(alpha: 0.18),
        destinations: const <NavigationDestination>[
          NavigationDestination(
            icon: Icon(Icons.dashboard_outlined),
            selectedIcon:
                Icon(Icons.dashboard_rounded, color: AppTheme.cyanPrimary),
            label: 'Lộ trình',
          ),
          NavigationDestination(
            icon: Icon(Icons.headphones_outlined),
            selectedIcon:
                Icon(Icons.headphones_rounded, color: AppTheme.cyanPrimary),
            label: 'Nghe',
          ),
          NavigationDestination(
            icon: Icon(Icons.mic_none_rounded),
            selectedIcon: Icon(Icons.mic_rounded, color: AppTheme.cyanPrimary),
            label: 'Nói AI',
          ),
          NavigationDestination(
            icon: Icon(Icons.menu_book_outlined),
            selectedIcon:
                Icon(Icons.menu_book_rounded, color: AppTheme.cyanPrimary),
            label: 'Đọc',
          ),
          NavigationDestination(
            icon: Icon(Icons.edit_note_outlined),
            selectedIcon:
                Icon(Icons.edit_note_rounded, color: AppTheme.cyanPrimary),
            label: 'Viết AI',
          ),
        ],
      ),
    );
  }

  Widget _buildDashboardTab() {
    return ListenableBuilder(
      listenable: widget.viewModel,
      builder: (context, _) {
        final state = widget.viewModel.state!;
        final placement = state.placementResult;

        return SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                // Top Profile & Streak Header
                Row(
                  children: <Widget>[
                    InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: () => _showGoogleAccountSheet(state),
                      child: Row(
                        children: <Widget>[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: Image.asset(
                              'assets/icon/app_icon.png',
                              width: 42,
                              height: 42,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => CircleAvatar(
                                radius: 21,
                                backgroundColor: AppTheme.violetAccent,
                                child: Text(state.user.initials),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Row(
                                children: <Widget>[
                                  Text(
                                    state.user.displayName,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w800,
                                      fontSize: 16,
                                    ),
                                  ),
                                  const SizedBox(width: 4),
                                  const Icon(
                                    Icons.verified_rounded,
                                    size: 16,
                                    color: AppTheme.cyanPrimary,
                                  ),
                                ],
                              ),
                              Text(
                                '${state.currentCefr} • IELTS ${state.currentIelts}',
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: AppTheme.textSecondary,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const Spacer(),
                    // Streak Badge
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 11,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFF6B35).withValues(alpha: 0.16),
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(
                          color: const Color(0xFFFF6B35).withValues(alpha: 0.4),
                        ),
                      ),
                      child: Row(
                        children: <Widget>[
                          const Icon(
                            Icons.local_fire_department_rounded,
                            color: Color(0xFFFF6B35),
                            size: 18,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            '${state.streakDays} ngày',
                            style: const TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 12.5,
                              color: Color(0xFFFF6B35),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    // Total XP Badge
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 11,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: AppTheme.goldAccent.withValues(alpha: 0.16),
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(
                          color: AppTheme.goldAccent.withValues(alpha: 0.4),
                        ),
                      ),
                      child: Row(
                        children: <Widget>[
                          const Icon(
                            Icons.bolt_rounded,
                            color: AppTheme.goldAccent,
                            size: 18,
                          ),
                          Text(
                            '${state.totalXp} XP',
                            style: const TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 12.5,
                              color: AppTheme.goldAccent,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),

                // Daily Progress Hero Card
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: <Color>[Color(0xFF1E1B4B), Color(0xFF0F172A)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(
                      color: AppTheme.cyanPrimary.withValues(alpha: 0.45),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          SizedBox(
                            width: 64,
                            height: 64,
                            child: Stack(
                              alignment: Alignment.center,
                              children: <Widget>[
                                CircularProgressIndicator(
                                  value: state.dailyGoalProgress,
                                  strokeWidth: 7,
                                  backgroundColor: AppTheme.bgSurface,
                                  valueColor:
                                      const AlwaysStoppedAnimation<Color>(
                                    AppTheme.cyanPrimary,
                                  ),
                                ),
                                Text(
                                  '${(state.dailyGoalProgress * 100).round()}%',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w900,
                                    fontSize: 13.5,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                const Text(
                                  'Mục Tiêu Bài Tập Hôm Nay',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w800,
                                    fontSize: 16.5,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  'Đã đạt ${state.todayXp}/${state.dailyGoalXp} XP • Hoàn thành ${state.completedQuestsCount}/${state.dailyQuests.length} nhiệm vụ',
                                  style: const TextStyle(
                                    fontSize: 13,
                                    color: AppTheme.textSecondary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: () =>
                                  _openDailyWorkout(initialTab: 0),
                              icon: const Icon(
                                Icons.play_arrow_rounded,
                                size: 20,
                              ),
                              label: const Text('Làm Bài Tập Hàng Ngày'),
                            ),
                          ),
                          const SizedBox(width: 10),
                          OutlinedButton.icon(
                            onPressed: () => _openDailyWorkout(initialTab: 1),
                            icon: const Icon(Icons.style_outlined, size: 18),
                            label: Text('Từ vựng (${state.savedVocab.length})'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // Daily Quests Checklist (5 tasks every day)
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    const Text(
                      '📅 Nhiệm Vụ Hàng Ngày (Daily Quests)',
                      style: TextStyle(
                        fontSize: 16.5,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    Text(
                      StudentProgressState.todayKey(),
                      style: const TextStyle(
                        fontSize: 12,
                        color: AppTheme.textSecondary,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                ...state.dailyQuests.map(
                  (quest) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: () {
                        if (quest.id == 'q_quiz') {
                          _openDailyWorkout(initialTab: 0);
                        } else {
                          _navigateToSkillTab(quest.skill);
                        }
                      },
                      child: Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: AppTheme.bgCard,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: quest.isCompleted
                                ? AppTheme.emeraldSuccess
                                : AppTheme.borderSubtle,
                          ),
                        ),
                        child: Row(
                          children: <Widget>[
                            Container(
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                color: (quest.isCompleted
                                        ? AppTheme.emeraldSuccess
                                        : AppTheme.cyanPrimary)
                                    .withValues(alpha: 0.15),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Icon(
                                quest.isCompleted
                                    ? Icons.check_circle_rounded
                                    : Icons.flag_circle_rounded,
                                color: quest.isCompleted
                                    ? AppTheme.emeraldSuccess
                                    : AppTheme.cyanPrimary,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    quest.title,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w800,
                                      fontSize: 14,
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    quest.subtitle,
                                    style: const TextStyle(
                                      fontSize: 12,
                                      color: AppTheme.textSecondary,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 5,
                              ),
                              decoration: BoxDecoration(
                                color:
                                    AppTheme.goldAccent.withValues(alpha: 0.15),
                                borderRadius: BorderRadius.circular(999),
                              ),
                              child: Text(
                                quest.isCompleted
                                    ? 'Hoàn thành'
                                    : '+${quest.xpReward} XP',
                                style: const TextStyle(
                                  fontSize: 11.5,
                                  fontWeight: FontWeight.w800,
                                  color: AppTheme.goldAccent,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                // 4 Skills Mastery Grid
                const Text(
                  '🎯 Năng Lực 4 Kỹ Năng (Bấm để vào Phòng Luyện)',
                  style: TextStyle(
                    fontSize: 16.5,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 10),
                GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  childAspectRatio: 1.5,
                  children: <Widget>[
                    _SkillCard(
                      title: '🎧 Nghe (Listening)',
                      subtitle: 'Bài giảng & Dictation',
                      score: state.listeningSkillScore,
                      color: AppTheme.cyanPrimary,
                      onTap: () => _navigateToSkillTab(SkillType.listening),
                    ),
                    _SkillCard(
                      title: '🎙️ Nói (Speaking)',
                      subtitle: 'AI Roleplay & IPA',
                      score: state.speakingSkillScore,
                      color: AppTheme.goldAccent,
                      onTap: () => _navigateToSkillTab(SkillType.speaking),
                    ),
                    _SkillCard(
                      title: '📖 Đọc (Reading)',
                      subtitle: 'Song ngữ Chuyên ngành',
                      score: state.readingSkillScore,
                      color: AppTheme.emeraldSuccess,
                      onTap: () => _navigateToSkillTab(SkillType.reading),
                    ),
                    _SkillCard(
                      title: '✍️ Viết (Writing)',
                      subtitle: 'AI Chấm Luận IELTS',
                      score: state.writingSkillScore,
                      color: AppTheme.violetAccent,
                      onTap: () => _navigateToSkillTab(SkillType.writing),
                    ),
                  ],
                ),
                const SizedBox(height: 22),

                // Personalized 12-Week University Roadmap Section
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    const Expanded(
                      child: Text(
                        '🎓 Lộ Trình Đại Học Cá Nhân Hóa 12 Tuần',
                        style: TextStyle(
                          fontSize: 16.5,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    TextButton.icon(
                      onPressed: _openRetakePlacement,
                      icon: const Icon(Icons.refresh_rounded, size: 16),
                      label: const Text('Test lại'),
                    ),
                  ],
                ),
                if (placement != null) ...<Widget>[
                  Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: AppTheme.bgCardElevated,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: AppTheme.cyanPrimary.withValues(alpha: 0.35),
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          '${state.user.academicYear} • ${state.user.majorField} • ${state.user.dailyTargetMinutes} phút/ngày',
                          style: const TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 13,
                            color: AppTheme.cyanPrimary,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          placement.aiDiagnosticSummary,
                          style: const TextStyle(
                            fontSize: 13,
                            height: 1.45,
                            color: AppTheme.textPrimary,
                          ),
                        ),
                        if (placement.criticalGaps.isNotEmpty) ...<Widget>[
                          const SizedBox(height: 10),
                          const Text(
                            '🎯 Lỗ hổng trọng điểm từ bài test đầu vào:',
                            style: TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 12.5,
                              color: AppTheme.goldAccent,
                            ),
                          ),
                          const SizedBox(height: 4),
                          ...placement.criticalGaps.take(3).map(
                                (g) => Text(
                                  '• $g',
                                  style: const TextStyle(
                                    fontSize: 12.5,
                                    color: AppTheme.textSecondary,
                                  ),
                                ),
                              ),
                        ],
                      ],
                    ),
                  ),
                  if (placement.dailySchedule.isNotEmpty) ...<Widget>[
                    const Padding(
                      padding: EdgeInsets.only(bottom: 8),
                      child: Text(
                        '⏱️ Phân bổ Lịch Học Hôm Nay (Theo kỹ năng yếu nhất)',
                        style: TextStyle(
                          fontSize: 14.5,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    ...placement.dailySchedule.map(
                      (slot) => Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(14),
                          onTap: () => _navigateToSkillTab(slot.skill),
                          child: Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: AppTheme.bgCard,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: AppTheme.borderSubtle),
                            ),
                            child: Row(
                              children: <Widget>[
                                Container(
                                  width: 48,
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 6),
                                  decoration: BoxDecoration(
                                    color: AppTheme.cyanPrimary
                                        .withValues(alpha: 0.14),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  alignment: Alignment.center,
                                  child: Text(
                                    '${slot.minutes}\'',
                                    style: const TextStyle(
                                      color: AppTheme.cyanPrimary,
                                      fontWeight: FontWeight.w900,
                                      fontSize: 13,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Text(
                                        slot.activityTitle,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w800,
                                          fontSize: 13.5,
                                        ),
                                      ),
                                      Text(
                                        slot.detail,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          fontSize: 12,
                                          color: AppTheme.textSecondary,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const Icon(
                                  Icons.chevron_right_rounded,
                                  color: AppTheme.cyanPrimary,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                  ],
                  ...placement.roadmapPhases.map(
                    (phase) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: AppTheme.bgCard,
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: AppTheme.borderSubtle),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              phase.weekRange,
                              style: const TextStyle(
                                color: AppTheme.goldAccent,
                                fontWeight: FontWeight.w800,
                                fontSize: 12,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              phase.title,
                              style: const TextStyle(
                                fontWeight: FontWeight.w800,
                                fontSize: 15,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              phase.focusGoal,
                              style: const TextStyle(
                                fontSize: 12.5,
                                color: AppTheme.textSecondary,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              '🎧 ${phase.listeningTask}',
                              style: const TextStyle(fontSize: 12.5, height: 1.35),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              '🎙️ ${phase.speakingTask}',
                              style: const TextStyle(fontSize: 12.5, height: 1.35),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              '📖 ${phase.readingTask}',
                              style: const TextStyle(fontSize: 12.5, height: 1.35),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              '✍️ ${phase.writingTask}',
                              style: const TextStyle(fontSize: 12.5, height: 1.35),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              '🏁 ${phase.milestone}',
                              style: const TextStyle(
                                fontSize: 12.5,
                                fontWeight: FontWeight.w700,
                                color: AppTheme.emeraldSuccess,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}

class _SkillCard extends StatelessWidget {
  const _SkillCard({
    required this.title,
    required this.subtitle,
    required this.score,
    required this.color,
    required this.onTap,
  });

  final String title;
  final String subtitle;
  final int score;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppTheme.bgCard,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: color.withValues(alpha: 0.45)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 11.5,
                    color: AppTheme.textSecondary,
                  ),
                ),
              ],
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    const Text(
                      'Điểm kỹ năng',
                      style: TextStyle(
                        fontSize: 11,
                        color: AppTheme.textSecondary,
                      ),
                    ),
                    Text(
                      '$score/100',
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w900,
                        color: color,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(999),
                  child: LinearProgressIndicator(
                    value: (score / 100).clamp(0.0, 1.0),
                    minHeight: 6,
                    backgroundColor: AppTheme.bgSurface,
                    valueColor: AlwaysStoppedAnimation<Color>(color),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
