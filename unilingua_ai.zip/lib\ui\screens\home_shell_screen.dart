import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../data/repositories/curriculum_repository.dart';
import '../../data/services/app_update_service.dart';
import '../../domain/models/learning_models.dart';
import '../theme/app_theme.dart';
import '../view_models/learning_view_model.dart';
import 'daily_workout_sheet.dart';
import 'placement_test_screen.dart';
import 'skills/listening_screen.dart';
import 'skills/reading_screen.dart';
import 'skills/speaking_screen.dart';
import 'skills/writing_screen.dart';

class HomeShellScreen extends StatefulWidget {
  const HomeShellScreen({
    super.key,
    required this.viewModel,
  });

  final LearningViewModel viewModel;

  @override
  State<HomeShellScreen> createState() => _HomeShellScreenState();
}

class _HomeShellScreenState extends State<HomeShellScreen> {
  int _currentTab = 0;

  void _navigateToSkillTab(SkillType skill) {
    switch (skill) {
      case SkillType.listening:
        setState(() => _currentTab = 1);
        break;
      case SkillType.speaking:
        setState(() => _currentTab = 2);
        break;
      case SkillType.reading:
        setState(() => _currentTab = 3);
        break;
      case SkillType.writing:
        setState(() => _currentTab = 4);
        break;
    }
  }

  void _openDailyWorkout({int initialTab = 0}) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => DailyWorkoutScreen(
          viewModel: widget.viewModel,
          initialTab: initialTab,
        ),
      ),
    );
  }

  void _openRetakePlacement() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => PlacementTestScreen(
          viewModel: widget.viewModel,
          isRetake: true,
        ),
      ),
    );
  }

  Future<void> _showGoogleAccountSheet(StudentProgressState state) async {
    final syncCode = widget.viewModel.exportCloudSyncCode();
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppTheme.bgCard,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                children: <Widget>[
                  CircleAvatar(
                    radius: 22,
                    backgroundColor: AppTheme.violetAccent,
                    child: Text(
                      state.user.initials,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 15,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          state.user.displayName,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        Text(
                          state.user.email,
                          style: const TextStyle(
                            fontSize: 12.5,
                            color: AppTheme.cyanPrimary,
                          ),
                        ),
                        Text(
                          'Phiên bản ${AppUpdateService.currentVersion} • Lộ trình ${state.user.targetWeeks} tuần',
                          style: const TextStyle(
                            fontSize: 11.5,
                            color: AppTheme.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const Divider(height: 22),
              ListTile(
                contentPadding: EdgeInsets.zero,
                dense: true,
                leading: const Icon(
                  Icons.system_update_rounded,
                  color: AppTheme.emeraldSuccess,
                ),
                title: const Text(
                  'Kiểm tra cập nhật ứng dụng (Cài đè)',
                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                ),
                onTap: () async {
                  Navigator.of(ctx).pop();
                  final update = await widget.viewModel.checkForAppUpdate();
                  if (!mounted) return;
                  if (update != null) {
                    await widget.viewModel.openAvailableUpdate();
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Bạn đang dùng phiên bản mới nhất!'),
                      ),
                    );
                  }
                },
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                dense: true,
                leading: const Icon(
                  Icons.cloud_upload_outlined,
                  color: AppTheme.cyanPrimary,
                ),
                title: const Text(
                  'Sao chép Mã Sao Lưu Tiến Trình',
                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                ),
                onTap: () {
                  Clipboard.setData(ClipboardData(text: syncCode));
                  Navigator.of(ctx).pop();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Đã sao chép mã sao lưu tiến trình!'),
                    ),
                  );
                },
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                dense: true,
                leading: const Icon(
                  Icons.quiz_outlined,
                  color: AppTheme.goldAccent,
                ),
                title: const Text(
                  'Làm lại Bài Test Đầu Vào',
                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                ),
                onTap: () {
                  Navigator.of(ctx).pop();
                  _openRetakePlacement();
                },
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                dense: true,
                leading: const Icon(
                  Icons.logout_rounded,
                  color: AppTheme.coralDanger,
                ),
                title: const Text(
                  'Đổi tài khoản Google',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 14,
                    color: AppTheme.coralDanger,
                  ),
                ),
                onTap: () {
                  Navigator.of(ctx).pop();
                  widget.viewModel.signOut();
                },
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      _buildDashboardTab(),
      ListeningScreen(viewModel: widget.viewModel),
      SpeakingScreen(viewModel: widget.viewModel),
      ReadingScreen(viewModel: widget.viewModel),
      WritingScreen(viewModel: widget.viewModel),
    ];

    return ListenableBuilder(
      listenable: widget.viewModel,
      builder: (context, _) {
        final boost = widget.viewModel.latestSkillBoost;
        final state = widget.viewModel.state!;

        return Scaffold(
          body: Column(
            children: <Widget>[
              // Instant post-study Competency Ring Bar shown right after completing a lesson on any skill tab
              if (boost != null && _currentTab != 0)
                SafeArea(
                  bottom: false,
                  child: Container(
                    margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: AppTheme.emeraldSuccess.withValues(alpha: 0.16),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: AppTheme.emeraldSuccess),
                    ),
                    child: Row(
                      children: <Widget>[
                        SizedBox(
                          width: 34,
                          height: 34,
                          child: Stack(
                            alignment: Alignment.center,
                            children: <Widget>[
                              CircularProgressIndicator(
                                value: (boost.newScore / 100).clamp(0.0, 1.0),
                                strokeWidth: 4,
                                backgroundColor: AppTheme.bgSurface,
                                valueColor: const AlwaysStoppedAnimation<Color>(
                                  AppTheme.emeraldSuccess,
                                ),
                              ),
                              Text(
                                '${boost.newScore}%',
                                style: const TextStyle(
                                  fontSize: 9.5,
                                  fontWeight: FontWeight.w900,
                                  color: AppTheme.emeraldSuccess,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            '🎉 Năng lực ${boost.skill.shortVi}: ${boost.previousScore}% → ${boost.newScore}% (+${boost.delta}%) • Tổng ${state.overallCompetencyPercent}%',
                            style: const TextStyle(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w800,
                              color: AppTheme.emeraldSuccess,
                            ),
                          ),
                        ),
                        IconButton(
                          visualDensity: VisualDensity.compact,
                          onPressed: widget.viewModel.clearLatestSkillBoost,
                          icon: const Icon(
                            Icons.close_rounded,
                            size: 16,
                            color: AppTheme.emeraldSuccess,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              Expanded(
                child: IndexedStack(
                  index: _currentTab,
                  children: pages,
                ),
              ),
            ],
          ),
          bottomNavigationBar: NavigationBar(
            selectedIndex: _currentTab,
            onDestinationSelected: (idx) {
              widget.viewModel.tts.stop();
              widget.viewModel.voiceRecorder.stopListening();
              setState(() => _currentTab = idx);
            },
            backgroundColor: AppTheme.bgSurface,
            indicatorColor: AppTheme.cyanPrimary.withValues(alpha: 0.18),
            destinations: const <NavigationDestination>[
              NavigationDestination(
                icon: Icon(Icons.dashboard_outlined),
                selectedIcon:
                    Icon(Icons.dashboard_rounded, color: AppTheme.cyanPrimary),
                label: 'Trang chủ',
              ),
              NavigationDestination(
                icon: Icon(Icons.headphones_outlined),
                selectedIcon:
                    Icon(Icons.headphones_rounded, color: AppTheme.cyanPrimary),
                label: 'Nghe',
              ),
              NavigationDestination(
                icon: Icon(Icons.mic_none_rounded),
                selectedIcon:
                    Icon(Icons.mic_rounded, color: AppTheme.cyanPrimary),
                label: 'Nói AI',
              ),
              NavigationDestination(
                icon: Icon(Icons.menu_book_outlined),
                selectedIcon:
                    Icon(Icons.menu_book_rounded, color: AppTheme.cyanPrimary),
                label: 'Đọc',
              ),
              NavigationDestination(
                icon: Icon(Icons.edit_note_outlined),
                selectedIcon:
                    Icon(Icons.edit_note_rounded, color: AppTheme.cyanPrimary),
                label: 'Viết AI',
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildDashboardTab() {
    return ListenableBuilder(
      listenable: widget.viewModel,
      builder: (context, _) {
        final state = widget.viewModel.state!;
        final placement = state.placementResult;
        final boost = widget.viewModel.latestSkillBoost;
        final update = widget.viewModel.availableUpdate;

        return SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                // 1. Compact Header: Profile + Streak + XP
                Row(
                  children: <Widget>[
                    InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: () => _showGoogleAccountSheet(state),
                      child: Row(
                        children: <Widget>[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: Image.asset(
                              'assets/icon/app_icon.png',
                              width: 40,
                              height: 40,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => CircleAvatar(
                                radius: 20,
                                backgroundColor: AppTheme.violetAccent,
                                child: Text(state.user.initials),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                state.user.displayName,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontSize: 15.5,
                                ),
                              ),
                              Text(
                                'Trình độ ${state.currentCefr} • Chạm xem tài khoản',
                                style: const TextStyle(
                                  fontSize: 11.5,
                                  color: AppTheme.textSecondary,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFF6B35).withValues(alpha: 0.16),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Row(
                        children: <Widget>[
                          const Icon(
                            Icons.local_fire_department_rounded,
                            color: Color(0xFFFF6B35),
                            size: 16,
                          ),
                          const SizedBox(width: 3),
                          Text(
                            '${state.streakDays}',
                            style: const TextStyle(
                              fontWeight: FontWeight.w900,
                              fontSize: 12.5,
                              color: Color(0xFFFF6B35),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: AppTheme.goldAccent.withValues(alpha: 0.16),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        '⚡ ${state.totalXp} XP',
                        style: const TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 12,
                          color: AppTheme.goldAccent,
                        ),
                      ),
                    ),
                  ],
                ),

                // Optional In-App Update Banner (Overwrite directly!)
                if (update != null) ...<Widget>[
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 10,
                    ),
                    decoration: BoxDecoration(
                      color: AppTheme.emeraldSuccess.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: AppTheme.emeraldSuccess),
                    ),
                    child: Row(
                      children: <Widget>[
                        const Icon(
                          Icons.system_update_rounded,
                          color: AppTheme.emeraldSuccess,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'Có bản mới v${update.latestVersion} (Cài đè không mất dữ liệu)',
                            style: const TextStyle(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        TextButton(
                          onPressed: widget.viewModel.openAvailableUpdate,
                          child: const Text(
                            'Cập nhật',
                            style: TextStyle(
                              color: AppTheme.emeraldSuccess,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
                const SizedBox(height: 16),

                // 2. COMPETENCY RINGS CARD (Vòng Xem Năng Lực Hiện Tại & Sau Khi Học)
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: <Color>[Color(0xFF1E1B4B), Color(0xFF0F172A)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(
                      color: AppTheme.cyanPrimary.withValues(alpha: 0.45),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          // Main Overall Competency Ring
                          SizedBox(
                            width: 78,
                            height: 78,
                            child: Stack(
                              alignment: Alignment.center,
                              children: <Widget>[
                                CircularProgressIndicator(
                                  value:
                                      (state.overallCompetencyPercent / 100)
                                          .clamp(0.0, 1.0),
                                  strokeWidth: 8,
                                  backgroundColor: AppTheme.bgSurface,
                                  valueColor:
                                      const AlwaysStoppedAnimation<Color>(
                                    AppTheme.cyanPrimary,
                                  ),
                                ),
                                Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: <Widget>[
                                    Text(
                                      '${state.overallCompetencyPercent}%',
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w900,
                                        fontSize: 17,
                                        color: AppTheme.cyanPrimary,
                                      ),
                                    ),
                                    Text(
                                      state.currentCefr,
                                      style: const TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w800,
                                        color: AppTheme.goldAccent,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                const Text(
                                  'Vòng Năng Lực Hiện Tại',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w900,
                                    fontSize: 16,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  'IELTS ~${state.currentIelts} • TOEIC ~${state.currentToeic}',
                                  style: const TextStyle(
                                    fontSize: 12.5,
                                    color: AppTheme.textSecondary,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  'Chạm vào từng vòng kỹ năng bên dưới để học ngay.',
                                  style: TextStyle(
                                    fontSize: 11.5,
                                    color: AppTheme.cyanPrimary
                                        .withValues(alpha: 0.85),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),

                      // Live Post-Study Boost Highlight (ngay sau khi học)
                      if (boost != null) ...<Widget>[
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 8,
                          ),
                          decoration: BoxDecoration(
                            color:
                                AppTheme.emeraldSuccess.withValues(alpha: 0.16),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: AppTheme.emeraldSuccess
                                  .withValues(alpha: 0.6),
                            ),
                          ),
                          child: Row(
                            children: <Widget>[
                              const Icon(
                                Icons.trending_up_rounded,
                                size: 18,
                                color: AppTheme.emeraldSuccess,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  'Vừa học xong ${boost.skill.shortVi}: ${boost.previousScore}% → ${boost.newScore}% (+${boost.delta}%)',
                                  style: const TextStyle(
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w800,
                                    color: AppTheme.emeraldSuccess,
                                  ),
                                ),
                              ),
                              InkWell(
                                onTap: widget.viewModel.clearLatestSkillBoost,
                                child: const Icon(
                                  Icons.close_rounded,
                                  size: 16,
                                  color: AppTheme.emeraldSuccess,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                      const SizedBox(height: 16),

                      // 4 Mini Skill Competency Rings
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          _MiniSkillRing(
                            label: 'Nghe',
                            score: state.listeningSkillScore,
                            color: AppTheme.cyanPrimary,
                            delta: boost?.skill == SkillType.listening
                                ? boost!.delta
                                : null,
                            onTap: () =>
                                _navigateToSkillTab(SkillType.listening),
                          ),
                          _MiniSkillRing(
                            label: 'Nói',
                            score: state.speakingSkillScore,
                            color: AppTheme.goldAccent,
                            delta: boost?.skill == SkillType.speaking
                                ? boost!.delta
                                : null,
                            onTap: () =>
                                _navigateToSkillTab(SkillType.speaking),
                          ),
                          _MiniSkillRing(
                            label: 'Đọc',
                            score: state.readingSkillScore,
                            color: AppTheme.emeraldSuccess,
                            delta: boost?.skill == SkillType.reading
                                ? boost!.delta
                                : null,
                            onTap: () => _navigateToSkillTab(SkillType.reading),
                          ),
                          _MiniSkillRing(
                            label: 'Viết',
                            score: state.writingSkillScore,
                            color: AppTheme.violetAccent,
                            delta: boost?.skill == SkillType.writing
                                ? boost!.delta
                                : null,
                            onTap: () => _navigateToSkillTab(SkillType.writing),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),

                // 3. ULTRA-CLEAN DAILY CHECKLIST (Đơn giản, gọn mắt, 1 khung duy nhất)
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppTheme.bgCard,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: AppTheme.borderSubtle),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          const Text(
                            '✅ Việc hôm nay',
                            style: TextStyle(
                              fontSize: 15.5,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color:
                                  AppTheme.cyanPrimary.withValues(alpha: 0.14),
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Text(
                              '${state.completedQuestsCount}/${state.dailyQuests.length}',
                              style: const TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w800,
                                color: AppTheme.cyanPrimary,
                              ),
                            ),
                          ),
                          const Spacer(),
                          TextButton(
                            onPressed: () => _openDailyWorkout(initialTab: 0),
                            child: const Text(
                              'Bài tập 5 câu →',
                              style: TextStyle(
                                fontSize: 12.5,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const Divider(height: 12),
                      ...state.dailyQuests.map(
                        (quest) => InkWell(
                          borderRadius: BorderRadius.circular(10),
                          onTap: () => _navigateToSkillTab(quest.skill),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8),
                            child: Row(
                              children: <Widget>[
                                Icon(
                                  quest.isCompleted
                                      ? Icons.check_circle_rounded
                                      : Icons.radio_button_unchecked_rounded,
                                  size: 22,
                                  color: quest.isCompleted
                                      ? AppTheme.emeraldSuccess
                                      : AppTheme.textSecondary,
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    quest.title,
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w700,
                                      decoration: quest.isCompleted
                                          ? TextDecoration.lineThrough
                                          : null,
                                      color: quest.isCompleted
                                          ? AppTheme.textSecondary
                                          : AppTheme.textPrimary,
                                    ),
                                  ),
                                ),
                                Text(
                                  quest.isCompleted ? 'Xong' : 'Học →',
                                  style: TextStyle(
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w800,
                                    color: quest.isCompleted
                                        ? AppTheme.emeraldSuccess
                                        : AppTheme.cyanPrimary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: () => _openDailyWorkout(initialTab: 1),
                              icon: const Icon(Icons.style_outlined, size: 16),
                              label: Text(
                                'Sổ từ vựng (${state.savedVocab.length})',
                                style: const TextStyle(fontSize: 12.5),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),

                // 4. ROADMAP WITH CUSTOMIZABLE WEEKS (4 / 8 / 12 / 16 tuần)
                Row(
                  children: <Widget>[
                    Expanded(
                      child: Text(
                        '🗺️ Lộ trình ${state.user.targetWeeks} tuần',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    TextButton(
                      onPressed: _openRetakePlacement,
                      child: const Text('Test lại'),
                    ),
                  ],
                ),
                Wrap(
                  spacing: 8,
                  children: CurriculumRepository.targetWeekOptions.map((weeks) {
                    final selected = state.user.targetWeeks == weeks;
                    return ChoiceChip(
                      visualDensity: VisualDensity.compact,
                      label: Text(
                        '$weeks tuần',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: selected
                              ? const Color(0xFF04101E)
                              : AppTheme.textPrimary,
                        ),
                      ),
                      selected: selected,
                      selectedColor: AppTheme.goldAccent,
                      onSelected: (_) => widget.viewModel
                          .updateStudyPlan(targetWeeks: weeks),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 10),
                if (placement != null) ...<Widget>[
                  ...placement.roadmapPhases.map(
                    (phase) => Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: AppTheme.bgCard,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: AppTheme.borderSubtle),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              phase.weekRange,
                              style: const TextStyle(
                                color: AppTheme.goldAccent,
                                fontWeight: FontWeight.w800,
                                fontSize: 12,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              phase.title,
                              style: const TextStyle(
                                fontWeight: FontWeight.w800,
                                fontSize: 14.5,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              phase.focusGoal,
                              style: const TextStyle(
                                fontSize: 12.5,
                                color: AppTheme.textSecondary,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              '🏁 ${phase.milestone}',
                              style: const TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                color: AppTheme.emeraldSuccess,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}

class _MiniSkillRing extends StatelessWidget {
  const _MiniSkillRing({
    required this.label,
    required this.score,
    required this.color,
    required this.onTap,
    this.delta,
  });

  final String label;
  final int score;
  final Color color;
  final VoidCallback onTap;
  final int? delta;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
        child: Column(
          children: <Widget>[
            SizedBox(
              width: 54,
              height: 54,
              child: Stack(
                alignment: Alignment.center,
                children: <Widget>[
                  CircularProgressIndicator(
                    value: (score / 100).clamp(0.0, 1.0),
                    strokeWidth: 5,
                    backgroundColor: AppTheme.bgSurface,
                    valueColor: AlwaysStoppedAnimation<Color>(color),
                  ),
                  Text(
                    '$score%',
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      fontSize: 12.5,
                      color: color,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 5),
            Text(
              label,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
            if (delta != null && delta! > 0)
              Text(
                '+$delta%',
                style: const TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  color: AppTheme.emeraldSuccess,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
