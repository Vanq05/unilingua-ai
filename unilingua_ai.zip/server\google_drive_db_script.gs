/**
 * UniLingua AI — Central Google Drive Server Database (Google Apps Script)
 *
 * Triển khai làm Web App trên 1 tài khoản Google Drive cố định:
 *   1. Mở https://script.google.com -> Dự án mới (New Project)
 *   2. Dán toàn bộ code này vào Code.gs -> Lưu lại
 *   3. Bấm "Triển khai" (Deploy) -> "Tùy chọn triển khai mới" (New deployment)
 *      - Loại: Ứng dụng web (Web app)
 *      - Thực thi dưới dạng (Execute as): Tôi (Me - chủ tài khoản Drive)
 *      - Người có quyền truy cập (Who has access): Bất kỳ ai (Anyone)
 *   4. Cấp quyền Google Drive & Sheets -> Sao chép URL Web App (/exec) gắn vào app!
 */

const DB_FOLDER_NAME = 'UniLingua_Server_DB';
const USERS_FOLDER_NAME = 'users';
const DASHBOARD_SHEET_NAME = 'UniLingua_Users_Dashboard';
const APP_SHARED_SECRET = 'UL_DB_2026_SECURE_KEY_9981';

function getOrCreateRootFolder_() {
  const it = DriveApp.getFoldersByName(DB_FOLDER_NAME);
  if (it.hasNext()) return it.next();
  return DriveApp.createFolder(DB_FOLDER_NAME);
}

function getOrCreateUsersFolder_(rootFolder) {
  const it = rootFolder.getFoldersByName(USERS_FOLDER_NAME);
  if (it.hasNext()) return it.next();
  return rootFolder.createFolder(USERS_FOLDER_NAME);
}

function safeFileName_(email) {
  return String(email || 'guest')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9@._-]/g, '_') + '.json';
}

function updateUsersDashboard_(rootFolder, stateObj) {
  try {
    const user = stateObj.user || {};
    const email = String(user.email || '').trim().toLowerCase();
    if (!email) return;

    var ssFile;
    const files = rootFolder.getFilesByName(DASHBOARD_SHEET_NAME);
    if (files.hasNext()) {
      ssFile = SpreadsheetApp.open(files.next());
    } else {
      ssFile = SpreadsheetApp.create(DASHBOARD_SHEET_NAME);
      const createdFile = DriveApp.getFileById(ssFile.getId());
      rootFolder.addFile(createdFile);
      try {
        DriveApp.getRootFolder().removeFile(createdFile);
      } catch (e) {}
    }

    const sheet = ssFile.getSheets()[0];
    if (sheet.getLastRow() === 0) {
      sheet.appendRow([
        'Email',
        'Tên hiển thị',
        'Trình độ',
        'Nghe (%)',
        'Nói (%)',
        'Đọc (%)',
        'Viết (%)',
        'Streak (ngày)',
        'Tổng XP',
        'Số tuần lộ trình',
        'Cập nhật gần nhất',
      ]);
    }

    const placement = stateObj.placementResult || {};
    const rowData = [
      email,
      user.displayName || '',
      placement.cefrLevel || 'Chưa test',
      stateObj.listeningSkillScore || 0,
      stateObj.speakingSkillScore || 0,
      stateObj.readingSkillScore || 0,
      stateObj.writingSkillScore || 0,
      stateObj.streakDays || 1,
      stateObj.totalXp || 0,
      user.targetWeeks || 8,
      new Date().toISOString(),
    ];

    const lastRow = sheet.getLastRow();
    if (lastRow >= 2) {
      const emails = sheet.getRange(2, 1, lastRow - 1, 1).getValues();
      for (var i = 0; i < emails.length; i++) {
        if (String(emails[i][0]).trim().toLowerCase() === email) {
          sheet.getRange(i + 2, 1, 1, rowData.length).setValues([rowData]);
          return;
        }
      }
    }
    sheet.appendRow(rowData);
  } catch (err) {
    // Non-blocking dashboard update
  }
}

function jsonOut_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(
    ContentService.MimeType.JSON
  );
}

function doGet(e) {
  return jsonOut_({
    ok: true,
    service: 'UniLingua Central Google Drive Database',
    status: 'online',
  });
}

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents || '{}');
    if (body.secret !== APP_SHARED_SECRET) {
      return jsonOut_({ ok: false, error: 'Unauthorized' });
    }

    const action = String(body.action || '');
    const email = String(body.email || '').trim().toLowerCase();
    if (!email) {
      return jsonOut_({ ok: false, error: 'Missing email' });
    }

    const rootFolder = getOrCreateRootFolder_();
    const usersFolder = getOrCreateUsersFolder_(rootFolder);
    const fileName = safeFileName_(email);

    if (action === 'load') {
      const files = usersFolder.getFilesByName(fileName);
      if (!files.hasNext()) {
        return jsonOut_({ ok: true, found: false, data: null });
      }
      const content = files.next().getBlob().getDataAsString('UTF-8');
      return jsonOut_({
        ok: true,
        found: true,
        data: JSON.parse(content),
      });
    }

    if (action === 'save') {
      const stateObj = body.data;
      if (!stateObj) {
        return jsonOut_({ ok: false, error: 'Missing data payload' });
      }
      const serialized = JSON.stringify(stateObj);
      const files = usersFolder.getFilesByName(fileName);
      if (files.hasNext()) {
        files.next().setContent(serialized);
      } else {
        usersFolder.createFile(fileName, serialized, MimeType.PLAIN_TEXT);
      }
      updateUsersDashboard_(rootFolder, stateObj);
      return jsonOut_({ ok: true, saved: true });
    }

    return jsonOut_({ ok: false, error: 'Unknown action' });
  } catch (err) {
    return jsonOut_({ ok: false, error: String(err) });
  }
}
