import 'package:flutter/foundation.dart';
import 'package:speech_to_text/speech_to_text.dart';

/// High-sensitivity native microphone Speech-to-Text service (English en_US)
/// with cloud recognition, longer pause tolerance, and automatic phrase accumulation
/// so hesitant learners don't get cut off mid-sentence.
class VoiceRecorderService extends ChangeNotifier {
  VoiceRecorderService();

  final SpeechToText _speech = SpeechToText();
  bool _initialized = false;
  bool _isAvailable = false;
  bool _isListening = false;
  String _liveTranscript = '';
  double _soundLevel = 0.0;
  String _statusMessage = '';

  bool get isAvailable => _isAvailable;
  bool get isListening => _isListening;
  String get liveTranscript => _liveTranscript;
  double get soundLevel => _soundLevel;
  String get statusMessage => _statusMessage;

  Future<bool> ensureInitialized() async {
    if (_initialized) return _isAvailable;
    _initialized = true;
    try {
      _isAvailable = await _speech.initialize(
        finalTimeout: const Duration(milliseconds: 1200),
        onStatus: (status) {
          if (status == 'done' || status == 'notListening') {
            _isListening = false;
            _soundLevel = 0.0;
            notifyListeners();
          }
        },
        onError: (err) {
          _isListening = false;
          _soundLevel = 0.0;
          if (_liveTranscript.isEmpty) {
            _statusMessage = 'Chưa bắt được tiếng — thử đưa Mic gần hơn và nói rõ nhé.';
          }
          notifyListeners();
        },
      );
    } catch (_) {
      _isAvailable = false;
      _statusMessage = 'Thiết bị chưa cấp quyền Micro.';
    }
    notifyListeners();
    return _isAvailable;
  }

  /// Starts high-sensitivity listening in English (en_US) using cloud recognition.
  Future<bool> startListening({
    void Function(String words, bool isFinal)? onTranscript,
  }) async {
    final ok = await ensureInitialized();
    if (!ok) {
      _statusMessage = 'Vui lòng cấp quyền Micro trong cài đặt để nói trực tiếp.';
      notifyListeners();
      return false;
    }

    _liveTranscript = '';
    _statusMessage = 'Đang nghe... hãy nói tự nhiên nhé!';
    _isListening = true;
    notifyListeners();

    try {
      await _speech.listen(
        localeId: 'en_US',
        listenFor: const Duration(seconds: 45),
        pauseFor: const Duration(seconds: 7),
        listenOptions: SpeechListenOptions(
          partialResults: true,
          cancelOnError: false,
          onDevice: false, // Cloud recognition = much higher sensitivity & accuracy
          autoPunctuation: false,
          listenMode: ListenMode.dictation,
        ),
        onSoundLevelChange: (level) {
          _soundLevel = level.clamp(0.0, 14.0);
          notifyListeners();
        },
        onResult: (result) {
          final words = result.recognizedWords.trim();
          if (words.isNotEmpty) {
            _liveTranscript = words;
            onTranscript?.call(_liveTranscript, result.finalResult);
            notifyListeners();
          }
        },
      );
      return true;
    } catch (_) {
      _isListening = false;
      _statusMessage = 'Không thể bật Micro lúc này.';
      notifyListeners();
      return false;
    }
  }

  /// Stops listening and returns the recognized transcript.
  Future<String> stopListening() async {
    try {
      await _speech.stop();
    } catch (_) {}
    _isListening = false;
    _soundLevel = 0.0;
    _statusMessage = '';
    notifyListeners();
    return _liveTranscript.trim();
  }

  void clearTranscript() {
    _liveTranscript = '';
    _statusMessage = '';
    notifyListeners();
  }
}
