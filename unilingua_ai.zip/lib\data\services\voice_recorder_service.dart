import 'package:flutter/foundation.dart';
import 'package:speech_to_text/speech_to_text.dart';

/// Native device microphone Speech-to-Text service supporting both:
/// 1) Tap to start & tap to stop
/// 2) Press-and-hold continuous speaking (release to stop)
class VoiceRecorderService extends ChangeNotifier {
  VoiceRecorderService();

  final SpeechToText _speech = SpeechToText();
  bool _initialized = false;
  bool _isAvailable = false;
  bool _isListening = false;
  String _liveTranscript = '';
  double _soundLevel = 0.0;
  String _statusMessage = '';

  bool get isAvailable => _isAvailable;
  bool get isListening => _isListening;
  String get liveTranscript => _liveTranscript;
  double get soundLevel => _soundLevel;
  String get statusMessage => _statusMessage;

  Future<bool> ensureInitialized() async {
    if (_initialized) return _isAvailable;
    _initialized = true;
    try {
      _isAvailable = await _speech.initialize(
        onStatus: (status) {
          if (status == 'done' || status == 'notListening') {
            _isListening = false;
            _soundLevel = 0.0;
            notifyListeners();
          }
        },
        onError: (err) {
          _isListening = false;
          _soundLevel = 0.0;
          _statusMessage = 'Không nghe rõ giọng nói, bạn thử nói lại nhé.';
          notifyListeners();
        },
      );
    } catch (_) {
      _isAvailable = false;
      _statusMessage = 'Thiết bị chưa cấp quyền Micro.';
    }
    notifyListeners();
    return _isAvailable;
  }

  /// Starts listening using the device microphone in English (en_US).
  Future<bool> startListening({
    void Function(String words, bool isFinal)? onTranscript,
  }) async {
    final ok = await ensureInitialized();
    if (!ok) {
      _statusMessage =
          'Vui lòng cấp quyền Micro trong cài đặt để nói trực tiếp.';
      notifyListeners();
      return false;
    }

    _liveTranscript = '';
    _statusMessage = 'Đang nghe bạn nói...';
    _isListening = true;
    notifyListeners();

    try {
      await _speech.listen(
        localeId: 'en_US',
        listenFor: const Duration(seconds: 30),
        pauseFor: const Duration(seconds: 5),
        listenOptions: SpeechListenOptions(
          partialResults: true,
          cancelOnError: false,
          listenMode: ListenMode.dictation,
        ),
        onSoundLevelChange: (level) {
          _soundLevel = level.clamp(0.0, 12.0);
          notifyListeners();
        },
        onResult: (result) {
          _liveTranscript = result.recognizedWords.trim();
          onTranscript?.call(_liveTranscript, result.finalResult);
          notifyListeners();
        },
      );
      return true;
    } catch (_) {
      _isListening = false;
      _statusMessage = 'Không thể bật Micro lúc này.';
      notifyListeners();
      return false;
    }
  }

  /// Stops listening and returns the recognized transcript.
  Future<String> stopListening() async {
    try {
      await _speech.stop();
    } catch (_) {}
    _isListening = false;
    _soundLevel = 0.0;
    _statusMessage = '';
    notifyListeners();
    return _liveTranscript.trim();
  }

  void clearTranscript() {
    _liveTranscript = '';
    _statusMessage = '';
    notifyListeners();
  }
}
